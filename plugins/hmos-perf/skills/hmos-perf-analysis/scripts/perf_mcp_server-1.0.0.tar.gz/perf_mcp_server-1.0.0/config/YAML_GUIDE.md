# YAML 开发指导

> 本文档面向负责把"占位 SQL"重写为"真实可运行 HiTrace SQL"的 Agent。
> 阅读完本文，你应当能在不破坏校验、不破坏测试、不破坏运行时合约的前提下，
> 按声明式风格新增/修改任意一条指标 (atomic / group) 或 Skill。

---

## 0. 目录与文件组织

```
config/
├── indicators/                         # 60+ 原子指标与若干组合指标
│   ├── cpu/        freq.yaml load.yaml topology.yaml  # 包含 SMT ST/MT 统计
│   ├── gpu/        render.yaml composition.yaml
│   ├── sched/      latency.yaml runtime.yaml load_balance.yaml
│   ├── uninterruptible/ uninterruptible_dstate.yaml    # D-IO / D-NIO / D / D|W 耗时分析
│   ├── thermal/    temp.yaml throttle.yaml
│   ├── memory/     pressure.yaml alloc.yaml swap.yaml
│   ├── network/    throughput.yaml queue.yaml
│   ├── power/      rail.yaml wakeup.yaml
│   ├── frame/      frame_summary.yaml frame_ts.yaml
│   ├── pmu/        pmu_summary.yaml pmu_timeline.yaml  # IPC/MPKI/SMT 统计
│   ├── marker/     trace_duration.yaml trace_timeline.yaml callstack.yaml
│   ├── startup/    phases.yaml launch.yaml             # 启动阶段分析
│   └── groups/     jank.yaml launch_essentials.yaml ... # 组合指标
├── skills/                             # 工作流声明
│   ├── frame_drop.yaml ad_hoc_exploration.yaml ...
└── YAML_GUIDE.md                       # 本文
```

**铁律：**
- 一个 atomic / group 指标只能在 **一个** YAML 文件中声明（重复定义会被
  `core/validators.py` 拒绝，CI 直接红）。
- 文件名按"category/<topic>.yaml"组织；同一 category 的多条原子可共用一个文件。
- 校验入口：`python scripts/validate_yaml.py config/`，提交前必须本地跑一次。

---

## 1. 顶层结构（atomic）

```yaml
indicators:
  - name: cpu_freq                       # 必填，必须是合法 Python 标识符（[a-zA-Z_][a-zA-Z0-9_]*）
    type: atomic                         # 必填，atomic / group
    display_name: CPU 频率                # 必填，对人类与 LLM 展示用
    category: cpu                        # 必填，与目录名保持一致
    description: |                       # 必填，告诉 LLM 这个指标"问什么时候该用"
      多行说明……
    unit: MHz                            # 必填；标量混合写 mixed
    default_granularity: raw             # raw / 1ms / 10ms / 100ms / auto
    sql: |                               # 必填，见 §2
      SELECT ...
    sql_params: [ ... ]                  # 必填（见 §3），SQL 中所有 :xxx 占位符必须在此声明
    result_schema: { ... }               # 必填（见 §4）
    preprocess: null                     # 可选，见 §6
    template_vars: { bucket_ms: 10 }     # 可选，配置级常量（直接做字符串替换，不走绑定）
    related: [temperature]               # 可选，提示 LLM "可一起查的指标"
```

> **不要**新增本文未列出的字段——它们只会被 `IndicatorMeta` 默默丢弃。
> 如确需新增，先在 `core/registry.py::IndicatorMeta` 加字段、改 `_parse_indicator`，
> 再写测试，最后才回到 YAML。

---

## 2. SQL 编写规范

### 2.1 命名参数（强制）

**永远** 用 SQLite 命名绑定 `:xxx`，**永远不要** 字符串拼接用户输入：

```yaml
# ✓ 正确：参数走绑定，SQL 注入由 sqlite3 防住
sql: |
  SELECT ts_ms AS ts, freq_mhz AS value
  FROM cpu_freq_raw
  WHERE ts_ms BETWEEN :start_ms AND :end_ms
    AND (:cluster IS NULL OR cluster = :cluster)
  ORDER BY ts
```

```yaml
# ✗ 错误：字符串拼接 cluster_name → 绕过绑定，CI 拦截
sql: |
  SELECT * FROM cpu_freq_raw WHERE cluster = '{{cluster_name}}'
```

### 2.2 占位符与 sql_params 必须 1:1 对齐

加载时 `core/registry.py::_validate_sql_params_coverage` 会用正则
`re.findall(r":(\w+)", sql)` 抽出 SQL 中的所有 `:xxx`，并要求它们要么
出现在 `sql_params` 的 `name` 中，要么在 `template_vars` 的 key 中。
任何一个找不到 → 启动报错。

> 实战提示：写完 SQL 立刻把 `:` 后面的标识符抄到 `sql_params` 里，
> 再决定 type / required / default / enum，避免漏写。

### 2.3 时序指标的列名约定

QueryEngine 通过 `result_schema.items.properties` 中是否含 `ts` 或
`timestamp_ms` 来判断时序，**进而决定大数据采样策略**（时序 → 分桶聚合，
非时序 → Top N 截断）。所以：

- 时序指标 SELECT 时把时间列别名为 `ts`（更短）或 `timestamp_ms`
- 数值列别名为 `value`（采样器读 `r["value"]` 计算 avg/max/min）
- 把过滤维度（`cluster`、`tid`、`zone_name` 等）作为额外列直传

```sql
SELECT
  CAST(ts_ns / 1000000 AS INT) AS ts,    -- 时间列：必须叫 ts 或 timestamp_ms
  cluster,                               -- 维度列：保留即可
  freq_mhz AS value                      -- 数值列：必须叫 value，分桶聚合按它算
FROM cpu_freq_raw
WHERE ts_ns BETWEEN :start_ms * 1e6 AND :end_ms * 1e6
  AND (:cluster IS NULL OR cluster = :cluster)
ORDER BY ts
```

### 2.4 非时序指标（Top N、聚合标量）

非时序情形下：
- 让 SQL 自己 `ORDER BY metric DESC LIMIT :limit` 完成排序与截断
- `result_schema.type` 写 `array` 或 `object`（后者表示标量结果）
- 不要在 SQL 里手写 `LIMIT 500`，应该绑定 `:limit`，让 group / agent 能覆写

```sql
SELECT tid, tname, runtime_ms AS value, wait_time_ms
FROM thread_runtime
WHERE ts_ms BETWEEN :start_ms AND :end_ms
ORDER BY runtime_ms DESC
LIMIT :limit
```

### 2.5 标量对象（`result_schema.type=object`）

如果 SQL 永远只返回一行（比如 `SELECT COUNT(*)... AVG(...)...`），
`type` 应写 `object`，QueryEngine 会自动把首行展开为字典并强制
`truncated=false`：

```yaml
sql: |
  SELECT
    COUNT(*) AS total_frames,
    AVG(frame_time_ms) AS avg_frame_time
  FROM frames WHERE ts BETWEEN :start_ms AND :end_ms
result_schema:
  type: object
  properties:
    total_frames: { type: integer, unit: count }
    avg_frame_time: { type: number, unit: ms }
```

### 2.6 不要写副作用 SQL

- 严禁 `UPDATE` / `DELETE` / `INSERT` / `CREATE` / `DROP` / `ATTACH`，
  本系统全程只用 `SELECT`；CI 暂未自动拦截，但 PR 会被人 review 退回。
- 不要写多语句（一条 SQL 一个 `;`，结尾不要分号）。

---

## 3. sql_params 声明

每个 `sql_params` 项的字段对应 `core/registry.py::SQLParam` 数据类：

```yaml
sql_params:
  - name: start_ms
    type: number               # number / integer / string / boolean
    required: true
    description: 开始时间戳(ms)，必须来自上一步 analyze_frame_drops
  - name: cluster
    type: string
    required: false
    default: null              # 可省略；显式 null 表示"无值"
    enum: [big, mid, little]   # 可选；写了之后非法值会被 Spy Server 标 WARN
    description: 集群名；不填返回全部集群
```

### 3.1 五层参数合并优先级

```
sql_params.default           (最低)
  ↓ 被 group.expands_to.override_params 覆盖
group_overrides
  ↓ 被 agent indicator_params 覆盖
agent_params
  ↓ 被 base_params 强制注入（start_ms / end_ms 等）
base_params
  ↓ 被 template_vars 字面替换（配置级常量）
template_vars                (最高，仅占位符替换不走绑定)
```

**含义：**
- `default` 是兜底；只要 group 或 agent 传了同名字段，default 就被覆盖。
- `start_ms` / `end_ms` 总以 `base_params` 为准，`default` 再写也是没用的——
  保留它们只是为了占位让 `:start_ms` 在 SQL 里能解析。

### 3.2 `required: true` vs 给个 `default`

- 如果指标"没这个字段就完全跑不动"（如时间窗），`required: true`，无 default。
- 如果"绝大多数情况下用默认值就行"（如 limit、top_n），写 `required: false` 与
  合理的 default。
- enum 字段如果用户经常不传，建议 `default: null`，并在 SQL 里写
  `(:cluster IS NULL OR cluster = :cluster)` 形式做条件穿透。

### 3.3 enum 与类型一致性

- enum 列表的元素类型必须与 `type` 匹配：`type: integer` 时 enum 不能写
  `["L1", "L2"]`。
- 当用户传入非 enum 值，目前 Spy Server 会发 WARN，未来会升级为强校验。

---

## 4. result_schema

只允许三种 `type`：

| type | 含义 | 大数据采样 | 例子 |
|------|------|-----------|------|
| `array` | 行数组（最常见） | 时序分桶 / Top N | cpu_freq, thread_runtime |
| `object` | 单行展开的标量字典 | **永不截断** | frame_summary |
| `scalar` | 单个数字（保留字段，目前等价于 object） | 永不截断 | （未启用） |

### 4.1 array

```yaml
result_schema:
  type: array
  items:
    type: object
    properties:
      ts:                                # 时序锚点；触发分桶的关键字段
        type: integer
        description: 时间戳(ms)
      cluster:
        type: string
      value:
        type: integer
        unit: MHz                        # 单位写在叶子节点，便于 LLM 理解
```

### 4.2 object（标量摘要）

```yaml
result_schema:
  type: object
  properties:
    total_frames:
      type: integer
      unit: count
    p95_frame_time:
      type: number
      unit: ms
```

### 4.3 嵌套 object（preprocess pipeline 输出）

复杂多阶段处理后的输出常常是嵌套结构，schema 也要写全：

```yaml
result_schema:
  type: object
  properties:
    meta:
      type: object
      properties: { type: { type: string }, total_launch_ms: { type: number } }
    phases:
      type: array
      items: { ... }
    bottleneck:
      type: object
      properties: { phase: { type: string }, duration_ms: { type: number } }
```

> result_schema 不仅给 LLM 看，也给 query_metrics 的调用方（前端、CI）做契约
> 校验。务必写完整。

### 4.4 summary 字段设计规范（通用模板）

使用 preprocess pipeline 的 atomic 指标，输出结构为 `{ summary, data }`。
summary 让 Agent 用极少 Token 掌握指标全貌，再决定是否深入 data。

**summary 的职责（每个指标都必须填）：**

| 字段类型 | 用途 | 示例 |
|----------|------|------|
| 核心聚合量 | 全局 avg/max/min/total | `avg_load`, `max_freq`, `total_count` |
| top N 维度 | 贡献最大的维度 | `top_cluster: "big"`, `hotspots: [{cpu: 0, avg: 97.2}]` |
| filter_context | 回显本次查询的过滤条件 | `tid: 33461`, `cluster: "mid"` |
| 指标特有结论 | 明确的业务结论 | `compute_supply: "83.1%"`, `bottleneck_phase: "surfaceflinger"` |

**通用模板：**
```yaml
result_schema:
  type: object
  properties:
    summary:
      type: object
      properties:
        # 核心聚合量
        avg_value:    { type: number,  description: "全局平均值" }
        max_value:    { type: number,  description: "全局最大值" }
        min_value:    { type: number,  description: "全局最小值" }
        total_count:  { type: integer, description: "事件/样本总数" }
        duration_ms:  { type: number,  description: "分析窗口时长(ms)" }

        # top N 维度
        top_cluster:  { type: string,  description: "贡献最大的集群" }
        top_cpu:      { type: integer, description: "负载最高的 CPU 核" }

        # 过滤上下文
        filter_context:
          type: object
          properties:
            tid: { type: integer, description: "线程 ID（未过滤则为 null）" }
            pid: { type: integer, description: "进程 ID（未过滤则为 null）" }

    data:
      type: array
      items: { ... }
```

> **注意：** 具体指标应在 yaml 的 `description` 中描述该指标特有的 summary 字段
>（如 cpu_freq 的 `cluster_stats`、`compute_supply`），结构模板通用。

---

## 5. group 指标（组合指标）

```yaml
indicators:
  - name: jank_essentials
    type: group
    display_name: 丢帧分析核心指标包
    category: analysis
    description: ...
    expands_to:
      - cpu_load                         # 形式 1：直接引用名字
      - name: cpu_freq                   # 形式 2：引用 + override_params
        override_params:
          cluster: null
      - name: thread_runtime
        override_params:
          limit: 50
      - frame_summary
      - jank_extra_subgroup              # 形式 3：嵌套引用别的 group
    reasoning_hints:
      - "cpu_freq 骤降 + temperature 高 → thermal 限频导致丢帧"
```

**约束：**
- group 不允许直接 `sql` 字段；它只是把 N 个原子指标打包。
- `expands_to` 不能循环引用（A→B→A 会被启动期 DFS 拦截抛异常）。
- `override_params` 优先级低于 `agent_params`：用户如果显式传 `cluster=big`，
  group 强制写的 `cluster: null` 不生效。
- group 的展开顺序保持 YAML 写法顺序，且做去重。

---

## 6. preprocess（重要）

### 6.1 何时启用

- ✅ 单 SQL 拿不到 LLM 友好结果，需要内存里再处理（火焰图、启动阶段拆解）。
- ✅ 数据量太大，必须先聚合再返回（火焰图同类合并）。
- ✅ 需要跨表 JOIN 或扫描线算法（如 SMT ST/MT 时长计算需要 running + freq 联合分析）。
- ❌ 简单时序数组（cpu_freq 旧版、temperature）：直接 `preprocess: null` 就好；
  采样由 QueryEngine 自动处理。

**现代 cpu_freq 架构示例**（SMT 统计）：

```yaml
# cpu_freq.yaml
indicators:
  - name: cpu_freq
    sql: |
      -- Running 区间（用于 SMT 计算）
      SELECT cpu AS cpuid, ts AS ts_start, ts + dur AS ts_end,
             0 AS freq, 'running' AS data_type, tid, pid
      FROM thread_state
      WHERE ts >= :start_ms * 1000000 AND ts < :end_ms * 1000000
        AND state = 'Running' AND cpu IS NOT NULL
      UNION ALL
      -- 频点区间
      SELECT cmf.cpu AS cpuid, m.ts AS ts_start,
             COALESCE(m.ts + m.dur, tb.end_ts) AS ts_end,
             m.value / 1000 AS freq, 'freq' AS data_type, NULL, NULL
      FROM measure m
      JOIN cpu_measure_filter cmf ON m.filter_id = cmf.id
      CROSS JOIN (SELECT MAX(ts) as end_ts FROM thread_state) tb
      WHERE cmf.name = 'cpu_frequency'
        AND m.ts >= :start_ms * 1000000 AND m.ts < :end_ms * 1000000

    preprocess:
      pipeline:
        - op: smt_residency
          params:
            cluster: :cluster
            tid: :tid
            pid: :pid

    result_schema:
      type: object
      properties:
        summary:
          type: object
          properties:
            cluster_stats: { type: object }
        data:
          type: array
          items:
            properties:
              cpuid: { type: integer }
              freq: { type: integer }
              mt_duration_ms: { type: number }
              st_duration_ms: { type: number }
```

### 6.2 两种声明形态

**形态 A：单引擎（向后兼容）**

```yaml
preprocess:
  engine: flamegraph_collapse            # 内置引擎名
  params:
    top_n_paths: :top_n                  # `:xxx` 引用同名 sql_params
    noise_threshold_ms: :noise_threshold_ms
```

适用场景：固定的端到端流程，不需要拆步。当前内置引擎：
- `flamegraph_collapse` — 函数堆栈四层折叠

**形态 B：多阶段 pipeline（推荐用于复杂场景）**

```yaml
preprocess:
  pipeline:
    - op: pair_lifecycle_events          # 算子名，core/preprocess/__init__.py 注册
      params:
        pid_field: pid
        event_field: event_name
    - op: compute_phase_durations
    - op: identify_bottleneck_phase
      params:
        threshold_ms: :bottleneck_threshold_ms   # 引用 sql_params 自动解析
        only_significant: :only_significant
    - op: detect_cold_or_warm
    - op: format_phase_summary
```

适用场景：步骤可拆、可裁剪、可单测、可被多个指标复用。

### 6.3 实现新算子的步骤

1. 在 `core/preprocess/<topic>_ops.py` 写函数：
   ```python
   from .base import PreprocessContext, register_operator
   @register_operator("my_new_op")
   def my_new_op(ctx: PreprocessContext) -> PreprocessContext:
       df = ctx.data
       threshold = float(ctx.params.get("threshold_ms", 5.0))
       # ... 业务逻辑 ...
       ctx.data = result_df
       ctx.meta["my_stat"] = some_value
       return ctx
   ```
2. 在 `core/preprocess/__init__.py` 顶部追加 `from . import my_topic_ops` 让算子被注册。
3. 在指标 YAML 中引用：`- op: my_new_op`。
4. 给新算子写单测（参考 `tests/test_preprocess_pipeline.py`）。

### 6.4 算子契约

- `run(ctx) -> ctx`：必须返回更新后的 ctx（同一个 ctx 引用即可）。
- 把"中间数据"放 `ctx.data`，把"统计/标注"放 `ctx.meta`。
- 最后一步必须把 `ctx.data` 收敛为最终 dict（含 `meta` / 业务字段）。
- 任何业务异常 raise `PreprocessError`，会被 QueryEngine 接到并写入 `errors`。
- 不要在算子里读外部全局状态（除 `ctx.sqlite_conn` / `ctx.indicator_meta`）。

### 6.5 已注册算子

| 模块 | 算子 | 作用 |
|------|------|------|
| flamegraph | normalize_and_collapse | 同类函数归一化合并（Layer 0） |
| flamegraph | prune_by_self_time | self_time 阈值剪枝（Layer 1） |
| flamegraph | collapse_system_libs | 系统库折叠（Layer 2） |
| flamegraph | extract_hot_paths | Top N 热点路径（Layer 3） |
| flamegraph | detect_recursion | 直接 / 间接递归检测 |
| flamegraph | rank_bottleneck_functions | self_time Top N 瓶颈函数 |
| flamegraph | finalize_flamegraph | 收敛为最终 dict |
| launch | pair_lifecycle_events | 配对生命周期事件 → 时间线 |
| launch | compute_phase_durations | 计算各启动阶段耗时 |
| launch | identify_bottleneck_phase | 识别耗时瓶颈阶段 |
| launch | detect_cold_or_warm | 冷启动 / 热启动判定 |
| launch | format_phase_summary | 收敛输出 |
| smt | smt_residency | 扫描线算法计算 ST/MT 时长，按 cpuid/freq 聚合 |
| pmu | compute_pmc_stats | 计算 IPC、MPKI 等 PMU 统计 |
| marker | aggregate_by_function_tag | 按 function_tag 聚合 |
| marker | format_hotpath_summary | 热点路径格式化 |
| uninterruptible | compute_uninterruptible_duration | 计算 D-IO / D-NIO / D / D|W 耗时，关联 BlockReason caller |
| uninterruptible | format_uninterruptible_summary | 收敛为 summary + data 输出 |

> 启动新增算子前，先 `python -c "from core.preprocess import OPERATORS; print(sorted(OPERATORS))"`
> 看一眼现有列表，避免重名（重名会启动期抛异常）。

### 6.6 算子代码完整模板

每个算子都是一个 `(ctx) -> ctx` 的纯函数，文件放在 `core/preprocess/<topic>_ops.py`。
下面是一份带完整说明的样板：

```python
# core/preprocess/launch_ops.py
"""启动流程拆解算子。"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

import pandas as pd

from .base import (
    PreprocessContext,        # 数据 / 元数据 / 参数容器
    PreprocessError,          # 业务异常基类，QueryEngine 接到后写入 errors
    register_operator,        # 装饰器：登记算子供 pipeline 调用
)

log = logging.getLogger(__name__)


@register_operator("compute_phase_durations")
def compute_phase_durations(ctx: PreprocessContext) -> PreprocessContext:
    """对相邻生命周期事件求 phase 耗时。

    输入约定（来自上一步算子）:
        ctx.data: pd.DataFrame，列 = ['phase', 'start_ts_ns', 'end_ts_ns']

    本算子负责:
        - 计算 duration_ms（ns→ms）
        - 缺失 end_ts_ns 的行标记为 status='missing'
        - 把累计耗时写到 ctx.meta['total_duration_ms']

    Raises:
        PreprocessError: 上一步未给出必要列。
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame):
        raise PreprocessError("ctx.data 期望为 DataFrame")

    required = {"phase", "start_ts_ns", "end_ts_ns"}
    missing_cols = required - set(df.columns)
    if missing_cols:
        raise PreprocessError(f"缺少列: {sorted(missing_cols)}")

    df = df.copy()
    df["duration_ms"] = (df["end_ts_ns"] - df["start_ts_ns"]) / 1e6
    df["status"] = df["duration_ms"].apply(
        lambda x: "missing" if pd.isna(x) else "ok"
    )

    ctx.data = df
    ctx.meta["total_duration_ms"] = float(df["duration_ms"].sum(skipna=True))
    log.debug("compute_phase_durations: total=%.2fms rows=%d",
              ctx.meta["total_duration_ms"], len(df))
    return ctx
```

逐项检查表（全部必须满足）：

| 元素 | 含义 | 漏写后果 |
|------|------|----------|
| `@register_operator("name")` | 把函数注册到全局 OPERATORS dict | YAML 引用时 `pipeline 第 N 步引用了未注册的算子` |
| `ctx: PreprocessContext` 唯一入参 | pipeline 串接靠它 | run_pipeline 类型不匹配 |
| `return ctx` | 返回同一个 ctx | 下游算子拿到 None，链路炸 |
| `raise PreprocessError(...)` | QueryEngine 接到后写入 errors，不影响其他指标 | 抛 `Exception` 也会被 base.py 包成 PreprocessError，但语义不清 |
| `log.debug(...)` 而非 `print` | print 会污染 MCP stdout 的 JSON 协议 | MCP 客户端解析失败 |
| `ctx.data = df` | 写回供下游使用 | 下一算子拿到上一份的 data |
| `ctx.meta[k] = v` | 跨算子积累统计；最终算子收敛时塞输出 | bottleneck/total 之类找不到 |

### 6.7 PreprocessContext 字段速查

```python
@dataclass
class PreprocessContext:
    data: Any                     # 当前流转的数据（类型由上游决定）
    meta: Dict[str, Any]          # 跨算子的统计/标签累积区
    params: Dict[str, Any]        # 当前算子参数（YAML params: 解析后）
    sqlite_conn: Optional[Any]    # 原始 SQLite 连接，必要时可补充查表
    indicator_meta: Optional[Any] # 当前指标元信息（IndicatorMeta）
```

**何时该用 `ctx.sqlite_conn`：** 单 SQL 表达不下的场景。例如启动阶段拆完后还想取该 PID 的 binder 调用列表，可以在算子里：
```python
rows = ctx.sqlite_conn.execute(
    "SELECT * FROM binder_calls WHERE pid = ? AND ts_ns BETWEEN ? AND ?",
    (pid, start_ns, end_ns),
).fetchall()
```
一旦在算子里查表，docstring 必须写清"读了哪张表 / 大概多少行"，方便后续优化。

**何时该读 `ctx.indicator_meta`：** 算子要按 `default_granularity` / `unit` 自动决策聚合窗口或单位换算时使用。

**永远不要：** 读全局变量、写文件、改环境变量；算子必须是纯函数。

### 6.8 算子调试技巧

1. **不通过 pipeline，单独构造 ctx 跑一个算子：**
   ```python
   from core.preprocess import OPERATORS
   from core.preprocess.base import PreprocessContext
   import pandas as pd

   ctx = PreprocessContext(
       data=pd.DataFrame({
           "phase": ["AppOnCreate"],
           "start_ts_ns": [1_000_000_000],
           "end_ts_ns":   [1_500_000_000],
       }),
       params={"threshold_ms": 50},
   )
   out = OPERATORS["compute_phase_durations"](ctx)
   print(out.data, out.meta)
   ```

2. **定位 pipeline 中哪一步炸了：** 把 YAML 的 `pipeline:` 临时砍到出错前一步，让数据停在那里再 print；定位到具体算子后再恢复。

3. **打开 DEBUG 日志：**
   ```bash
   PYTHONLOGLEVEL=DEBUG python -m pytest tests/test_preprocess_pipeline.py -s -v
   ```
   pytest 默认吞 stdout，要加 `-s` 才能看到 `log.debug`。

4. **断点：** `python -m pdb -c continue scripts/run_local.py <args>`；或在算子里临时插 `breakpoint()`。

5. **算子热重载（REPL 调试）：** 改完代码后 `importlib.reload(core.preprocess.launch_ops)` 会因为 `@register_operator` 重名报错；调试时可以先 `from core.preprocess.base import OPERATORS; OPERATORS.pop("xxx", None)` 再 import。

---

## 7. Skill YAML（工作流声明）

`config/skills/*.yaml`：

```yaml
skill_id: frame_drop_analysis
name: 滑动卡顿根因分析
priority: high                            # high / low（low 用于 fallback）
description: ...
triggers: [滑动卡顿, 丢帧, 卡顿]            # 关键词触发；low priority Skill 用 fallback
input_params: [device_id, scenario]
steps:
  - step: 1
    tool: get_hitrace_path
    args: { device_id: ":device_id", scenario: ":scenario" }
    output: trace_path
  - step: 2
    tool: convert_hitrace_to_sqlite
    args: { trace_path: ":step1.trace_path" }
    output: { sqlite_path, trace_meta }
  - step: 3
    tool: analyze_frame_drops
    args: { sqlite_path: ":step2.sqlite_path" }
    output: drop_ranges
  - step: 4
    tool: query_metrics
    iterate: step3.drop_ranges            # 对每个区间执行一次
    args:
      indicators: [jank_essentials]
    default_indicator_params:
      cpu_freq: { cluster: big }          # 默认带的指标参数（会被 LLM 决策覆盖）
  - step: 5
    action: llm_reasoning                 # 不调 Tool，让 LLM 综合上一步结果
    instruction: |
      ……
rules:
  - "查到的指标必须落在 drop_ranges 内（参数血缘）"
  - "如果时间窗 > 30s，max_rows_per_indicator 可下调到 100"
```

**约束：**
- `priority: high` Skill 在 routing 阶段被关键词触发；`priority: low` 是 fallback。
- 同名 `skill_id` 不允许重复定义。
- step 中的 `:step1.foo` 表示引用上一步的输出；具体 Tool 实现已知输出字段。
- `iterate` 字段告诉编排引擎"对这个数组循环 N 次执行此 step"。

---

## 8. HiTrace SQL 取数注意事项

### 8.1 最常见的踩坑

1. **时间单位**：HiTrace 原始记录通常是纳秒（`ts_ns`），而 base_params 传入
   毫秒（`start_ms`）。SQL 里乘 1e6 换算，如 `ts >= :start_ms * 1000000`。
2. **PID/TID 命名**：`pid` / `tid`；HiSysEvent 可能叫 `process_id` / `thread_id`。
   改 SQL 时要对齐表字段名。
3. **事件常量**：进程生命周期事件名在不同 HOS 版本可能是
   `H:ProcessCreate` / `H:CrashStart` / `OSAL_PROCESS_CREATE` 等，
   做 `IN (...)` 匹配时务必核对版本。
4. **大表过滤**：`callstack`、`sched_switch`、`phase_task_delta` 几张表都可能
   是几百万行，**SQL 中第一句 WHERE 必须是时间窗过滤**，否则全表扫描会卡死。
5. **NULL 穿透**：可选维度的写法是 `(:zone_name IS NULL OR zone_name = :zone_name)`，
   不要写成 `zone_name = COALESCE(:zone_name, zone_name)`（部分 SQLite 版本性能差）。
6. **SMT 分析注意**：running 事件表需要全量扫描才能正确计算 MT/ST 时间，
   不要在 SQL 层按 tid/pid 预过滤（否则 scanline 丢失 sibling 状态）。

### 8.2 schema 探查方法

接到一份新的 trace.db，先做以下三件事再写 SQL：

```sql
-- 1. 列出所有表
SELECT name FROM sqlite_master WHERE type='table';

-- 2. 看表结构与索引
SELECT sql FROM sqlite_master WHERE name='cpu_freq';
PRAGMA index_list('cpu_freq');

-- 3. 估算行数 & 时间范围
SELECT COUNT(*), MIN(ts_ns), MAX(ts_ns) FROM cpu_freq;
```

把上述探查结果记在 PR 描述里，方便 review 人核对。

### 8.3 SQL 性能自查

写完每条 SQL 都要：
1. `EXPLAIN QUERY PLAN <SQL>` 确认走了索引（`SCAN` ≠ 必差，但 `SCAN` + 大表 = 危险）。
2. 在 1 万行 / 100 万行两种规模上各跑一次，观察耗时是否随时间窗线性增长。
3. 把 `:limit` 调到极小（如 10）跑一次，确认 `ORDER BY` + `LIMIT` 没退化为
   全表排序。

---

## 9. 真实 HiTrace 端到端验证流程

> 新增/修改指标后，按下面步骤顺次验证，全部通过才能提 PR。

### 9.1 准备 trace.db

```bash
# 1. 设备抓 trace
hdc shell "hitrace --buffer_size 32768 -t 10 sched freq disk gfx -o /data/local/tmp/trace.htrace"
hdc file recv /data/local/tmp/trace.htrace ./trace.htrace

# 2. 转 SQLite（具体工具按团队约定，假设用 trace2db）
trace2db trace.htrace -o trace.db
```

把 `trace.db` 放到 `tests/fixtures/<scenario>/trace.db`。**注意脱敏**：包名、用户 ID、token 等需替换为占位。

### 9.2 schema 探查

按 §8.2 的三件套先把表结构、索引、行数摸清，再动手写 SQL：

```bash
sqlite3 trace.db ".schema cpu_freq_raw"
sqlite3 trace.db "SELECT COUNT(*), MIN(ts_ns), MAX(ts_ns) FROM lifecycle_events"
```

把探查结果记到 PR 描述或 `tests/fixtures/<scenario>/README.md`。

### 9.3 单条指标手动跑

写一段一次性脚本（推荐每个团队共建一份 `scripts/run_local.py`）：

```python
# scripts/run_local.py
# 完整版本见 scripts/run_local.py

用法:
    python scripts/run_local.py <trace.db> <indicator> <start_ms> <end_ms> [indicator_params_json]

示例:
    python scripts/run_local.py trace.db cpu_freq 0 5000
    python scripts/run_local.py trace.db cpu_freq 0 5000 '{"cluster": "big"}'
    python scripts/run_local.py trace.db "cpu_freq,temperature" 0 5000
```

跑：

```bash
python scripts/run_local.py tests/fixtures/launch_cold_001/trace.db launch_phase_breakdown 1000 6000
python scripts/run_local.py tests/fixtures/launch_cold_001/trace.db launch_phase_breakdown 1000 6000 '{"bottleneck_threshold_ms": 50}'
```

### 9.4 四个验证维度（缺一不可）

| 维度 | 怎么查 | 期望 |
|------|--------|------|
| 格式合规 | 输出 JSON 与指标 `result_schema` 比对（手眼 + 若 `core/validators` 提供 `validate_indicator_output` 则直接调） | type 与字段全部一致 |
| 数值合理 | 跟 perfetto / HiTraceViewer 对比同一窗口的关键值 | 偏差 < 5% |
| 边界鲁棒 | 把窗口缩到没有事件的范围 | 返回空数组或 errors，**不能** raise |
| 性能 | 在 1M 行表上 `time` 一次 | < 2s（1M 行）/ < 200ms（1 万行） |

### 9.5 集成进 pytest

把 9.3 跑出来的 JSON 落盘成 `expected.json`，写一个 fixture-based 测试（详见 §10），后续回归交给 pytest，不再人肉。

---

## 10. 黄金样本：人工需要提供的输入/输出契约

> Agent 重写一个原子指标 / Skill 时，光看 YAML 和 schema 是猜不出"对了没"的——
> 必须由懂 HiTrace 的人先给一份"输入 → 期望输出"的黄金样本，Agent 才能闭环。

### 10.1 必要输入清单

| 必要程度 | 项 | 内容 | 文件位置建议 |
|--------|----|------|------------|
| 必须 | 真实 trace 切片 | 5–30s 真机 trace（脱敏后约 1–10 MB） | `tests/fixtures/<scenario>/trace.db` |
| 必须 | 输入参数 | start_ms / end_ms / indicator_params 完整 JSON | `tests/fixtures/<scenario>/input.json` |
| 必须 | 期望输出 | 关键字段（phase 名、bottleneck、阈值）的期望 dict | `tests/fixtures/<scenario>/expected.json` |
| 必须 | 容差 / 忽略键 | 哪些字段允许 ±X%、哪些字段直接忽略 | 写进 `expected.json` 的 `tolerance` 节 |
| 强烈建议 | 业务诠释 | "为什么这次启动算 cold？瓶颈为什么是 AppOnCreate→ActivityOnCreate？" | `tests/fixtures/<scenario>/README.md` |
| 可选 | 性能基线 | 单次跑耗时上限（如 < 500ms） | `expected.json` 的 `meta.latency_ms_max` |

### 10.2 input.json 模板

```json
{
  "trace_path": "trace.db",
  "indicators": ["launch_phase_breakdown"],
  "base_params": { "start_ms": 12345, "end_ms": 13800 },
  "indicator_params": {
    "launch_phase_breakdown": { "bottleneck_threshold_ms": 50 }
  }
}
```

### 10.3 expected.json 模板

```json
{
  "indicators": {
    "launch_phase_breakdown": {
      "type": "object",
      "data": {
        "meta": { "type": "cold", "total_launch_ms": 1455 },
        "phases": [
          { "phase": "ProcessCreate→AttachApplication",   "duration_ms": 230 },
          { "phase": "AttachApplication→AppOnCreate",     "duration_ms": 110 },
          { "phase": "AppOnCreate→ActivityOnCreate",      "duration_ms": 850 },
          { "phase": "ActivityOnCreate→ActivityOnStart",  "duration_ms": 145 },
          { "phase": "ActivityOnStart→ActivityOnResume",  "duration_ms":  80 },
          { "phase": "ActivityOnResume→FirstFrame",       "duration_ms":  40 }
        ],
        "bottleneck": {
          "phase": "AppOnCreate→ActivityOnCreate",
          "duration_ms": 850
        }
      }
    }
  },
  "errors": [],
  "tolerance": {
    "duration_ms_relative": 0.05,
    "ignore_keys": ["timestamp_collected", "trace_uuid"]
  },
  "meta": { "latency_ms_max": 500 }
}
```

### 10.4 fixture-based 测试代码（人写一次，所有 fixture 复用）

```python
# tests/test_fixture_indicators.py
from pathlib import Path
import json, time
import pytest

from core.registry import ConfigRegistry
from core.query_engine import QueryEngine

FIXTURE_ROOT = Path("tests/fixtures")
SCENARIOS = [p for p in FIXTURE_ROOT.iterdir()
             if (p / "input.json").exists() and (p / "expected.json").exists()]


@pytest.mark.parametrize("scn", SCENARIOS, ids=lambda p: p.name)
def test_indicator_fixture(scn):
    inp = json.loads((scn / "input.json").read_text(encoding="utf-8"))
    exp = json.loads((scn / "expected.json").read_text(encoding="utf-8"))

    reg = ConfigRegistry(Path("config"))
    engine = QueryEngine(reg)

    t0 = time.perf_counter()
    actual = engine.execute(
        sqlite_path=str(scn / inp["trace_path"]),
        indicator_names=inp["indicators"],
        base_params=inp["base_params"],
        agent_params=inp.get("indicator_params"),
    )
    elapsed_ms = (time.perf_counter() - t0) * 1000

    # 1. 关键字段对齐（递归比对，支持 tolerance / ignore_keys）
    assert_close(actual["indicators"], exp["indicators"], exp.get("tolerance", {}))
    # 2. 错误清单一致
    assert sorted(e["indicator"] for e in actual["errors"]) == \
           sorted(e["indicator"] for e in exp.get("errors", []))
    # 3. 性能（可选）
    if exp.get("meta", {}).get("latency_ms_max"):
        assert elapsed_ms < exp["meta"]["latency_ms_max"], \
            f"latency {elapsed_ms:.1f}ms 超过基线 {exp['meta']['latency_ms_max']}ms"
```

`assert_close` 由人编写一次后通用——递归比对 dict / list，遇到 number 字段允许 ±relative，遇到 ignore key 直接跳过：

```python
def assert_close(actual, expected, tol):
    rel = float(tol.get("duration_ms_relative", 0))
    ignore = set(tol.get("ignore_keys", []))

    def _close(a, e, path=""):
        if isinstance(e, dict):
            assert isinstance(a, dict), f"{path}: 类型不匹配"
            for k, v in e.items():
                if k in ignore:
                    continue
                assert k in a, f"{path}.{k} 缺失"
                _close(a[k], v, f"{path}.{k}")
        elif isinstance(e, list):
            assert isinstance(a, list) and len(a) == len(e), f"{path}: 长度不一致"
            for i, (ai, ei) in enumerate(zip(a, e)):
                _close(ai, ei, f"{path}[{i}]")
        elif isinstance(e, (int, float)) and not isinstance(e, bool):
            tol_val = abs(e) * rel
            assert abs(a - e) <= tol_val, f"{path}: {a} 与 {e} 偏差超过 ±{tol_val}"
        else:
            assert a == e, f"{path}: {a!r} != {e!r}"

    _close(actual, expected, "$")
```

### 10.5 哪些参数 / 阈值需要人来拍

下表所有项 **Agent 不应自己拍脑袋**——由 perf 老司机给出后，落到 YAML 的 `default` 或 `config/<topic>/README.md`：

| 类别 | 例子 | 备注 |
|------|------|------|
| 业务阈值 | `bottleneck_threshold_ms` 默认值 | 不同设备 / 场景标准不同 |
| 时间窗策略 | 一次启动从哪个事件到哪个事件叫"完整启动" | 决定 trace 切片边界 |
| 单位换算精度 | ts_ns → ms 是否允许浮点损失 | 决定 `CAST(... AS INT)` 还是 `/1e6 AS REAL` |
| 噪声过滤 | `self_time < X ms` 的栈帧合并 | 经验值 |
| Top N | 热路径数量、瓶颈函数数量 | LLM 阅读体验 vs 信息完整度 |
| 设备差异 | 大小核 cluster 命名（big/mid/little vs cpu0/cpu4/cpu7） | 不同 SoC 不同 |
| 错误恢复 | 缺关键事件时 phase 怎么显示 | `missing` vs `truncated` vs 跳过 |
| 事件常量 | "ProcessCreate" 在不同 HOS 版本的实际事件名 | 版本相关 |

**约定：** 上述决策一旦确定，写到对应 YAML 的 `description:` 或同级 README，并以 `## 决策记录` 为锚，方便后续追溯。

### 10.6 一份完整 fixture 的目录结构

```
tests/fixtures/launch_cold_com_example_app_001/
├── trace.db                  # 真实 hitrace 切片（脱敏，<10MB）
├── input.json                # 入参契约
├── expected.json             # 期望输出（含 tolerance）
└── README.md                 # 业务诠释 / 录制条件 / 设备型号
```

人工提供以上四个文件，Agent 重写 SQL/preprocess 后跑 `pytest tests/test_fixture_indicators.py -k launch_cold` 自动验证；**有黄金样本兜底，Agent 才能在没有人盯的情况下迭代到正确**。

---

## 11. 提交前自检清单

```bash
# 1. YAML 静态校验（必须 0 error）
python scripts/validate_yaml.py config/

# 2. SQL 占位符一致性（CI 单独 step）
python scripts/validate_yaml.py --check-placeholders config/

# 3. 跑全部 pytest
python -m pytest -q --tb=short

# 4. 如果改了 preprocess 算子，跑专项
python -m pytest tests/test_preprocess_pipeline.py -v

# 5. 如果改了火焰图，跑专项
python -m pytest tests/test_flamegraph_collapse.py -v
```

任意一项红，**禁止提交**。

---

## 12. 速查清单

| 我想做的事 | 该改哪 |
|----------|--------|
| 加一条简单时序原子指标 | `config/indicators/<cat>/*.yaml`，`preprocess: null` |
| 加一条标量摘要原子指标 | 同上，但 `result_schema.type: object` |
| 加一条需要多步处理的原子指标 | 上述 + `preprocess.pipeline:`，并在 `core/preprocess/` 写算子 |
| 加一个原子的可选过滤维度 | `sql_params` 加项 + SQL 加 `(:x IS NULL OR col=:x)` |
| 加一个组合指标 | `config/indicators/groups/*.yaml`，`type: group` |
| 给一个组合指标的某个原子改默认参数 | `expands_to` 里给该原子加 `override_params` |
| 加一个工作流（Skill） | `config/skills/*.yaml`，参考 `frame_drop.yaml` |
| 加一个新的预处理算子 | `core/preprocess/<topic>_ops.py` + `@register_operator` + 单测 |
| 加一个新的内置 preprocess 引擎 | `core/query_engine.py::_execute_with_preprocess` 中加分支 |

---

## 13. 我有问题怎么办

1. 先看 `docs/architecture.md`（架构设计，权威来源）。
2. 跑 `python scripts/validate_yaml.py --json config/` 看错误结构化输出。
3. 在 `tests/test_*.py` 中找最相似的用例当模板。
4. 还不行，开 Issue 时附上 YAML 片段 + 校验失败的 traceback。
