<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-06-11 | Updated: 2026-06-23 -->

# config/skills — Analysis Skill Workflow Definitions

## Purpose
Defines 8 declarative skill workflows that orchestrate multi-step performance analyses. Each skill is a sequence of tool invocations (steps) triggered by user query keywords. Skills compose indicator queries, preprocessing operators, and external tool calls into structured analysis pipelines. The SkillExecutor engine interprets these YAML definitions at runtime.

## Key Files

| File | Description |
|------|-------------|
| `frame_drop.yaml` | Frame drop / jank root cause analysis. Trigger: 丢帧, 卡顿, jank. Flows: trace→convert→chip→frame_drop→metrics→LLM. |
| `parallelization_opportunity.yaml` | 并行化机会点分析 Skill YAML 定义 |
| `sched_analysis.yaml` | Thread scheduling health: wakeup latency, CPU affinity, CGroup analysis. Trigger: 调度, 线程. |
| `launch_perf.yaml` | Cold/warm start performance analysis. Trigger: 启动慢, 冷启动, 首屏. |
| `ad_hoc_exploration.yaml` | General-purpose exploratory analysis. Fallback skill for unmatched queries. |
| `freq_distribution.yaml` | CPU/GPU frequency distribution analysis. |
| `load_compare.yaml` | Load comparison between traces/scenarios/devices. |
| `io_analysis.yaml` | IO bottleneck analysis. |
| `detect_rendering_pipeline.yaml` | Automatic rendering pipeline detection (ArkUI/Flutter/KMP/RN/Web). |
| `game_jank.yaml` | Game jank analysis skill YAML definition |

## For AI Agents

### Working In This Directory
- Each skill YAML must include: `id` (unique), `name`, `triggers` (keyword list for routing), `input_params`, `steps[]`, `rules` (with verify conditions).
- Step types: `tool` (call an MCP tool), `iterate` (loop over previous step output), `action: llm_reasoning` (pause for agent reasoning), `action: llm_decision` (ask agent for decision).
- `verify` conditions must be quantifiable: ✅ `jank_count > 0`, ❌ `数据合理`.
- YAML placeholders must match actual tool output paths: `step4.drop_ranges` not `step4.drop_analysis.drop_ranges`.
- `iterate` step outputs (with `tag`) are automatically lifted to `indicators` outer level by the framework.
- Do NOT manually assemble `default_indicator_params` — the framework injects them automatically.

### Testing Requirements
- New skills: test with `run_skill` through the MCP server, verify all steps execute correctly.
- Changed skills: verify the workflow still completes end-to-end.
- Integration tests in `tests/test_skill_integration.py`.

### Common Patterns
- Every skill follows: locate traces → convert to SQLite → identify chip → domain analysis → query metrics → LLM reasoning.
- Steps reference prior outputs via expressions: `step1.traces[0].trace_path`, `step2.sqlite_path`, `item.tid`.
- High-priority skills: `frame_drop`, `sched_analysis`, `launch_perf`, `freq_distribution`, `load_compare`.

## Dependencies

### Internal
- `core/skill_executor.py` — Runtime engine for skill execution
- `core/skill_router.py` — Routes to skills based on trigger keywords
- `server.py` — Exposes skill-related MCP tools (list_skills, get_skill, run_skill)

### External
- `pyyaml` — YAML parsing
