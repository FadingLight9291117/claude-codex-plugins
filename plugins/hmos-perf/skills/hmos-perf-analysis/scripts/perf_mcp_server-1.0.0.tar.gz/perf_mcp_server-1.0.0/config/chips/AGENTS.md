<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-06-11 -->

# config/chips — Chip Topology Database

## Purpose
JSON database of mobile chip configurations used by the `identify_chip_model` MCP tool. Each entry describes a chip's CPU topology: cluster layout (little/mid/big), CPU ID ranges, SMT configuration, frequency bounds, and relative compute scale. Currently contains 5 TESTVENDOR chip entries used in HarmonyOS devices.

## Key Files

| File | Description |
|------|-------------|
| `chip_database.json` | Chip configuration database. 5 entries: TESTCHIP_E (6 cores, 3 clusters), TESTCHIP_B (14 cores, SMT), TESTCHIP_B_12 (12 cores, SMT), TESTCHIP_C, TESTCHIP_A. ⚠️ Requires human confirmation before modification. |

## For AI Agents

### Working In This Directory
- ⚠️ **Do not modify `chip_database.json` without human confirmation.** Incorrect chip data leads to wrong SMT pairing, cluster identification, and frequency analysis.
- Each chip entry must include: `model` (chip model name), `vendor`, `clusters[]` with `cpuid_range`, `smt_enabled`, `smt_pairs`, `freq_min_mhz`, `freq_max_mhz`, `compute_scale`.
- Optional `gpu` segment: `{ "rated_max_mhz": <int|null> }` — GPU 额定最大频点(MHz);null 表示未知。用于 gpu_pipeline_analysis 的「GPU 频点低」分类判定。
- `smt_pairs` format: `[[core_a, core_b], ...]` for each SMT sibling pair.
- `compute_scale`: relative per-cluster compute coefficient, big normalized to 1.0 (e.g. mid 0.65, little 0.25 — example values).

### Testing Requirements
- After adding a chip entry, verify `identify_chip_model` correctly identifies it from a known trace.
- Verify SMT sibling lookup works: `get_sibling_cpuid(cpuid)` returns the correct pairing.

### Common Patterns
- Chip data is loaded by `core/preprocess/chip_config.py` as a lazy singleton.
- Results are cached by `(sqlite_path, mtime)` for performance.
- Used by scheduling, frequency, and SMT analysis workflows.

## Dependencies

### Internal
- `core/preprocess/chip_config.py` — Loads and queries chip data
- `core/chip_identify.py` — MCP tool facade

### External
- `json` (stdlib) — JSON parsing
