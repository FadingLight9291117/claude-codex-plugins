<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-06-11 -->

# config/indicators — Performance Indicator Definitions

## Purpose
Defines 80+ performance indicators as parameterized SQL queries against HiTrace/SQLite trace databases. Each indicator is a YAML file declaring its SQL query, parameters, result schema, and optional preprocessing pipeline. Indicators are organized into 17 category subdirectories mirroring performance analysis domains. This is the data layer consumed by query_metrics tool.

## Subdirectories

| Directory | Purpose |
|-----------|---------|
| `cpu/` | CPU frequency (freq.yaml) and load (load.yaml) metrics |
| `gpu/` | GPU rendering metrics: load, frequency (render.yaml) |
| `sched/` | Scheduler latency (latency.yaml), thread runtime (runtime.yaml), aggregated runtime (runtime_agg.yaml) |
| `rendering/` | Frame-level rendering: frame summary, frame timestamps (frame_summary.yaml, frame_ts.yaml) |
| `binder/` | Binder IPC latency (binder_latency.yaml) |
| `input/` | Input event latency (input_latency.yaml) |
| `io/` | IO block, latency, page cache, priority, size (5 files) |
| `memory/` | Memory pressure (pressure.yaml) |
| `network/` | Network throughput (throughput.yaml) |
| `power/` | Power rail analysis (rail.yaml) |
| `thermal/` | Thermal temperature, throttling (temp.yaml) |
| `marker/` | Trace marker/callstack analysis: callstack, trace duration, hotpath, timeline (4 files) |
| `sampling/hiperf/` | HiPerf sampling: hot functions, thread hotpaths (hot_function.yaml, thread_hotpath.yaml) |
| `sampling/pmu/` | PMU counters: IPC, MPKI, pipeline stats, summary, timeline (pipeline.yaml, pmu_summary.yaml, pmu_timeline.yaml) |
| `sleep/` | Thread sleep analysis (thread_sleep_summary.yaml) |
| `startup/` | App launch phases (phases.yaml) |
| `uninterruptible/` | D-state analysis (uninterruptible_dstate.yaml) |
| `groups/` | Composite indicator bundles: jank.yaml, launch.yaml, sched.yaml |

## For AI Agents

### Working In This Directory
- **Do NOT manually create indicator YAML files.** Use `python scripts/scaffold_indicator.py <category> <name>` to generate the proper package with README, ai_guide, indicator.yaml, base.py, and test file.
- Every indicator must have:
  - `name` — unique, valid Python identifier
  - `type` — `atomic` or `group`
  - `category` — matching the parent directory
  - For atomic: `sql` with named bind parameters, `sql_params` (1:1 with SQL placeholders), `result_schema`
  - For group: `expands_to` list of indicator names
- SQL convention: time-series use `ts`/`value` column aliases.
- Thresholds must be parameterized via `sql_params`, never hardcoded in SQL.
- Validate after any change: `python scripts/validate_yaml.py --check-placeholders config/`

### Testing Requirements
- New indicators: test via `python scripts/run_local.py <trace.db> <indicator_name> 0 10000` (manual) + fixture-based regression in `tests/`.
- Changed SQL: verify output matches `tests/fixtures/<scenario>/expected.json`.
- Run full regression: `pytest tests/ -v --tb=short`

### Common Patterns
- Indicator naming: `{domain}_{metric}` (e.g., `cpu_freq`, `binder_latency`, `frame_summary`).
- `sql_params` each have: `name`, `type`, `required`, `default` (optional), `enum` (optional).
- `preprocess.pipeline` or `preprocess.engine` for complex transformations.
- `result_schema.type`: `array` (time-series/list), `object` (single row), `scalar`.

## Dependencies

### Internal
- `core/registry.py` — Loads and validates indicators
- `core/query_engine.py` — Executes SQL from these definitions
- `core/preprocess/` — Preprocessing operators referenced in preprocess.pipeline

### External
- `sqlite3` — The database engine all SQL queries target
