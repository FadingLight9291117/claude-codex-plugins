<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-06-11 -->

# config/pipelines — Rendering Pipeline Detection Signatures

## Purpose
Defines rendering pipeline signatures for identifying which UI framework a trace comes from. Each YAML file describes a pipeline's characteristic threads, key trace slices, detection signals, and scoring rules. Consumed by `core/rendering_pipeline.py`'s 9-step detection workflow. Supports 5 rendering frameworks on HarmonyOS: ArkUI, Flutter, KMP, React Native (with 6 sub-variants), and Web.

## Key Files

| File | Description |
|------|-------------|
| `index.yaml` | Pipeline registry: maps pipeline IDs to skill files, organizes 14 pipelines into 5 families (harmony: 9, webview: 2, flutter: 1, game: 1, rs: 1) |
| `harmony_arkui_render.skill.yaml` | Native ArkUI declarative UI — ACE engine. VSyncGenerator→FlushMessages→MarshRSTransactionData pipeline. |
| `harmony_kmp_render.skill.yaml` | Kotlin Multiplatform — Recomposer→RenderView::onDraw pipeline. |
| `harmony_rn_render.skill.yaml` | React Native + 6 sub-variants (DX, Cube, Lynx, Taro, AJX, Weex). RNView/RNNode-based rendering. |
| `harmony_flutter.skill.yaml` | Flutter engine — GPU Rasterizer with SurfaceView/TextureView modes. Known traps: three-thread budget issue. |
| `harmony_web_pipeline.skill.yaml` | Web via VizCompositor — IssueBeginFrame→OnVSyncImpl pipeline. DidNotProduceFrame reason codes. |

## For AI Agents

### Working In This Directory
- Each pipeline YAML uses `type: pipeline_definition`, `category: rendering`.
- `meta.four_features` is the key differentiator: `producer_threads`, `consumer_threads`, `expected_layer_count`, `bufferqueue_path`.
- `meta.deviation_anchors`: Named stages with 4-12 step rendering stage descriptions.
- `meta.known_traps`: Common pitfalls and misidentification risks.
- `meta.subvariants_note`: Edge cases and variant handling.
- Detection signals use weighted scoring: required signals (must match) + scoring signals (contribute to rank).

### Testing Requirements
- Verify pipeline detection against known trace fixtures.
- New pipeline: add corresponding docs in `docs/rendering_pipelines/`.
- The index.yaml must be updated when adding/removing pipeline files.

### Common Patterns
- `pipeline_id` format: `HARMONY_{FRAMEWORK}` (or `HARMONY_{FRAMEWORK}_{VARIANT}`).
- `family`: One of `harmony`, `flutter`, `webview`, `game`, `rs`.
- Thread roles describe the rendering pipeline: producer threads (generate frames), consumer threads (composite/display).
- Referenced from `detect_rendering_pipeline` skill for automatic pipeline-aware analysis.

## Dependencies

### Internal
- `core/rendering_pipeline.py` — Detection engine consuming these definitions
- `core/rendering/models.py` — Python data models mirroring these YAML structures
- `docs/rendering_pipelines/` — Human-readable pipeline documentation

### External
- `pyyaml` — YAML parsing
