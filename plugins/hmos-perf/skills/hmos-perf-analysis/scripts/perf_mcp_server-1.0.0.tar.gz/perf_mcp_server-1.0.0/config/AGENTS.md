<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-06-11 -->

# config — Declarative Configuration

## Purpose
All declarative configuration for the perf-mcp-server. Contains performance indicator SQL definitions (80+ metrics across 15 categories), skill workflow definitions (7 analysis workflows), chip topology database, and rendering pipeline detection signatures (5 pipelines, 61 signals). All configuration is YAML/JSON — no imperative code. Hot-reload is supported via `PERF_MCP_HOT_RELOAD=1`.

## Key Files

| File | Description |
|------|-------------|
| `YAML_GUIDE.md` | Comprehensive developer guide (40 KB) for YAML config format: indicator structure, SQL conventions, sql_params rules, result_schema, preprocess pipelines, group composition, skill workflow spec, validation workflow. Read this first before editing any YAML. |

## Subdirectories

| Directory | Purpose |
|-----------|---------|
| `indicators/` | 80+ metric definitions in 17 category subdirectories (see `indicators/AGENTS.md`) |
| `skills/` | 7 declarative skill workflow definitions (see `skills/AGENTS.md`) |
| `pipelines/` | 5 rendering pipeline detection signatures + index (see `pipelines/AGENTS.md`) |
| `chips/` | Chip topology database (JSON) (see `chips/AGENTS.md`) |

## For AI Agents

### Working In This Directory
- **Always validate after changes**: `python scripts/validate_yaml.py --check-placeholders config/`
- SQL placeholders (`:xxx`) must exactly match `sql_params` entries.
- Indicator names must be valid Python identifiers.
- Time-series indicators must have `ts` + `value` columns in result_schema.
- Follow the conventions in `YAML_GUIDE.md` — it is authoritative.

### Testing Requirements
- Run `python scripts/validate_yaml.py --check-placeholders config/` after any YAML change.
- Run `pytest tests/ -v --tb=short` to verify indicator queries still work.
- For new indicators: create fixture-based tests in `tests/`.

### Common Patterns
- `type: atomic` — Single SQL query indicator.
- `type: group` — Expands to multiple atomic indicators via `expands_to`.
- SQL uses named bind parameters (`:start_ms`, `:end_ms`, `:cluster`) — never string concatenation.
- `preprocess.pipeline` — Optional preprocessing operator chain per indicator.

## Dependencies

### Internal
- `core/registry.py` — Loads and validates all config YAML
- `core/validators.py` — Validation logic for YAML config
- `core/query_engine.py` — Executes SQL from indicator definitions
- `scripts/validate_yaml.py` — CI validation entry point
- `scripts/scaffold_indicator.py` — Generates indicator packages

### External
- `pyyaml` — YAML parsing
