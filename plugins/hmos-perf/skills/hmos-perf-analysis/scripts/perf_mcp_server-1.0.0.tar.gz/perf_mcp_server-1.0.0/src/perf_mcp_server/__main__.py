#!/usr/bin/env python3
"""perf-mcp-server CLI 入口。"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def main() -> None:
    """启动 MCP Server (stdio 模式) — 默认入口。"""
    from server import main as _main

    _main()


def run_stdio() -> None:
    from server import main as _main

    _main()


async def run_sse() -> None:
    from server import mcp

    await mcp.run_sse_async()


async def run_streamable_http() -> None:
    from server import mcp

    await mcp.run_streamable_http_async()


if __name__ == "__main__":
    main()
