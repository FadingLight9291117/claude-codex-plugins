"""perf-mcp-server: 性能分析 MCP Server 与声明式 Skill 系统"""
