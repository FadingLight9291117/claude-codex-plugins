<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-06-11 -->

# utils -- Utility Modules

## Purpose
Shared utility modules used across the project. Contains process name mapping for translating HarmonyOS/Android package identifiers to human-readable Chinese display names, plus window name and dynamic case name resolution.

## Key Files

| File | Description |
|------|-------------|
| `process_name.py` | Process name resolution: maps package/window/case identifiers to Chinese labels (502 lines, 4 lookup functions). See details below. |

## Exports

| Function | Purpose |
|----------|---------|
| `get_process_name(pkg_name)` | Resolve a raw process name to Chinese label via `pkg_name_map` (139 entries) or `aosp_pkg_name_map` (160 entries). Strips digits before lookup. Falls back to last 15-char suffix match. |
| `get_window_name(window_name)` | Resolve a HarmonyOS window scene name to Chinese label via `window_name_nap` (66 entries). |
| `get_perf_dynamic_case_name(case_name)` | Resolve a perf dynamic test case name to Chinese label via `pkg_name_map`, `aosp_pkg_name_map`, or `perf_dynamic_case_app_name` (91 entries). |

## For AI Agents

### Working In This Directory
- Add new process name mappings to the appropriate dict when encountering new apps.
- `pkg_name_map` (139 entries): HarmonyOS short package suffix -> Chinese label. Use `[自研]` suffix for internally developed apps.
- `aosp_pkg_name_map` (160 entries): Android/AOSP short package suffix -> Chinese label.
- `window_name_nap` (66 entries): HarmonyOS window scene name prefix -> Chinese label.
- `perf_dynamic_case_app_name` (91 entries): Case name -> Chinese label for perf dynamic tests.
- Fallback behavior: if no match found, returns the raw (digit-stripped) string unchanged.

### Testing Requirements
- Verify mappings produce correct display names in analysis output.
- New entries should correspond to actual apps found in trace data.

### Common Patterns
- Simple dict-based lookup with digit stripping via `re.sub('\d+', '', name)`.
- Last-15-character suffix matching for fuzzy package name resolution.
- All functions return the original input string as fallback when no mapping exists.

## Dependencies

### Internal
- `core/preprocess/frame_ops.py` -- Uses process_name for frame app name resolution

### External
- `re` (stdlib) -- Digit stripping
