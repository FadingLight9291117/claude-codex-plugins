"""
Rendering pipeline data models
Based on SmartPerfetto pipelineSkillLoader.ts types
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any


@dataclass
class PipelineThreadRole:
    thread: str
    role: str
    description: str
    trace_tags: Optional[str] = None


@dataclass
class PipelineKeySlice:
    name: str
    thread: str
    description: str


@dataclass
class SmartFilterConfig:
    enabled: bool
    description: Optional[str] = None
    detection_sql: Optional[str] = None
    fallback_sql: Optional[str] = None


@dataclass
class PinInstruction:
    pattern: str
    match_by: str  # 'name' | 'uri'
    priority: int
    reason: str
    expand: Optional[bool] = None
    main_thread_only: Optional[bool] = None
    smart_filter: Optional[SmartFilterConfig] = None
    # Runtime fields
    smart_pin: Optional[bool] = None
    skip_pin: Optional[bool] = None
    active_process_names: Optional[List[str]] = None


@dataclass
class TeachingContent:
    title: str
    summary: str
    mermaid: Optional[str] = None
    thread_roles: List[PipelineThreadRole] = field(default_factory=list)
    key_slices: List[PipelineKeySlice] = field(default_factory=list)


@dataclass
class PipelineMeta:
    pipeline_id: str
    display_name: str
    description: str
    icon: str
    family: str
    doc_path: Optional[str] = None
    # Article-grounded signature
    s_article_ref: Optional[str] = None
    four_features: Optional[Dict[str, Any]] = None
    deviation_anchors: Optional[str] = None
    # Additional SmartPerfetto meta fields
    subvariants_note: Optional[str] = None
    layer_signature: Optional[str] = None
    thread_locations: Optional[str] = None
    impeller_advantage: Optional[str] = None
    known_traps: Optional[str] = None
    difference_from_standalone_chrome: Optional[str] = None


@dataclass
class CommonIssue:
    id: str
    name: str
    description: Optional[str] = None
    detection_skill: Optional[str] = None


@dataclass
class PipelineAnalysis:
    common_issues: Optional[List[CommonIssue]] = None
    recommended_skills: Optional[List[str]] = None


@dataclass
class DetectionSignal:
    thread: Optional[str] = None
    thread_pattern: Optional[str] = None
    slice: Optional[str] = None
    slice_pattern: Optional[str] = None
    min_count: Optional[int] = None


@dataclass
class ScoringSignal(DetectionSignal):
    signal: str = ""
    weight: int = 0
    condition: Optional[str] = None


@dataclass
class DetectionRules:
    required_signals: Optional[List[DetectionSignal]] = None
    scoring_signals: Optional[List[ScoringSignal]] = None
    exclude_if: Optional[List[DetectionSignal]] = None
    min_frames: Optional[int] = None  # Minimum frame count requirement


@dataclass
class PipelineDefinition:
    name: str
    version: str
    type: str  # 'pipeline_definition'
    category: str  # 'rendering'
    meta: PipelineMeta
    detection: Optional[DetectionRules] = None
    teaching: Optional[TeachingContent] = None
    auto_pin: Optional[Dict[str, Any]] = None
    analysis: Optional[PipelineAnalysis] = None


@dataclass
class PipelineIndex:
    version: str
    description: str
    families: Dict[str, Dict[str, Any]]
    pipeline_files: Dict[str, str]
