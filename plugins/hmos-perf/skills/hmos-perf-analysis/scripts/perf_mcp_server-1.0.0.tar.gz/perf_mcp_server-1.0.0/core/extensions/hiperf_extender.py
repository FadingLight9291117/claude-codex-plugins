"""Extend a trace_streamer SQLite DB with BRBE-derived dimension tables.

This module consumes the ordered PERF_RECORD_SAMPLE stream from
`HiperfBinaryParser.iter_samples_ordered()` together with the
`SymbolResolver`, and writes three new tables into the existing
`trace_streamer` database:

- `dim_binary`   : known binaries (binary_id 0 reserved for unknown)
- `dim_symbol`   : function-entry symbols, keyed by (binary_id, offset)
- `brbe_sample`  : compact branch records with pre-computed previous-branch target (BB entry)
  and from_symbol_entry_offset (FK → dim_symbol)

All address offsets are wrapped to SQLite signed-int64 range via
`_to_sqlite_int`; callers should unwrap with `value & 0xFFFFFFFFFFFFFFFF`
when they need the original unsigned 64-bit value.

IPC semantics (ARM BRBE BRBINF.CC):
  cycles = PE clock cycles from the previous branch record to the current one,
  which exactly covers the source-side basic block (prev_to_offset → from_offset).
  IPC formula: (from_offset - prev_to_offset) / 4 + 1  /  cycles

See docs/GOLDEN_RULES.md rule 24: extender stage does symbol resolution.
"""
from __future__ import annotations

import sqlite3
import time
from typing import Any, Optional

from core.observability import get_observability_logger

from .hiperf_binary_parser import HiperfBinaryParser
from .hiperf_symbol_resolver import SymbolResolver

log = get_observability_logger("hiperf_extender")

SQLITE_INT64_MASK = 0xFFFFFFFFFFFFFFFF


def _to_sqlite_int(value: int | None) -> int | None:
    """Wrap an unsigned 64-bit integer into SQLite's signed int64 range.

    Returns None if input is None. Bit pattern is preserved for round-trip
    queries (callers do `v & 0xFFFFFFFFFFFFFFFF` to get unsigned back).
    """
    if value is None:
        return None
    value &= SQLITE_INT64_MASK
    if value > 0x7FFFFFFFFFFFFFFF:
        value -= 1 << 64
    return value


# ---------------------------------------------------------------------------
# Schema helpers
# ---------------------------------------------------------------------------

def _create_tables(conn: sqlite3.Connection) -> None:
    """Create dimension tables and the compact brbe_sample table.

    Drops the extended tables first so repeated runs are idempotent.
    Also drops old-style brbe_sample / spe_sample if they exist.
    """
    conn.execute("DROP TABLE IF EXISTS brbe_sample")
    conn.execute("DROP TABLE IF EXISTS spe_sample")
    conn.execute("DROP TABLE IF EXISTS dim_binary")
    conn.execute("DROP TABLE IF EXISTS dim_symbol")

    conn.execute(
        """
        CREATE TABLE dim_binary (
            binary_id INTEGER PRIMARY KEY,
            path TEXT NOT NULL UNIQUE
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE dim_symbol (
            binary_id INTEGER NOT NULL,
            offset INTEGER NOT NULL,
            symbol_name TEXT NOT NULL,
            PRIMARY KEY (binary_id, offset)
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE brbe_sample (
            sample_id          INTEGER NOT NULL,
            timestamp_ns       INTEGER NOT NULL,
            sequence           INTEGER NOT NULL,
            thread_id          INTEGER NOT NULL,
            from_binary_id     INTEGER NOT NULL DEFAULT 0,
            from_offset        INTEGER NOT NULL,
            to_binary_id       INTEGER NOT NULL DEFAULT 0,
            to_offset          INTEGER NOT NULL,
            prev_to_offset     INTEGER NOT NULL DEFAULT 0,
            from_symbol_entry_offset INTEGER NOT NULL DEFAULT 0,
            el_type            INTEGER NOT NULL DEFAULT 0,
            br_type            INTEGER NOT NULL,
            cycles             INTEGER NOT NULL,
            mispredicted       INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (sample_id, timestamp_ns, sequence)
        ) WITHOUT ROWID
        """
    )


def _create_indexes(conn: sqlite3.Connection) -> None:
    """Create the query-time indexes defined by the design spec."""
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_brbe_from_bin_off
        ON brbe_sample(from_binary_id, from_offset)
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_brbe_to_bin_off_tid
        ON brbe_sample(to_binary_id, to_offset, thread_id)
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_brbe_sample_thread_seq
        ON brbe_sample(sample_id, thread_id, sequence)
        """
    )


def _write_dim_binary(conn: sqlite3.Connection, binaries: list[str]) -> None:
    """Populate dim_binary, reserving binary_id 0 for the unknown binary."""
    conn.execute(
        "INSERT OR IGNORE INTO dim_binary (binary_id, path) VALUES (0, ?)",
        ("unknown",),
    )
    rows = [(i, path) for i, path in enumerate(binaries, start=1)]
    conn.executemany(
        "INSERT OR IGNORE INTO dim_binary (binary_id, path) VALUES (?, ?)", rows
    )


def _load_path_to_id(conn: sqlite3.Connection) -> dict[str, int]:
    """Return mapping from binary path to binary_id."""
    return {
        row[1]: row[0]
        for row in conn.execute("SELECT binary_id, path FROM dim_binary")
    }


def _load_callchain_fallback(
    conn: sqlite3.Connection,
) -> dict[int, tuple[Optional[str], Optional[str], Optional[int]]]:
    """Build an IP -> (symbol, binary_path, file_offset) fallback from perf_callchain.

    The trace_streamer database already parsed a subset of symbol information
    into `perf_callchain` and `perf_files`.  We use it only when the binary
    resolver cannot map an address.
    """
    ip_to_symbol: dict[int, tuple[Optional[str], Optional[str], Optional[int]]] = {}
    try:
        cursor = conn.execute(
            """
            SELECT pc.ip, pc.name, pf.path, pc.vaddr_in_file
            FROM perf_callchain pc
            JOIN perf_files pf ON pc.file_id = pf.file_id
            """
        )
        for ip, name, path, vaddr_in_file in cursor:
            if ip not in ip_to_symbol:
                ip_to_symbol[ip] = (name, path, vaddr_in_file)
    except sqlite3.Error:
        # Older DBs may not have vaddr_in_file; try simpler query
        try:
            cursor = conn.execute(
                """
                SELECT pc.ip, pf.symbol, pf.path
                FROM perf_callchain pc
                LEFT JOIN perf_files pf ON pc.symbol_id = pf.id
                """
            )
            for ip, name, path in cursor:
                if ip not in ip_to_symbol:
                    ip_to_symbol[ip] = (name, path, None)
        except sqlite3.Error as exc2:
            log.warning("callchain_fallback_load_failed", error=str(exc2))
    return ip_to_symbol


def _load_sample_id_index(conn: sqlite3.Connection) -> dict[tuple[int, int], int]:
    """Build (timestamp_ns, tid) -> perf_sample.id lookup."""
    ts_tid_to_id: dict[tuple[int, int], int] = {}
    try:
        for row in conn.execute(
            "SELECT id, timeStamp, thread_id FROM perf_sample"
        ):
            ts_tid_to_id[(row[1], row[2])] = row[0]
    except sqlite3.Error as exc:
        log.warning("sample_id_index_load_failed", error=str(exc))
    return ts_tid_to_id


def _resolve_address_full(
    addr: int,
    pid: int,
    ip_to_symbol: dict[int, tuple[Optional[str], Optional[str], Optional[int]]],
    resolver: SymbolResolver,
) -> tuple[Optional[str], Optional[str], Optional[int], Optional[int]]:
    """Resolve an address, falling back to perf_callchain when MMAP resolution fails.

    Returns (symbol, binary_path, file_offset, symbol_entry_offset).  The
    symbol_entry_offset is the function-entry offset (bisect result) and is
    the value that should be stored in `dim_symbol.offset`.  For the
    perf_callchain fallback we do not have a sorted symbol table, so the
    entry offset is returned as None.
    """
    symbol, binary, file_offset, entry_offset = resolver.resolve_symbol_entry(
        addr, pid
    )
    if binary:
        return symbol, binary, file_offset, entry_offset
    fallback = ip_to_symbol.get(addr)
    if fallback is not None and fallback[1]:
        return fallback[0], fallback[1], fallback[2], None
    return None, None, None, None


def _flush_brbe_batch(conn: sqlite3.Connection, batch: list[tuple]) -> None:
    """Flush the BRBE batch buffer to sqlite."""
    if not batch:
        return
    conn.executemany(
        """
        INSERT INTO brbe_sample (
            sample_id, timestamp_ns, sequence, thread_id,
            from_binary_id, from_offset, to_binary_id, to_offset,
            prev_to_offset, from_symbol_entry_offset,
            el_type, br_type, cycles, mispredicted
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        batch,
    )
    batch.clear()


def _flush_symbol_cache(
    conn: sqlite3.Connection, symbol_cache: dict[tuple[int, int], str]
) -> None:
    """Flush the dimension-symbol cache to sqlite."""
    if not symbol_cache:
        return
    conn.executemany(
        """
        INSERT OR IGNORE INTO dim_symbol (binary_id, offset, symbol_name)
        VALUES (?, ?, ?)
        """,
        [(k[0], k[1], v) for k, v in symbol_cache.items()],
    )
    symbol_cache.clear()


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def extend_db_with_brbe_spe(sqlite_path: str, data_path: str) -> dict[str, Any]:
    """Extend a trace_streamer DB with BRBE dimension tables and sample rows.

    Args:
        sqlite_path: path to the trace_streamer-produced SQLite database.
        data_path: path to the original hiperf `.data` binary.

    Returns:
        dict with summary statistics, including `brbe_sample_count`,
        `spe_sample_count`, `perf_sample_matched`, symbol-resolution
        counters, and timing.
    """
    start_time = time.perf_counter()

    parser = HiperfBinaryParser(data_path)
    resolver = SymbolResolver(parser)
    try:
        resolver.build()
    except Exception as exc:
        log.warning("symbol_resolver_build_failed", error=str(exc))

    conn = sqlite3.connect(sqlite_path)
    # The extended tables are derived artifacts that can always be rebuilt,
    # so favor bulk-load speed over crash durability during the build.
    conn.execute("PRAGMA synchronous=OFF")
    conn.execute("PRAGMA journal_mode=MEMORY")
    _create_tables(conn)
    _write_dim_binary(conn, resolver.known_binaries())
    dim_binary_count = conn.execute("SELECT COUNT(*) FROM dim_binary").fetchone()[0]

    ip_to_symbol = _load_callchain_fallback(conn)
    ts_tid_to_id = _load_sample_id_index(conn)
    path_to_id = _load_path_to_id(conn)

    batch: list[tuple] = []
    symbol_cache: dict[tuple[int, int], str] = {}
    prev_window_last_by_tid: dict[int, tuple[int, int]] = {}

    total_samples = 0
    total_brbe_entries = 0
    perf_sample_matched = 0
    symbols_resolved = 0
    exact_symbols_resolved = 0

    for sample in parser.iter_samples_ordered():
        total_samples += 1
        entries = sorted(sample.brbe_entries, key=lambda e: e.sequence)
        if not entries:
            continue

        perf_sample_matched += 1
        sample_id = ts_tid_to_id.get((sample.timestamp_ns, sample.tid), 0)

        # Pre-resolve all from/to addresses for this sample so BB computation
        # can reuse the next entry's resolution without double work.
        # Each resolved tuple carries both the wrapped file offset, the
        # function-entry offset (bisect result), and the symbol name needed
        # for dim_symbol and from_symbol_entry_offset.
        resolved: list[tuple[Any, int, int, Optional[str], Optional[int], int, Optional[int], Optional[int]]] = []
        for entry in entries:
            from_sym, from_bin, from_off, from_entry_off = _resolve_address_full(
                entry.from_ip, sample.pid, ip_to_symbol, resolver
            )
            to_sym, to_bin, to_off, to_entry_off = _resolve_address_full(
                entry.to_ip, sample.pid, ip_to_symbol, resolver
            )
            from_bin_id = path_to_id.get(from_bin, 0) if from_bin else 0
            to_bin_id = path_to_id.get(to_bin, 0) if to_bin else 0
            from_off_wrapped = _to_sqlite_int(from_off) if from_off is not None else 0
            to_off_wrapped = _to_sqlite_int(to_off) if to_off is not None else 0

            resolved.append(
                (
                    entry,
                    from_bin_id,
                    from_off_wrapped,
                    from_sym,
                    from_entry_off,
                    to_bin_id,
                    to_off_wrapped,
                    to_entry_off,
                )
            )

            # Count symbol resolutions
            if from_sym is not None:
                symbols_resolved += 1
            if from_entry_off is not None:
                exact_symbols_resolved += 1
            if to_sym is not None:
                symbols_resolved += 1
            if to_entry_off is not None:
                exact_symbols_resolved += 1

            # dim_symbol is keyed by function-entry offset, not by the exact
            # branch file offset, to collapse symbol rows to one per function.
            if from_sym and from_bin_id and from_entry_off is not None:
                symbol_cache[(from_bin_id, _to_sqlite_int(from_entry_off))] = from_sym
            if to_sym and to_bin_id and to_entry_off is not None:
                symbol_cache[(to_bin_id, _to_sqlite_int(to_entry_off))] = to_sym

        # Compute prev_to_offset for each branch: it is the target of the
        # previous (older) branch in the window, i.e. the entry point of the
        # basic block that ends at this branch's from_offset.
        # Sequence 0 is newest; ascending sequence = time forward, so the
        # older neighbor of sorted index i is i + 1.
        # Skip entries with valid==0 (invalid record) or cycles_unknown
        # (CCU==1, cycle count not usable for IPC).
        for i, (
            entry,
            from_bin_id,
            from_off,
            from_sym,
            from_entry_off,
            to_bin_id,
            to_off,
            to_entry_off,
        ) in enumerate(resolved):
            # Skip invalid or cycles-unknown records per ARM BRBINF_EL1
            if entry.valid == 0 or entry.cycles_unknown:
                continue

            if i + 1 < len(resolved):
                prev_to_bin_id = resolved[i + 1][5]
                prev_to_off_raw = resolved[i + 1][6] & SQLITE_INT64_MASK
            elif sample.tid in prev_window_last_by_tid:
                prev_to_bin_id, prev_to_off = prev_window_last_by_tid[sample.tid]
                prev_to_off_raw = prev_to_off & SQLITE_INT64_MASK
            else:
                prev_to_bin_id = 0
                prev_to_off_raw = 0

            if prev_to_bin_id != 0:
                prev_to_offset = _to_sqlite_int(prev_to_off_raw)
            else:
                prev_to_offset = 0

            from_symbol_entry_offset = (
                _to_sqlite_int(from_entry_off)
                if from_entry_off is not None and from_bin_id != 0 and from_sym is not None
                else 0
            )

            batch.append(
                (
                    sample_id,
                    sample.timestamp_ns,
                    entry.sequence,
                    sample.tid,
                    from_bin_id,
                    from_off,
                    to_bin_id,
                    to_off,
                    prev_to_offset,
                    from_symbol_entry_offset,
                    entry.el_type,
                    entry.br_type,
                    _to_sqlite_int(entry.cycles),
                    int(entry.is_mispredicted),
                )
            )
            total_brbe_entries += 1

            if len(batch) >= 50_000:
                _flush_brbe_batch(conn, batch)

        if len(symbol_cache) >= 50_000:
            _flush_symbol_cache(conn, symbol_cache)

        # Update cross-window state with this window's newest valid branch target;
        # it becomes the previous branch context for the next sample on this tid.
        # Use the first valid entry (valid!=0) to avoid poisoning the state
        # with an invalid entry's unreliable to_offset.
        for _, (entry, _, _, _, _, to_bin_id, to_off, _) in enumerate(resolved):
            if entry.valid != 0:
                prev_window_last_by_tid[sample.tid] = (to_bin_id, to_off)
                break

    _flush_brbe_batch(conn, batch)
    _flush_symbol_cache(conn, symbol_cache)
    dim_symbol_count = conn.execute("SELECT COUNT(*) FROM dim_symbol").fetchone()[0]
    _create_indexes(conn)
    conn.commit()
    conn.close()

    duration_ms = (time.perf_counter() - start_time) * 1000
    total_branch_addresses = total_brbe_entries * 2
    symbol_resolution_rate = (
        symbols_resolved / total_branch_addresses if total_branch_addresses else 0.0
    )
    exact_symbol_resolution_rate = (
        exact_symbols_resolved / total_branch_addresses
        if total_branch_addresses
        else 0.0
    )

    cache = resolver.cache_stats()
    log.info(
        "hiperf_extender_complete",
        brbe_count=total_brbe_entries,
        dim_binary=dim_binary_count,
        dim_symbol=dim_symbol_count,
        duration_ms=round(duration_ms, 1),
        resolve_cache_size=cache["size"],
        resolve_cache_hits=cache["hits"],
    )

    return {
        "brbe_sample_count": total_brbe_entries,
        "spe_sample_count": 0,
        "perf_sample_matched": perf_sample_matched,
        "symbols_resolved": symbols_resolved,
        "exact_symbols_resolved": exact_symbols_resolved,
        "symbol_resolution_rate": symbol_resolution_rate,
        "exact_symbol_resolution_rate": exact_symbol_resolution_rate,
        "dim_binary_count": dim_binary_count,
        "dim_symbol_count": dim_symbol_count,
        "duration_ms": duration_ms,
    }
