# -*- coding: utf-8 -*-
"""Sleep 状态与唤醒链预处理算子（pipeline 形态）。

基于 OSS wakeup_link_helper.py 的核心算法：
1. 从 thread_state 表构建 S 状态链（连续 S 条目归为一段）
2. 通过 instant 表关联唤醒关系（sched_wakeup 事件）
3. 递归回溯唤醒链（walking_wakeup_link）
4. 计算链深度、算力供给、阻塞函数

关键概念（参考 wakeup_link_helper.py WakeupLinkInfo）：
    - wakeup_chain: 从被唤醒线程到根唤醒者的路径
    - chain_depth: 唤醒链深度
    - mean_supply: 算力供给（等效大核最高频百分比）
    - key_function: 阻塞函数名

数据链路：
    thread_state.state='S' → instant.ref (itid) → instant.wakeup_from (唤醒者 itid)
    递归回溯直到 wakeup_from=0 或找到根唤醒者
"""
from __future__ import annotations

import bisect as _bisect
import heapq
import re

from core.observability import get_module_logger
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

# Agent 友好化 helper（spec §5.5）
from .base import shorten_func_name

# legend 常量（spec §4.3）— sleep 算子自有的图例片段
LEGEND_PRIO = "prio=线程优先级（鸿蒙 RT/LINUX 动态优先级，范围 -1~99；rt=实时调度类）"
LEGEND_SLEEP_ROW = "[block_ms|占该段睡眠%] 函数 | block_reason"
LEGEND_CHAIN_TREE = "chain_text 缩进层=更上游阻塞原因；子行耗时是父行窗口子区间；禁止跨层累加"
LEGEND_TIME_OFFSET = "所有时间均为相对帧窗口起点偏移(ms)"

from .base import PreprocessContext, PreprocessError, register_operator

log = get_module_logger(__name__)


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def _percentile(data: list[float], p: float) -> float:
    """线性插值百分位数。"""
    if not data:
        return 0.0
    sorted_data = sorted(data)
    n = len(sorted_data)
    idx = p / 100.0 * (n - 1)
    lo = int(idx)
    hi = min(lo + 1, n - 1)
    frac = idx - lo
    return round(sorted_data[lo] + frac * (sorted_data[hi] - sorted_data[lo]), 3)


_FUNC_NAME_MAX_LEN = 60

# W-S 匹配容差：W.ts 应在 S 段结束点 ±5us 内（wakeup 发生在 Sleep 结束时）。
# 实测 140 个真实 W 事件都在 S.ts+S.dur ±1us 内，取 5us 容差留余量。
WAKEUP_TOLERANCE_NS = 5_000
# ISA 后缀: |I38, |I64, |ARM 等
_ISA_SUFFIX_PATTERN = re.compile(r"\|[A-Za-z0-9]+$")
# H:[hash]# 前缀（trace 内部 hash，无诊断价值）
_H_HASH_PREFIX = re.compile(r"^H:\[[A-Za-z0-9,]+\]#")
# [id:xxx, value:yyy] 参数串
_ID_VALUE_PATTERN = re.compile(r"\[id:[^\]]*\]")
# >=4 位数字串（hash 开头标志）
_LONG_DIGITS_PATTERN = re.compile(r"\d{4,}")


def _truncate_function_name(name: str) -> str:
    """截断 callstack 函数名到 LLM 友好长度。

    规则:
    1. 去掉 |I38 / |I64 / |ARM 等 ISA 后缀
    2. 去掉 H:[hash]# 前缀（保留 # 后的语义部分）
    3. 去掉 [id:xxx, value:yyy] 参数串
    4. 在第一个 >=4 位数字串前截断（数字通常标志 hash 开始）
    5. 清理残留的 [,] 符号
    6. 总长度上限 60 字符，超出加 ... 标记

    示例:
      H:Load/Compile Shaders Inner 56393854756c4f39...|I38
        -> H:Load/Compile Shaders Inner
      ML: bisheng_graphic_pipeline_compilation_173109.498629_vs_6562...
        -> ML: bisheng_graphic_pipeline_compilation
      ML: bisheng_backend_compilation  (无数字 hash，保持不变)
      H:[a92ab3b6925f309,0,0]#send data to perf so,[id:4007, value:0],...
        -> send data to perf so
    """
    if not name:
        return ""
    s = name
    # 1. 去 ISA 后缀
    s = _ISA_SUFFIX_PATTERN.sub("", s)
    # 2. 去 H:[hash]# 前缀，保留 # 后的语义部分
    s = _H_HASH_PREFIX.sub("", s)
    # 3. 去 [id:xxx, value:yyy] 参数串
    s = _ID_VALUE_PATTERN.sub("", s)
    # 4. 在第一个 >=4 位数字串前截断
    m = _LONG_DIGITS_PATTERN.search(s)
    if m and m.start() > 0:
        sep = m.start()
        while sep > 0 and s[sep - 1] in " _.,":
            sep -= 1
        if sep > 0:
            s = s[:sep]
    # 5. 清理残留的 [,] 符号
    s = re.sub(r"[\[\],]", "", s)
    # 6. 合并多空格 + strip
    s = re.sub(r" +", " ", s).strip(" _")
    # 7. 总长度上限
    if len(s) > _FUNC_NAME_MAX_LEN:
        s = s[:_FUNC_NAME_MAX_LEN - 3] + "..."
    return s


def _get_blocked_function_from_cache(callstack_list: List[Tuple[int, int, str, int]],
                                       start_ts: int, end_ts: int,
                                       ts_only: List[int] = None,
                                       max_dur: int = 0) -> str:
    """从内存中的 callstack 列表查找与 [start_ts, end_ts] 有交集的代表性函数名。

    策略：取两个 depth 层级里各自 dur 最大的函数，用 " > " 拼接：
    - max_depth 层（最内层，反映具体在做什么）
    - mid_depth = max_depth // 2 层（中间层，反映业务语义上下文）

    理由：
    - 单取 depth=0 太外层（如 "H:DDGR::TaskQueue Execute Task"），看不出在做啥
    - 单取 depth 最大有时是 hash 名（如 "ML: bisheng_graphic_pipeline_compilation_<hash>"），
      虽能看出在编译但缺业务上下文
    - 中间层（如 "H:Load/Compile Shaders"）+ 最内层（如 "ML: bisheng_backend_compilation"）
      组合，LLM 既能看到业务语义又能看到具体动作

    callstack_list: [(ts, dur, name, depth), ...]  按 ts 升序
    Callstack 范围: [ts, ts + dur]，交集条件: ts <= end_ts AND ts + dur >= start_ts

    优化：用 bisect 在升序列表中找 cs_ts <= end_ts 的最右项 idx_end，
    然后从 idx_end 往前扫描，当 cs_ts + max_dur < start_ts 时 break。
    收集所有交集项后，按 depth 分组取各自 dur 最大。

    Args:
        ts_only: 预提取的 ts 列表（与 callstack_list 同序），避免每次调用都重建
        max_dur: callstack_list 中的最大 dur，用于 break 提前退出
    """
    if not callstack_list:
        return ""
    if ts_only is None:
        ts_only = [t[0] for t in callstack_list]
    # 找 cs_ts <= end_ts 的最右索引
    idx_end = _bisect.bisect_right(ts_only, end_ts)
    # 提前停止阈值：cs_ts < start_ts - max_dur 时，cs_ts + max_dur < start_ts，必然无交集
    early_stop_ts = start_ts - max_dur if max_dur > 0 else None

    # 收集所有交集项，按 depth 分组记录各自 dur 最大的函数
    # depth_max_dur: {depth: (dur, name)}
    depth_max_dur: Dict[int, Tuple[int, str]] = {}
    for i in range(idx_end - 1, -1, -1):
        cs_ts, cs_dur, cs_name, cs_depth = callstack_list[i]
        if early_stop_ts is not None and cs_ts < early_stop_ts:
            break
        if cs_dur is None:
            continue
        # cs_ts <= end_ts 已由 bisect 保证
        if cs_ts + cs_dur >= start_ts:
            # 有交集，按 clipped dur 比较（clip 到 [start_ts, end_ts]）
            actual_start = cs_ts if cs_ts >= start_ts else start_ts
            actual_end = cs_ts + cs_dur
            if actual_end > end_ts:
                actual_end = end_ts
            clipped_dur = actual_end - actual_start
            cur = depth_max_dur.get(cs_depth)
            if cur is None or clipped_dur > cur[0]:
                depth_max_dur[cs_depth] = (clipped_dur, cs_name)

    if not depth_max_dur:
        return ""

    # 找 max_depth 和 mid_depth
    max_depth = max(depth_max_dur.keys())
    # 只有一层时，mid_depth == max_depth，去重后只输出一个
    mid_depth = max_depth // 2

    max_name = _truncate_function_name(depth_max_dur[max_depth][1])
    mid_name = _truncate_function_name(depth_max_dur[mid_depth][1]) if mid_depth in depth_max_dur else ""

    if mid_name and mid_name != max_name:
        return f"{mid_name} > {max_name}"
    return max_name


def _stat_thread_state_from_cache(
    cache: Dict[int, List[Tuple[int, int, str]]],
    itid: int,
    win_start_ns: int,
    win_end_ns: int,
    ts_only: Optional[List[int]] = None,
) -> Dict[str, float]:
    """从内存缓存统计指定线程在窗口内的状态时长（ms）。

    与 _stat_thread_state_in_window 语义完全一致，但数据来自 _build_thread_state_cache
    预拉取的内存结构，避免循环内 N+1 SQL 查询（规则 19/32）。

    Args:
        cache: _build_thread_state_cache 返回的 {itid: [(ts, dur, state), ...]}
        itid: 目标线程
        win_start_ns / win_end_ns: 窗口范围(ns)
        ts_only: 预提取的 ts 列表（与 cache 同序），避免每次调用都重建

    Returns: {running_ms, runnable_ms, sleep_ms, dstate_ms}
    """
    result = {"running_ms": 0.0, "runnable_ms": 0.0, "sleep_ms": 0.0, "dstate_ms": 0.0}
    rows = cache.get(itid)
    if not rows:
        return result
    # bisect 缩小扫描范围到窗口内 + 1（捕获跨边界项）。
    # 区间交集条件: (ts + dur) > win_start AND ts < win_end。
    # list 按 ts 升序：
    #   - bisect_left(ts_only, win_end) = 第一个 ts >= win_end 的位置 → 右边界（不含）
    #   - bisect_right(ts_only, win_start) - 1 = 最后一个 ts < win_start 的位置，
    #     从此处开始扫描以捕获 ts < win_start 但 (ts+dur) 跨越 win_start 的行
    # 原线性扫描单 itid 全量状态记录（连接级缓存场景单 itid 可达上万行），
    # 15822 次调用 × 5600 行 = 8900万次 max/min，53.5s。
    # bisect 缩到窗口内 ~50 行，预期 -98%。
    if ts_only is None:
        ts_only = [r[0] for r in rows]
    idx_end = _bisect.bisect_left(ts_only, win_end_ns)
    idx_start = max(0, _bisect.bisect_right(ts_only, win_start_ns) - 1)
    # 扫描 [idx_start, idx_end) 范围内的行
    for i in range(idx_start, idx_end):
        ts, dur, state = rows[i]
        if not state or not dur:
            continue
        # 区间交集：actual = [max(ts, win_start), min(ts+dur, win_end)]
        # 内联 max/min 比调用内置函数快（避免函数调用开销）
        actual_start = ts if ts >= win_start_ns else win_start_ns
        ts_plus_dur = ts + dur
        actual_end = ts_plus_dur if ts_plus_dur <= win_end_ns else win_end_ns
        if actual_end <= actual_start:
            continue
        actual_ms = (actual_end - actual_start) / 1_000_000.0
        if state == "Running":
            result["running_ms"] += actual_ms
        elif state in ("R", "R+"):
            result["runnable_ms"] += actual_ms
        elif state == "S":
            result["sleep_ms"] += actual_ms
        elif state.startswith("D"):
            result["dstate_ms"] += actual_ms
    for k in result:
        result[k] = round(result[k], 3)
    return result


# ---------------------------------------------------------------------------
# Sleep 重构辅助函数（树形阻塞链 §2.2/§3.3/§4/§7.5）
# ---------------------------------------------------------------------------

_BLOCK_REASON_LABELS = {
    "dstate_ms": "D状态阻塞",
    "sleep_ms": "Sleep等待",
    "runnable_ms": "调度延迟(Runnable)",
    "running_ms": "Running耗时",
}


def _format_block_reason(stats: Dict[str, float]) -> str:
    """从 _stat_thread_state_from_cache 的四 bucket 统计生成自然语言 block_reason。

    四个 bucket 按时长降序，所有 ≥ 0.1ms 的状态都输出（不限制 top-N）。
    仅当 Running 是唯一 ≥0.1ms 的状态时标注"（计算慢）"。
    Running 必须参与排序——否则"waker 自己算了 10ms 再唤醒、中间只 D 了 2ms"
    的场景只输出 D 部分，严重误导。
    阈值 0.1ms：低于 100μs 的状态视为调度抖动噪声，不输出。
    """
    items = [(k, v) for k, v in stats.items() if v >= 0.1]
    if not items:
        return ""
    items.sort(key=lambda x: -x[1])
    parts = [f"{_BLOCK_REASON_LABELS[k]}{v:.1f}ms" for k, v in items]
    if len(items) == 1 and items[0][0] == "running_ms":
        parts[0] += "（计算慢）"
    return "+".join(parts)


def _find_covering_sd_segment(
    thread_state_cache: Dict[int, List[Tuple[int, int, str]]],
    itid: int,
    t_w: int,
    ts_only: Optional[List[int]] = None,
) -> Optional[Dict]:
    """查覆盖 t_w 的单条 S/D 状态行（§7.5）。

    在 thread_state_cache[itid] 中找 ts <= t_w < ts+dur 的行，
    且 state ∈ {S, D, D 前缀变体}。R+/Running/其他返回 None。

    Args:
        thread_state_cache: _build_thread_state_cache 返回的 {itid: [(ts, dur, state), ...]}
        itid: 目标线程
        t_w: 唤醒时间戳（ns）
        ts_only: 预提取的 ts 列表（与 cache 同序），避免每次调用都重建

    Returns: {"ts": int, "dur": int, "state": str} 或 None
    """
    rows = thread_state_cache.get(itid)
    if not rows:
        return None
    if ts_only is None:
        ts_only = [r[0] for r in rows]
    # bisect_right(t_w) - 1 → 最后一个 ts <= t_w 的候选行
    idx = _bisect.bisect_right(ts_only, t_w) - 1
    if idx < 0:
        return None
    ts, dur, state = rows[idx]
    # 校验 ts <= t_w <= ts+dur（闭区间：wakeup ts 可以等于段 end，spec §1.2）
    # spec §1.2: "wakeup ts 恰好等于段 end（半开区间 [ts, ts+dur) 下状态段的 ts+dur == wakeup ts）"
    # 即 wakeup 结束 S/D 段时，t_w == ts+dur 是合法的覆盖关系
    # 边界情况：t_w == ts+dur(segment A) == ts(segment B)，bisect_right 会找到 B
    # 此时 B 的 ts == t_w 但 B 是 wakeup 后的状态（R/Running），不是我们要的
    # 需要回退到前一行（segment A），它的 ts+dur == t_w
    if ts == t_w and idx > 0:
        # t_w 恰好是两段的边界，回退到前一段
        idx -= 1
        ts, dur, state = rows[idx]
    if ts > t_w or (ts + dur) < t_w:
        return None
    # 仅 S/D 段产生分支（§1.3）
    if state == "S" or state.startswith("D"):
        return {"ts": ts, "dur": dur, "state": state}
    return None


def _aggregate_blocker(agg: Dict[int, dict], node: dict) -> None:
    """DFS 遍历树，每个节点 = 一次阻塞事件（§3.3）。

    聚合在 compute 层、top-N 裁剪之前，对全部 analyzed segments 的树做 DFS 遍历。
    不受 blocker_min_cost_ms / max_detail_count 限制，确保 "200×0.5ms = 100ms"
    极端场景下小阻塞事件也被计入聚合（spec §3.3 关键修正）。

    Args:
        agg: 聚合字典 {itid: {total_block_ms, block_events, prio, ...}}，原地修改
        node: build_blocking_tree 产出的树节点（含 itid/tid/block_ms/
              blocked_function/blocked_state/blockers）

    Notes:
        - depth-0 节点由外层循环显式设置 blocked_state="S"（目标线程 sleep 段固定 S）
        - max_block_function 取 max_block_ms 那次事件的 blocked_function（§2.3）
        - state_counts 用于推导 primary_reason（众数 state，§2.3）
        - prio = 首个该 itid 节点的线程优先级（spec §5.4，取 build_blocking_tree 写入值）
    """
    itid = node.get("itid", 0)
    if not itid:
        return
    entry = agg.setdefault(itid, {
        "tid": node["tid"],
        "thread_name": node["thread_name"],
        "process_name": node.get("process_name", ""),
        "prio": node.get("prio", -1),  # spec §5.4
        "total_block_ms": 0.0,
        "block_events": 0,
        "max_block_ms": 0.0,
        "state_counts": {},
        "max_block_function": "",
    })
    cost = node.get("block_ms", 0.0)
    entry["total_block_ms"] += cost
    entry["block_events"] += 1
    if cost > entry["max_block_ms"]:
        entry["max_block_ms"] = cost
        entry["max_block_function"] = node.get("blocked_function", "")
    st = node.get("blocked_state")
    if st:
        entry["state_counts"][st] = entry["state_counts"].get(st, 0) + 1
    for child in node.get("blockers", []):
        _aggregate_blocker(agg, child)


def _finalize_blocker_agg(agg: Dict[int, dict], top_n: int = 5) -> List[Dict]:
    """将 blocker_aggregate 原始数据转为输出格式（§3.3/§5）。

    Args:
        agg: _aggregate_blocker 产出的 {itid: {...}} 字典
        top_n: 按 total_block_ms 降序取前 N（blocker_aggregate_top_n）

    Returns:
        [{tid, thread_name, process_name, prio, total_block_ms, block_events,
          max_block_ms, avg_block_ms?, primary_reason, function}, ...]
        - prio = 阻塞者线程优先级（spec §5.4，未知名时 -1）
        - avg_block_ms 仅在 block_events > 1 时输出（与 avg_sleep_ms 一致）
        - primary_reason = state_counts 众数映射 {"D":"D状态","S":"Sleep等待"}
        - function = max_block_ms 那次事件的函数名（§2.3，最具代表性）
    """
    _REASON_MAP = {"D": "D状态", "S": "Sleep等待"}
    result = []
    for itid, entry in sorted(agg.items(), key=lambda x: -x[1]["total_block_ms"]):
        state_counts = entry.get("state_counts", {})
        if state_counts:
            # 众数：出现次数最多的 state；并列时取累计时长更长（这里用 count 降序作为近似）
            primary_state = max(state_counts, key=state_counts.get)
            primary_reason = _REASON_MAP.get(primary_state, primary_state)
        else:
            primary_reason = ""
        out = {
            "tid": entry["tid"],
            "thread_name": entry["thread_name"],
            "process_name": entry.get("process_name", ""),
            "prio": entry.get("prio", -1),  # spec §5.4
            "total_block_ms": round(entry["total_block_ms"], 3),
            "block_events": entry["block_events"],
            "max_block_ms": round(entry["max_block_ms"], 3),
            "primary_reason": primary_reason,
            "function": entry.get("max_block_function", ""),
        }
        if entry["block_events"] > 1:
            out["avg_block_ms"] = round(entry["total_block_ms"] / entry["block_events"], 3)
        result.append(out)
    return result[:top_n]


def _render_tree_text(tree: dict, target_pname: str, seg_duration_ms: float) -> str:
    """树 → 树形文本（spec §4.2）。

    将 build_blocking_tree 产出的完整阻塞树渲染为带 ├──/└── 前缀的 pre-formatted
    文本，供 LLM 消费。同层子节点按 block_ms 降序排列；末子节点用 └──，其余用 ├──；
    每深一层追加 4 空格缩进（末子节点用 "    "，非末子节点用 "│   " 以延续上层分支线）。

    行格式（spec §4.2）:
        {线程名}({tid}, prio={N})[@{进程名}] [{block_ms}ms | {pct}%] [{function}] [| {block_reason}]

    - 首行（根节点）无前缀；后续行带前缀。
    - pct = block_ms / seg_duration_ms × 100，所有行共用同一分母（火焰图惯例 §11.5）。
    - `@进程名` 仅当节点 process_name 与 target_pname 不同时输出（跨进程标注，省 token）。
    - blocked_function / block_reason 为空时省略对应片段，不留尾随空格或 "|"。

    Args:
        tree: build_blocking_tree 产出的树节点（递归结构，含 blockers 子节点列表）
        target_pname: 目标线程的进程名（用于判断跨进程）
        seg_duration_ms: 当前 sleep 段总时长（ms），用作 pct 分母

    Returns:
        多行字符串，每行一个节点，"\n" 拼接
    """
    lines: List[str] = []

    def _fmt(node: dict) -> str:
        block_ms = node.get("block_ms", 0.0)
        pct = block_ms / seg_duration_ms * 100 if seg_duration_ms > 0 else 0.0
        proc = node.get("process_name", "")
        proc_suffix = f"@{proc}" if proc and proc != target_pname else ""
        line = (
            f"{node.get('thread_name', '')}({node.get('tid', 0)}, "
            f"prio={node.get('prio', -1)}){proc_suffix} "
            f"[{block_ms:.1f}ms | {pct:.1f}%]"
        )
        func = node.get("blocked_function", "")
        if func:
            line += f" {func}"
        reason = node.get("block_reason", "")
        if reason:
            line += f" | {reason}"
        return line

    def _walk(node: dict, prefix: str, is_root: bool, is_last: bool) -> None:
        if is_root:
            lines.append(_fmt(node))
            child_prefix = ""
        else:
            lines.append(prefix + ("└── " if is_last else "├── ") + _fmt(node))
            child_prefix = prefix + ("    " if is_last else "│   ")
        children = sorted(node.get("blockers", []), key=lambda x: -x.get("block_ms", 0))
        for i, child in enumerate(children):
            _walk(child, child_prefix, False, i == len(children) - 1)

    _walk(tree, "", True, True)
    return "\n".join(lines)


def build_blocking_tree(
    blocked_tid: int,
    blocked_itid: int,
    window_start: int,
    window_end: int,
    depth: int,
    visited: set,
    budget: list,
    *,
    wakeup_idx,
    max_depth: int,
    blocker_min_cost_ms: float,
    max_blockers_per_node: int,
    meta_dict: Dict[int, tuple],
    process_names: Dict[int, str],
    itid_to_ipid: Dict[int, int],
    callstack_cache: Dict[int, list],
    callstack_ts_only_cache: Dict[int, list],
    callstack_max_dur_cache: Dict[int, int],
    thread_state_cache: Dict[int, List[Tuple[int, int, str]]],
    thread_state_ts_only_cache: Dict[int, list],
    prio_map: Dict[int, int],
) -> Optional[dict]:
    """树形阻塞链递归构建（spec §3.1）。

    线性链 → 树形链：每层可产生多个分支（S/D 阻塞段），R+/Running 不产生分支。
    动态窗口：depth-0 窗口 = [seg_start, seg_end]；depth≥1 窗口 = 父节点阻塞段
    [max(seg.ts, parent_ws), t_w]（§1.4）。
    visited 回溯式 add/discard（try/finally），兄弟分支互不影响（§1.5）。
    递归内禁止任何 cache 方法调用（§7.6），所有数据源以 dict 参数形式传入。

    Args:
        blocked_tid: 被阻塞线程 tid
        blocked_itid: 被阻塞线程 itid（状态段查询用）
        window_start / window_end: 当前节点窗口（ns）
        depth: 当前递归深度
        visited: 回溯式使用，DFS 路径防环
        budget: 单元素 list 做计数器，单事件总节点预算（§7.2）
        wakeup_idx: WakeupChainIndex，提供 find_direct_waker/find_wakeups_in_window
        max_depth: 树最大递归深度
        blocker_min_cost_ms: 阻塞段 < 此值不展开为分支（§5）
        max_blockers_per_node: 每节点最多分支数，递归前 heapq.nlargest 裁剪（§7.1）
        meta_dict / process_names / itid_to_ipid / callstack_cache /
        callstack_ts_only_cache / callstack_max_dur_cache /
        thread_state_cache / thread_state_ts_only_cache / prio_map:
            全量 dict，外层循环前一次性取（§7.6）

    Returns:
        树节点 dict 或 None（无 wakeup / waker 未知 / 超深度 / 预算耗尽）
        节点字段：tid / itid / thread_name / process_name / blocked_function /
        block_ms（0.0，由调用方设置）/ block_reason / prio / blockers
    """
    if depth >= max_depth or blocked_tid in visited or budget[0] <= 0:
        return None

    # 1. 直接唤醒者 = 结束该段的最后一次 wakeup（端点含，§1.2）
    direct = wakeup_idx.find_direct_waker(blocked_tid, window_end)
    if direct is None:
        return None
    w_ts, waker_itid = direct
    if waker_itid <= 0:
        # 中断/未知唤醒：不产节点（§6 极端情况）
        return None
    if w_ts < window_start:
        return None

    waker_meta = meta_dict.get(waker_itid)
    if not waker_meta:
        return None
    waker_tid = waker_meta[1]

    visited.add(blocked_tid)
    budget[0] -= 1
    try:
        # 2. 本节点窗口内状态统计 → block_reason（动态窗口，§1.4）
        state_stats = _stat_thread_state_from_cache(
            thread_state_cache, waker_itid, window_start, w_ts,
            ts_only=thread_state_ts_only_cache.get(waker_itid),
        )
        block_reason = _format_block_reason(state_stats)

        # 3. 枚举 waker 的 S/D 阻塞段（§1.3），先裁剪再递归（§7.1）
        # candidate_segs 元组：(seg_dur_ms, seg_start, t_w, from_itid, seg_state)
        candidate_segs = []
        for t_w, from_itid in wakeup_idx.find_wakeups_in_window(
                waker_tid, window_start, w_ts):
            if from_itid <= 0:
                continue
            seg = _find_covering_sd_segment(
                thread_state_cache, waker_itid, t_w,
                ts_only=thread_state_ts_only_cache.get(waker_itid),
            )
            if seg is None:
                continue
            seg_start = max(seg["ts"], window_start)
            seg_dur_ms = (t_w - seg_start) / 1_000_000
            if seg_dur_ms < blocker_min_cost_ms:
                continue
            candidate_segs.append((seg_dur_ms, seg_start, t_w, from_itid, seg["state"]))

        # 先按段时长降序取 top-K，再递归（heapq.nlargest，§7.1）
        candidate_segs = heapq.nlargest(
            max_blockers_per_node, candidate_segs, key=lambda x: x[0])

        blockers = []
        for seg_dur_ms, seg_start, t_w, from_itid, seg_state in candidate_segs:
            child = build_blocking_tree(
                blocked_tid=waker_tid,
                blocked_itid=waker_itid,
                window_start=seg_start,
                window_end=t_w,
                depth=depth + 1,
                visited=visited,        # 回溯式，不 copy
                budget=budget,
                wakeup_idx=wakeup_idx,
                max_depth=max_depth,
                blocker_min_cost_ms=blocker_min_cost_ms,
                max_blockers_per_node=max_blockers_per_node,
                meta_dict=meta_dict,
                process_names=process_names,
                itid_to_ipid=itid_to_ipid,
                callstack_cache=callstack_cache,
                callstack_ts_only_cache=callstack_ts_only_cache,
                callstack_max_dur_cache=callstack_max_dur_cache,
                thread_state_cache=thread_state_cache,
                thread_state_ts_only_cache=thread_state_ts_only_cache,
                prio_map=prio_map,
            )
            if child:
                child["block_ms"] = round(seg_dur_ms, 3)
                child["blocked_state"] = seg_state  # "S"/"D"，聚合用（§2.3）
                blockers.append(child)

        # 4. 构造节点
        # block_ms 由调用方设置：
        # - depth-0 根节点：外层循环设为 seg["duration_ms"]（§3.2）
        # - depth≥1 子节点：父调用方设为 seg_dur_ms（§3.1）
        node = {
            "tid": waker_tid,
            "itid": waker_itid,
            "thread_name": (waker_meta[0] or "").strip(),
            "process_name": (process_names.get(itid_to_ipid.get(waker_itid, 0), "") or "").strip(),
            "blocked_function": _get_blocked_function_from_cache(
                callstack_cache.get(waker_itid, []), window_start, w_ts,
                ts_only=callstack_ts_only_cache.get(waker_itid),
                max_dur=callstack_max_dur_cache.get(waker_itid, 0),
            ),
            "block_ms": 0.0,       # 由调用方设置
            "block_reason": block_reason,
            "prio": prio_map.get(waker_itid, -1),
            "blockers": blockers,
        }
        return node
    finally:
        visited.discard(blocked_tid)


# ---------------------------------------------------------------------------
# sleep_duration: Layer 1 - S状态链合并 + 聚合
# ---------------------------------------------------------------------------

@register_operator("compute_sleep_durations")
def compute_sleep_durations(ctx: PreprocessContext) -> PreprocessContext:
    """从 thread_state 数据计算每个线程的睡眠时长（连续 S 条目合并为一段）。

    输入:
        ctx.data: DataFrame 含列 ts / dur / itid / tid / pid / state / tname
                  ts: ns 时间戳
                  dur: ns 持续时间
                  state: 'S'
    输出:
        ctx.data: DataFrame 含列 itid / tid / pid / tname / sleep_ms /
                              sleep_events / avg_ms
        ctx.meta["sleep_total_ms"]: 所有线程总睡眠时长
        ctx.meta["sleep_events"]: 睡眠事件数（合并后）
        ctx.meta["thread_count"]: 活跃线程数
    """
    df = ctx.data
    required = {"ts", "itid", "state"}
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(
            f"compute_sleep_durations 输入缺少列: {sorted(missing)}; "
            f"请确认 SQL 输出已包含 {sorted(required)}"
        )

    if not len(df):
        ctx.meta["thread_count"] = 0
        ctx.meta["sleep_total_ms"] = 0.0
        ctx.meta["sleep_events"] = 0
        ctx.data = pd.DataFrame(columns=[
            "itid", "tid", "pid", "tname", "sleep_ms", "sleep_events", "avg_ms"
        ])
        return ctx

    df = df.copy()
    df = df.sort_values(["itid", "ts"]).reset_index(drop=True)

    # 按线程分组，合并连续 S 状态
    results: list[dict[str, Any]] = []
    for itid, group in df.groupby("itid"):
        group = group.sort_values("ts").reset_index(drop=True)
        n = len(group)

        total_sleep_us = 0.0
        sleep_events = 0
        tid = int(group["tid"].iloc[0]) if "tid" in group.columns else itid
        pid = int(group["pid"].iloc[0]) if "pid" in group.columns else 0

        i = 0
        while i < n:
            row = group.iloc[i]
            state = str(row["state"])
            if state == "S":
                # 找连续 S 段结束位置
                sleep_start = float(row["ts"])
                j = i + 1
                while j < n and str(group.iloc[j]["state"]) == "S":
                    j += 1
                # 合并段结束时间 = 下一段非 S 的开始时间，或最后一条 + dur
                if j < n:
                    sleep_end = float(group.iloc[j]["ts"])
                else:
                    last_dur = float(group.iloc[j - 1]["dur"]) if "dur" in group.columns else 0
                    sleep_end = sleep_start + last_dur
                sleep_duration_us = sleep_end - sleep_start
                total_sleep_us += sleep_duration_us
                sleep_events += 1
                i = j
            else:
                i += 1

        sleep_ms = total_sleep_us / 1000.0
        avg_ms = sleep_ms / sleep_events if sleep_events > 0 else 0.0

        results.append({
            "itid": int(itid),
            "tid": tid,
            "pid": pid,
            "sleep_ms": round(sleep_ms, 3),
            "sleep_events": sleep_events,
            "avg_ms": round(avg_ms, 3),
        })

    if not results:
        ctx.data = pd.DataFrame(columns=[
            "itid", "tid", "pid", "tname", "sleep_ms", "sleep_events", "avg_ms"
        ])
        ctx.meta["thread_count"] = 0
        ctx.meta["sleep_total_ms"] = 0.0
        ctx.meta["sleep_events"] = 0
        return ctx

    result_df = pd.DataFrame(results)

    # 关联线程名（TraceDataCache 替代 SQL）
    cache = ctx.trace_cache
    if len(result_df):
        meta_dict = cache.thread_meta_all()
        name_map = {itid: (meta[0] or "") for itid, meta in meta_dict.items() if meta}
        result_df["tname"] = result_df["itid"].apply(lambda x: name_map.get(x, ""))

    result_df = result_df.sort_values("sleep_ms", ascending=False).reset_index(drop=True)

    ctx.meta["thread_count"] = len(result_df)
    ctx.meta["sleep_total_ms"] = round(float(result_df["sleep_ms"].sum()), 3)
    ctx.meta["sleep_events"] = int(result_df["sleep_events"].sum())
    ctx.data = result_df
    return ctx


# ---------------------------------------------------------------------------
# sleep_duration: Layer 2 - 收敛睡眠时长摘要
# ---------------------------------------------------------------------------

@register_operator("format_sleep_summary")
def format_sleep_summary(ctx: PreprocessContext) -> PreprocessContext:
    """收敛睡眠时长为 LLM 友好摘要。

    输入:
        ctx.data: compute_sleep_durations 输出的聚合 DataFrame
        ctx.meta: 包含 sleep_total_ms / sleep_events 等统计信息
    输出:
        ctx.data: dict 含 summary / top_sleeping_threads
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "summary": {
                "type": "sleep_duration_summary",
                "thread_count": 0,
                "sleep_total_ms": 0.0,
                "sleep_events": 0,
                "avg_sleep_ms": 0.0,
            },
            "top_sleeping_threads": [],
        }
        return ctx

    thread_count = ctx.meta.get("thread_count", len(df))
    sleep_total_ms = ctx.meta.get("sleep_total_ms", 0.0)
    sleep_events = ctx.meta.get("sleep_events", 0)
    avg_sleep_ms = sleep_total_ms / sleep_events if sleep_events > 0 else 0.0

    # 获取所有 waker 信息（TraceDataCache 替代 SQL）
    waker_info: Dict[int, List[Dict]] = {}
    if len(df):
        try:
            cache = ctx.trace_cache
            itids_set = set(df["itid"].tolist())

            # 从 wakeup_index 聚合每个线程的唤醒者计数（替代 SQL GROUP BY）
            wakeup_idx = cache.wakeup_index()
            waker_map: Dict[int, Dict[int, int]] = {}
            # 批量取 thread 元数据
            meta_dict = cache.thread_meta_all()
            # itid → tid 映射（用于 wakeup_index 查询）
            itid_to_tid = {itid: meta[1] for itid, meta in meta_dict.items() if meta}

            for ref_itid in itids_set:
                ref_tid = itid_to_tid.get(ref_itid)
                if ref_tid is None:
                    continue
                ev_list = wakeup_idx.events.get(ref_tid, [])
                if not ev_list:
                    continue
                # 聚合 from_itid → count
                cnt_map: Dict[int, int] = {}
                for _ts, _from_tid, from_itid in ev_list:
                    if from_itid and from_itid > 0:
                        cnt_map[from_itid] = cnt_map.get(from_itid, 0) + 1
                if cnt_map:
                    waker_map[ref_itid] = cnt_map

            # 获取 waker 线程名（从 cache 批量取）
            all_waker_itids = set()
            for wakers in waker_map.values():
                all_waker_itids.update(wakers.keys())
            waker_names = {itid: (meta_dict[itid][0] or "") for itid in all_waker_itids
                          if itid in meta_dict and meta_dict[itid]}

            # 构建 top_wakers（规则 9: waker_tid 用真实 tid，不用 itid）
            for itid_val, waker_counts in waker_map.items():
                sorted_wakers = sorted(waker_counts.items(), key=lambda x: -x[1])[:3]
                waker_info[itid_val] = [
                    {
                        "waker_tid": itid_to_tid.get(waker_itid, 0),
                        "waker_name": waker_names.get(waker_itid, ""),
                        "wake_count": cnt,
                    }
                    for waker_itid, cnt in sorted_wakers
                ]
        except Exception as e:
            log.debug(f"无法从 cache 获取 waker 信息: {e}")

    # Top N 线程
    top_n = int(ctx.params.get("top_n", 50))
    top_df = df.head(top_n)

    top_threads = []
    for _, row in top_df.iterrows():
        itid_val = int(row["itid"])
        entry = {
            "tid": int(row["tid"]),
            "tname": str(row.get("tname", "")),
            "pid": int(row["pid"]) if "pid" in row and pd.notna(row["pid"]) else None,
            "sleep_ms": float(row["sleep_ms"]),
            "sleep_events": int(row["sleep_events"]),
            "avg_ms": float(row["avg_ms"]),
            "top_wakers": waker_info.get(itid_val, []),
        }
        top_threads.append(entry)

    ctx.data = {
        "summary": {
            "type": "sleep_duration_summary",
            "thread_count": thread_count,
            "sleep_total_ms": sleep_total_ms,
            "sleep_events": sleep_events,
            "avg_sleep_ms": round(avg_sleep_ms, 3),
        },
        "top_sleeping_threads": top_threads,
    }
    return ctx


# ---------------------------------------------------------------------------
# thread_sleep_summary: Layer 1 - 综合分析（Sleep时长 + 唤醒链）
# ---------------------------------------------------------------------------

@register_operator("compute_thread_sleep_summary")
def compute_thread_sleep_summary(ctx: PreprocessContext) -> PreprocessContext:
    """综合分析指定线程的 Sleep 时长和唤醒链（树形版）。

    输入:
        ctx.data: DataFrame 含列 ts / dur / itid / tid / pid / state / tname / pname
    输出:
        ctx.data: DataFrame 含列 duration_ms / start_ns / end_ns / tree
        ctx.meta: sleep_total_ms / sleep_events / avg_sleep_ms / max_sleep_ms /
                  analyzed_segments / tid / tname / pid / pname / blocker_aggregate
    """
    df = ctx.data
    required = {"ts", "itid", "state"}
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(
            f"compute_thread_sleep_summary 输入缺少列: {sorted(missing)}; "
            f"请确认 SQL 输出已包含 {sorted(required)}"
        )

    min_wakeup_us = int(ctx.params.get("min_wakeup_duration_us", 1000))
    blocker_min_cost_ms = float(ctx.params.get("blocker_min_cost_ms", 1.0) or 0)
    max_depth = int(ctx.params.get("max_depth", 5) or 5)
    max_blockers_per_node = int(ctx.params.get("max_blockers_per_node", 5) or 5)
    max_total_nodes = int(ctx.params.get("max_total_nodes", 50) or 50)

    if not len(df):
        ctx.meta["sleep_total_ms"] = 0.0
        ctx.meta["sleep_events"] = 0
        ctx.meta["analyzed_segments"] = 0
        ctx.meta["blocker_aggregate"] = []
        ctx.data = pd.DataFrame(columns=["duration_ms", "start_ns", "end_ns", "tree"])
        return ctx

    df = df.copy()
    df = df.sort_values(["itid", "ts"]).reset_index(drop=True)

    # 获取线程基本信息
    first_row = df.iloc[0]
    tid_val = int(first_row["tid"]) if "tid" in df.columns else 0
    itid_val = int(first_row["itid"])
    pid_val = int(first_row["pid"]) if "pid" in df.columns else 0
    tname_val = (str(first_row.get("tname") or "").strip()) if "tname" in df.columns else ""
    pname_val = (str(first_row.get("pname") or "").strip()) if "pname" in df.columns else ""

    start_ms = ctx.meta.get("start_ms")
    end_ms = ctx.meta.get("end_ms")
    if start_ms is not None and end_ms is not None:
        time_range_start_ns = int(start_ms * 1_000_000)
        time_range_end_ns = int(end_ms * 1_000_000)
    else:
        time_range_start_ns = None
        time_range_end_ns = None

    # sleep_total_ms / sleep_events / avg / max 直接从 S 段 clip 到窗口累加，
    # 与 W-S 匹配解耦：W 匹配遗漏不影响总量准确性。
    # 修复前 bug：sleep_total_ms 从 sleep_segments 累加，W-to-W 间隔被误算
    # 导致虚高 ~3x（43.867ms → 138.150ms）。
    s_rows: list[tuple[int, int]] = []  # [(ts, dur), ...]
    for _, row in df.iterrows():
        if str(row["state"]) == "S":
            s_ts = int(row["ts"])
            s_dur = int(row["dur"]) if row.get("dur") is not None else 0
            s_rows.append((s_ts, s_dur))

    sleep_total_ns = 0
    sleep_durations_ms: list[float] = []
    for s_ts, s_dur in s_rows:
        # clip 到窗口
        begin = s_ts if time_range_start_ns is None else max(s_ts, time_range_start_ns)
        end = (s_ts + s_dur) if time_range_end_ns is None else min(s_ts + s_dur, time_range_end_ns)
        if end > begin:
            dur_ms = round((end - begin) / 1_000_000.0, 3)
            sleep_total_ns += (end - begin)
            sleep_durations_ms.append(dur_ms)

    sleep_events_count = len(sleep_durations_ms)
    sleep_total_ms_val = round(sleep_total_ns / 1_000_000.0, 3)
    max_sleep_ms_val = max(sleep_durations_ms) if sleep_durations_ms else 0.0

    ctx.meta["sleep_total_ms"] = sleep_total_ms_val
    ctx.meta["sleep_events"] = sleep_events_count
    ctx.meta["avg_sleep_ms"] = round(sleep_total_ms_val / sleep_events_count, 3) if sleep_events_count > 0 else 0.0
    ctx.meta["max_sleep_ms"] = max_sleep_ms_val
    ctx.meta["tid"] = tid_val
    ctx.meta["tname"] = tname_val
    ctx.meta["pid"] = pid_val
    ctx.meta["pname"] = pname_val

    # 构建 sleep_segments 用于 wakeup_chain_detail / blocker_aggregate。
    # 这些 segment 需要关联 waker_from，所以仍走 W-S 匹配逻辑，
    # 但不再用于 sleep_total_ms（已上直接从 S 段累加）。
    events: List[Tuple[int, str, Any]] = []
    for s_ts, s_dur in s_rows:
        events.append((s_ts, "S", float(s_dur)))

    cache = ctx.trace_cache
    wakeup_idx_for_events = cache.wakeup_index()
    ev_list = wakeup_idx_for_events.events.get(tid_val, [])
    if time_range_start_ns is not None and time_range_end_ns is not None:
        ts_list = wakeup_idx_for_events.ts_only.get(tid_val, [])
        idx_lo = _bisect.bisect_left(ts_list, time_range_start_ns)
        idx_hi = _bisect.bisect_right(ts_list, time_range_end_ns)
        for i in range(idx_lo, idx_hi):
            ts, _from_tid, from_itid = ev_list[i]
            if from_itid:
                events.append((ts, "W", from_itid))
    else:
        for ts, _from_tid, from_itid in ev_list:
            if from_itid:
                events.append((ts, "W", from_itid))

    events.sort(key=lambda x: -x[0])

    sleep_segments: list[dict[str, Any]] = []
    # 容差：W.ts 应在 S 段结束点附近（wakeup 发生在 Sleep 结束时）。
    # 实测 140 个真实 W 事件都在 S.ts+S.dur ±1us 内，取 5us 容差留余量。
    # bug 复现：原代码不校验 events[j] 类型也不校验 W 是否对应 S 段结束点，
    # 把"W-to-W 间隔"（314/454 次）和"W 远离 S 段结束点"都算成 Sleep，
    # 导致 sleep_total_ms 虚高 ~3x（43.867ms → 138.150ms）。
    # 修复后 sleep_total_ms 已独立从 S 段累加，此处匹配仅用于唤醒链 detail，
    # 但仍保留校验避免向 wakeup_chain_detail 注入假 segment。
    # 匹配条件：W 在 S 段结束点 ±容差 范围内（双向校验，避免 W 在 S 段中间误匹配）。
    # 一个 S 段只匹配一个 W（一对一：一次 Sleep 只被唤醒一次）。
    matched_s_indices: set[int] = set()
    for i, (ts, typ, val) in enumerate(events):
        if typ == "W":
            if time_range_start_ns is not None and (ts < time_range_start_ns or ts > time_range_end_ns):
                continue
            # 找最近的前一个 S 事件，且 W.ts 在 S 段结束点 ±容差 范围内。
            for j in range(i + 1, len(events)):
                if events[j][1] != "S":
                    continue
                if j in matched_s_indices:
                    continue
                s_ts, _, s_dur = events[j]
                s_end = s_ts + s_dur
                # W 必须在 S 段结束点附近（双向校验：上界 + 下界）
                if s_end - WAKEUP_TOLERANCE_NS <= ts <= s_end + WAKEUP_TOLERANCE_NS:
                    begin = s_ts
                    end = ts
                    # 跨边界 S 段：clamp 到 time_range_start_ns，而不是整个丢弃。
                    # 原行为 break 会把 ts < 区间起点但 (ts+dur) 跨越起点的长 S 段丢了，
                    # 导致丢帧区间内最长的 Sleep（通常是核心瓶颈）被漏分析。
                    # clamp 后 block_ms 反映该段在区间内的实际贡献，窗口下游分析不变。
                    if time_range_start_ns is not None and begin < time_range_start_ns:
                        begin = time_range_start_ns
                    waker_from = val
                    duration_ms = round((end - begin) / 1_000_000.0, 3)
                    sleep_segments.append({
                        "itid": itid_val,
                        "start_time": begin,
                        "end_time": end,
                        "waker_from": waker_from,
                        "duration_ms": duration_ms,
                    })
                    matched_s_indices.add(j)
                    break

    if not sleep_segments:
        # sleep_total_ms 等已从 S 段直接累加，此处仅需清理唤醒链相关字段。
        ctx.meta["analyzed_segments"] = 0
        ctx.meta["blocker_aggregate"] = []
        ctx.data = pd.DataFrame(columns=["duration_ms", "start_ns", "end_ns", "tree"])
        return ctx

    # 批量字典全部在循环外取一次（§7.6）
    wakeup_idx = cache.wakeup_index()
    meta_dict = cache.thread_meta_all()
    pn_dict = cache.process_name_all()
    process_names: Dict[int, str] = {ipid: pn for ipid, pn in pn_dict.items() if pn}
    itid_to_ipid: Dict[int, int] = {itid: meta[2] for itid, meta in meta_dict.items() if meta}
    callstack_cache, callstack_ts_only_cache, callstack_max_dur_cache = cache.sleep_callstack_view()
    thread_state_cache, thread_state_ts_only_cache = cache.sleep_thread_state_view()
    prio_map = cache.sleep_prio_map()

    # 外层循环（spec §3.2）
    results = []
    blocker_agg: Dict[int, dict] = {}

    for seg in sleep_segments:
        if seg["duration_ms"] * 1000 < min_wakeup_us:
            continue

        budget = [max_total_nodes]
        tree = build_blocking_tree(
            blocked_tid=tid_val, blocked_itid=itid_val,
            window_start=seg["start_time"], window_end=seg["end_time"],
            depth=0, visited=set(), budget=budget,
            wakeup_idx=wakeup_idx,
            max_depth=max_depth,
            blocker_min_cost_ms=blocker_min_cost_ms,
            max_blockers_per_node=max_blockers_per_node,
            meta_dict=meta_dict,
            process_names=process_names,
            itid_to_ipid=itid_to_ipid,
            callstack_cache=callstack_cache,
            callstack_ts_only_cache=callstack_ts_only_cache,
            callstack_max_dur_cache=callstack_max_dur_cache,
            thread_state_cache=thread_state_cache,
            thread_state_ts_only_cache=thread_state_ts_only_cache,
            prio_map=prio_map,
        )
        if not tree:
            continue

        tree["block_ms"] = round(seg["duration_ms"], 3)
        tree["blocked_state"] = "S"
        _aggregate_blocker(blocker_agg, tree)
        results.append({
            "duration_ms": seg["duration_ms"],
            "start_ns": seg["start_time"],
            "end_ns": seg["end_time"],
            "tree": tree,
        })

    # Guard: sleep_segments 非空但全部被 min_wakeup_us 过滤或 tree is None 时，
    # results 为空，pd.DataFrame([]) 会丢失列定义。返回带正确 schema 的空 DataFrame。
    if not results:
        ctx.meta["blocker_aggregate"] = _finalize_blocker_agg(blocker_agg)
        ctx.meta["analyzed_segments"] = 0
        ctx.data = pd.DataFrame(columns=["duration_ms", "start_ns", "end_ns", "tree"])
        return ctx

    results.sort(key=lambda x: -x["duration_ms"])
    ctx.meta["blocker_aggregate"] = _finalize_blocker_agg(blocker_agg)
    ctx.meta["analyzed_segments"] = len(results)
    ctx.data = pd.DataFrame(results)
    return ctx


# ---------------------------------------------------------------------------
# thread_sleep_summary: Layer 2 - 收敛综合分析结果
# ---------------------------------------------------------------------------

@register_operator("format_thread_sleep_summary")
def format_thread_sleep_summary(ctx: PreprocessContext) -> PreprocessContext:
    """收敛线程 Sleep 综合分析为 LLM 友好格式（spec §5）。

    输入:
        ctx.data: compute_thread_sleep_summary 输出的 DataFrame
        ctx.meta: sleep_total_ms / sleep_events / avg_sleep_ms / max_sleep_ms /
                  analyzed_segments / blocker_aggregate / tid / tname / pid / pname /
                  start_ms（trace 时间窗口起点，用于 offset 计算）
    输出:
        ctx.data: dict 含 summary / blocker_aggregate / wakeup_chain_detail /
                  headline / text / _legend_fragments（spec §5）
    """
    max_detail_count = int(ctx.params.get("max_detail_count", 3) or 3)
    blocker_aggregate_top_n = int(ctx.params.get("blocker_aggregate_top_n", 5) or 5)

    df = ctx.data
    target_pname = ctx.meta.get("pname", "")
    frame_start_ms = ctx.meta.get("start_ms", 0) or 0

    # legend fragments（spec §4.3）
    legend_fragments = {
        "prio": LEGEND_PRIO,
        "sleep_row": LEGEND_SLEEP_ROW,
        "chain_tree": LEGEND_CHAIN_TREE,
        "time_offset": LEGEND_TIME_OFFSET,
    }

    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "summary": {
                "type": "thread_sleep_summary",
                "tid": ctx.meta.get("tid", 0),
                "tname": ctx.meta.get("tname", ""),
                "pid": ctx.meta.get("pid", 0),
                "pname": ctx.meta.get("pname", ""),
                "sleep_total_ms": ctx.meta.get("sleep_total_ms", 0.0),
                "sleep_events": ctx.meta.get("sleep_events", 0),
                "analyzed_segments": ctx.meta.get("analyzed_segments", 0),
                "shown_segments": 0,
            },
            "wakeup_chain_detail": [],
            "headline": "",
            "text": "",
            "_legend_fragments": legend_fragments,
        }
        return ctx

    top_df = df.head(max_detail_count)
    detail = []
    for _, row in top_df.iterrows():
        tree = row["tree"] if "tree" in row else None
        seg_duration_ms = float(row["duration_ms"])
        chain_text = _render_tree_text(tree, target_pname, seg_duration_ms) if tree else ""
        raw_start_ns = int(row["start_ns"])
        raw_end_ns = int(row["end_ns"])
        offset_ms = round(raw_start_ns / 1_000_000.0 - frame_start_ms, 3)
        detail.append({
            "duration_ms": seg_duration_ms,
            "raw_start_ns": raw_start_ns,
            "raw_end_ns": raw_end_ns,
            "offset_from_frame_start_ms": offset_ms,
            "chain_text": chain_text,
        })

    sleep_events = ctx.meta.get("sleep_events", 0)
    summary = {
        "type": "thread_sleep_summary",
        "tid": ctx.meta.get("tid", 0),
        "tname": ctx.meta.get("tname", ""),
        "pid": ctx.meta.get("pid", 0),
        "pname": ctx.meta.get("pname", ""),
        "sleep_total_ms": ctx.meta.get("sleep_total_ms", 0.0),
        "sleep_events": sleep_events,
        "analyzed_segments": ctx.meta.get("analyzed_segments", 0),
        "shown_segments": len(detail),
    }
    if sleep_events > 1:
        summary["avg_sleep_ms"] = ctx.meta.get("avg_sleep_ms", 0.0)
        summary["max_sleep_ms"] = ctx.meta.get("max_sleep_ms", 0.0)

    blockers = ctx.meta.get("blocker_aggregate", [])[:blocker_aggregate_top_n]

    # headline（spec §5.1）
    headline = _build_sleep_headline(summary, blockers)

    # text（spec §5.2）
    text = _build_sleep_text(blockers, target_pname)

    ctx.data = {
        "headline": headline,
        "text": text,
        "summary": summary,
        "wakeup_chain_detail": detail,
        "_legend_fragments": legend_fragments,
    }
    return ctx


def _build_sleep_headline(summary: dict, blockers: list) -> str:
    """spec §5.1：{sleep_total_ms}ms/{sleep_events}次(单次max {max_sleep_ms}ms)；最大阻塞者 ..."""
    sleep_total = summary.get("sleep_total_ms", 0.0)
    events = summary.get("sleep_events", 0)
    max_ms = summary.get("max_sleep_ms", 0.0)
    parts = [f"{sleep_total}ms/{events}次"]
    if events > 1:
        parts.append(f"(单次max {max_ms}ms)")
    head = "".join(parts)
    if not blockers:
        return head
    top1 = blockers[0]
    name = top1.get("thread_name", "")
    total = top1.get("total_block_ms", 0.0)
    func_full = top1.get("function", "")
    func_short = shorten_func_name(func_full) if func_full else ""
    tail = f"；最大阻塞者 {name} {total}ms"
    if func_short:
        tail += f" ({func_short})"
    return head + tail


def _build_sleep_text(blockers: list, target_pname: str) -> str:
    """spec §5.2：每行一个阻塞者，同进程省略 @process_name。"""
    if not blockers:
        return ""
    lines = []
    for b in blockers:
        name = b.get("thread_name", "")
        tid = b.get("tid", 0)
        prio = b.get("prio", -1)
        proc = b.get("process_name", "")
        total = b.get("total_block_ms", 0.0)
        events = b.get("block_events", 0)
        func_full = b.get("function", "")
        proc_suffix = f"@{proc}" if proc and proc != target_pname else ""
        prio_suffix = f", prio={prio}" if prio is not None and prio != -1 else ""
        line = f"{name}({tid}{prio_suffix}){proc_suffix}: {total}ms/{events}次"
        if events > 1:
            avg = b.get("avg_block_ms")
            if avg is None:
                avg = round(total / events, 3)
            line += f" (单次avg {avg}ms)"
        if func_full:
            line += f"  {func_full}"
        lines.append(line)
    return "\n".join(lines)
