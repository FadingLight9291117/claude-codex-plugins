# -*- coding: utf-8 -*-
"""单线程调度调频分析算子。

将 thread_state 状态时长计算 + sched metadata 增强 + SMT residency 频点分析
合并为一个 pipeline 算子，输出统一的单线程调度全景数据。

SQL 通过 data_source 列区分行来源：
  - 'thread_state': 线程状态数据，用于计算 running/runnable 时长
  - 'freq_data':    freq+Running 数据，用于 SMT residency 频点分析
  - 'temp_data':    温度传感器数据（shell_frame_temp / soc_temp）

输出各字段值对齐 cpu_freq.summary + thread_state_durations.top_threads[0]。
"""
from __future__ import annotations

from core.observability import get_module_logger
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .trace_data_cache import TraceDataCache

import numpy as np
import pandas as pd

from .base import PreprocessContext, register_operator
from .sched_ops import (
    _is_running,
    _is_runnable,
)
from .smt_ops import (
    _smt_residency_one_core,
)
from .chip_config import (
    get_top_cluster,
    get_cpu_load_by_compute_scale,
    get_top_cluster_max_load,
)

log = get_module_logger(__name__)


def _get_sched_class(priority: int) -> str:
    """鸿蒙调度类：interrupt(>=100) / rt([40,100)) / cfs([0,40))。

    鸿蒙优先级语义：
      - [0, 39]: 普通任务（CFS），公式 19 - nice
      - [40, 99]: 实时任务（RT）
      - >=100: 中断线程
    """
    if priority >= 100:
        return "interrupt"
    elif priority >= 40:  # [40, 100) 为 RT
        return "rt"
    else:
        return "cfs"


def _calculate_big_occupy_duration(
    running_start: int, running_end: int, occupy_df: pd.DataFrame
) -> float:
    """计算其他线程在大核上的 Running 切片与当前 running 区间的重叠时长。

    对齐 CpuExecLinkInfo.calculate_big_cpu_occupy()：
    用 sweep-line 扫描 ENTER/EXIT 事件，多个占用同时存在时重叠区间只算一次。

    Args:
        running_start: 当前 running 时间片起始（ns）
        running_end:   当前 running 时间片结束（ns）
        occupy_df:     其他线程在大核上的 Running 切片

    Returns:
        重叠总时长（ns）
    """
    if occupy_df.empty or running_end <= running_start:
        return 0.0

    # 向量化 clip + 过滤（替代 pandas copy/clip/iterrows）
    ts_start = occupy_df["ts_start"].to_numpy(dtype=np.int64)
    ts_end = occupy_df["ts_end"].to_numpy(dtype=np.int64)
    s = np.maximum(ts_start, np.int64(running_start))
    e = np.minimum(ts_end, np.int64(running_end))
    mask = s < e
    if not mask.any():
        return 0.0
    s = s[mask]
    e = e[mask]

    # sweep-line：构建 (timestamp, delta) 事件数组，stable sort 保证同时刻先退出(-1)后进入(+1)
    n = s.shape[0]
    events_ts = np.empty(2 * n, dtype=np.int64)
    events_delta = np.empty(2 * n, dtype=np.int8)
    events_ts[:n] = s
    events_ts[n:] = e
    events_delta[:n] = 1
    events_delta[n:] = -1
    order = np.argsort(events_ts, kind="stable")
    events_ts = events_ts[order]
    events_delta = events_delta[order]

    # 累加深度>0 的区间时长
    total = np.int64(0)
    depth = 0
    last_ts = events_ts[0]
    for i in range(events_ts.shape[0]):
        ts = events_ts[i]
        if depth > 0 and ts > last_ts:
            total += ts - last_ts
        depth += events_delta[i]
        last_ts = ts
    return float(total)


def _match_freq_limit_for_interval(
    interval_start: int, interval_end: int, cpuid: int, freq_limit_df: pd.DataFrame
) -> Optional[float]:
    """为单个时间片匹配生效的限频值（MHz）。

    对齐 do_calculate 的 big_freq_limit_info.max_freq 语义：
    当时间片横跨多个限频区间时，取最大值代表"该时间片能用的最高频"。

    Args:
        interval_start: 时间片起始（ns）
        interval_end:   时间片结束（ns）
        cpuid:          CPU ID
        freq_limit_df:  限频切片 DataFrame（已按 cpuid, ts_start 排序）

    Returns:
        生效限频值（MHz），无限频记录或无重叠时返回 None
    """
    if freq_limit_df.empty:
        return None
    cpu_df = freq_limit_df[freq_limit_df["cpuid"] == cpuid]
    if cpu_df.empty:
        return None
    # 筛选与时间片有交集的限频记录
    overlap = cpu_df[
        (cpu_df["ts_end"] > interval_start) & (cpu_df["ts_start"] < interval_end)
    ]
    if overlap.empty:
        return None
    return float(overlap["max_freq_mhz"].max())


def _build_df_from_cache(
    cache: TraceDataCache,
    frame_start_ns: int,
    frame_end_ns: int,
    tid_filter: Optional[int],
    filter_thread_name: Optional[str],
    filter_process_name: Optional[str],
) -> pd.DataFrame:
    """从 TraceDataCache 构建等效于 YAML 4-UNION-ALL SQL 的 DataFrame。

    替代 Path A：YAML sql 已改为空 stub，数据由本函数从 cache 拉取，
    避免每帧 4 段 UNION ALL 重复扫 SQLite（24.8s → ~0s）。

    4 个分支映射：
      - 分支1 (thread_state) → cache.thread_state(itid, start, end) 按 itid
      - 分支2 (freq_data/running) → 同上，过滤 Running
      - 分支3 (freq_data/freq) → cache.measure('cpu_frequency', ...)
      - 分支4 (temp_data) → cache.measure_no_cpu('shell_frame_temp/soc_temp', ...)

    性能关键：用 cache.thread_state(itid, start, end) 按 itid 交集过滤，
    而非遍历全量 thread_state_all()（1.2M 行遍历导致 36s 瓶颈）。
    """
    _, trace_end_ns = cache.trace_range()
    ts_rows: list = []  # 分支1
    running_rows: list = []  # 分支2
    freq_rows: list = []  # 分支3
    temp_rows: list = []  # 分支4

    # 元数据（用于 tname + 过滤）
    meta_dict = cache.thread_meta_all()
    pid_to_pname: Dict[int, str] = {}
    if filter_process_name:
        pid_to_pname = cache.process_name_all()

    valid_states = {'Running', 'R', 'R+', 'S', 'D-IO', 'D-NIO', 'D', 'D|W', 'I', 'X', 'Z'}

    # 分支1 + 分支2：thread_state（按 itid 交集过滤，而非遍历全量）
    for itid, meta in meta_dict.items():
        tname = meta[0] if meta else ""
        # 提前过滤：filter_thread_name
        if filter_thread_name and filter_thread_name not in tname:
            continue
        rows = cache.thread_state(itid, frame_start_ns, frame_end_ns)
        for r in rows:
            # r: (ts, dur, state, cpu, tid, pid, itid, arg_setid)
            ts_val, dur_val, state = r[0], r[1], r[2]
            cpu, tid, pid, itid2 = r[3], r[4], r[5], r[6]
            ts_end = (ts_val + dur_val) if dur_val else trace_end_ns

            if state in valid_states:
                if tid_filter is not None and tid != tid_filter:
                    # 分支1 跳过，但分支2 仍需（不过滤 tid）
                    if state == 'Running' and cpu is not None:
                        running_rows.append((
                            ts_val, ts_end, dur_val, cpu, itid2, tid, pid,
                            None, None, 'freq_data', 'running', 0,
                        ))
                    continue
                if filter_process_name:
                    pname = pid_to_pname.get(pid, "")
                    if filter_process_name not in pname:
                        continue
                ts_rows.append((
                    ts_val, ts_end, dur_val, cpu, itid2, tid, pid,
                    state, tname, 'thread_state', None, None,
                ))

            # 分支2：所有 Running（不过滤 tid，SMT 需要全量）
            if state == 'Running' and cpu is not None:
                running_rows.append((
                    ts_val, ts_end, dur_val, cpu, itid2, tid, pid,
                    None, None, 'freq_data', 'running', 0,
                ))

    # 分支3：cpu_frequency
    raw_freq = cache.measure('cpu_frequency', frame_start_ns, frame_end_ns)
    for ts_val, dur_val, value, cpuid in raw_freq:
        ts_end = (ts_val + dur_val) if dur_val else trace_end_ns
        dur_eff = dur_val if dur_val else (trace_end_ns - ts_val)
        if dur_eff <= 0:
            continue
        freq_rows.append((
            ts_val, ts_end, dur_eff, cpuid, None, None, None,
            None, None, 'freq_data', 'freq', value / 1000.0,
        ))

    # 分支4：温度传感器
    for sensor_name in ('shell_frame_temp', 'soc_temp'):
        raw_temp = cache.measure_no_cpu(sensor_name, frame_start_ns, frame_end_ns)
        for ts_val, dur_val, value in raw_temp:
            ts_end = (ts_val + dur_val) if dur_val else trace_end_ns
            dur_eff = dur_val if dur_val else (trace_end_ns - ts_val)
            temp_rows.append((
                ts_val, ts_end, dur_eff, None, None, None, None,
                None, None, 'temp_data', sensor_name, value / 1000.0,
            ))

    all_rows = ts_rows + running_rows + freq_rows + temp_rows
    if not all_rows:
        return pd.DataFrame(columns=[
            "ts_start", "ts_end", "dur", "cpuid", "itid", "tid", "pid",
            "state", "tname", "data_source", "data_type", "freq",
        ])

    return pd.DataFrame(all_rows, columns=[
        "ts_start", "ts_end", "dur", "cpuid", "itid", "tid", "pid",
        "state", "tname", "data_source", "data_type", "freq",
    ])


@register_operator("thread_sched_analysis")
def thread_sched_analysis(ctx: PreprocessContext) -> PreprocessContext:
    """单线程调度+调频全景分析。

    输入 ctx.data: DataFrame，含 data_source 列区分行来源。
    输出 ctx.data: dict { thread, sched, state, migration, freq }。
    """
    tid_filter = ctx.params.get("tid")
    # Task 11: cache 由 query_engine.py 始终注入（Task 6 后），不再判 None。
    cache = ctx.trace_cache

    frame_start_ns = (ctx.meta.get("start_ms") or 0) * 1_000_000
    frame_end_ns = (ctx.meta.get("end_ms") or 0) * 1_000_000

    # Path A: YAML SQL 已改为空 stub，从 TraceDataCache 构建 DataFrame
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or len(df) == 0 or "data_source" not in df.columns:
        if cache is None:
            ctx.data = {"error": "输入数据为空且 trace_cache 不可用"}
            return ctx
        filter_thread_name = ctx.params.get("filter_thread_name")
        filter_process_name = ctx.params.get("filter_process_name")
        df = _build_df_from_cache(
            cache, frame_start_ns, frame_end_ns, tid_filter,
            filter_thread_name, filter_process_name,
        )
        if df.empty:
            ctx.data = {"error": "输入数据为空"}
            return ctx

    # Part 1: 线程状态时长计算
    # 仅取 data_source='thread_state' 的行（freq_data+running 行用于 Part 3 SMT）
    # =========================================================================
    # 区间交集查询可能返回 ts_start < frame_start 的行，需 clamp 到帧范围内
    # 否则 dur 会包含帧外时间，导致 running/runnable 偏大
    frame_start_ns = (ctx.meta.get("start_ms") or 0) * 1_000_000
    frame_end_ns = (ctx.meta.get("end_ms") or 0) * 1_000_000
    if frame_start_ns > 0 and frame_end_ns > frame_start_ns:
        ts_col = df["ts_start"].astype(float)
        te_col = df["ts_end"].astype(float)
        df["ts_start"] = ts_col.clip(lower=frame_start_ns)
        df["ts_end"] = te_col.clip(upper=frame_end_ns)
        df["dur"] = df["ts_end"] - df["ts_start"]

    ts_df = df[df["data_source"] == "thread_state"].copy()

    thread_result: Dict[str, Any] = {}
    state_durations: Dict[str, Any] = {}

    if len(ts_df) > 0:
        ts_df = ts_df.sort_values(["itid", "ts_start"]).reset_index(drop=True)

        for itid, group in ts_df.groupby("itid"):
            group_tid = int(group["tid"].iloc[0]) if "tid" in group.columns else 0
            if tid_filter is not None and group_tid != tid_filter:
                continue

            group = group.sort_values("ts_start").reset_index(drop=True)
            n = len(group)

            running_ms = 0.0
            runnable_ms = 0.0
            runnable_events = 0
            last_r_ts: Optional[float] = None

            # 提前转 numpy 数组，避免 iloc 在 while 循环中产生 Series 开销
            # 保留 NaN（不 fillna）：dur=NULL 表示"该状态切片时长未知"
            # 累加时跳过 NaN 行（不污染整线程，不当作 0），同线程其他正常行保留
            ts_arr = group["ts_start"].values.astype(float)
            state_arr = group["state"].values.astype(str)
            dur_arr = pd.to_numeric(group["dur"], errors="coerce").values.astype(float)

            i = 0
            while i < n:
                ts_val = ts_arr[i]
                state = state_arr[i]
                dur_val = dur_arr[i]
                dur_is_nan = pd.isna(dur_val)

                if _is_running(state):
                    if not dur_is_nan:
                        running_ms += dur_val / 1_000_000.0
                    if last_r_ts is not None:
                        gap_ms = (ts_val - last_r_ts) / 1_000_000.0
                        if gap_ms >= 0:
                            runnable_ms += gap_ms
                            runnable_events += 1
                        last_r_ts = None
                    i += 1
                elif _is_runnable(state):
                    last_r_ts = ts_val
                    i += 1
                else:
                    last_r_ts = None
                    i += 1

            tid_val = int(group["tid"].iloc[0]) if "tid" in group.columns else group_tid
            pid_val = int(group["pid"].iloc[0]) if "pid" in group.columns and pd.notna(group["pid"].iloc[0]) else 0
            tname = str(group["tname"].iloc[0]) if "tname" in group.columns else ""

            window_ms = (ctx.meta.get("end_ms") or 0) - (ctx.meta.get("start_ms") or 0)
            runnable_ratio = round(runnable_ms / window_ms * 100, 1) if window_ms > 0 else 0.0

            thread_result = {"tid": tid_val, "tname": tname, "pid": pid_val}
            state_durations = {
                "running_ms": round(running_ms, 3),
                "runnable_ms": round(runnable_ms, 3),
                "runnable_ratio": runnable_ratio,
            }
            break  # 只取 tid_filter 匹配的线程

        # 查进程名（O(1) TraceDataCache 替代 N+1 SQL）
        # cache.get_thread(tid).process_name 链路：tid → itid → ipid → process_name
        # 与原 SQL `SELECT name FROM process WHERE pid=?` 语义一致
        # （process 表有 pid 和 ipid 两列，cache 用 ipid 索引；tname/pid 已在 thread_state
        # 数据中，process_name 通过 thread 表的 itid→ipid 关联取）
        # Task 11: cache 由 query_engine.py 始终注入，无需 None 兜底。
        process_name = ""
        if thread_result.get("tid"):
            try:
                pn = cache.get_thread(int(thread_result["tid"])).process_name
                if pn:
                    process_name = pn.strip()
            except Exception:
                log.debug("trace_cache 查 process_name 失败 for tid=%s",
                          thread_result.get("tid"))
        thread_result["process_name"] = process_name

    # =========================================================================
    # Part 2: 调度元数据增强（priority / migration / preemption）
    # =========================================================================
    sched_result: Dict[str, Any] = {"priority": 0, "sched_class": "cfs"}
    migration_result: Dict[str, Any] = {"migration_count": 0, "preemption_count": 0}

    if tid_filter is not None:
        # sched_slice 只有 itid, 需要先通过 thread 表查 itid
        # O(1) TraceDataCache 替代 3 处 N+1 SQL（itid/priority/migration+preemption）
        # Task 11: cache 由 query_engine.py 始终注入，无需 None 兜底。
        try:
            thread_info = cache.get_thread(int(tid_filter))
            itid_val = thread_info.itid
            if itid_val:
                # priority: 首条 sched_slice 的 priority（用 trace_range 作窗口上界）
                priority = thread_info.get_priority_first()
                if priority:
                    sched_result = {
                        "priority": priority,
                        "sched_class": _get_sched_class(priority),
                    }

                # migration_count + preemption_count
                # cache.sched_slice 已用区间交集 (ts+dur > start AND ts < end)
                # 直接使用，无需后过滤（规则 30：统一用区间交集，不再保留旧 SQL 端点包含语义）
                start_ms = ctx.meta.get("start_ms") or 0
                end_ms = ctx.meta.get("end_ms") or 0
                start_ns = int(start_ms * 1_000_000)
                end_ns = int(end_ms * 1_000_000)
                slices = cache.sched_slice(itid_val, start_ns, end_ns)
                if len(slices) > 0:
                    # migration_count: 相邻切片 cpu 不同则 +1（对齐 LAG(cpu) OVER (... ORDER BY ts)）
                    cpu_arr = [s[2] for s in slices]
                    migration_count = sum(
                        1 for i in range(1, len(cpu_arr))
                        if cpu_arr[i] != cpu_arr[i - 1]
                    )
                    # preemption_count: end_state == 'R+' 的行数
                    preemption_count = sum(1 for s in slices if s[3] == "R+")
                    migration_result = {
                        "migration_count": int(migration_count),
                        "preemption_count": int(preemption_count),
                    }
        except Exception:
            log.debug("trace_cache 获取 sched metadata 失败 for tid=%s", tid_filter)

    # Part 3: 频点分布 — 基于 Raw Running 做集群时长，SMT residency 做频点/MT-ST
    # =========================================================================
    freq_df = df[df["data_source"] == "freq_data"].copy()
    freq_summary: Dict[str, Any] = {"cluster_stats": {}, "compute_supply": "0%"}
    supply_breakdown: Dict[str, Any] = {}

    if len(freq_df) > 0 and tid_filter is not None:
        try:
            freq_df = freq_df.dropna(subset=["ts_end"])

            chip_config = cache.chip_config()
            if chip_config:
                # 先构建 cpuid→cluster 映射
                cpuid_cluster_map: Dict[int, Optional[str]] = {}
                for cpuid in sorted(freq_df["cpuid"].unique()):
                    cpuid_cluster_map[int(cpuid)] = cache.cluster_of(int(cpuid))

                # === 真实 Running 时长（按 cluster 聚合，不用 smt_residency 的区间时长）===
                # df_running_raw 包含所有线程的 running（用于 SMT MT/ST 检测，需要 sibling 核数据）
                # 但 raw_cluster 聚合只统计当前 tid 的 running（线程级视角）
                df_running_raw = freq_df[freq_df["data_type"] == "running"]
                # raw running: 直接按 cluster 聚合当前 tid 的 Running dur
                raw_cluster: Dict[str, float] = {}
                for _, run_row in df_running_raw[df_running_raw["tid"] == tid_filter].iterrows():
                    cpuid = int(run_row["cpuid"])
                    cl = cpuid_cluster_map.get(cpuid, "unknown")
                    dur_ms = (float(run_row["ts_end"]) - float(run_row["ts_start"])) / 1e6
                    raw_cluster[cl] = raw_cluster.get(cl, 0.0) + dur_ms

                total_raw_ms = sum(raw_cluster.values())

                # === SMT residency 用于频点加权和 ST/MT 比例 ===
                df_running = df_running_raw
                df_freq = freq_df[freq_df["data_type"] == "freq"]

                filtered_cpuid_list = sorted(cpuid_cluster_map.keys())

                running_by_cpuid: Dict[int, pd.DataFrame] = {
                    int(cpuid): g for cpuid, g in df_running.groupby(df_running["cpuid"])
                }

                freq_by_cpuid: Dict[int, pd.DataFrame] = {
                    int(cpuid): g for cpuid, g in df_freq.groupby(df_freq["cpuid"])
                }

                # sibling 对
                sibling_pairs: set = set()
                for cpuid in filtered_cpuid_list:
                    sib = cache.sibling_of(cpuid)
                    if sib is not None:
                        sibling_pairs.add((min(cpuid, sib), max(cpuid, sib)))

                for cpuid, sib in sibling_pairs:
                    if sib not in running_by_cpuid:
                        running_by_cpuid[sib] = df_running[df_running["cpuid"] == sib]

                # 计算 MT/ST intervals（仅用于频点加权和 ST/MT 比例）
                # 性能优化：只对 tid_filter 有 Running 的 cpuid 计算 SMT。
                # SMT intervals 最终只过滤 tid_intervals 使用，无 tid_filter Running 的核
                # 不会产生 tid_filter 的 interval，可安全跳过（兄弟核 SMT 数据仍通过
                # sibling 机制获取）。14 核 → 通常 1-3 核，省 7ms/帧。
                all_intervals: List[Dict[str, Any]] = []
                for cpuid in filtered_cpuid_list:
                    # 早期过滤：tid_filter 在该核无 Running 则跳过
                    df_run_cpuid = running_by_cpuid.get(cpuid, pd.DataFrame())
                    if df_run_cpuid.empty or not (df_run_cpuid["tid"] == tid_filter).any():
                        continue

                    sibling_cpuid = cache.sibling_of(cpuid)
                    cluster = cpuid_cluster_map.get(cpuid, "unknown")
                    smt_on = sibling_cpuid is not None

                    df_freq_core = freq_by_cpuid.get(cpuid)
                    if df_freq_core is None or df_freq_core.empty:
                        continue

                    df_run_sib = (
                        running_by_cpuid.get(sibling_cpuid, pd.DataFrame())
                        if sibling_cpuid else pd.DataFrame()
                    )

                    intervals = _smt_residency_one_core(
                        cpuid, sibling_cpuid, df_freq_core, df_run_cpuid, df_run_sib, smt_on,
                    )
                    for iv in intervals:
                        iv["cpuid"] = int(cpuid)
                        iv["cluster"] = cluster
                    all_intervals.extend(intervals)

                # 筛选 tid_filter 的区间，用于频点加权
                tid_intervals = [
                    iv for iv in all_intervals
                    if iv.get("tid") == tid_filter
                ]

                # 按 cluster 聚合频点加权和 ST/MT
                cluster_freq: Dict[str, Dict[str, float]] = {}
                for iv in tid_intervals:
                    cl = iv.get("cluster", "unknown")
                    if cl not in cluster_freq:
                        cluster_freq[cl] = {
                            "weighted_freq_sum": 0.0, "interval_dur": 0.0,
                            "st_dur": 0.0, "mt_dur": 0.0,
                        }
                    dur_ns = float(iv["ts_end"] - iv["ts_start"])
                    dur_ms = dur_ns / 1e6
                    cluster_freq[cl]["weighted_freq_sum"] += dur_ms * iv["freq"]
                    cluster_freq[cl]["interval_dur"] += dur_ms
                    if iv.get("is_mt"):
                        cluster_freq[cl]["mt_dur"] += dur_ms
                    else:
                        cluster_freq[cl]["st_dur"] += dur_ms

                # 组装 cluster_stats: total_duration_ms/duration_ratio 用 raw running
                cluster_stats: Dict[str, Dict[str, Any]] = {}
                for cl in raw_cluster:
                    raw_dur = raw_cluster[cl]
                    ratio = round(raw_dur / total_raw_ms * 100, 1) if total_raw_ms > 0 else 0

                    cf = cluster_freq.get(cl, {})
                    interval_dur = cf.get("interval_dur", 0)
                    st_dur = cf.get("st_dur", 0)
                    mt_dur = cf.get("mt_dur", 0)
                    # 频点：用 interval_dur 加权平均（归一化到 interval_dur，不是 raw_dur）
                    avg_freq = cf["weighted_freq_sum"] / interval_dur if interval_dur > 0 else 0
                    st_ratio = st_dur / interval_dur * 100 if interval_dur > 0 else 0
                    mt_ratio = mt_dur / interval_dur * 100 if interval_dur > 0 else 0

                    cluster_stats[cl] = {
                        "total_duration_ms": round(raw_dur, 3),
                        "avg_freq_mhz": round(avg_freq, 1),
                        "duration_ratio": ratio,
                        "st_duration_ms": round(st_dur, 3),
                        "mt_duration_ms": round(mt_dur, 3),
                        "st_ratio": round(st_ratio, 1),
                        "mt_ratio": round(mt_ratio, 1),
                    }

                # 综合算力供给（用 raw 时长加权）
                total_system_compute = 0.0
                for cl, stats in cluster_stats.items():
                    cluster_cfg = None
                    for c in chip_config.get("clusters", []):
                        if c.get("cluster_name") == cl:
                            cluster_cfg = c
                            break
                    if not cluster_cfg:
                        continue
                    freq_max = cluster_cfg.get("freq_max_mhz", 1)
                    compute_scale = cluster_cfg.get("compute_scale", 1.0)
                    st_eff = 1.0
                    mt_eff = 0.6
                    cluster_eff = stats["st_ratio"] / 100 * st_eff + stats["mt_ratio"] / 100 * mt_eff
                    freq_ratio = stats["avg_freq_mhz"] / freq_max if freq_max > 0 else 0
                    cluster_compute = (
                        cluster_eff * freq_ratio * compute_scale * stats["duration_ratio"] / 100
                    )
                    total_system_compute += cluster_compute

                freq_summary = {
                    "cluster_stats": dict(sorted(cluster_stats.items())),
                    "compute_supply": f"{round(total_system_compute * 100, 1)}%",
                }
                # =========================================================================
                # Part 3.5: 供给拆解（supply_breakdown）
                # 对齐 oss_tracetools CpuExecLinkInfo.do_calculate()
                # 复用 tid_intervals（含 freq + is_mt）作为 cpu_exec_info 等价
                # =========================================================================
                try:
                    if cache is None:
                        raise RuntimeError("trace_cache is None, skip supply_breakdown")
                    top_cluster_cfg = get_top_cluster(chip_config)
                    top_cluster_name = top_cluster_cfg.get("cluster_name")
                    top_freq_max = top_cluster_cfg.get("freq_max_mhz", 0)
                    big_cpu_range = top_cluster_cfg.get("cpuid_range", [0, 0])
                    big_cpu_ids = list(range(big_cpu_range[0], big_cpu_range[1] + 1))

                    start_ns = int((ctx.meta.get("start_ms") or 0) * 1_000_000)
                    end_ns = int((ctx.meta.get("end_ms") or 0) * 1_000_000)

                    # 限频切片：TraceDataCache 替代 SQL（measure 表连接级缓存）
                    raw_slices = cache.measure('cpu_frequency_limits_max', start_ns, end_ns)
                    _, trace_end_ns = cache.trace_range()
                    # SQL 版 COALESCE(m.ts+m.dur, tb.end_ts)：dur 为 NULL 时用 trace_range.end_ts 兜底
                    rows_for_df = []
                    for ts_val, dur_val, value, cpuid in raw_slices:
                        ts_end = (ts_val + dur_val) if dur_val else trace_end_ns
                        rows_for_df.append((ts_val, ts_end, value / 1000.0, cpuid))
                    freq_limit_df = pd.DataFrame(
                        rows_for_df,
                        columns=["ts_start", "ts_end", "max_freq_mhz", "cpuid"],
                    ) if rows_for_df else pd.DataFrame(columns=["ts_start", "ts_end", "max_freq_mhz", "cpuid"])
                    # 大核占用：复用主 SQL 分支2 (freq_data/running) 已拉取的数据
                    # 避免对 thread_state 再发一次 SQL（125 万行全表扫 138ms → 内存过滤 1ms）
                    # 分支2 已包含所有线程的 Running 切片，过滤 big_cpu_ids + tid!=current 即可
                    df_running_all = df[(df["data_source"] == "freq_data") & (df["data_type"] == "running")]
                    occupy_df = df_running_all[
                        df_running_all["cpuid"].isin(big_cpu_ids) & (df_running_all["tid"] != tid_filter)
                    ][["ts_start", "ts_end", "cpuid", "pid", "tid"]].reset_index(drop=True)

                    priority = sched_result.get("priority", 41)
                    big_max_load = get_top_cluster_max_load(chip_config)

                    sched_sum_ns = 0.0
                    occupy_sum_ns = 0.0
                    limit_sum_ns = 0.0
                    mt_sum_ns = 0.0

                    for iv in tid_intervals:
                        iv_start = int(iv["ts_start"])
                        iv_end = int(iv["ts_end"])
                        total_dur = iv_end - iv_start
                        if total_dur <= 0:
                            continue

                        iv_cpuid = int(iv.get("cpuid", 0))
                        iv_cluster = iv.get("cluster", "unknown")
                        iv_freq = float(iv.get("freq", 0))
                        is_mt = bool(iv.get("is_mt", False))

                        # MT 时长：整个时间片 is_mt 则全部算 MT
                        mt_duration = total_dur if is_mt else 0

                        # 当前算力（考虑 MT 折扣 0.4）
                        cur_load = get_cpu_load_by_compute_scale(
                            iv_cluster, iv_freq, chip_config
                        )
                        if mt_duration > 0:
                            cur_load = cur_load * (1 - mt_duration / total_dur * 0.4)

                        # 大核可用最高频点（考虑限频）
                        is_on_top = (iv_cluster == top_cluster_name)
                        if is_on_top:
                            freq_limit_mhz = _match_freq_limit_for_interval(
                                iv_start, iv_end, iv_cpuid, freq_limit_df
                            )
                            big_max_freq = freq_limit_mhz if freq_limit_mhz else top_freq_max
                        else:
                            # 当前线程不在大核：用大核的限频值（取大核 cpu 的限频最大值）
                            top_cpuid = big_cpu_range[0]
                            freq_limit_mhz = _match_freq_limit_for_interval(
                                iv_start, iv_end, top_cpuid, freq_limit_df
                            )
                            big_max_freq = freq_limit_mhz if freq_limit_mhz else top_freq_max

                        big_load_at_max = get_cpu_load_by_compute_scale(
                            top_cluster_name, big_max_freq, chip_config
                        )

                        # 限频可优化 = 当前算力提升到可用最高频的差距
                        if big_load_at_max > 0:
                            limit_opt = total_dur * (1 - cur_load / big_load_at_max)
                        else:
                            limit_opt = 0.0

                        # 理论最大可优化 = 当前算力提升到理论最高频的差距
                        if big_max_load > 0:
                            max_opt = total_dur * (1 - cur_load / big_max_load)
                        else:
                            max_opt = 0.0

                        # 大核占用导致
                        # 对齐 do_calculate() sched_info_parser.py:128-130：
                        # 仅当线程不在大核时才计算 big_occupy_duration，
                        # 在大核上时 big_occupy_dur=0（不调用 calculate_big_cpu_occupy）。
                        if not is_on_top:
                            big_occupy_dur = _calculate_big_occupy_duration(
                                iv_start, iv_end, occupy_df
                            )
                        else:
                            big_occupy_dur = 0.0
                        occupy_cause = limit_opt * (big_occupy_dur / total_dur) if total_dur > 0 else 0.0

                        # 调度导致 = 限频可优化 - 大核占用
                        sched_cause = limit_opt - occupy_cause

                        # 限频导致 = 理论最大 - 大核占用 - 调度
                        limit_cause = max_opt - occupy_cause - sched_cause

                        # MT 导致（仅 priority >= 41）
                        # 对齐 __add_sche_cause_info sched_info_parser.py:44-49：
                        # 在累加 sched_cause 时减去 mt_cause（未 clamp 前的值）。
                        mt_cause = (mt_duration * 0.4) if priority >= 41 else 0.0

                        sched_sum_ns += max(0.0, sched_cause - mt_cause)
                        occupy_sum_ns += max(0.0, occupy_cause)
                        limit_sum_ns += max(0.0, limit_cause)
                        mt_sum_ns += max(0.0, mt_cause)

                    jank_dur_ns = ((ctx.meta.get("end_ms") or 0) - (ctx.meta.get("start_ms") or 0)) * 1_000_000
                    # 供给不足 = runnable + (sched + occupy + limit + mt)
                    # 对齐 oss_tracetools: 供给不足耗时 = Runnable + 大核最高频下可节省耗时
                    # 其中可节省耗时 = sched + occupy + limit + mt（breakdown 四项之和）
                    runnable_ns = state_durations.get("runnable_ms", 0.0) * 1_000_000
                    insufficient_ns = sched_sum_ns + occupy_sum_ns + limit_sum_ns + mt_sum_ns + runnable_ns

                    def _ratio(part_ns: float) -> float:
                        return round(part_ns / jank_dur_ns * 100, 1) if jank_dur_ns > 0 else 0.0

                    supply_breakdown = {
                        "runnable_ms": state_durations.get("runnable_ms", 0.0),
                        "compute_insufficient_ms": round(insufficient_ns / 1e6, 3),
                        "compute_insufficient_ratio": _ratio(insufficient_ns),
                        "breakdown": {
                            "sched_cause_ms": round(sched_sum_ns / 1e6, 3),
                            "sched_cause_ratio": _ratio(sched_sum_ns),
                            "occupy_cause_ms": round(occupy_sum_ns / 1e6, 3),
                            "occupy_cause_ratio": _ratio(occupy_sum_ns),
                            "limit_cause_ms": round(limit_sum_ns / 1e6, 3),
                            "limit_cause_ratio": _ratio(limit_sum_ns),
                            "mt_cause_ms": round(mt_sum_ns / 1e6, 3),
                            "mt_cause_ratio": _ratio(mt_sum_ns),
                        },
                    }
                except Exception as exc:
                    log.debug("supply_breakdown 计算失败: %s", exc)
        except Exception as exc:
            log.info("smt_residency 计算失败: %s", exc)

    # =========================================================================
    # Part 4: 温度提取（区间交集 + 平均）
    # =========================================================================
    thermal_result: Dict[str, Any] = {}
    df_temp = df[df["data_source"] == "temp_data"]
    if len(df_temp) > 0:
        frame_start_ns = (ctx.meta.get("start_ms") or 0) * 1_000_000
        frame_end_ns = (ctx.meta.get("end_ms") or 0) * 1_000_000
        for sensor_name in ["shell_frame_temp", "soc_temp"]:
            df_sensor = df_temp[df_temp["data_type"] == sensor_name]
            if df_sensor.empty:
                continue
            # 区间交集: ts < end AND ts+dur > start
            mask = (df_sensor["ts_start"].astype(float) < frame_end_ns) & (
                df_sensor["ts_end"].astype(float) > frame_start_ns
            )
            matching = df_sensor[mask]
            if len(matching) == 1:
                thermal_result[sensor_name] = round(float(matching.iloc[0]["freq"]), 1)
            elif len(matching) > 1:
                thermal_result[sensor_name] = round(float(matching["freq"].mean()), 1)

    # =========================================================================
    # Part 5: 组装最终输出
    # state 合并 + 改为自然语言（无论 supply_breakdown 是否存在，都生成 state_text/breakdown_text）
    # =========================================================================
    # active_ms = 线程真实活跃时长（running + runnable），用于 state_text 百分比基准
    # 与 frame window（end-start）不同：线程可能未占满整个窗口
    active_ms = state_durations.get("running_ms", 0.0) + state_durations.get("runnable_ms", 0.0)
    state_durations["compute_insufficient_ms"] = (
        supply_breakdown.get("compute_insufficient_ms", 0.0) if supply_breakdown else 0.0
    )
    breakdown = supply_breakdown.get("breakdown", {}) if supply_breakdown else {}
    state_durations["state_text"] = _build_state_text(state_durations, active_ms)
    state_durations["breakdown_text"] = _build_breakdown_text(breakdown, state_durations["compute_insufficient_ms"])
    # 删除旧字段（无论是否存在 supply_breakdown，都 pop 保持 schema 一致）
    state_durations.pop("breakdown", None)
    state_durations.pop("compute_insufficient_ratio", None)
    state_durations.pop("runnable_ratio", None)

    # freq 改为自然语言（cluster_stats 和 compute_supply 独立判断，避免 compute_supply_text 丢失）
    cluster_stats_for_text = freq_summary.get("cluster_stats", {})
    if cluster_stats_for_text:
        freq_summary["cluster_stats_text"] = _build_cluster_stats_text(
            cluster_stats_for_text, state_durations.get("running_ms", 0.0)
        )
        freq_summary.pop("cluster_stats", None)

    # compute_supply_text 独立判断（不依赖 cluster_stats）
    compute_supply_raw = freq_summary.get("compute_supply", "")
    if compute_supply_raw and compute_supply_raw != "0%":
        freq_summary["compute_supply_text"] = _build_compute_supply_text(compute_supply_raw)
    elif compute_supply_raw == "0%":
        freq_summary["compute_supply_text"] = "无数据"
    # 缺失时不输出该字段
    freq_summary.pop("compute_supply", None)

    ctx.data = {
        "thread": thread_result,
        "sched": sched_result,
        "state": state_durations,
        "migration": migration_result,
        "freq": freq_summary,
        "thermal": thermal_result,
    }
    return ctx


# =========================================================================
# Agent 友好化 helper（Level E 方案）
# =========================================================================
def _fmt_ms(v: float) -> str:
    """统一 2 位小数 + 去尾随零。

    0 → "0"; 0.07 → "0.07"; 28.70 → "28.7"; 28.00 → "28"; 122.788 → "122.79"
    """
    return f"{v:.2f}".rstrip("0").rstrip(".")


def _fmt_mhz(v: float) -> str:
    """频率取整（四舍五入）。

    0 → "0"; 1545.4 → "1545"; 1909.8 → "1910"; 2893.0 → "2893"
    """
    return str(round(v))


def _fmt_pct(part: float, total: float) -> str:
    """百分比四舍五入 1 位小数（不截断）。

    42.93% → "42.9%"，不能是 "42.8%"；100% → "100%"（非 "100.0%"）
    """
    if total <= 0:
        return "0%"
    pct = f"{round(part / total * 100, 1)}".rstrip("0").rstrip(".")
    return f"{pct}%"


def _build_state_text(state: dict, active_ms: float) -> str:
    """生成 state 自然语言字符串。

    只写百分比，不重复 ms 数值；基准 active 在末尾声明一次。

    "Running 99.8% / Runnable 0.2% / 使用最高算力理论可省 58.8%（基准 active 28.79ms）"
    """
    running_ms = state.get("running_ms", 0.0)
    runnable_ms = state.get("runnable_ms", 0.0)
    compute_insufficient_ms = state.get("compute_insufficient_ms", 0.0)

    running_pct = _fmt_pct(running_ms, active_ms)
    runnable_pct = _fmt_pct(runnable_ms, active_ms)
    compute_insufficient_pct = _fmt_pct(compute_insufficient_ms, active_ms)

    return (
        f"Running {running_pct} / Runnable {runnable_pct} / "
        f"使用最高算力理论可省 {compute_insufficient_pct}"
        f"（基准 active {_fmt_ms(active_ms)}ms）"
    )


def _build_breakdown_text(breakdown: dict, compute_insufficient_ms: float) -> str:
    """生成 breakdown 自然语言字符串。

    按 dominant 降序排列 4 项 cause；首项声明基准"占使用最高算力可省的Y%"，
    后续项省略基准只写百分比；不重复 runnable/compute_insufficient 总数。

    compute_insufficient=0 → "无使用最高算力可省时间"
    """
    if compute_insufficient_ms <= 0:
        return "无使用最高算力可省时间"

    # 4 项 cause 及其中文标签
    cause_items = [
        ("sched_cause_ms", "调度到低频核"),
        ("occupy_cause_ms", "大核被占用导致无法升频"),
        ("limit_cause_ms", "限频无法提频"),
        ("mt_cause_ms", "MT折损(微架构资源分摊)"),
    ]
    # 取值并按 dominant 降序排序
    items = [(label, breakdown.get(key, 0.0)) for key, label in cause_items]
    items.sort(key=lambda x: x[1], reverse=True)

    parts: list[str] = []
    for idx, (label, value_ms) in enumerate(items):
        pct = _fmt_pct(value_ms, compute_insufficient_ms)
        if idx == 0:
            # 首项：主导= + 基准声明
            parts.append(
                f"主导={label} {_fmt_ms(value_ms)}ms(占使用最高算力可省的{pct})"
            )
        else:
            # 后续项：只写百分比
            parts.append(f"{label} {_fmt_ms(value_ms)}ms({pct})")
    return "；".join(parts)


# cluster 固定输出顺序：little → mid → big → cluster3
_CLUSTER_ORDER: tuple[str, ...] = ("little", "mid", "big", "cluster3")


def _build_cluster_stats_text(cluster_stats: dict, running_ms: float) -> str:
    """生成 cluster_stats 自然语言字符串。

    只写出现的 cluster（缺席的不提）；cluster 顺序固定：little → mid → big → cluster3。
    首个 cluster 声明"基准running"并带 ST/MT 解释，后续 cluster 只写 "ST X% / MT Y%"。

    4199 示例（running_ms=28.718）：
        "mid: avg 1500MHz, 28.72ms(100%基准running)，ST 98.7%(逻辑核独占物理核，无折损) / MT 1.3%(两个逻辑核并发同一物理核，微架构资源分摊)"

    4384 示例（running_ms=122.788，big + cluster3）：
        "big: avg 1900MHz, 49.68ms(40.5%基准running)，ST 97.1%(逻辑核独占物理核，无折损) / MT 2.9%(两个逻辑核并发同一物理核，微架构资源分摊)；
         cluster3: avg 2850MHz, 73.11ms(59.5%)，ST 22.2% / MT 77.8%"
    """
    if not cluster_stats:
        return ""

    # cluster_stats 输入字段：
    #   total_duration_ms, avg_freq_mhz, duration_ratio (0-100 已是百分比),
    #   st_ratio (0-100), mt_ratio (0-100)
    parts: list[str] = []
    is_first = True
    for cluster_name in _CLUSTER_ORDER:
        stats = cluster_stats.get(cluster_name)
        if stats is None:
            continue
        avg_freq_mhz = _fmt_mhz(stats.get("avg_freq_mhz", 0.0))
        total_duration_ms = _fmt_ms(stats.get("total_duration_ms", 0.0))
        # duration_ratio 已经是 0-100 的百分比，直接格式化即可（不调用 _fmt_pct）
        duration_ratio = stats.get("duration_ratio", 0.0)
        ratio_str = f"{round(duration_ratio, 1)}".rstrip("0").rstrip(".")
        st_ratio = stats.get("st_ratio", 0.0)
        st_str = f"{round(st_ratio, 1)}".rstrip("0").rstrip(".")
        mt_ratio = stats.get("mt_ratio", 0.0)
        mt_str = f"{round(mt_ratio, 1)}".rstrip("0").rstrip(".")

        if is_first:
            # 首个 cluster：声明基准 running + ST/MT 解释
            parts.append(
                f"{cluster_name}: avg {avg_freq_mhz}MHz, "
                f"{total_duration_ms}ms({ratio_str}%基准running)，"
                f"ST {st_str}%(逻辑核独占物理核，无折损) / "
                f"MT {mt_str}%(两个逻辑核并发同一物理核，微架构资源分摊)"
            )
            is_first = False
        else:
            # 后续 cluster：只写 "ST X% / MT Y%"
            parts.append(
                f"{cluster_name}: avg {avg_freq_mhz}MHz, "
                f"{total_duration_ms}ms({ratio_str}%)，"
                f"ST {st_str}% / MT {mt_str}%"
            )
    return "；".join(parts)


def _build_compute_supply_text(compute_supply_str: str) -> str:
    """生成 compute_supply 自然语言字符串。

    "41.2%" → "CPU最强核最高算力的 41.2%"
    "0%" 或 "" → "无数据"（区分数据缺失和真的 0%）
    """
    if not compute_supply_str or compute_supply_str == "0%":
        return "无数据"
    return f"CPU最强核最高算力的 {compute_supply_str}"
