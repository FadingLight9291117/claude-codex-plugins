"""Parse hiperf .data binary files (PERFILE2 format).

Scope: extract PERF_RECORD_SAMPLE records with BRBE branch_stock, and
PERF_RECORD_AUXTRACE (SPE) records. Symbol resolution is delegated to
hiperf_symbol_resolver; this module only parses the binary structure.

Also parses hiperf_files_symbol feature section (feature 192) directly
from the single .data binary to build per-file symbol tables.

Design reference: docs/superpowers/specs/2026-07-03-hiperf-sampling-integration-design.md
"""
from __future__ import annotations

import mmap
import struct
from dataclasses import dataclass, field
from pathlib import Path

PERFILE2_MAGIC = b"PERFILE2"

# sample_type bitmask bits (perf_event_attr.sample_type)
ST_IP = 1 << 0
ST_TID = 1 << 1
ST_TIME = 1 << 2
ST_ID = 1 << 6
ST_CPU = 1 << 7
ST_PERIOD = 1 << 8
ST_STREAM_ID = 1 << 9
ST_REGS_INTR = 1 << 11
ST_IDENTIFIER = 1 << 16


@dataclass
class PerfFileHeader:
    """perf_file_header struct (first 48 bytes of file)."""

    magic: bytes
    header_size: int
    attr_size: int
    attrs_offset: int
    attrs_size: int
    data_offset: int
    data_size: int

    @property
    def is_valid(self) -> bool:
        return self.magic == PERFILE2_MAGIC


@dataclass
class PerfFileAttr:
    """perf_file_attr struct (one per event)."""

    sample_type: int
    branch_sample_type: int
    sample_regs_intr: int


@dataclass
class BrbeEntry:
    """One BRBE branch record (from→to with cycles and flags).

    Field semantics per ARM BRBINF<n>_EL1:
      - br_type:  TYPE[13:8], 6-bit branch type
      - el_type:  EL[7:6], exception level at target
      - is_mispredicted: MPRED[5], True only when VALID∈{2,3} AND TYPE[5]==0
      - cycles:   CC[45:32] decoded via M*2^E; invalid when CCU[46]==1
      - valid:    VALID[1:0], 0=invalid, 1=valid(no src/mpred),
                  2=valid(no tgt/el), 3=fully valid
      - cycles_unknown: CCU[46], True when cycle count is unknown
    """

    sequence: int          # index within the sample's brbe_entries list
    from_ip: int
    to_ip: int
    is_mispredicted: bool  # MPRED[5]
    el_type: int           # EL[7:6]: 0=EL0, 1=EL1, 2=EL2, 3=EL3
    br_type: int           # TYPE[13:8]: 6-bit, see ARM TYPE encoding
    cycles: int            # CC[45:32] decoded; 0 if CCU==1
    valid: int = 3         # VALID[1:0]: 0/1/2/3
    cycles_unknown: bool = False  # CCU[46]


@dataclass
class ParsedSample:
    """One PERF_RECORD_SAMPLE with its BRBE entries."""

    timestamp_ns: int
    pid: int
    tid: int
    cpu: int
    period: int
    brbe_entries: list[BrbeEntry]


PERF_RECORD_SAMPLE = 9
PERF_RECORD_AUXTRACE = 71
PERF_RECORD_MMAP = 1
PERF_RECORD_MMAP2 = 10

# hiperf custom feature section type in the perf feature bitmap.
HEADER_HIPERF_FILES_SYMBOL = 192


@dataclass
class MmapRecord:
    """PERF_RECORD_MMAP / PERF_RECORD_MMAP2 record.

    Maps a virtual address range [start, end) to a file backing at pgoff
    within that file. file_id is resolved from filename via the
    SymbolResolver.build() step (assigned per-unique-filename).
    """

    pid: int
    start: int
    end: int  # start + len
    pgoff: int
    file_id: int  # resolved from filename via files_map (-1 = unresolved)
    filename: str


@dataclass
class FileSymbolTable:
    """Symbol table for one file, parsed from hiperf_files_symbol feature.

    Attributes:
        file_path: the filePath from the feature section
        symbols: list of (offset, symbol_name), sorted by offset
        min_exec_addr: minExecAddr value (address in file's virtual space)
        min_exec_addr_file_offset: minExecAddrFileOffset value
    """

    file_path: str
    symbols: list[tuple[int, str]] = field(default_factory=list)
    min_exec_addr: int = 0
    min_exec_addr_file_offset: int = 0


def decode_brbe_cycles(flags: int) -> int:
    """Decode BRBE cycles from flags: M * 2^E formula.

    The upper 32 bits of flags encode clock_cycles:
      M = bits 0-7 (mantissa)
      E = bits 8-13 (exponent)
    If E == 0: cycles = M
    Else:      cycles = (1 << E) | (M << (E - 1))
    """
    clock_cycles = flags >> 32
    m = clock_cycles & 0xFF
    e = (clock_cycles >> 8) & 0x3F
    if e == 0:
        return m
    return (1 << e) | (m << (e - 1))


class HiperfBinaryParser:
    """Streaming parser for hiperf .data binary files.

    Uses mmap + struct.unpack_from for zero-copy parsing.
    """

    def __init__(self, file_path: str | Path) -> None:
        self.path = str(file_path)

    def parse_header(self) -> PerfFileHeader:
        """Parse the perf_file_header (first 48 bytes). Does not consume the file."""
        with open(self.path, "rb") as f:
            with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                magic = bytes(mm[0:8])
                (
                    header_size,
                    attr_size,
                    attrs_offset,
                    attrs_size,
                    data_offset,
                    data_size,
                ) = struct.unpack_from("<QQQQQQ", mm, 8)
                return PerfFileHeader(
                    magic=magic,
                    header_size=header_size,
                    attr_size=attr_size,
                    attrs_offset=attrs_offset,
                    attrs_size=attrs_size,
                    data_offset=data_offset,
                    data_size=data_size,
                )

    def parse_attrs(self) -> list[PerfFileAttr]:
        """Parse perf_file_attr structs from attrs section.

        Layout of perf_event_attr (offsets from start of struct):
            0: u32 type, u32 size
            8: u64 config
           16: u64 sample_period_or_freq
           24: u64 sample_type              <- we need this
           32: u64 read_format
           56: u64 branch_sample_type       <- we need this
           88: u64 sample_regs_intr (kernel >= 4.0)
        """
        header = self.parse_header()
        with open(self.path, "rb") as f:
            with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                n_attrs = max(1, header.attrs_size // header.attr_size)
                attrs: list[PerfFileAttr] = []
                for i in range(n_attrs):
                    base = header.attrs_offset + i * header.attr_size
                    sample_type = struct.unpack_from("<Q", mm, base + 24)[0]
                    branch_sample_type = struct.unpack_from("<Q", mm, base + 56)[0]
                    try:
                        sample_regs_intr = struct.unpack_from("<Q", mm, base + 88)[0]
                    except struct.error:
                        sample_regs_intr = 0
                    attrs.append(
                        PerfFileAttr(
                            sample_type=sample_type,
                            branch_sample_type=branch_sample_type,
                            sample_regs_intr=sample_regs_intr,
                        )
                    )
                return attrs

    def parse_samples(self) -> list[ParsedSample]:
        """Compatibility wrapper returning all PERF_RECORD_SAMPLE records.

        Internally delegates to iter_samples_ordered() so ordering and parsing
        stay consistent.
        """
        return list(self.iter_samples_ordered())

    def build_sample_index(self) -> list[tuple[int, int, int]]:
        """Return list of (offset, timestamp_ns, size) for all PERF_RECORD_SAMPLE records."""
        header = self.parse_header()
        attrs = self.parse_attrs()
        sample_type = attrs[0].sample_type if attrs else 0
        index: list[tuple[int, int, int]] = []
        with open(self.path, "rb") as f:
            with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                offset = header.data_offset
                data_end = header.data_offset + header.data_size
                while offset < data_end - 8:
                    rtype, _rmisc, rsize = struct.unpack_from("<IHH", mm, offset)
                    if rsize == 0 or rsize > 65535:
                        break
                    if rtype == PERF_RECORD_SAMPLE:
                        try:
                            ts = self._extract_timestamp(
                                mm, offset + 8, rsize - 8, sample_type
                            )
                            index.append((offset, ts, rsize))
                        except struct.error:
                            pass
                    offset += rsize
        return index

    @staticmethod
    def _extract_timestamp(
        mm: mmap.mmap,
        body_offset: int,
        body_size: int,
        sample_type: int,
    ) -> int:
        """Extract timestamp_ns from a SAMPLE body without parsing BRBE entries."""
        pos = body_offset
        ts = 0
        if sample_type & ST_IDENTIFIER:
            pos += 8
        if sample_type & ST_IP:
            pos += 8
        if sample_type & ST_TID:
            pos += 8
        if sample_type & ST_TIME:
            ts = struct.unpack_from("<Q", mm, pos)[0]
        return ts

    def iter_samples_ordered(self):
        """Yield ParsedSample ordered by timestamp_ns.

        Memory usage is O(sample count) for the (offset, timestamp_ns, size)
        index only; BRBE entries are parsed one sample at a time.
        """
        attrs = self.parse_attrs()
        sample_type = attrs[0].sample_type if attrs else 0
        index = self.build_sample_index()
        index.sort(key=lambda x: x[1])
        with open(self.path, "rb") as f:
            with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                for offset, _ts, size in index:
                    try:
                        sample = self._parse_sample_body(
                            mm, offset + 8, size - 8, sample_type
                        )
                        if sample is not None:
                            yield sample
                    except struct.error:
                        continue

    @staticmethod
    def _parse_sample_body(
        mm: mmap.mmap,
        body_offset: int,
        body_size: int,
        sample_type: int,
    ) -> ParsedSample | None:
        """Parse one SAMPLE record body (after the 8-byte header)."""
        pos = body_offset

        # Standard fields in sample_type order
        _identifier = _ip = pid = tid = ts = _sample_id = _stream_id = cpu = period = 0

        if sample_type & ST_IDENTIFIER:
            _identifier = struct.unpack_from("<Q", mm, pos)[0]
            pos += 8
        if sample_type & ST_IP:
            _ip = struct.unpack_from("<Q", mm, pos)[0]
            pos += 8
        if sample_type & ST_TID:
            pid, tid = struct.unpack_from("<ii", mm, pos)
            pos += 8
        if sample_type & ST_TIME:
            ts = struct.unpack_from("<Q", mm, pos)[0]
            pos += 8
        if sample_type & ST_ID:
            _sample_id = struct.unpack_from("<Q", mm, pos)[0]
            pos += 8
        if sample_type & ST_STREAM_ID:
            _stream_id = struct.unpack_from("<Q", mm, pos)[0]
            pos += 8
        if sample_type & ST_CPU:
            cpu, _res = struct.unpack_from("<II", mm, pos)
            pos += 8
        if sample_type & ST_PERIOD:
            period = struct.unpack_from("<Q", mm, pos)[0]
            pos += 8

        # Hiperf custom extension: branch_stack + server
        standard_consumed = pos - body_offset
        remaining = body_size - standard_consumed
        brbe_entries: list[BrbeEntry] = []

        if remaining >= 8:
            brbe_nr = struct.unpack_from("<Q", mm, pos)[0]
            pos += 8
            remaining -= 8

            if 0 < brbe_nr <= 32:
                needed = brbe_nr * 24
                if remaining >= needed:
                    for i in range(brbe_nr):
                        from_ip, to_ip, flags = struct.unpack_from(
                            "<QQQ", mm, pos + i * 24
                        )
                        brbe_entries.append(BrbeEntry(
                            sequence=i,
                            from_ip=from_ip,
                            to_ip=to_ip,
                            # BRBINF<n>_EL1 field extraction per ARM spec:
                            valid=flags & 0x3,                    # VALID [1:0]
                            # MPRED [5]: only valid when VALID∈{2,3} AND TYPE[5]==0
                            is_mispredicted=(
                                (flags & 0x3) in (2, 3)
                                and not ((flags >> 8) & 0x20)     # TYPE[5]==0
                                and bool((flags >> 5) & 1)
                            ),
                            el_type=(flags >> 6) & 0x3,           # EL [7:6]
                            # TYPE [13:8]: 6 bits per ARM BRBINF_EL1
                            br_type=(flags >> 8) & 0x3F,
                            # CC [45:32] with CCU [46] check
                            cycles_unknown=bool((flags >> 46) & 1),
                            cycles=(
                                0 if (flags >> 46) & 1
                                else decode_brbe_cycles(flags)
                            ),
                        ))
                    pos += needed
                    remaining -= needed
                else:
                    return None  # malformed
            # server section skipped (not needed for BRBE analysis)

        return ParsedSample(
            timestamp_ns=ts, pid=pid, tid=tid, cpu=cpu, period=period,
            brbe_entries=brbe_entries,
        )

    def parse_mmap_records(self) -> list[MmapRecord]:
        """Parse PERF_RECORD_MMAP (type=1) and MMAP2 (type=10) records.

        MMAP records contain: pid, tid, addr, len, pgoff, filename.
        MMAP2 records contain: pid, tid, addr, len, pgoff, maj(4), min(4),
        ino(8), ino_generation(8), prot(4), flags(4), filename.
        The MMAP2 extra fields (32 bytes) are between pgoff and filename.

        file_id is left as -1; SymbolResolver.build() assigns unique ids
        per unique filename.
        """
        header = self.parse_header()
        records: list[MmapRecord] = []
        with open(self.path, "rb") as f:
            with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                offset = header.data_offset
                data_end = header.data_offset + header.data_size

                while offset < data_end - 8:
                    rtype, _rmisc, rsize = struct.unpack_from("<IHH", mm, offset)
                    if rsize == 0 or rsize > 65535:
                        break

                    if rtype in (PERF_RECORD_MMAP, PERF_RECORD_MMAP2):
                        body = offset + 8
                        if body + 32 > offset + rsize:
                            offset += rsize
                            continue
                        pid, tid = struct.unpack_from("<ii", mm, body)
                        addr = struct.unpack_from("<Q", mm, body + 8)[0]
                        length = struct.unpack_from("<Q", mm, body + 16)[0]
                        pgoff = struct.unpack_from("<Q", mm, body + 24)[0]
                        # MMAP: filename starts at body+32
                        # MMAP2: filename starts at body+64 (32 extra bytes:
                        #   maj(4)+min(4)+ino(8)+ino_generation(8)+prot(4)+flags(4))
                        if rtype == PERF_RECORD_MMAP2:
                            filename_start = body + 64
                        else:
                            filename_start = body + 32
                        filename_end = mm.find(
                            b"\x00", filename_start, offset + rsize
                        )
                        if filename_end == -1:
                            filename_end = offset + rsize
                        filename = mm[filename_start:filename_end].decode(
                            "utf-8", errors="replace"
                        )
                        records.append(
                            MmapRecord(
                                pid=pid,
                                start=addr,
                                end=addr + length,
                                pgoff=pgoff,
                                file_id=-1,
                                filename=filename,
                            )
                        )
                    offset += rsize

        return records

    def _find_feature_section(self, feature_type: int) -> tuple[int, int] | None:
        """Locate a perf feature section by type.

        Returns (offset, size) within the file, or None if not present.
        """
        header = self.parse_header()
        with open(self.path, "rb") as f:
            with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                # Standard perf_file_header: adds_features bitmap starts at
                # offset 72 and is 32 bytes (256 bits) long.
                if header.header_size < 104:
                    return None
                bitmap = mm[72:104]
                bits = []
                for byte_idx, byte in enumerate(bitmap):
                    for bit in range(8):
                        if byte & (1 << bit):
                            bits.append(byte_idx * 8 + bit)
                if feature_type not in bits:
                    return None
                idx = bits.index(feature_type)
                dir_offset = header.data_offset + header.data_size
                entry_offset = dir_offset + idx * 16
                if entry_offset + 16 > len(mm):
                    return None
                off, size = struct.unpack_from("<QQ", mm, entry_offset)
                if off + size > len(mm):
                    return None
                return int(off), int(size)

    def parse_files_symbol_from_binary(self) -> dict[str, FileSymbolTable]:
        """Parse hiperf_files_symbol feature (feature 192) from binary section.

        The binary layout was reverse-engineered from run_A1/brbe.data:
          - 8-byte feature header (version/type + an unknown constant)
          - One file entry after another until the section ends:
              * file 0 path: null-terminated UTF-8 string
              * file 1+ path: u32 length (incl. null) followed by bytes
              * symbolType: u32
              * minExecAddr: u64
              * minExecAddrFileOffset: u64
              * build_id_length: u32 (incl. null)
              * build_id: bytes
              * symbol_number: u32
              * For each symbol:
                  - vaddr: u64
                  - file_offset: u32
                  - name_length: u32 (incl. null)
                  - name: bytes
        The file_offset value is stored as the symbol offset so that
        SymbolResolver.resolve() can look up symbols by file offset.

        Returns:
            dict mapping file_path -> FileSymbolTable with sorted symbols.

        Raises:
            RuntimeError: if the feature section is missing or malformed.
        """
        section = self._find_feature_section(HEADER_HIPERF_FILES_SYMBOL)
        if section is None:
            raise RuntimeError(
                f"hiperf_files_symbol feature ({HEADER_HIPERF_FILES_SYMBOL}) "
                "not found in binary"
            )
        feat_off, feat_size = section
        tables: dict[str, FileSymbolTable] = {}
        with open(self.path, "rb") as f:
            with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                data = mm[feat_off : feat_off + feat_size]
                if len(data) < 8:
                    raise RuntimeError("hiperf_files_symbol section too small")

                # Feature header (8 bytes).  We don't currently interpret it;
                # the file entries follow immediately.
                pos = 8
                file_idx = 0
                while pos < len(data):
                    # File 0 uses a null-terminated path; subsequent files use
                    # a length-prefixed path.  This asymmetry matches the
                    # captured binary format.
                    if file_idx == 0:
                        end = data.find(b"\x00", pos)
                        if end == -1:
                            raise RuntimeError(
                                "unterminated path in hiperf_files_symbol"
                            )
                        path = data[pos:end].decode("utf-8", errors="replace")
                        pos = end + 1
                    else:
                        if pos + 4 > len(data):
                            break
                        path_len = struct.unpack_from("<I", data, pos)[0]
                        pos += 4
                        if path_len == 0 or pos + path_len > len(data):
                            raise RuntimeError(
                                "invalid path length in hiperf_files_symbol"
                            )
                        path = data[pos : pos + path_len - 1].decode(
                            "utf-8", errors="replace"
                        )
                        pos += path_len

                    if pos + 4 + 8 + 8 + 4 + 4 > len(data):
                        raise RuntimeError(
                            "truncated file header in hiperf_files_symbol"
                        )
                    struct.unpack_from("<I", data, pos)[0]  # symbolType
                    pos += 4
                    min_exec_addr = struct.unpack_from("<Q", data, pos)[0]
                    pos += 8
                    min_exec_addr_file_offset = struct.unpack_from("<Q", data, pos)[0]
                    pos += 8
                    build_id_len = struct.unpack_from("<I", data, pos)[0]
                    pos += 4
                    if pos + build_id_len + 4 > len(data):
                        raise RuntimeError(
                            "truncated build_id in hiperf_files_symbol"
                        )
                    pos += build_id_len
                    sym_count = struct.unpack_from("<I", data, pos)[0]
                    pos += 4

                    symbols: list[tuple[int, str]] = []
                    for _ in range(sym_count):
                        if pos + 8 + 4 + 4 > len(data):
                            raise RuntimeError(
                                "truncated symbol record in hiperf_files_symbol"
                            )
                        struct.unpack_from("<Q", data, pos)[0]  # vaddr (unused, skip)
                        pos += 8
                        file_offset = struct.unpack_from("<I", data, pos)[0]
                        pos += 4
                        name_len = struct.unpack_from("<I", data, pos)[0]
                        pos += 4
                        if name_len == 0 or pos + name_len > len(data):
                            raise RuntimeError(
                                "invalid symbol name length in hiperf_files_symbol"
                            )
                        name = data[pos : pos + name_len - 1].decode(
                            "utf-8", errors="replace"
                        )
                        pos += name_len
                        symbols.append((file_offset, name))

                    if path:
                        symbols.sort(key=lambda s: s[0])
                        tables[path] = FileSymbolTable(
                            file_path=path,
                            symbols=symbols,
                            min_exec_addr=min_exec_addr,
                            min_exec_addr_file_offset=min_exec_addr_file_offset,
                        )

                    file_idx += 1

                if not tables:
                    raise RuntimeError(
                        "hiperf_files_symbol section parsed but contained no files"
                    )
                return tables
