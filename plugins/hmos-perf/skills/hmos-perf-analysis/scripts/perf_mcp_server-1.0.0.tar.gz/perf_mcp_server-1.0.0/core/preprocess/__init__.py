"""可组合预处理算子注册中心。

设计目标：
- 让一个原子指标可以声明 ``preprocess.pipeline`` 多阶段处理（例如启动流程拆解）
- 让简单场景仍能用 ``preprocess.engine`` 单引擎写法（向后兼容）
- 复杂步骤可以独立单测、独立替换、独立追加 Todo 占位

调度入口在 ``core.query_engine.QueryEngine._execute_with_preprocess``。
"""
from __future__ import annotations

from .base import (  # noqa: F401
    OPERATORS,
    PreprocessContext,
    PreprocessError,
    PreprocessOperator,
    register_operator,
    run_pipeline,
)

# 触发各算子模块的 register_operator 装饰器执行
from . import cpu_load_ops    # noqa: F401  (副作用 import)
from . import flamegraph_ops  # noqa: F401  (副作用 import)
from . import frame_ops       # noqa: F401  (副作用 import)
from . import jank_ops        # noqa: F401  (副作用 import)
from . import launch_ops      # noqa: F401  (副作用 import)
from . import sched_ops        # noqa: F401  (副作用 import)
from . import smt_ops         # noqa: F401  (副作用 import)
from . import marker_ops      # noqa: F401  (副作用 import)
from . import pmu_ops         # noqa: F401  (副作用 import)
from . import sleep_ops       # noqa: F401  (副作用 import)
from . import io_ops          # noqa: F401  (副作用 import)
from . import hiperf_ops      # noqa: F401  (副作用 import)
from . import brbe_ops         # noqa: F401  (副作用 import)
from . import throttle_ops           # noqa: F401  (副作用 import)
from . import uninterruptible_ops  # noqa: F401  (副作用 import)
from . import game_render_ops  # noqa: F401  (副作用 import)
from . import game_experience_ops  # noqa: F401  (副作用 import)
from . import game_launch_ops  # noqa: F401  (副作用 import)
from . import game_sched_ops  # noqa: F401  (副作用 import)
from . import thread_sched_ops  # noqa: F401  (副作用 import)
from . import jank_interval_ops  # noqa: F401  (副作用 import)
from . import rs_frame_ops       # noqa: F401  (副作用 import)
from . import flutter_frame_ops  # noqa: F401  (副作用 import)
from . import ui_frame_ops       # noqa: F401  (副作用 import)
from . import web_frame_ops       # noqa: F401  (副作用 import)
from . import frame_rate_ops       # noqa: F401  (副作用 import)
from . import thread_query_ops  # noqa: F401  (副作用 import)
from . import gpu_freq_ops     # noqa: F401  (副作用 import)
from . import gpu_pipeline_ops  # noqa: F401  (副作用 import)
from . import parallelism_ops  # noqa: F401  (副作用 import)
from . import so_load_ops     # noqa: F401  (副作用 import)
from . import animation_ops   # noqa: F401  (副作用 import)
from . import perf_compare_ops  # noqa: F401  (副作用 import)
from . import cpu_state_freq_ops  # noqa: F401
from . import process_profile_ops  # noqa: F401  (副作用 import)
from . import tag_instruction_ops  # noqa: F401  (副作用 import)
