# -*- coding: utf-8 -*-
"""不可中断状态（D-IO / D-NIO / D / D|W）耗时分析算子。

数据源:
    thread_state LEFT JOIN args + data_dict，主 SQL 已带 caller 列。
    一次查询同时获取时长和 BlockReason，算子不再内部回查 SQLite。

BlockReason 数据链路:
    thread_state.arg_setid → args.argset (key=3, datatype=1)
    → args.value = data_dict.id → data_dict.data = caller 函数名
"""
from __future__ import annotations

from core.observability import get_module_logger
from typing import Any, Optional

import pandas as pd

from .base import PreprocessContext, PreprocessError, register_operator
from .trace_data_cache import TraceDataCache

log = get_module_logger(__name__)


@register_operator("compute_uninterruptible_duration")
def compute_uninterruptible_duration(ctx: PreprocessContext) -> PreprocessContext:
    """从 thread_state 数据计算不可中断状态耗时，并关联 BlockReason caller 函数名。

    主 SQL 已 LEFT JOIN args + data_dict 输出 caller 列，
    算子一次遍历同时聚合时长和 block_reason_distribution，不再内部回查 SQLite。

    输入:
        ctx.data: DataFrame 含列 ts / dur / itid / tid / pid / state / tname / caller
                  caller: BlockReason 函数名（可为 NULL）
    输出:
        ctx.data: DataFrame 含列 tid / tname / pid /
                         dio_ms / dio_events / avg_dio_ms /
                         dnio_ms / dnio_events /
                         io_count / block_reason_distribution
        ctx.meta["thread_count"]: 发生不可中断状态的线程数
        ctx.meta["total_dio_ms"]: 所有线程 D-IO 总耗时
        ctx.meta["total_dio_events"]: D-IO 事件总数
        ctx.meta["total_dnio_ms"]: 所有线程 D-NIO 总耗时
        ctx.meta["total_dnio_events"]: D-NIO 事件总数

    cache 路径（ctx.trace_cache 非空时）:
        用 cache.thread_state(itid, start_ns, end_ns) + cache.block_reason(arg_setid)
        替代 YAML SQL（N+1 → O(1) 查找）。YAML SQL（4 表 LEFT JOIN + 时间窗过滤）在无索引时
        每 item ~22ms × 204 = 4.4s；cache 一次性全量拉取后按 itid 分组 + bisect 区间过滤，
        caller 由 cache.block_reason(arg_setid) 字典 O(1) 反查。
    """
    # Task 11: cache 由 query_engine.py 始终注入（Task 6 后），不再判 None。
    cache: TraceDataCache = ctx.trace_cache
    df_from_cache = _build_uninterruptible_df_from_cache(ctx, cache)
    if df_from_cache is not None:
        ctx.data = df_from_cache
        ctx.meta["uninterruptible_data_source"] = "trace_cache"
    return _compute_uninterruptible_duration_legacy(ctx)


def _build_uninterruptible_df_from_cache(
    ctx: PreprocessContext, cache: TraceDataCache
) -> Optional[Any]:
    """用 cache.thread_state + cache.block_reason 重建 DataFrame，等价于 YAML SQL 输出。

    YAML SQL:
        SELECT ts.ts, ts.dur, ts.cpu, ts.itid, ts.tid, ts.pid, ts.state,
               t.name as tname, d.data as caller
        FROM thread_state ts
        LEFT JOIN thread t ON ts.itid = t.itid
        LEFT JOIN args a ON ts.arg_setid = a.argset AND a.key = 3 AND a.datatype = 1
        LEFT JOIN data_dict d ON a.value = d.id
        WHERE (ts.ts + ts.dur) > :start_ms * 1e6 AND ts.ts < :end_ms * 1e6
          AND ts.state IN ('D-IO', 'D-NIO', 'D', 'D|W')
          AND ( :filter_thread_name IS NULL OR t.name LIKE '%' || :filter_thread_name || '%' )
          AND ( :filter_process_name IS NULL OR ts.pid IN (
              SELECT p.pid FROM process p WHERE p.name LIKE '%' || :filter_process_name || '%'
          ) )
          AND ( :tid IS NULL OR ts.tid = :tid )
        ORDER BY ts.itid, ts.ts

    cache.thread_state tuple: (ts, dur, state, cpu, tid, pid, itid, arg_setid)
    - tname 由 cache.thread_meta(itid) 取 (name, tid, ipid)
    - caller 由 cache.block_reason(arg_setid) 取；arg_setid 为 None 时 caller = None
    """
    start_ms = ctx.params.get("start_ms")
    end_ms = ctx.params.get("end_ms")
    if start_ms is None or end_ms is None:
        return None
    try:
        start_ns = int(start_ms * 1_000_000)
        end_ns = int(end_ms * 1_000_000)
    except (TypeError, ValueError):
        return None

    # 可选过滤参数
    tid_filter = ctx.params.get("tid")
    filter_thread_name = ctx.params.get("filter_thread_name")
    filter_process_name = ctx.params.get("filter_process_name")

    # tid 过滤：先转 itid；tid 为 None 时遍历所有 itid
    if tid_filter is not None:
        try:
            tid_int = int(tid_filter)
        except (TypeError, ValueError):
            return None
        itid = cache.tid_to_itid(tid_int)
        if not itid:
            # tid 不在 thread 表，返回空 DataFrame（与 SQL 行为一致）
            return pd.DataFrame(
                columns=["ts", "dur", "cpu", "itid", "tid", "pid",
                         "state", "tname", "caller"]
            )
        itids = [itid]
    else:
        # 无 tid 过滤：遍历 cache 中所有 itid
        if cache._thread_state is None:
            cache._build_thread_state()
        itids = list((cache._thread_state or {}).keys())

    # process_name 过滤：预取 pid 集合（仅 filter_process_name 非空时）
    pids_set = None
    if filter_process_name:
        # SQL 语义：p.name LIKE '%xxx%'，cache.process_name 返回完整 name，
        # 模糊匹配在 Python 端做（数据量小，可接受）
        try:
            rows = cache._conn.execute(
                "SELECT pid FROM process WHERE name LIKE ?",
                (f"%{filter_process_name}%",),
            ).fetchall()
            pids_set = {r[0] for r in rows}
            if not pids_set:
                # 进程名无匹配，返回空
                return pd.DataFrame(
                    columns=["ts", "dur", "cpu", "itid", "tid", "pid",
                             "state", "tname", "caller"]
                )
        except Exception as e:
            log.debug(f"无法查询 process 表: {e}")
            return None

    # thread_name 过滤：预取 itid 集合（仅 filter_thread_name 非空时）
    if filter_thread_name:
        # SQL 语义：t.name LIKE '%xxx%'，从 cache.thread_meta 全量扫描
        if cache._thread_meta is None:
            cache._build_thread_meta()
        try:
            from fnmatch import fnmatch
            pattern = f"*{filter_thread_name}*"
            valid_itids = {
                itid for itid, meta in (cache._thread_meta or {}).items()
                if meta and meta[0] and fnmatch(meta[0], pattern)
            }
            itids = [i for i in itids if i in valid_itids]
            if not itids:
                return pd.DataFrame(
                    columns=["ts", "dur", "cpu", "itid", "tid", "pid",
                             "state", "tname", "caller"]
                )
        except Exception as e:
            log.debug(f"thread_name 过滤失败: {e}")
            return None

    records = []
    d_states = ("D-IO", "D-NIO", "D", "D|W")
    for itid in itids:
        rows = cache.thread_state(itid, start_ns, end_ns)
        if not rows:
            continue
        thread_meta = cache.thread_meta(itid)
        tname = thread_meta[0] if thread_meta and thread_meta[0] else None
        tid_val = thread_meta[1] if thread_meta else None
        pid_val = thread_meta[2] if thread_meta else None

        for r in rows:
            # r = (ts, dur, state, cpu, tid, pid, itid, arg_setid)
            state = r[2]
            # 状态过滤：YAML SQL WHERE state IN ('D-IO', 'D-NIO', 'D', 'D|W')
            if state not in d_states:
                continue
            ts = r[0]
            dur = r[1]
            cpu = r[3]
            # tid / pid 取 thread 表 JOIN 结果（与 SQL 一致：ts.tid, ts.pid）
            # 但 cache.tid/pid 等价于 thread_state.tid/pid（同源）
            row_tid = r[4] if r[4] is not None else tid_val
            row_pid = r[5] if r[5] is not None else pid_val

            # 区间交集：(ts + dur) > start_ns AND ts < end_ns
            # cache._filter_intersection 已按此语义过滤，但需后过滤到 ts 范围内
            # 严格对齐 YAML SQL 的 `ts.ts < :end_ms * 1e6 AND (ts.ts + ts.dur) > :start_ms * 1e6`
            ts_end = ts + (dur or 0)
            if ts_end <= start_ns or ts >= end_ns:
                continue

            # process_name 过滤（按 pid）
            if pids_set is not None and row_pid not in pids_set:
                continue

            # caller 反查：arg_setid → cache.block_reason(arg_setid)
            arg_setid = r[7]
            caller = cache.block_reason(arg_setid) if arg_setid is not None else None

            records.append({
                "ts": ts,
                "dur": dur,
                "cpu": cpu,
                "itid": itid,
                "tid": row_tid,
                "pid": row_pid,
                "state": state,
                "tname": tname,
                "caller": caller,
            })

    # ORDER BY ts.itid, ts.ts（与 YAML SQL 一致）
    records.sort(key=lambda x: (x["itid"], x["ts"]))
    return pd.DataFrame(records, columns=[
        "ts", "dur", "cpu", "itid", "tid", "pid", "state", "tname", "caller",
    ])


def _compute_uninterruptible_duration_legacy(ctx: PreprocessContext) -> PreprocessContext:
    """legacy: 用 YAML SQL 拉取的 DataFrame 计算 D 状态耗时。

    cache 路径未命中时回退到此函数（ctx.data 已是 pd.read_sql_query 的结果）。
    """
    df = ctx.data
    required = {"ts", "itid", "state"}
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(
            f"compute_uninterruptible_duration 输入缺少列: {sorted(missing)}; "
            f"请确认 SQL 输出已包含 {sorted(required)}"
        )

    if not len(df):
        ctx.meta["thread_count"] = 0
        ctx.meta["total_dio_ms"] = 0.0
        ctx.meta["total_dio_events"] = 0
        ctx.meta["total_dnio_ms"] = 0.0
        ctx.meta["total_dnio_events"] = 0
        ctx.data = pd.DataFrame(columns=[
            "tid", "tname", "pid",
            "dio_ms", "dio_events", "avg_dio_ms",
            "dnio_ms", "dnio_events",
            "io_count", "block_reason_distribution",
        ])
        return ctx

    # 读取时间范围用于 clamp（规则 30：区间交集后裁剪）
    start_ms = ctx.params.get("start_ms")
    end_ms = ctx.params.get("end_ms")
    start_ns = int(start_ms * 1_000_000) if start_ms is not None else None
    end_ns = int(end_ms * 1_000_000) if end_ms is not None else None

    # 预提取列为 numpy array，避免逐行 namedtuple/iterrows 装箱开销
    ts_arr = df["ts"].values
    dur_arr = pd.to_numeric(df["dur"], errors="coerce").values
    itid_arr = df["itid"].values
    tid_arr = df["tid"].values
    pid_arr = df["pid"].values
    state_arr = df["state"].values
    tname_arr = df["tname"].values
    # caller 列：主 SQL LEFT JOIN args+data_dict 已解析，无 caller 时为 NULL
    caller_arr = df["caller"].values if "caller" in df.columns else None

    # 一次遍历：同时聚合时长 + block_reason_distribution
    # thread_agg[itid] = {tid, pid, tname, dio_ns, dio_events, dnio_ns, dnio_events,
    #                     other_ns, other_events, io_count, block_reason_distribution}
    thread_agg: dict[int, dict[str, Any]] = {}

    for i in range(len(df)):
        itid = int(itid_arr[i])
        state = state_arr[i]
        dur_raw = dur_arr[i]
        dur_ns = int(dur_raw) if dur_raw == dur_raw else 0  # NaN check
        ts_ns = int(ts_arr[i])

        # 规则 30：clamp 到时间窗范围内
        if start_ns is not None and end_ns is not None:
            s = max(ts_ns, start_ns)
            e = min(ts_ns + dur_ns, end_ns)
            if e <= s:
                continue
            dur_ns = e - s

        if itid not in thread_agg:
            tname_val = tname_arr[i]
            thread_agg[itid] = {
                "tid": int(tid_arr[i]),
                "pid": int(pid_arr[i]),
                "tname": str(tname_val) if tname_val is not None and tname_val == tname_val else "",
                "dio_ns": 0,
                "dio_events": 0,
                "dnio_ns": 0,
                "dnio_events": 0,
                "other_ns": 0,
                "other_events": 0,
                "io_count": 0,
                "block_reason_distribution": {},
            }

        agg = thread_agg[itid]
        dur_ms = dur_ns / 1_000_000.0

        # 聚合时长
        if state == "D-IO":
            agg["dio_ns"] += dur_ns
            agg["dio_events"] += 1
        elif state == "D-NIO":
            agg["dnio_ns"] += dur_ns
            agg["dnio_events"] += 1
        else:  # D / D|W
            agg["other_ns"] += dur_ns
            agg["other_events"] += 1

        # 同时聚合 block_reason（仅 D-IO / D-NIO 有 caller）
        if caller_arr is not None and state in ("D-IO", "D-NIO"):
            caller_val = caller_arr[i]
            if caller_val is not None and caller_val == caller_val:  # 非 NaN/None
                caller = str(caller_val)
                agg["io_count"] += 1
                br = agg["block_reason_distribution"]
                if caller not in br:
                    br[caller] = {"count": 0, "total_ms": 0.0, "source": state}
                br[caller]["count"] += 1
                br[caller]["total_ms"] += dur_ms

    # ---- 构建结果列表 ----
    results = []
    other_total_ms = 0.0
    other_total_events = 0

    for itid, agg in thread_agg.items():
        dio_ms = round(agg["dio_ns"] / 1_000_000.0, 3)
        dnio_ms = round(agg["dnio_ns"] / 1_000_000.0, 3)
        other_ms = agg["other_ns"] / 1_000_000.0
        other_total_ms += other_ms
        other_total_events += agg["other_events"]

        avg_dio_ms = round(dio_ms / agg["dio_events"], 3) if agg["dio_events"] > 0 else 0.0

        results.append({
            "tid": agg["tid"],
            "tname": agg["tname"],
            "pid": agg["pid"],
            "dio_ms": dio_ms,
            "dio_events": agg["dio_events"],
            "avg_dio_ms": avg_dio_ms,
            "dnio_ms": dnio_ms,
            "dnio_events": agg["dnio_events"],
            "io_count": agg["io_count"],
            "block_reason_distribution": agg["block_reason_distribution"],
        })

    # 按 dio_ms 降序排列
    results.sort(key=lambda r: r["dio_ms"], reverse=True)

    result_df = pd.DataFrame(results)
    total_dio = result_df["dio_ms"].sum()
    total_dnio = result_df["dnio_ms"].sum()
    ctx.meta["thread_count"] = len(result_df)
    ctx.meta["total_dio_ms"] = round(float(total_dio), 3)
    ctx.meta["total_dio_events"] = int(result_df["dio_events"].sum())
    ctx.meta["total_dnio_ms"] = round(float(total_dnio) + other_total_ms, 3)
    ctx.meta["total_dnio_events"] = int(result_df["dnio_events"].sum() + other_total_events)
    ctx.data = result_df
    return ctx


@register_operator("format_uninterruptible_summary")
def format_uninterruptible_summary(ctx: PreprocessContext) -> PreprocessContext:
    """收敛不可中断状态耗时至 LLM 友好摘要。

    输入:
        ctx.data: compute_uninterruptible_duration 输出的聚合 DataFrame
        ctx.meta: 包含 total_dio_ms / thread_count 等统计信息
    输出:
        ctx.data: dict 含 summary / data
    """
    df = ctx.data
    thread_count = ctx.meta.get("thread_count", 0)
    total_dio_ms = ctx.meta.get("total_dio_ms", 0.0)
    total_dio_events = ctx.meta.get("total_dio_events", 0)
    total_dnio_ms = ctx.meta.get("total_dnio_ms", 0.0)
    total_dnio_events = ctx.meta.get("total_dnio_events", 0)

    top_n = int(ctx.params.get("top_n", 50))

    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "summary": {
                "type": "uninterruptible_dstate_summary",
                "thread_count": 0,
                "io_total_ms": 0.0,
                "io_events": 0,
                "non_io_total_ms": 0.0,
                "non_io_events": 0,
            },
            "data": [],
        }
        return ctx

    top_df = df.head(top_n)

    data = []
    for _, row in top_df.iterrows():
        entry = {
            "tid": int(row["tid"]),
            "tname": str(row.get("tname", "")),
            "pid": int(row["pid"]) if "pid" in row and pd.notna(row["pid"]) else 0,
            "io_ms": float(row["dio_ms"]),
            "io_events": int(row["dio_events"]),
            "avg_io_ms": float(row["avg_dio_ms"]),
            "non_io_ms": float(row["dnio_ms"]),
            "non_io_events": int(row["dnio_events"]),
        }
        # block_reason_distribution: top 5 by total_ms
        br_dist = row.get("block_reason_distribution", {})
        if br_dist and isinstance(br_dist, dict):
            sorted_br = sorted(br_dist.items(), key=lambda x: x[1].get("total_ms", 0.0), reverse=True)[:5]
            entry["block_reason_distribution"] = {
                caller: {
                    "count": info["count"],
                    "total_ms": round(info["total_ms"], 3),
                    "source": info.get("source", "unknown"),
                }
                for caller, info in sorted_br
            }
        else:
            entry["block_reason_distribution"] = {}

        data.append(entry)

    ctx.data = {
        "summary": {
            "type": "uninterruptible_dstate_summary",
            "thread_count": thread_count,
            "io_total_ms": round(total_dio_ms, 3),
            "io_events": total_dio_events,
            "non_io_total_ms": round(total_dnio_ms, 3),
            "non_io_events": total_dnio_events,
        },
        "data": data,
    }
    return ctx
