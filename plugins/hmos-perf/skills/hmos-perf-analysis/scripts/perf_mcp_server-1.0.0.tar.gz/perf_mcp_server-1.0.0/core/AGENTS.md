<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-06-11 -->

# core — Engine Core

## Purpose
Core engine of the perf-mcp-server: configuration loading (registry), SQL query rendering and execution (query_engine), declarative skill workflow execution (skill_executor), YAML validation, data sampling, flamegraph collapse, chip identification, rendering pipeline detection, and structured observability logging. This directory is the backbone of the system — all MCP tools exposed by server.py delegate to modules here.

## Key Files

| File | Description |
|------|-------------|
| `registry.py` | ConfigRegistry: loads config/indicators/**/*.yaml and config/skills/*.yaml, parses into data classes, validates via validators.py. ❌ Do not modify directly — requires human review. |
| `query_engine.py` | QueryEngine: renders SQL templates, binds parameters, executes against SQLite, applies sampling strategies, dispatches to preprocess pipelines. ❌ Do not modify directly — requires human review. |
| `skill_executor.py` | SkillExecutor: runtime engine for skill workflows. Handles expression resolution, iterate loops, LLM action breakpoints, default_indicator_params injection. ⚠️ Modifications must preserve Tool signatures. |
| `skill_router.py` | SkillRouter: assembles MCP response payloads for list_skills, get_skill tools. Manages priority-based routing table for agent intent matching. |
| `validators.py` | YAML validation: sql_params coverage, schema conformance, naming conventions, circular dependency detection. Also usable standalone via scripts/validate_yaml.py. |
| `sampling.py` | Downsampling strategies: timeseries bucket aggregation, non-timeseries Top-N, scalar passthrough, histogram generation. |
| `flamegraph_collapse.py` | Four-layer flame graph processing: function name normalization, self-time pruning, system library collapsing, hot path extraction. |
| `chip_identify.py` | Thin facade for the identify_chip MCP tool, delegates to preprocess.chip_config. |
| `rendering_pipeline.py` | Rendering pipeline detection engine (1,946 lines, largest module). 9-step detection workflow: signal scoring, ranking, subvariant detection, auto-pin generation. Loads from config/pipelines/ YAML definitions. |
| `observability.py` | JSONL structured logging: session-scoped, daily file rotation, module-level loggers. Output to logs/observability/{date}/. |
| `__init__.py` | Package init, version 2.2.0. |

## Subdirectories

| Directory | Purpose |
|-----------|---------|
| `preprocess/` | 40+ registered preprocessing operators (see `preprocess/AGENTS.md`) |
| `extensions/` | Optional database augmentation (page cache events) (see `extensions/AGENTS.md`) |
| `rendering/` | Rendering pipeline data models (see `rendering/AGENTS.md`) |

## For AI Agents

### Working In This Directory
- `registry.py` and `query_engine.py` are **no-edit zones** — require human review for any changes.
- `skill_executor.py` requires confirmation that Tool signatures are unchanged after any modification.
- All other files: follow standard PR process with test coverage.

### Testing Requirements
- Changes to `validators.py` must have corresponding test cases in `tests/`.
- Changes to `sampling.py` must verify with `test_bigdata_sampling.py`.
- Changes to `rendering_pipeline.py` must verify pipeline detection accuracy.
- Run `pytest tests/ -v --tb=short` before committing.

### Common Patterns
- `@register_operator` decorator for preprocessing operators.
- `(ctx: PreprocessContext) -> PreprocessContext` protocol for operator functions.
- Three-tier parameter merging: sql_params defaults < group override_params < agent indicator_params < base_params.
- Global singletons initialized in server.py: `ConfigRegistry`, `QueryEngine`, `SkillExecutor`.

## Dependencies

### Internal
- `config/` — YAML configuration files loaded by registry
- `core/preprocess/` — Operator implementations invoked by query_engine and skill_executor
- `utils/` — Utility modules (process_name mapping)

### External
- `pyyaml` — YAML parsing
- `pydantic` — Data validation
- `pandas` — Data manipulation
- `sqlite3` (stdlib) — Database queries
