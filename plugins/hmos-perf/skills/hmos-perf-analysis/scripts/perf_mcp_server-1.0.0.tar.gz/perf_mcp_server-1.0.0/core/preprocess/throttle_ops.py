"""CPU 限速（Throttle）检测算子。

基于 measure 表的 cpu_frequency_limits_max / cpu_frequency / boost 信号，
结合芯片配置动态识别 cluster 和 chip_max，检测限速事件并判定原因。

算法流程:
    1. 通过 ctx.trace_cache.chip_config() 获取芯片配置
    2. 构建 cluster -> chip_max 映射
    3. 遍历 limit 记录，判断限速（soft_limit < chip_max）并判定原因
    4. 同 cluster + 同 limit + gap < 10ms 合并相邻段
    5. 构建 summary 汇总
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from core.observability import get_observability_logger
from core.preprocess.base import PreprocessContext, PreprocessError, register_operator

_log = get_observability_logger("throttle_ops")

# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------


@dataclass
class ClusterInfo:
    """单个 cluster 的芯片配置（仅保留限速检测所需字段）。"""

    name: str
    chip_max_mhz: int


@dataclass
class ThrottleEvent:
    """单个限速事件。"""

    cluster: str
    ts_ns: int
    ts_end_ns: int
    soft_limit_mhz: float
    chip_max_mhz: int
    reason: str
    count: int = 1

    @property
    def duration_ms(self) -> float:
        return (self.ts_end_ns - self.ts_ns) / 1_000_000.0


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------


def _build_cluster_map(chip_info: Dict[str, Any]) -> Dict[int, ClusterInfo]:
    """从 chip_config 构建 cpuid -> ClusterInfo 的映射。

    复用 chip_config.get_cpuid_cluster_map 的 O(1) 查询,
    保留 ClusterInfo 数据类(仅含限速检测所需 chip_max_mhz 字段)。
    """
    from core.preprocess.chip_config import get_cpuid_cluster_map

    cluster_name_map = get_cpuid_cluster_map(chip_info)  # cpuid → cluster_name
    # 反向查 cluster_name → cluster_cfg(取 freq_max_mhz)
    clusters_data = chip_info.get("clusters", [])
    name_to_cfg = {cl.get("cluster_name"): cl for cl in clusters_data}

    cpuid_to_cluster: Dict[int, ClusterInfo] = {}
    cluster_names: List[str] = []
    for cpuid, name in cluster_name_map.items():
        cfg = name_to_cfg.get(name) or {}
        chip_max = cfg.get("freq_max_mhz", 0)
        ci = ClusterInfo(name=name, chip_max_mhz=chip_max)
        cpuid_to_cluster[cpuid] = ci
        if name not in cluster_names:
            cluster_names.append(name)

    _log.info("cluster_map_built", chip_model=chip_info.get("chip_model", "unknown"),
              clusters=cluster_names, cpuid_mapped_count=len(cpuid_to_cluster))
    return cpuid_to_cluster


def _prepare_boost_intervals(boost_signals: pd.DataFrame):
    """从 boost_signals DataFrame 提取 active=1 的 [ts_ns, ts_end_ns] numpy 数组。

    返回 (b_ts_arr, b_te_arr)；空时返回两个空数组。
    """
    if boost_signals.empty:
        return np.array([], dtype=np.int64), np.array([], dtype=np.int64)
    active = boost_signals[boost_signals["boost_val"] == 1]
    if active.empty:
        return np.array([], dtype=np.int64), np.array([], dtype=np.int64)
    b_ts_arr = active["ts_ns"].values.astype(np.int64)
    b_te_arr = active["ts_end_ns"].values.astype(np.int64)
    return b_ts_arr, b_te_arr


def _determine_reason_from_intervals(
    ts_ns: int, ts_end_ns: int, b_ts_arr, b_te_arr
) -> str:
    """判断限速原因：与 thermal boost 信号有重叠则为 thermal，否则为 load_based。"""
    if len(b_ts_arr) == 0:
        return "load_based"
    # 向量化重叠判断: ts_ns < b_te AND ts_end_ns > b_ts
    overlap = np.any((ts_ns < b_te_arr) & (ts_end_ns > b_ts_arr))
    return "thermal" if overlap else "load_based"


# ---------------------------------------------------------------------------
# 主算子
# ---------------------------------------------------------------------------


@register_operator("detect_freq_throttle")
def detect_freq_throttle(ctx: PreprocessContext) -> PreprocessContext:
    """CPU 限速检测主算子。

    输入 ctx.data:
        DataFrame with columns:
            cpu, ts_ns, ts_end_ns, soft_limit_mhz, boost_name, boost_val, freq_mhz, data_type

    输出 ctx.data:
        {"summary": {...}, "data": [ThrottleEvent, ...]}
    """
    df: pd.DataFrame = ctx.data  # type: ignore[assignment]
    cluster_filter: Optional[str] = ctx.params.get("cluster")

    if df.empty:
        ctx.data = {"summary": {"total_throttle_events": 0, "total_throttle_duration_ms": 0,
                                "by_cluster": {}}, "data": []}
        return ctx

    # ---- step 1: 分离三路数据 ----
    df_limits = df[df["data_type"] == "limits"].copy()
    df_boost = df[df["data_type"] == "boost"]
    df_freq = df[df["data_type"] == "freq"]

    _log.info("data_split", limits_rows=len(df_limits), boost_rows=len(df_boost), freq_rows=len(df_freq))

    # ---- step 2: 芯片识别 + cluster 映射 ----
    cache = ctx.trace_cache
    if cache is None:
        raise PreprocessError("detect_freq_throttle: trace_cache 不可用")
    chip_info = cache.chip_config()
    cpuid_to_cluster = _build_cluster_map(chip_info)

    if df_limits.empty:
        ctx.data = {"summary": {"total_throttle_events": 0, "total_throttle_duration_ms": 0,
                                "by_cluster": {}}, "data": []}
        _log.info("no_limits_data")
        return ctx

    # ---- step 3: 遍历 limit 记录，判断限速 ----
    # 按 (cluster, cpu) 排序，逐条扫描
    df_limits = df_limits.sort_values(["cpu", "ts_ns"]).reset_index(drop=True)

    events: List[ThrottleEvent] = []

    # 按 cluster 分组处理
    # 先给每条记录加上 cluster 标签
    limits_with_cluster = []
    for _, row in df_limits.iterrows():
        cpu = int(row["cpu"])
        cl = cpuid_to_cluster.get(cpu)
        if cl is None:
            continue
        if cluster_filter and cl.name != cluster_filter:
            continue
        limits_with_cluster.append((cl, row))

    # 预计算 boost intervals（避免在循环内重复过滤+iterrows）
    b_ts_arr, b_te_arr = _prepare_boost_intervals(df_boost)

    if not limits_with_cluster:
        ctx.data = {"summary": {"total_throttle_events": 0, "total_throttle_duration_ms": 0,
                                "by_cluster": {}}, "data": []}
        _log.info("no_limits_after_cluster_filter")
        return ctx

    # 按 cluster 分组，每个 cluster 内所有 CPU 的记录按时间排序后合并
    cluster_rows: Dict[str, List[Any]] = defaultdict(list)
    for cl, row in limits_with_cluster:
        cluster_rows[cl.name].append((cl, row))

    for cluster_name, rows in cluster_rows.items():
        cl = rows[0][0]  # ClusterInfo
        chip_max = cl.chip_max_mhz

        # 同 cluster 下所有 CPU 按时间排序
        rows.sort(key=lambda x: (x[1]["ts_ns"], x[1]["cpu"]))

        current: Optional[ThrottleEvent] = None

        for _, row in rows:
            ts = int(row["ts_ns"])
            ts_end = int(row["ts_end_ns"])
            soft_limit = float(row["soft_limit_mhz"])

            # 非限速 → 跳过
            if soft_limit >= chip_max:
                continue

            # 判断原因
            reason = _determine_reason_from_intervals(ts, ts_end, b_ts_arr, b_te_arr)

            if current is None:
                current = ThrottleEvent(
                    cluster=cluster_name,
                    ts_ns=ts,
                    ts_end_ns=ts_end,
                    soft_limit_mhz=soft_limit,
                    chip_max_mhz=chip_max,
                    reason=reason,
                    count=1,
                )
            elif (current.soft_limit_mhz == soft_limit
                  and (ts - current.ts_end_ns) / 1_000_000.0 < 10.0):
                # 同 limit + gap < 10ms → 合并
                current.ts_end_ns = max(current.ts_end_ns, ts_end)
                current.count += 1
                # reason 优先 thermal
                if reason == "thermal":
                    current.reason = "thermal"
            else:
                # 输出当前事件，开启新事件
                events.append(current)
                current = ThrottleEvent(
                    cluster=cluster_name,
                    ts_ns=ts,
                    ts_end_ns=ts_end,
                    soft_limit_mhz=soft_limit,
                    chip_max_mhz=chip_max,
                    reason=reason,
                    count=1,
                )

        # 输出最后一个事件
        if current is not None:
            events.append(current)

    # ---- step 4: 构建 summary ----
    total_duration_ms = sum(e.duration_ms for e in events)

    by_cluster: Dict[str, Dict[str, Any]] = {}
    for e in events:
        if e.cluster not in by_cluster:
            by_cluster[e.cluster] = {
                "event_count": 0,
                "total_duration_ms": 0.0,
                "thermal_count": 0,
                "load_based_count": 0,
                "chip_max_mhz": e.chip_max_mhz,
                "soft_limit_min_mhz": float("inf"),
                "soft_limit_max_mhz": float("-inf"),
                "soft_limit_sum_mhz": 0.0,
            }
        bc = by_cluster[e.cluster]
        bc["event_count"] += 1
        bc["total_duration_ms"] += e.duration_ms
        bc["soft_limit_min_mhz"] = min(bc["soft_limit_min_mhz"], e.soft_limit_mhz)
        bc["soft_limit_max_mhz"] = max(bc["soft_limit_max_mhz"], e.soft_limit_mhz)
        bc["soft_limit_sum_mhz"] += e.soft_limit_mhz
        if e.reason == "thermal":
            bc["thermal_count"] += 1
        else:
            bc["load_based_count"] += 1

    # 四舍五入到 3 位小数 + 计算平均限频
    total_duration_ms = round(total_duration_ms, 3)
    for bc in by_cluster.values():
        bc["total_duration_ms"] = round(bc["total_duration_ms"], 3)
        if bc["event_count"] > 0:
            bc["soft_limit_avg_mhz"] = round(bc["soft_limit_sum_mhz"] / bc["event_count"], 3)
        else:
            bc["soft_limit_avg_mhz"] = 0.0
        bc["soft_limit_min_mhz"] = round(bc["soft_limit_min_mhz"], 3)
        bc["soft_limit_max_mhz"] = round(bc["soft_limit_max_mhz"], 3)
        del bc["soft_limit_sum_mhz"]

    # ---- step 5: 输出 ----
    data_list = []
    for e in events:
        data_list.append({
            "cluster": e.cluster,
            "ts_ms": round(e.ts_ns / 1_000_000.0, 6),
            "ts_end_ms": round(e.ts_end_ns / 1_000_000.0, 6),
            "soft_limit_mhz": e.soft_limit_mhz,
            "chip_max_mhz": e.chip_max_mhz,
            "reason": e.reason,
            "count": e.count,
            "duration_ms": round(e.duration_ms, 3),
        })

    ctx.data = {
        "summary": {
            "total_throttle_events": len(events),
            "total_throttle_duration_ms": total_duration_ms,
            "by_cluster": by_cluster,
        },
        "data": data_list,
    }

    _log.info("throttle_detect_done",
              total_events=len(events),
              total_duration_ms=total_duration_ms,
              clusters=list(by_cluster.keys()),
              chip_model=chip_info.get("chip_model", "unknown"))

    return ctx
