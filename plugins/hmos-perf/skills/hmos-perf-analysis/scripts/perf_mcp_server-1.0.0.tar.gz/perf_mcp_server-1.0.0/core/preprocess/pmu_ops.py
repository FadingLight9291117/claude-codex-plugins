"""PMU 计数器预处理算子。

从 phase_task_delta 表读取 delta_0~9，按 delta_mapping 映射为具名事件，
计算 IPC / MPKI 等指标。
"""
from __future__ import annotations

from typing import Any

from .base import PreprocessContext, PreprocessError, register_operator

# 默认 PMU 事件与 delta 列索引的映射关系
DEFAULT_DELTA_MAPPING = {
    "INST_RETIRED": 0,
    "L2D_CACHE_REFILL": 1,
    "L3D_CACHE_REFILL": 2,
    "L3D_CACHE_REFILL_RD": 3,
    "ACCESS_BUS": 4,
    "CPU_CYCLES": 5,
}


def _parse_delta_mapping(mapping_str: str) -> dict[str, int]:
    """解析 delta_mapping 字符串为 {事件名: delta列索引} 字典。

    格式: "INST_RETIRED:0,L2D_CACHE_REFILL:1,..."
    """
    if not mapping_str:
        return dict(DEFAULT_DELTA_MAPPING)
    result = {}
    for part in mapping_str.split(","):
        part = part.strip()
        if not part:
            continue
        if ":" not in part:
            continue
        key, val = part.split(":", 1)
        result[key.strip()] = int(val.strip())
    if not result:
        return dict(DEFAULT_DELTA_MAPPING)
    return result


def _compute_percentile(values: list[float], p: float) -> float | None:
    """计算分位数。"""
    if not values:
        return None
    sorted_vals = sorted(values)
    idx = int(len(sorted_vals) * p / 100.0)
    if idx >= len(sorted_vals):
        idx = len(sorted_vals) - 1
    return round(sorted_vals[idx], 3)


def _get_delta_col(df, col_idx: int | None) -> list:
    """安全获取 delta 列数据。

    col_idx 是 delta_mapping 中的列索引（如 0 表示 delta_0），
    需要映射到实际的 DataFrame 列名。
    """
    if col_idx is None:
        return []
    col_name = f"delta_{col_idx}"
    if col_name not in df.columns:
        return []
    return df[col_name].tolist()


@register_operator("compute_pmc_stats")
def compute_pmc_stats(ctx: PreprocessContext) -> PreprocessContext:
    """PMU 聚合统计：按 CPU 聚合后计算 IPC / MPKI。

    输入:
        ctx.data: DataFrame，含 ts/cpu/tid/dur/delta_0~9 列
        ctx.params: {
            cpu_ids: "0,1,2" 或 None,
            delta_mapping: "INST_RETIRED:0,CPU_CYCLES:5,..."
        }
    输出:
        ctx.data: {
            time_range: {...},
            filter: {...},
            summary: {system_avg_ipc, system_avg_ipc_p90, system_avg_ipc_p99, ...},
            per_cpu: [{cpu_id, avg_ipc, p90_ipc, p99_ipc, ...}, ...]
        }
    """
    import pandas as pd

    df = ctx.data
    if not isinstance(df, pd.DataFrame):
        raise PreprocessError("compute_pmc_stats 输入必须是 DataFrame")

    required_cols = {"ts", "cpu", "tid", "dur"}
    missing = required_cols - set(df.columns)
    if missing:
        raise PreprocessError(f"compute_pmc_stats 缺少列: {sorted(missing)}")

    # 解析 delta_mapping
    mapping_str = ctx.params.get("delta_mapping", "")
    delta_mapping = _parse_delta_mapping(mapping_str)

    # 解析 cpu_ids 过滤
    cpu_ids_param = ctx.params.get("cpu_ids")
    if cpu_ids_param:
        try:
            filter_cpu_ids = {int(x.strip()) for x in str(cpu_ids_param).split(",") if x.strip()}
        except ValueError:
            filter_cpu_ids = None
    else:
        filter_cpu_ids = None

    # 应用 CPU 过滤
    if filter_cpu_ids:
        df = df[df["cpu"].isin(filter_cpu_ids)]

    if df.empty:
        ctx.data = {
            "time_range": _build_time_range(ctx),
            "filter": _build_filter(ctx, delta_mapping),
            "summary": _empty_summary(),
            "per_cpu": [],
        }
        return ctx

    # 收集各 CPU 的采样点 IPC 列表
    cpu_groups: dict[int, dict[str, Any]] = {}
    all_ipc_values: list[float] = []

    inst_col = delta_mapping.get("INST_RETIRED")
    cycles_col = delta_mapping.get("CPU_CYCLES")
    l2d_col = delta_mapping.get("L2D_CACHE_REFILL")
    l3d_col = delta_mapping.get("L3D_CACHE_REFILL")
    l3d_rd_col = delta_mapping.get("L3D_CACHE_REFILL_RD")
    access_bus_col = delta_mapping.get("ACCESS_BUS")

    for cpu_id, group in df.groupby("cpu"):
        inst_vals = _get_delta_col(group, inst_col) if inst_col is not None else []
        cycles_vals = _get_delta_col(group, cycles_col) if cycles_col is not None else []
        l2d_vals = _get_delta_col(group, l2d_col) if l2d_col is not None else []
        l3d_vals = _get_delta_col(group, l3d_col) if l3d_col is not None else []
        l3d_rd_vals = _get_delta_col(group, l3d_rd_col) if l3d_rd_col is not None else []
        access_bus_vals = _get_delta_col(group, access_bus_col) if access_bus_col is not None else []

        total_inst = sum(v for v in inst_vals if v == v and v >= 0)
        total_cycles = sum(v for v in cycles_vals if v == v and v >= 0)
        total_l2d = sum(v for v in l2d_vals if v == v and v >= 0)
        total_l3d = sum(v for v in l3d_vals if v == v and v >= 0)
        total_l3d_rd = sum(v for v in l3d_rd_vals if v == v and v >= 0)
        total_access_bus = sum(v for v in access_bus_vals if v == v and v >= 0)
        total_dur_ns = int(group["dur"].sum()) if "dur" in group.columns else 0
        total_dur_ms = round(total_dur_ns / 1e6, 3)

        # 计算该 CPU 各采样点的 IPC
        ipc_per_sample: list[float] = []
        min_len = min(len(inst_vals), len(cycles_vals)) if (inst_vals and cycles_vals) else 0
        for i in range(min_len):
            inst = inst_vals[i]
            cycles = cycles_vals[i]
            if cycles and cycles > 0:
                ipc_per_sample.append(inst / cycles)

        all_ipc_values.extend(ipc_per_sample)

        cpu_groups[cpu_id] = {
            "cpu_id": cpu_id,
            "total_instructions": total_inst,
            "total_cycles": total_cycles,
            "total_l2d": total_l2d,
            "total_l3d": total_l3d,
            "total_l3d_rd": total_l3d_rd,
            "total_access_bus": total_access_bus,
            "total_dur_ms": total_dur_ms,
            "ipc_per_sample": ipc_per_sample,
        }

    # 计算全系统汇总
    system_inst = sum(g["total_instructions"] for g in cpu_groups.values())
    system_cycles = sum(g["total_cycles"] for g in cpu_groups.values())
    system_l2d = sum(g["total_l2d"] for g in cpu_groups.values())
    system_l3d = sum(g["total_l3d"] for g in cpu_groups.values())
    system_l3d_rd = sum(g["total_l3d_rd"] for g in cpu_groups.values())
    system_access_bus = sum(g["total_access_bus"] for g in cpu_groups.values())

    # 构建 per_cpu 结果
    per_cpu = []
    for cpu_id in sorted(cpu_groups.keys()):
        g = cpu_groups[cpu_id]
        inst = g["total_instructions"]
        cycles = g["total_cycles"]
        l2d = g["total_l2d"]
        l3d = g["total_l3d"]
        l3d_rd = g["total_l3d_rd"]
        access_bus = g["total_access_bus"]
        ipc_list = g["ipc_per_sample"]

        avg_ipc = round(inst / cycles, 6) if cycles and cycles > 0 and inst is not None else None
        l2d_cache_miss_mpki = round(l2d / inst * 1000, 3) if inst and inst > 0 and l2d is not None else None
        l3d_cache_miss_mpki = round(l3d / inst * 1000, 3) if inst and inst > 0 and l3d is not None else None
        l3d_rd_mpki = round(l3d_rd / inst * 1000, 3) if inst and inst > 0 and l3d_rd is not None else None
        access_bus_mpki = round(access_bus / inst * 1000, 3) if inst and inst > 0 and access_bus is not None else None

        per_cpu.append({
            "cpu_id": cpu_id,
            "avg_ipc": avg_ipc,
            "p90_ipc": _compute_percentile(ipc_list, 90),
            "p99_ipc": _compute_percentile(ipc_list, 99),
            "total_instructions": inst,
            "total_cycles": cycles,
            "total_dur_ms": g["total_dur_ms"],
            "l2d_cache_miss_mpki": l2d_cache_miss_mpki,
            "l3d_cache_miss_mpki": l3d_cache_miss_mpki,
            "l3d_cache_refill_rd_mpki": l3d_rd_mpki,
            "access_bus_mpki": access_bus_mpki,
        })

    # 全系统 summary
    system_avg_ipc = round(system_inst / system_cycles, 6) if system_cycles and system_cycles > 0 else None
    system_l2d_cache_miss_mpki = round(system_l2d / system_inst * 1000, 3) if system_inst and system_inst > 0 else None
    system_l3d_cache_miss_mpki = round(system_l3d / system_inst * 1000, 3) if system_inst and system_inst > 0 else None
    system_l3d_rd_mpki = round(system_l3d_rd / system_inst * 1000, 3) if system_inst and system_inst > 0 else None
    system_access_bus_mpki = round(system_access_bus / system_inst * 1000, 3) if system_inst and system_inst > 0 else None

    summary = {
        "system_avg_ipc": system_avg_ipc,
        "system_avg_ipc_p90": _compute_percentile(all_ipc_values, 90),
        "system_avg_ipc_p99": _compute_percentile(all_ipc_values, 99),
        "system_instructions": system_inst,
        "system_cycles": system_cycles,
        "system_total_dur_ms": round(sum(g["total_dur_ms"] for g in cpu_groups.values()), 3),
        "l2d_cache_miss_mpki": system_l2d_cache_miss_mpki,
        "l3d_cache_miss_mpki": system_l3d_cache_miss_mpki,
        "l3d_cache_refill_rd_mpki": system_l3d_rd_mpki,
        "access_bus_mpki": system_access_bus_mpki,
    }

    ctx.data = {
        "time_range": _build_time_range(ctx),
        "filter": _build_filter(ctx, delta_mapping),
        "summary": summary,
        "per_cpu": per_cpu,
    }
    return ctx


@register_operator("compute_pmc_timeline")
def compute_pmc_timeline(ctx: PreprocessContext) -> PreprocessContext:
    """PMU 时序数据：返回每条原始采样记录。

    输入:
        ctx.data: DataFrame，含 ts/cpu/tid/dur/delta_0~9 列
        ctx.params: {cpu_ids: "0,1,2" 或 None, delta_mapping: "..."}
    输出:
        ctx.data: list[dict]，每条记录含 ts/cpu_id/tid/dur 及具名 PMU 事件
    """
    import pandas as pd

    df = ctx.data
    if not isinstance(df, pd.DataFrame):
        raise PreprocessError("compute_pmc_timeline 输入必须是 DataFrame")

    # 解析 delta_mapping
    mapping_str = ctx.params.get("delta_mapping", "")
    delta_mapping = _parse_delta_mapping(mapping_str)

    # 解析 cpu_ids 过滤
    cpu_ids_param = ctx.params.get("cpu_ids")
    if cpu_ids_param:
        try:
            filter_cpu_ids = {int(x.strip()) for x in str(cpu_ids_param).split(",") if x.strip()}
        except ValueError:
            filter_cpu_ids = None
    else:
        filter_cpu_ids = None

    if filter_cpu_ids:
        df = df[df["cpu"].isin(filter_cpu_ids)]

    # 构建具名事件映射
    event_names = {
        "INST_RETIRED": "instructions",
        "CPU_CYCLES": "cycles",
        "L2D_CACHE_REFILL": "l2d_cache_refill",
        "L3D_CACHE_REFILL": "l3d_cache_refill",
        "L3D_CACHE_REFILL_RD": "l3d_cache_refill_rd",
        "ACCESS_BUS": "access_bus",
    }

    result = []
    for _, row in df.iterrows():
        rec: dict[str, Any] = {
            "ts": int(row["ts"]),
            "cpu_id": int(row["cpu"]),
            "tid": int(row["tid"]) if row["tid"] == row["tid"] else None,
            "dur": int(row["dur"]) if row["dur"] == row["dur"] else None,
        }
        # 按 delta_mapping 添加具名事件
        for event_name, col_idx in delta_mapping.items():
            col_name = f"delta_{col_idx}"
            if col_name not in df.columns:
                continue
            val = row[col_name]
            if val == val and val >= 0:  # 过滤 NaN
                field_name = event_names.get(event_name, event_name.lower())
                rec[field_name] = int(val)
        result.append(rec)

    ctx.data = result
    return ctx


def _build_time_range(ctx: PreprocessContext) -> dict:
    """从 meta 构建时间范围信息。

    meta 里的 start_ms/end_ms 已经是 ms 单位，直接使用。
    """
    start_ms = ctx.meta.get("start_ms")
    end_ms = ctx.meta.get("end_ms")
    if start_ms is not None and end_ms is not None:
        dur_ms = end_ms - start_ms
    else:
        dur_ms = None
    return {
        "start_ms": start_ms,
        "end_ms": end_ms,
        "dur_ms": dur_ms,
    }


def _build_filter(ctx: PreprocessContext, delta_mapping: dict) -> dict:
    """构建 filter 信息。tid 从 meta（SQL 层传入），cpu_ids/delta_mapping 从 params。"""
    return {
        "tid": ctx.meta.get("tid"),
        "cpu_ids": ctx.params.get("cpu_ids"),
        "delta_mapping": ctx.params.get("delta_mapping", ""),
    }


def _empty_summary() -> dict:
    """返回空 summary。"""
    return {
        "system_avg_ipc": None,
        "system_avg_ipc_p90": None,
        "system_avg_ipc_p99": None,
        "system_instructions": None,
        "system_cycles": None,
        "system_total_dur_ms": None,
        "l2d_cache_miss_mpki": None,
        "l3d_cache_miss_mpki": None,
        "l3d_cache_refill_rd_mpki": None,
        "access_bus_mpki": None,
    }
