"""预处理算子基类与注册中心。

所有可被 ``preprocess.pipeline`` 引用的步骤都必须通过 ``@register_operator``
注册到 ``OPERATORS`` 字典；之后 YAML 里写算子名即可串起来：

```yaml
preprocess:
  pipeline:
    - op: pair_lifecycle_events
      params:
        pid_field: pid
    - op: compute_phase_durations
    - op: identify_bottleneck_phase
      params:
        threshold_ms: :bottleneck_threshold_ms   # 引用 sql_params 的同名参数
    - op: format_phase_summary
```

每个算子实现 ``run(ctx) -> ctx`` 协议：从 ``ctx.data`` 读取 DataFrame / 列表，
计算后写回 ``ctx.data``，并把可选的统计写入 ``ctx.meta``。
"""
from __future__ import annotations

import re as _re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Protocol

from core.observability import get_observability_logger


class PreprocessError(Exception):
    """单个算子内部抛出的可恢复错误，由 QueryEngine 捕获并写入 errors 字段。"""


@dataclass
class PreprocessContext:
    """流水线执行上下文。

    Attributes:
        data: 当前阶段的数据载荷（通常是 ``pandas.DataFrame``，但允许任意类型）
        meta: 累积的元信息（每个算子可写入诊断字段）
        params: 当前算子的入参（已解析过 :xxx 引用）
        sqlite_conn: 部分算子可能需要回查 SQLite（如 launch 阶段对照表）
        indicator_meta: 原子指标元信息（IndicatorMeta），便于读取 sql_params 默认值
        trace_cache: 连接级 TraceDataCache（方案 D，框架注入，替代算子内 N+1 SQL）
    """

    data: Any
    meta: Dict[str, Any] = field(default_factory=dict)
    params: Dict[str, Any] = field(default_factory=dict)
    sqlite_conn: Optional[Any] = None
    indicator_meta: Optional[Any] = None
    trace_cache: Optional[Any] = None

    def with_params(self, params: Dict[str, Any]) -> "PreprocessContext":
        """返回一个共享 data/meta 但 params 不同的浅副本，便于算子隔离参数。"""
        return PreprocessContext(
            data=self.data,
            meta=self.meta,
            params=params,
            sqlite_conn=self.sqlite_conn,
            indicator_meta=self.indicator_meta,
            trace_cache=self.trace_cache,
        )


class PreprocessOperator(Protocol):
    """算子协议：接收 ctx，返回更新后的 ctx。"""

    name: str

    def run(self, ctx: PreprocessContext) -> PreprocessContext:
        ...


# 全局算子注册表（模块导入时填充）
OPERATORS: Dict[str, Callable[[PreprocessContext], PreprocessContext]] = {}


def register_operator(name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """装饰器：把一个 ``run(ctx) -> ctx`` 函数注册到 OPERATORS。

    用法:
        @register_operator("pair_lifecycle_events")
        def pair_lifecycle_events(ctx):
            ...
            return ctx
    """

    def deco(func: Callable[..., Any]) -> Callable[..., Any]:
        if name in OPERATORS:
            raise ValueError(f"预处理算子重复注册: {name}")
        OPERATORS[name] = func
        func.operator_name = name  # type: ignore[attr-defined]
        return func

    return deco


def run_pipeline(
    steps: List[Dict[str, Any]],
    ctx: PreprocessContext,
    *,
    param_resolver: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None,
    session_id: str = "",
    indicator: str = "",
) -> PreprocessContext:
    """按顺序跑完 pipeline 列表，把每步算子的输出串起来。

    Args:
        steps: 形如 ``[{"op": "name", "params": {...}}, ...]`` 的列表，
               每步必须含 ``op`` 字段；``params`` 会先用 ``param_resolver``
               解析其中的 ``:xxx`` 引用再传给算子。
        ctx:   起始上下文（含 SQL 查询返回的 DataFrame 等）
        param_resolver: 可选，把 ``{"key": ":start_ms"}`` 解析为 ``{"key": 1200}``

    Returns: 末步算子返回的 ctx（其 data 通常是已经格式化好的字典）
    """
    _log = get_observability_logger("preprocess")
    for idx, step in enumerate(steps):
        op_name = step.get("op")
        if not op_name:
            raise PreprocessError(f"pipeline 第 {idx} 步缺少 op 字段")
        op_func = OPERATORS.get(op_name)
        if not op_func:
            raise PreprocessError(
                f"pipeline 第 {idx} 步引用了未注册的算子: {op_name}; "
                f"已注册算子: {sorted(OPERATORS.keys())}"
            )
        raw_params = step.get("params", {}) or {}
        resolved = param_resolver(raw_params) if param_resolver else raw_params
        step_ctx = ctx.with_params(resolved)
        op_start = time.time()
        try:
            ctx = op_func(step_ctx)
            elapsed_ms = int((time.time() - op_start) * 1000)
            _log.info("operator_execute", session_id=session_id, operator=op_name, step_index=idx,
                      indicator=indicator,
                      input_rows=len(ctx.data) if hasattr(ctx.data, "__len__") else 0,
                      elapsed_ms=elapsed_ms)
        except PreprocessError:
            raise
        except Exception as exc:  # noqa: BLE001
            _log.error("operator_error", session_id=session_id, operator=op_name, step_index=idx,
                       indicator=indicator, error=str(exc))
            raise PreprocessError(
                f"算子 {op_name} 执行失败 (step {idx}): {exc}"
            ) from exc
    return ctx


def list_registered_operators() -> List[str]:
    """供 list_indicators / 文档脚本回显当前可用算子。"""
    return sorted(OPERATORS.keys())


def shorten_func_name(func: str) -> str:
    """函数名缩短规则（spec §5.5）。

    1. 含 [name:XXX] → 提取 XXX
    2. 含 > → 取最后一个 > 后部分，再应用规则 3
    3. 含 H: → 取最后一个 : 后内容
    4. 其他保持原样
    """
    if not func:
        return ""
    # 规则 1：[name:XXX]
    m = _re.search(r"\[name:([^\]]+)\]", func)
    if m:
        return m.group(1)
    # 规则 2：> 分隔符
    if ">" in func:
        func = func.rsplit(">", 1)[-1].strip()
    # 规则 3：H: 前缀
    if "H:" in func:
        return func.rsplit(":", 1)[-1]
    return func
