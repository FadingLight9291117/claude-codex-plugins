"""Skill 执行器核心逻辑。

职责:
- 解析 SkillDef，执行 steps 工作流
- 自动注入 default_indicator_params（解决 Agent 遗忘问题）
- iterate 循环展开
- LLM action 暂停并组装上下文返回给 Agent

设计原则: 框架执行工具，Agent 掌控流程，约定靠框架保障而非 Agent 记忆
"""
from __future__ import annotations

import json
import re
import threading
import uuid
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from core.registry import SkillDef

from core.observability import get_observability_logger
from core.registry import ConfigRegistry, SkillStep
from core.query_engine import QueryEngine

# LLM context 文件持久化目录（项目根目录下）
_LLM_CONTEXTS_DIR = Path(__file__).parent.parent / ".llm_contexts"
_LLM_CONTEXTS_DIR.mkdir(exist_ok=True)


# ---------------------------------------------------------------------------
# 工具调用映射（只映射有返回值的原子工具）
# ---------------------------------------------------------------------------

_TOOL_CALLABLE: dict[str, callable] = {}


def _register_tool(name: str, fn: callable) -> None:
    """注册可被 SkillExecutor 调用的工具。"""
    _TOOL_CALLABLE[name] = fn


def _resolve_expr(expr: str, state: dict, item: Optional[dict] = None) -> Any:
    """解析表达式，支持:
    - input.xxx         → 用户输入参数
    - stepN.output.xxx  → 前序步骤输出
    - item.xxx          → iterate 当前项
    - 纯字符串字面量     → 原样返回
    """
    expr = expr.strip()
    if not expr:
        return expr

    # 纯数字
    try:
        return int(expr)
    except ValueError:
        try:
            return float(expr)
        except ValueError:
            pass

    # input.xxx — resolves to None when absent, letting Optional tool params
    # use their declared defaults.  stepN/item expressions retain the original
    # string on failure to make workflow errors visible.
    m = re.match(r"^input\.(.+)$", expr)
    if m:
        key = m.group(1)
        return _INPUT_PARAMS.get(key, None)

    # 数组索引访问: step4.thread_queries[0].tid（[N] 后跟 .field）
    # 必须放在 stepN.output 之前，因为后者会把 [0].tid 当作 field 的一部分
    m = re.match(r"^(step\d+\.[\w\.\[\]0-9]+)\[(\d+)\]\.(.+)$", expr)
    if m:
        base_expr = m.group(1)
        idx = int(m.group(2))
        field = m.group(3)
        base_val = _resolve_expr(base_expr, state, item)
        if not isinstance(base_val, list):
            return expr
        if idx >= len(base_val):
            return expr
        item_val = base_val[idx]
        if isinstance(item_val, dict):
            return item_val.get(field, expr)
        return item_val

    # 数组索引访问（无后续字段）: step4.thread_queries[0]
    m = re.match(r"^(step\d+\.[\w\.\[\]0-9]+)\[(\d+)\]$", expr)
    if m:
        base_expr = m.group(1)
        idx = int(m.group(2))
        base_val = _resolve_expr(base_expr, state, item)
        if isinstance(base_val, list) and idx < len(base_val):
            return base_val[idx]
        return expr

    # stepN.output.xxx (N 是数字)
    m = re.match(r"^step(\d+)\.output\.(.+)$", expr)
    if m:
        step_num = int(m.group(1))
        field = m.group(2)
        step_state = state.get(f"step{step_num}", {})
        # 优先从 step_state 直接查，fallback 到 output 包装
        output_val = step_state.get("output", step_state)
        # 支持嵌套字段: step3.chip_info.matched_chips[0].chip_model
        return _get_nested(output_val, field, expr)

    # stepN.xxx (简化写法，e.g., step2.sqlite_path)
    m = re.match(r"^step(\d+)\.([\w\.]+)$", expr)
    if m:
        step_num = int(m.group(1))
        field = m.group(2)
        step_state = state.get(f"step{step_num}", {})
        # 优先从 step_state 直接查（tool 返回值），fallback 到 output 包装
        return _get_nested(step_state, field,
                           _get_nested(step_state.get("output", {}), field, expr))

    # item.xxx
    if item is not None:
        m = re.match(r"^item\.(\w+)$", expr)
        if m:
            key = m.group(1)
            val = item.get(key)
            if val is not None:
                return val

    # 列表字面量 [a, b, c] 或 ['a', 'b']
    if expr.startswith("[") and expr.endswith("]"):
        inner = expr[1:-1].strip()
        if not inner:
            return []
        items = []
        for part in inner.split(","):
            part = part.strip()
            # 处理带引号的字符串字面量: 'value' -> value
            if (part.startswith("'") and part.endswith("'")) or \
               (part.startswith('"') and part.endswith('"')):
                part = part[1:-1]
            else:
                part = _resolve_expr(part, state, item)
            items.append(part)
        return items

    # 字符串字面量（保留原样）
    return expr


def _get_nested(obj: Any, path: str, original: str) -> Any:
    """支持嵌套路径: matched_chips[0].chip_model 或 matched_chips.0.chip_model"""
    if obj is None:
        return original
    # 先把 a[0].b 统一转成 a.0.b（兼容点号分隔）
    normalized = re.sub(r"\[(\d+)\]", r".\1", path)
    parts = normalized.split(".")
    current = obj
    for part in parts:
        if not part:  # 跳过空部分（如 a[0].b 转换后的空字符串）
            continue
        if isinstance(current, list):
            try:
                idx = int(part)
                current = current[idx] if idx < len(current) else None
            except ValueError:
                return original
        elif isinstance(current, dict):
            current = current.get(part)
        else:
            return original
        if current is None:
            return original
    return current


# 全局输入参数存储（由 run_skill 传入）
_INPUT_PARAMS: dict[str, Any] = {}


class SkillExecutor:
    """Skill 执行器，解析 YAML 并执行 steps。"""

    def __init__(self, registry: ConfigRegistry, engine: QueryEngine):
        self.registry = registry
        self.engine = engine
        # group 展开结果缓存（iterate 场景下 indicators 列表不变时避免 500 次重复 registry 查找）
        self._expand_cache: dict[tuple, tuple] = {}
        self._expand_cache_lock = threading.Lock()

    def _validate_input_params(self, skill: SkillDef, input_params: dict | None) -> dict | None:
        """校验 required input_params。返回错误 dict 或 None（通过校验）。

        trace_path_or_dir 由 run_skill 顶层参数保证，不在 input_params dict 中。
        """
        missing = []
        for p in skill.input_params:
            if p.name == "trace_path_or_dir":
                continue
            if p.required and (input_params is None or input_params.get(p.name) is None):
                missing.append({
                    "name": p.name,
                    "type": p.type,
                    "description": p.description,
                })
        if not missing:
            return None
        return {
            "error": "缺少必需的 input_params",
            "missing_params": missing,
            "hint": "请根据缺失参数的 description 从用户输入中提取值，重新调用 run_skill 并传入 input_params",
        }

    def run(
        self,
        skill_id: str,
        trace_path_or_dir: str,
        step: int = None,
        iterate_index: int = None,
        auto_continue: bool = True,
        overrides: dict = None,
        resume: str = None,
        input_params: dict = None,  # MCP 层保证非 None（必填参数，无参数时传 {}）
    ) -> dict:
        """主入口，执行 Skill 工作流。

        Args:
            skill_id: Skill 标识符
            trace_path_or_dir: trace 文件路径或目录
            step: 从指定 step 开始执行（用于 resume）
            iterate_index: 只执行 iterate 的第 N 项（用于逐项调试）
            auto_continue: True=自动执行到 LLM action 暂停；False=每步暂停
            overrides: Agent 显式覆盖 step-level 参数（如 indicator_params）
            resume: 从指定 step 继续执行
            input_params: 传入 skill input_params 定义的输入参数（如 animation_type、top_n），
                          MCP 层保证非 None（必填参数，无参数时传 {}），
                          框架自动填充到 input.xxx 表达式解析

        Returns:
            执行结果 JSON，结构见下方
        """
        global _INPUT_PARAMS
        _INPUT_PARAMS = {"trace_path_or_dir": trace_path_or_dir}
        if input_params:
            _INPUT_PARAMS.update(input_params)

        skill = self.registry.get_skill(skill_id)
        if skill is None:
            return {"error": f"Skill '{skill_id}' not found"}

        # 校验 required input_params（排除 trace_path_or_dir，它由顶层参数保证）
        validation_error = self._validate_input_params(skill, input_params)
        if validation_error:
            return validation_error

        import time
        _log = get_observability_logger("skill_executor")
        session_start_ts = time.time()

        # 生成 session_id 用于状态追踪
        session_id = str(uuid.uuid4())[:8]
        from core.observability import set_observability_session_id
        set_observability_session_id(session_id)

        _log.info("skill_started", session_id=session_id, skill_id=skill_id,
                  trace_path=trace_path_or_dir)

        # state: {stepN: {output: {...}, ...}}
        state: dict[str, dict] = {}
        executed_steps: list[int] = []

        # 处理 resume：从上一个 session 恢复状态
        start_step = 1
        prev_session_id = None
        if resume:
            m = re.match(r"^step(\d+):(.+)$", resume)
            if m:
                start_step = int(m.group(1))
                prev_session_id = m.group(2)
            elif re.match(r"^step\d+$", resume):
                # resume="step4"：纯 step 引用，不恢复状态，直接从该 step 开始
                start_step = int(resume[4:])
            else:
                # resume 是纯 session_id（如 "4dc19aba"），从 step2 开始恢复
                prev_session_id = resume
                start_step = 2
        if step is not None:
            start_step = step
        if prev_session_id:
            saved = query_skill_state(prev_session_id)
            if "error" not in saved:
                state = saved["state"]
                executed_steps = list(saved.get("executed_steps", []))

        # 确定要执行的 steps
        steps_to_run = [s for s in skill.steps if s.step >= start_step]
        if not steps_to_run:
            return {"error": f"No steps to run from step {start_step}"}

        for step_def in steps_to_run:
            # 检查是否遇到 LLM action
            if step_def.action in ("llm_reasoning", "llm_decision"):
                save_skill_state(session_id, skill_id, state, executed_steps)
                _log.info("skill_llm_action_pause", session_id=session_id,
                          step=step_def.step, action=step_def.action)
                if auto_continue:
                    llm_context = self._collect_llm_context(state, step_def, session_id)
                    return {
                        "session_id": session_id,
                        "executed_steps": executed_steps,
                        "next_step": {"number": step_def.step, "is_llm_action": True},
                        "llm_context": llm_context,
                        "waiting_for_agent": True,
                        "is_complete": False,
                    }
                else:
                    # auto_continue=False: 每步暂停
                    result = self._build_step_result(
                        executed_steps, state, step_def, None, waiting=True
                    )
                    result["session_id"] = session_id
                    return result

            # 处理 iterate step
            if step_def.iterate:
                iterate_items = self._resolve_iterate_items(step_def.iterate, state)
                if not iterate_items:
                    state[f"step{step_def.step}"] = {
                        "output": [],
                        "iterate_items": [],
                    }
                    executed_steps.append(step_def.step)
                    continue

                # 安全限制：防止 iterate 项过多导致性能问题
                max_iterate = 500
                _log.info("skill_iterate_start", session_id=session_id,
                          step=step_def.step, iterate_count=len(iterate_items))
                if len(iterate_items) > max_iterate:
                    return {
                        "error": f"iterate items ({len(iterate_items)}) exceeds max_iterate ({max_iterate}). "
                                 f"Use iterate_index to process items individually."
                    }

                # iterate_index: 只执行单项
                if iterate_index is not None:
                    if iterate_index < len(iterate_items):
                        iterate_items = [iterate_items[iterate_index]]
                    else:
                        return {"error": f"iterate_index {iterate_index} out of range"}
                    result = self._execute_step(step_def, state, overrides, iterate_items[0], session_id=session_id)
                    if isinstance(result, dict) and "indicators" in result:
                        tag = iterate_items[0].get("tag")
                        if tag:
                            result = {"tag": tag, **result}
                    state[f"step{step_def.step}"] = {
                        "output": result,
                        "iterate_items": iterate_items,
                    }
                    executed_steps.append(step_def.step)
                    save_skill_state(session_id, skill_id, state, executed_steps)
                    res = self._build_step_result(
                        executed_steps, state, step_def, result, waiting=True
                    )
                    res["session_id"] = session_id
                    return res

                # 完整执行 iterate
                all_results = []
                for idx, item in enumerate(iterate_items):
                    item_start = time.time()
                    result = self._execute_step(step_def, state, overrides, item, session_id=session_id)
                    if isinstance(result, dict) and "indicators" in result:
                        tag = item.get("tag")
                        if tag:
                            result = {"tag": tag, **result}
                    all_results.append(result)
                    elapsed_ms = int((time.time() - item_start) * 1000)
                    tag = item.get("tag") if isinstance(item, dict) else None
                    _log.info("skill_iterate_item_complete", session_id=session_id,
                              step=step_def.step, item_index=idx, tag=tag,
                              elapsed_ms=elapsed_ms)

                state[f"step{step_def.step}"] = {
                    "output": all_results,
                    "iterate_items": iterate_items,
                }
                executed_steps.append(step_def.step)

                # auto_continue=False 时每步暂停
                if not auto_continue:
                    save_skill_state(session_id, skill_id, state, executed_steps)
                    res = self._build_step_result(
                        executed_steps, state, step_def, all_results, waiting=True
                    )
                    res["session_id"] = session_id
                    return res
                continue

            # 处理 parallel_iterate step
            if step_def.parallel_iterate:
                iterate_items = self._resolve_iterate_items(step_def.parallel_iterate, state)
                if not iterate_items:
                    state[f"step{step_def.step}"] = {
                        "output": [],
                        "iterate_items": [],
                    }
                    executed_steps.append(step_def.step)
                    continue

                # 安全限制
                max_iterate = 500
                _log.info("skill_parallel_iterate_start", session_id=session_id,
                          step=step_def.step, iterate_count=len(iterate_items))
                if len(iterate_items) > max_iterate:
                    return {
                        "error": f"parallel_iterate items ({len(iterate_items)}) exceeds max_iterate ({max_iterate}). "
                                 f"Use iterate_index to process items individually."
                    }

                # iterate_index: 只执行单项（串行）
                if iterate_index is not None:
                    if iterate_index < len(iterate_items):
                        iterate_items = [iterate_items[iterate_index]]
                    else:
                        return {"error": f"iterate_index {iterate_index} out of range"}
                    result = self._execute_step(step_def, state, overrides, iterate_items[0], session_id=session_id)
                    if isinstance(result, dict) and "indicators" in result:
                        tag = iterate_items[0].get("tag")
                        if tag:
                            result = {"tag": tag, **result}
                    state[f"step{step_def.step}"] = {
                        "output": result,
                        "iterate_items": iterate_items,
                    }
                    executed_steps.append(step_def.step)
                    save_skill_state(session_id, skill_id, state, executed_steps)
                    res = self._build_step_result(
                        executed_steps, state, step_def, result, waiting=True
                    )
                    res["session_id"] = session_id
                    return res

                # 并行执行 iterate
                # Thread-safety: `state` is only READ by worker threads (no writes).
                # `all_results[idx]` writes are indexed, so no data race.
                # `_expand_cache` is protected by `_expand_cache_lock`.
                # If future changes add state writes inside _execute_step, a lock will be needed.
                all_results = [None] * len(iterate_items)

                def _run_item(idx, item):
                    item_start = time.time()
                    result = self._execute_step(step_def, state, overrides, item, session_id=session_id)
                    if isinstance(result, dict) and "indicators" in result:
                        tag = item.get("tag") if isinstance(item, dict) else None
                        if tag:
                            result = {"tag": tag, **result}
                    elapsed_ms = int((time.time() - item_start) * 1000)
                    tag = item.get("tag") if isinstance(item, dict) else None
                    _log.info("skill_parallel_iterate_item_complete", session_id=session_id,
                              step=step_def.step, item_index=idx, tag=tag,
                              elapsed_ms=elapsed_ms)
                    return idx, result

                max_workers = min(len(iterate_items), 8)
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = {
                        executor.submit(_run_item, idx, item): idx
                        for idx, item in enumerate(iterate_items)
                    }
                    for future in as_completed(futures):
                        idx, result = future.result()
                        all_results[idx] = result

                state[f"step{step_def.step}"] = {
                    "output": all_results,
                    "iterate_items": iterate_items,
                }
                executed_steps.append(step_def.step)

                # auto_continue=False 时每步暂停
                if not auto_continue:
                    save_skill_state(session_id, skill_id, state, executed_steps)
                    res = self._build_step_result(
                        executed_steps, state, step_def, all_results, waiting=True
                    )
                    res["session_id"] = session_id
                    return res
                continue

            # 普通 step（非 iterate，非 parallel_iterate，非 LLM action）
            result = self._execute_step(step_def, state, overrides, session_id=session_id)
            state[f"step{step_def.step}"] = {"output": result}
            executed_steps.append(step_def.step)

            if not auto_continue:
                save_skill_state(session_id, skill_id, state, executed_steps)
                res = self._build_step_result(
                    executed_steps, state, step_def, result, waiting=True
                )
                res["session_id"] = session_id
                return res

        # 所有 step 执行完成
        save_skill_state(session_id, skill_id, state, executed_steps)
        total_elapsed_ms = int((time.time() - session_start_ts) * 1000)
        _log.info("skill_complete", session_id=session_id,
                  skill_id=skill_id, total_steps=len(executed_steps),
                  total_elapsed_ms=total_elapsed_ms)
        return {
            "session_id": session_id,
            "executed_steps": executed_steps,
            "state": {k: v.get("output") for k, v in state.items()},
            "next_step": None,
            "waiting_for_agent": False,
            "is_complete": True,
        }

    def _execute_step(
        self,
        step_def: SkillStep,
        state: dict,
        overrides: Optional[dict],
        item: Optional[dict] = None,
        session_id: str = "",
    ) -> Any:
        """执行单个 step，处理工具调用和参数注入。"""
        if step_def.tool is None:
            # LLM action should not reach here (handled in run())
            return None

        # 解析 args（代换 input.xxx / stepN.output.xxx / item.xxx）
        resolved_args = self._resolve_args(step_def.args, state, item)

        # 展开 indicators 中的 group 简写（如 launch_essentials → [cpu_freq, thread_state_durations, ...]）
        resolved_args = self._expand_groups(resolved_args)

        # 注入 default_indicator_params
        resolved_args = self._inject_default_params(
            resolved_args, step_def, state, item, overrides
        )

        # 处理 overrides（Agent 显式覆盖）
        if overrides:
            resolved_args = self._apply_overrides(resolved_args, overrides)

        # 调用工具前删除 framework-only 的元参数
        resolved_args.pop("default_indicator_params", None)

        import time as _time_module
        step_start = _time_module.time()
        _log = get_observability_logger("skill_executor")
        _log.info("skill_step_start", session_id=session_id, step=step_def.step, tool=step_def.tool)

        # 调用工具
        tool_fn = _TOOL_CALLABLE.get(step_def.tool)
        if tool_fn is None:
            _log.error("skill_step_error", session_id=session_id, step=step_def.step,
                       error=f"Unknown tool: {step_def.tool}")
            return {"error": f"Unknown tool: {step_def.tool}"}

        # 调用工具并捕获异常
        try:
            result_str = tool_fn(**resolved_args)
            # 解析返回的 JSON 字符串
            try:
                result = json.loads(result_str)
            except (json.JSONDecodeError, TypeError):
                result = result_str

            # 处理 preprocess（如果有）
            if step_def.preprocess:
                result = self._apply_preprocess(result, step_def.preprocess, session_id=session_id)

            elapsed_ms = int((_time_module.time() - step_start) * 1000)
            _log.info("skill_step_complete", session_id=session_id, step=step_def.step,
                      tool=step_def.tool, elapsed_ms=elapsed_ms)
            return result
        except Exception as e:
            _log.error("skill_step_error", session_id=session_id, step=step_def.step,
                       tool=step_def.tool, error=str(e))
            return {"error": str(e)}

    def _apply_preprocess(self, result: dict, preprocess_config: dict, *, session_id: str = "") -> dict:
        """应用 preprocess pipeline 到工具结果。"""
        from core.preprocess import PreprocessContext, run_pipeline

        pipeline = preprocess_config.get("pipeline", [])
        if not pipeline:
            return result

        # 创建 PreprocessContext
        ctx = PreprocessContext(data=result, meta={}, sqlite_conn=None)

        # 执行 pipeline (注意参数顺序: steps, ctx)
        ctx = run_pipeline(pipeline, ctx, session_id=session_id)

        # 返回处理后的数据
        return ctx.data

    def _resolve_args(
        self, args: dict, state: dict, item: Optional[dict] = None
    ) -> dict:
        """解析 args 中的占位符表达式。"""
        resolved = {}
        for key, val in args.items():
            if isinstance(val, str):
                resolved[key] = _resolve_expr(val, state, item)
            elif isinstance(val, list):
                resolved[key] = [
                    _resolve_expr(v, state, item) if isinstance(v, str) else v
                    for v in val
                ]
            elif isinstance(val, dict):
                resolved[key] = {
                    k: _resolve_expr(v, state, item) if isinstance(v, str) else v
                    for k, v in val.items()
                }
            else:
                resolved[key] = val
        return resolved

    def _expand_groups(self, args: dict) -> dict:
        """展开 args.indicators 中的 group 简写（indicator_set 已在路由层展开，
        此处处理直接写 group 名的场景），并将 group 的 override_params
        合并到 default_indicator_params。

        缓存：iterate 场景下 indicators 列表通常静态，缓存展开结果避免 500 次重复
        registry 查找。
        """
        indicators = args.get("indicators")
        if not isinstance(indicators, list):
            return args

        # 缓存 key：用 indicators 列表的 tuple 形式（按值哈希）
        try:
            cache_key = tuple(indicators)
        except TypeError:
            # 列表元素不可哈希（如 dict），不缓存
            cache_key = None

        if cache_key is not None:
            with self._expand_cache_lock:
                cached = self._expand_cache.get(cache_key)
        else:
            cached = None

        if cached is None:
            # 重新计算展开结果
            expanded: list = []
            # group 默认参数（低优先级，仅补缺失 key）
            group_dip_to_inject: dict[str, dict] = {}
            # group override 参数（高优先级，直接覆盖）
            override_to_inject: dict[str, dict] = {}

            for name in indicators:
                if not isinstance(name, str):
                    expanded.append(name)
                    continue
                meta = self.registry.indicators.get(name)
                if meta and meta.type == "group" and meta.expands_to:
                    # 展开为原子指标
                    for child in meta.expands_to:
                        child_name = child["name"] if isinstance(child, dict) else child
                        expanded.append(child_name)
                        # 1. 合并 group 的 default_indicator_params（低优先级，只补缺失的 key）
                        group_dip = getattr(meta, "default_indicator_params", None) or {}
                        if group_dip and child_name in group_dip:
                            target = group_dip_to_inject.setdefault(child_name, {})
                            for k, v in group_dip[child_name].items():
                                if k not in target:
                                    target[k] = v
                        # 2. 合并 override_params（高优先级，直接覆盖）
                        if isinstance(child, dict):
                            override_params = child.get("override_params") or {}
                            if override_params:
                                target = override_to_inject.setdefault(child_name, {})
                                target.update(override_params)
                else:
                    expanded.append(name)

            cached = (expanded, group_dip_to_inject, override_to_inject)
            if cache_key is not None:
                with self._expand_cache_lock:
                    self._expand_cache[cache_key] = cached

        expanded, group_dip_to_inject, override_to_inject = cached

        # 应用 side effects 到 args（每次调用都需要，因为 args 是 _resolve_args 的新输出）
        args["indicators"] = list(expanded)
        dip = args.setdefault("default_indicator_params", {})
        for child_name, params in group_dip_to_inject.items():
            if child_name not in dip:
                dip[child_name] = {}
            for k, v in params.items():
                if k not in dip[child_name]:
                    dip[child_name][k] = v
        for child_name, params in override_to_inject.items():
            if child_name not in dip:
                dip[child_name] = {}
            dip[child_name].update(params)

        return args

    def _inject_default_params(
        self,
        args: dict,
        step_def: SkillStep,
        state: dict,
        item: Optional[dict],
        overrides: Optional[dict],
    ) -> dict:
        """自动注入 default_indicator_params（只填充"没显式传的"）。"""
        default_params = step_def.default_indicator_params

        # 先把 group 展开时写入 default_indicator_params 的值合并到 indicator_params
        # （group-level defaults 放 default_indicator_params，框架内部使用）
        # 注意：dip 中的值可能含 item.xxx / stepN.xxx 表达式，需在此处解析
        dip = args.get("default_indicator_params", {})
        if dip:
            if "indicator_params" not in args:
                args["indicator_params"] = {}
            for k, v in dip.items():
                if k not in args["indicator_params"]:
                    # v 可能是 dict（如 {tid: item.tid, chip_model: step3.xxx}）
                    if isinstance(v, dict):
                        resolved_v = {}
                        for pk, pv in v.items():
                            if isinstance(pv, str):
                                resolved_v[pk] = _resolve_expr(pv, state, item)
                            else:
                                resolved_v[pk] = pv
                        args["indicator_params"][k] = resolved_v
                    else:
                        args["indicator_params"][k] = _resolve_expr(v, state, item) if isinstance(v, str) else v
                elif isinstance(v, dict) and isinstance(args["indicator_params"].get(k), dict):
                    for pk, pv in v.items():
                        if pk not in args["indicator_params"][k]:
                            if isinstance(pv, str):
                                args["indicator_params"][k][pk] = _resolve_expr(pv, state, item)
                            else:
                                args["indicator_params"][k][pk] = pv

        if not default_params and not dip:
            return args

        # 确保 indicator_params 存在
        if "indicator_params" not in args:
            args["indicator_params"] = {}

        # 遍历 default_indicator_params，只注入不存在的 key
        # 策略：key 完全不存在 → 整体写入；key 已存在 → 只填缺失的子键
        for k, v in default_params.items():
            if k not in args["indicator_params"]:
                # v 可能是 dict（如 {tid: item.tid, chip_model: step3.xxx}）
                if isinstance(v, dict):
                    resolved_v = {}
                    for pk, pv in v.items():
                        if isinstance(pv, str):
                            resolved_v[pk] = _resolve_expr(pv, state, item)
                        else:
                            resolved_v[pk] = pv
                    args["indicator_params"][k] = resolved_v
                else:
                    args["indicator_params"][k] = _resolve_expr(v, state, item) if isinstance(v, str) else v
            else:
                # key 已存在，只补充缺失的子键（不覆盖已显式传的值）
                if isinstance(v, dict):
                    existing = args["indicator_params"][k]
                    if isinstance(existing, dict):
                        for pk, pv in v.items():
                            if pk not in existing:
                                if isinstance(pv, str):
                                    existing[pk] = _resolve_expr(pv, state, item)
                                else:
                                    existing[pk] = pv

        return args

    def _apply_overrides(
        self, args: dict, overrides: dict
    ) -> dict:
        """应用 overrides（Agent 显式覆盖，优先级最高）。"""
        # overrides 的 indicator_params 合并到 args.indicator_params
        override_indicator_params = overrides.get("indicator_params")
        if override_indicator_params and "indicator_params" in args:
            args["indicator_params"].update(override_indicator_params)

        # 其他顶层 overrides
        for key, val in overrides.items():
            if key != "indicator_params":
                args[key] = val

        return args

    def _resolve_iterate_items(self, iterate_expr: str, state: dict) -> list:
        """解析 iterate 表达式，返回要遍历的项列表。"""
        # iterate: step4.thread_queries 或 step4.drop_analysis.thread_queries
        items = _resolve_expr(iterate_expr, state, None)
        if not isinstance(items, list):
            return []
        return items

    def _find_thread_queries(self, state: dict, current_step_key: str) -> list:
        """从前序 step 输出中找到 thread_queries 元数据。

        不同 skill 的 thread_queries 位置不同：
        - frame_drop / game_jank: step4.thread_queries（在 indicators.xxx.data.thread_queries）
        - launch_perf: step4.launch_process[].thread_queries 聚合
        - 直接输出: step4.thread_queries（analyze_frame_drops 扁平结构）

        Args:
            state: skill 执行状态 {stepN: {output: {...}}}
            current_step_key: 当前 step 的 key（如 "step5"），只搜此 step 之前

        Returns:
            thread_queries list，未找到返回 []
        """
        m = re.match(r"^step(\d+)$", current_step_key)
        if not m:
            return []
        current_step_num = int(m.group(1))

        for n in range(current_step_num - 1, 0, -1):
            prev = state.get(f"step{n}", {}).get("output", {})

            # 直接路径：thread_queries 在顶层
            if isinstance(prev, dict) and "thread_queries" in prev:
                tq = prev["thread_queries"]
                return tq if isinstance(tq, list) else []

            # 嵌套路径：在 indicators.xxx.data.thread_queries
            if isinstance(prev, dict) and "indicators" in prev:
                for ind_data in prev["indicators"].values():
                    if isinstance(ind_data, dict) and "data" in ind_data:
                        data = ind_data["data"]
                        if isinstance(data, dict) and "thread_queries" in data:
                            tq = data["thread_queries"]
                            return tq if isinstance(tq, list) else []

            # launch_perf 的 launch_process 路径
            if isinstance(prev, dict) and "launch_process" in prev:
                all_tq = []
                for proc in prev["launch_process"]:
                    tq = proc.get("thread_queries", [])
                    if isinstance(tq, list):
                        all_tq.extend(tq)
                return all_tq

        return []

    def _build_dispatch_groups(
        self,
        frame_index: list[dict],
        threshold: int = 5,
        max_per_group: int = 6,
        max_groups: int = 10,
    ) -> list[dict]:
        """根据帧数预算派发分组。

        - frame_count < threshold: 不分组（返回空 list，instruction 走单 Agent 路径）
        - frame_count >= threshold: 按 max_per_group 分组，组数受 max_groups 限制

        Args:
            frame_index: [{tag, file, priority_count, size_bytes, has_error}, ...]
            threshold: 触发派发的最小帧数
            max_per_group: 每组最多帧数
            max_groups: 派发组数上限，超过则每组放大

        Returns:
            [{"group_id", "frame_files", "tags"}, ...] 或 []（无需派发）
        """
        if len(frame_index) < threshold:
            return []

        n_frames = len(frame_index)
        n_groups = min((n_frames + max_per_group - 1) // max_per_group, max_groups)
        actual_per_group = (n_frames + n_groups - 1) // n_groups

        groups = []
        for i in range(0, n_frames, actual_per_group):
            chunk = frame_index[i:i + actual_per_group]
            groups.append({
                "group_id": len(groups) + 1,
                "frame_files": [f["file"] for f in chunk],
                "tags": [f["tag"] for f in chunk],
            })
        return groups

    def _split_iterate_to_per_frame_files(
        self, state: dict, step_key: str, session_id: str
    ) -> tuple[list[dict], "Path | None"]:
        """把 iterate list 按 tag 聚合切分，写入 per-frame 文件。

        Args:
            state: skill 执行状态
            step_key: 当前 step 的 key（如 "step5"）
            session_id: session ID（用于目录命名）

        Returns:
            (frame_index, out_dir):
              frame_index: [{tag, file, priority_count, size_bytes, has_error}, ...]
              out_dir: .llm_contexts/{session_id}/ 目录，空 iterate 返回 None
        """
        import time as _time_module
        _log = get_observability_logger("skill_executor")

        step_output = state.get(step_key, {}).get("output", [])
        if not isinstance(step_output, list):
            _log.warn("per_frame_split_empty", session_id=session_id, step_key=step_key)
            return [], None

        # 空迭代且无线程查询时直接返回；有线程查询但无 step5 item 时
        # 仍需生成 has_error=True 的 per-frame 文件
        if not step_output:
            thread_queries = self._find_thread_queries(state, step_key)
            if not thread_queries:
                _log.warn("per_frame_split_empty", session_id=session_id, step_key=step_key)
                return [], None
        else:
            thread_queries = self._find_thread_queries(state, step_key)

        item_count = len(step_output)
        start_ts = _time_module.time()
        _log.info("per_frame_split_start", session_id=session_id,
                  step_key=step_key, item_count=item_count)

        if not thread_queries:
            # 计算被搜索的前序 step 列表（step_key 前的所有 stepN）
            m = re.match(r"^step(\d+)$", step_key)
            cur_num = int(m.group(1)) if m else 0
            searched = [f"step{n}" for n in range(cur_num - 1, 0, -1)]
            _log.warn("thread_queries_not_found", session_id=session_id,
                      step_key=step_key, searched_steps=searched)

        # 按 tag 聚合
        tq_by_tag: dict[Any, list] = defaultdict(list)
        for tq in thread_queries:
            tq_by_tag[tq["tag"]].append(tq)

        s5_by_tag: dict[Any, list] = defaultdict(list)
        for item in step_output:
            tag = item.get("tag")
            if tag is not None:
                s5_by_tag[tag].append(item)

        # 创建目录
        out_dir = _LLM_CONTEXTS_DIR / session_id
        frames_dir = out_dir / "step5"
        try:
            frames_dir.mkdir(parents=True, exist_ok=True)
            (out_dir / "shared").mkdir(parents=True, exist_ok=True)
        except OSError as e:
            _log.warn("per_frame_split_degraded", session_id=session_id,
                      step_key=step_key, error=str(e))
            return [], None

        # 合并写入 per-frame 文件
        frame_index = []
        # legend 从第一个有效 item 的顶层 legend 字段聚合（query_engine 后处理产物）
        legend: dict = {}
        for tag, tq_list in tq_by_tag.items():
            s5_items = s5_by_tag.get(tag, [])
            per_priority = []
            for i, item in enumerate(s5_items):
                tq = tq_list[i] if i < len(tq_list) else {}
                indicators = item.get("indicators", {})
                # 聚合 legend（每个 item 的 legend 相同，取第一个非空即可）
                if not legend and item.get("legend"):
                    legend = item.get("legend") or {}
                # 聚合 headline_digest：收集所有指标的 _digest_line
                digest_lines = []
                if isinstance(indicators, dict):
                    for ind_name, ind_obj in indicators.items():
                        if isinstance(ind_obj, dict) and "_digest_line" in ind_obj:
                            digest_lines.append(ind_obj.pop("_digest_line"))
                per_priority.append({
                    "priority": self._extract_priority(item, tq),
                    "tid": tq.get("tid"),
                    "thread_name": tq.get("thread_name"),
                    "headline_digest": digest_lines,
                    "indicators": indicators,
                    "errors": item.get("errors", []),
                })

            frame_data = {
                "tag": tag,
                "thread_queries": tq_list,
                "legend": legend,
                "per_priority_indicators": per_priority,
            }
            # 文件名转义：tag 含 ":" 等 Windows 保留字符会导致文件名截断
            # (Windows 保留字符: <>:"/\|?* 以及控制字符)
            safe_tag = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', str(tag)) if tag else "unknown"
            fname = f"frame_{safe_tag}.json"
            fpath = frames_dir / fname
            fpath.write_text(
                json.dumps(frame_data, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
            frame_index.append({
                "tag": tag,
                "file": f"step5/{fname}",
                "priority_count": len(tq_list),
                "size_bytes": fpath.stat().st_size,
                "has_error": not s5_items,
            })

        elapsed_ms = int((_time_module.time() - start_ts) * 1000)
        has_error_count = sum(1 for f in frame_index if f.get("has_error"))
        _log.info("per_frame_split_complete", session_id=session_id,
                  step_key=step_key, tag_count=len(frame_index),
                  total_size_bytes=sum(f["size_bytes"] for f in frame_index),
                  has_error_count=has_error_count, elapsed_ms=elapsed_ms)

        return frame_index, out_dir

    def _extract_priority(self, item: dict, tq: dict) -> int | None:
        """从 step5 item 或 thread_query 提取 priority。"""
        # 优先从 thread_query 取
        if "priority" in tq:
            return tq["priority"]
        # 尝试从 indicators.thread_sched_analysis.data.sched.priority 取
        tsa = item.get("indicators", {}).get("thread_sched_analysis", {})
        data = tsa.get("data", {}) if isinstance(tsa, dict) else {}
        sched = data.get("sched", {}) if isinstance(data, dict) else {}
        return sched.get("priority")

    def _build_framework_prefix(
        self,
        session_id: str,
        skill_id: str,
        step_key: str,
        frame_index: list[dict],
        dispatch_groups: list[dict],
        shared_context: dict,
    ) -> str:
        """生成 skill 无关的注入前缀。

        框架注入只讲"数据结构和读取方式"，不讲业务语义（丢帧/启动/调度）。
        业务语义留在 YAML instruction 中。

        Args:
            session_id: session ID
            skill_id: skill 标识（仅用于提示，不掺入业务词）
            step_key: 当前 step 的 key
            frame_index: per-frame 文件索引
            dispatch_groups: 派发分组（空表示单 Agent 路径）
            shared_context: 共享上下文路径

        Returns:
            注入到 instruction 占位符的文本
        """
        frame_count = len(frame_index)
        out_dir = f".llm_contexts/{session_id}"

        # 空 iterate list
        if frame_count == 0:
            return f"""{skill_id} {step_key} 的 iterate 输出为空。

【含义】
- {step_key} 未收集到任何 tag 项数据（thread_queries 为空）
- 可能原因: 前序 step 未产出可分析的 tag 项

【处理方式】
- 跳过 per-tag 分析
- 在最终输出中告知用户"未检测到分析对象"
- 不要编造 tag 或数据
"""

        # 小规模：单 Agent 顺序处理
        if not dispatch_groups:
            dispatch_strategy = (
                f"项数较少（{frame_count} 项），请顺序处理：\n"
                f"- 依次读取 manifest.frames[].file\n"
                f"- 每项独立分析，最后跨项综合\n"
            )
        else:
            # 大规模：派发 SubAgent
            dispatch_strategy = (
                f"项数较多（{frame_count} 项），必须派发 SubAgent 并行处理：\n"
                f"1. 按 manifest.dispatch_groups 派发 {len(dispatch_groups)} 个 SubAgent\n"
                f"2. 每个 SubAgent 接收:\n"
                f"   - 一组 frame 文件路径（dispatch_groups[].frame_files）\n"
                f"   - 共享上下文路径（shared/ 目录）\n"
                f"3. SubAgent 完成后，主 Agent 收集输出做跨项综合\n"
                f"⛔ 不要在一个 SubAgent 中处理超过 6 项\n"
            )

        return f"""{skill_id} {step_key} 的 iterate 输出已按 tag 切分为 per-tag 自包含文件。

【数据结构】
- 每个文件含: tag / thread_queries (元数据) / per_priority_indicators (priority 1/2/3 各自的指标)
- 自包含: 读一个文件即可分析一个 tag，无需跨文件关联
- 共享上下文: chip_info 等在 shared/ 目录

【读取方式】
1. 读取 manifest: {out_dir}/manifest.json
2. 从 manifest.frames[].file 获取 per-tag 文件列表（共 {frame_count} 项）

【处理策略】
{dispatch_strategy}
【硬约束】
⛔ tag 列表必须来自 manifest.frames，禁止凭记忆或推算
⛔ 文件路径必须用 manifest 中的相对路径拼接，禁止臆造文件名
"""

    def _write_shared_context(self, state: dict, out_dir: Path, step_key: str) -> dict:
        """写共享上下文（chip_info / game_frame_summary 等）到 shared/ 目录。

        Args:
            state: skill 执行状态
            out_dir: per-frame 输出目录（.llm_contexts/{session_id}/）
            step_key: 当前 step 的 key

        Returns:
            shared 字典: {key: 相对路径}，如 {"chip_info": "shared/chip_info.json"}
        """
        shared_dir = out_dir / "shared"
        shared_dir.mkdir(parents=True, exist_ok=True)
        shared: dict[str, str] = {}

        # chip_info（从 step3 取）
        step3_out = state.get("step3", {}).get("output", {})
        if isinstance(step3_out, dict) and "matched_chips" in step3_out:
            chip_info = {k: v for k, v in step3_out.items() if k != "cpu_topology"}
            (shared_dir / "chip_info.json").write_text(
                json.dumps(chip_info, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            shared["chip_info"] = "shared/chip_info.json"

        # game_frame_summary（从 step4 取）
        step4_out = state.get("step4", {}).get("output", {})
        if isinstance(step4_out, dict) and "indicators" in step4_out:
            for ind_data in step4_out["indicators"].values():
                if isinstance(ind_data, dict) and "data" in ind_data:
                    data = ind_data["data"]
                    if isinstance(data, dict) and "summary" in data:
                        (shared_dir / "game_frame_summary.json").write_text(
                            json.dumps(data["summary"], ensure_ascii=False, indent=2),
                            encoding="utf-8"
                        )
                        shared["game_frame_summary"] = "shared/game_frame_summary.json"
                        break

        return shared

    def _write_manifest(
        self,
        session_id: str,
        step_def: SkillStep,
        out_dir: Path,
        frame_index: list[dict],
        shared: dict,
        dispatch_groups: list[dict],
        step_key: str,
    ) -> Path:
        """写 manifest.json 顶层索引。

        Args:
            session_id: session ID
            step_def: 当前 step 定义
            out_dir: per-frame 输出目录
            frame_index: per-frame 文件索引
            shared: 共享上下文路径映射
            dispatch_groups: 派发分组
            step_key: 当前 step 的 key（如 "step5"）

        Returns:
            manifest.json 的 Path
        """
        chip_info_path = shared.get("chip_info", "")
        chip_model = "?"
        if chip_info_path:
            try:
                ci = json.loads((out_dir / chip_info_path).read_text(encoding="utf-8"))
                matched = ci.get("matched_chips", [{}])
                if matched and isinstance(matched[0], dict):
                    chip_model = matched[0].get("chip_model", "?")
            except (json.JSONDecodeError, OSError):
                pass

        # 自检（Task 5 只填充 warnings 字段，事件注入在 Task 6）
        warnings = self._validate_manifest(frame_index, out_dir)
        if warnings:
            _log = get_observability_logger("skill_executor")
            _log.warn("per_frame_split_warning", session_id=session_id,
                      step_key=step_key, warnings=warnings)

        manifest = {
            "session_id": session_id,
            "skill_id": getattr(step_def, "skill_id", ""),
            "chip_model": chip_model,
            "frame_count": len(frame_index),
            "shared_context": shared,
            "frames": frame_index,
            "dispatch_hint": (
                f"frame_count={len(frame_index)}, 建议派发 {len(dispatch_groups)} 个 SubAgent 并行分析"
                if dispatch_groups else
                f"frame_count={len(frame_index)}, 单 Agent 顺序处理"
            ),
            "dispatch_groups": dispatch_groups,
            "warnings": warnings,
        }
        manifest_path = out_dir / "manifest.json"
        manifest_path.write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return manifest_path

    def _validate_manifest(self, frame_index: list[dict], out_dir: Path) -> list[str]:
        """manifest 自检，返回 warnings 列表。

        检查项：
        1. 每个 frame 文件真实存在
        2. tag 唯一性
        3. 空 indicators 检测

        Args:
            frame_index: per-frame 文件索引
            out_dir: per-frame 输出目录

        Returns:
            warnings 字符串列表（空表示无问题）
        """
        warnings: list[str] = []
        # 1. 每个文件真实存在
        for f in frame_index:
            if not (out_dir / f["file"]).exists():
                warnings.append(f"frame file missing: {f['file']}")
        # 2. tag 唯一性
        tags = [f["tag"] for f in frame_index]
        if len(tags) != len(set(tags)):
            warnings.append(f"duplicate tags: {tags}")
        # 3. 空 indicators 检测
        empty_count = sum(1 for f in frame_index if f.get("has_error"))
        if empty_count:
            warnings.append(f"{empty_count} frames have empty indicators")
        return warnings

    def _collect_llm_context(
        self, state: dict, step_def: SkillStep, session_id: str = ""
    ) -> dict:
        """为 llm_action 组装上下文。

        新路径（iterate list）: 按 tag 切分到 per-frame 文件 + manifest + 框架前缀
        老路径（chip_info / phases 等）: 单文件 + 预览（保留现有逻辑）
        """
        _log = get_observability_logger("skill_executor")
        instruction = step_def.instruction or ""
        needed = re.findall(r'\{([^}]+)\}', instruction)
        ctx_files = []
        resolved_instruction = instruction

        for ref in needed:
            if '.' not in ref:
                continue
            step_key, field = ref.split('.', 1)
            out = state.get(step_key, {}).get("output", {})

            # === 新路径：iterate list 切分 ===
            # 空 iterate list
            if isinstance(out, list) and not out:
                prefix = self._build_framework_prefix(
                    session_id, getattr(step_def, 'skill_id', ''), step_key, [], [], {}
                )
                resolved_instruction = resolved_instruction.replace('{' + ref + '}', prefix)
                continue

            # 非空 iterate list
            is_iterate_list = (
                isinstance(out, list) and out
                and isinstance(out[0], dict) and "indicators" in out[0]
            )
            if is_iterate_list:
                try:
                    frame_index, out_dir = self._split_iterate_to_per_frame_files(
                        state, step_key, session_id
                    )
                except (KeyError, TypeError):
                    # thread_queries 缺 tag 等必需字段，降级走老路径
                    _log.warn("llm_context_split_degraded", session_id=session_id,
                              step_key=step_key, error="KeyError/TypeError in split")
                    frame_index, out_dir = [], None
                if frame_index:
                    # 写 shared 上下文
                    shared = self._write_shared_context(state, out_dir, step_key)
                    # 预算派发分组
                    dispatch_groups = self._build_dispatch_groups(frame_index)
                    _log.debug("dispatch_groups_built", session_id=session_id,
                               step_key=step_key, group_count=len(dispatch_groups),
                               total_frames=len(frame_index))
                    # 写 manifest
                    manifest_path = self._write_manifest(
                        session_id, step_def, out_dir, frame_index, shared, dispatch_groups,
                        step_key
                    )
                    _log.info("manifest_written", session_id=session_id,
                              step_key=step_key, frame_count=len(frame_index),
                              dispatch_group_count=len(dispatch_groups))
                    ctx_files.append(str(manifest_path))
                    # 生成框架前缀并替换占位符
                    prefix = self._build_framework_prefix(
                        session_id, getattr(step_def, 'skill_id', ''), step_key,
                        frame_index, dispatch_groups, shared
                    )
                    _log.debug("framework_prefix_injected", session_id=session_id,
                               step_key=step_key, frame_count=len(frame_index),
                               dispatch_strategy="fan_out_subagent" if dispatch_groups else "single_agent")
                    resolved_instruction = resolved_instruction.replace('{' + ref + '}', prefix)
                    continue
                # 切分失败（如目录不可写），降级走老路径

            # === 老路径：iterate list 单文件（保留原逻辑） ===
            is_iterate_single = isinstance(out, dict) and "indicators" in out
            if is_iterate_list or is_iterate_single:
                metrics = out if is_iterate_list else [out]
                safe_name = f"{session_id}_{step_key}_metrics" if session_id else f"{step_key}_metrics"
                fpath = _LLM_CONTEXTS_DIR / f"{safe_name}.json"
                fpath.write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
                ctx_files.append(str(fpath))
                resolved_instruction = resolved_instruction.replace(
                    '{' + ref + '}',
                    f"[见文件 {fpath.name}，共 {len(metrics)} 项指标数据，Agent 需读取该文件获取完整数据后分析]"
                )
                continue

            # === 老路径：扁平或嵌套路径取值（chip_info / phases 等） ===
            if not isinstance(out, dict):
                continue

            value = None
            if field in out:
                value = out[field]
            else:
                parts = field.split('.')
                cur = out
                for p in parts:
                    if isinstance(cur, dict) and p in cur:
                        cur = cur[p]
                    else:
                        cur = None
                        break
                value = cur
            if value is None and "matched_chips" in out:
                value = out

            if value is None:
                continue

            # chip_info 特殊处理：排除 cpu_topology
            if isinstance(value, dict) and "matched_chips" in value:
                value = {k: v for k, v in value.items() if k != "cpu_topology"}

            safe_name = f"{session_id}_{step_key}_{field.replace('.', '_')}" if session_id else f"{step_key}_{field.replace('.', '_')}"
            fpath = _LLM_CONTEXTS_DIR / f"{safe_name}.json"
            fpath.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
            ctx_files.append(str(fpath))
            _log.debug("llm_context_old_path", session_id=session_id,
                       step_key=step_key, field=field)

            if isinstance(value, dict) and "matched_chips" in value:
                preview = json.dumps(value, ensure_ascii=False, indent=2)[:512]
                model = value.get("matched_chips", [{}])[0].get("chip_model", "?")
                resolved_instruction = resolved_instruction.replace(
                    '{' + ref + '}',
                    f"[见文件 {fpath.name}] 芯片型号: {model}\n预览: {preview}...\n[完整数据见文件]"
                )
            elif isinstance(value, list) and value and "name" in value[0]:
                names = [p.get("name") for p in value]
                resolved_instruction = resolved_instruction.replace(
                    '{' + ref + '}',
                    f"[见文件 {fpath.name}] 阶段列表: {names}\n[完整数据见文件]"
                )
            else:
                preview = json.dumps(value, ensure_ascii=False, indent=2)[:256]
                resolved_instruction = resolved_instruction.replace(
                    '{' + ref + '}',
                    f"[见文件 {fpath.name}] 预览: {preview}...\n[完整数据见文件]"
                )

        result = {"reasoning_instruction": resolved_instruction}
        if ctx_files:
            result["_ctx_files"] = ctx_files
        return result

    def _build_step_result(
        self,
        executed_steps: list[int],
        state: dict,
        step_def: SkillStep,
        result: Any,
        waiting: bool,
    ) -> dict:
        """构建单步暂停时的返回结构。"""
        return {
            "executed_steps": executed_steps,
            "state": {k: v.get("output") for k, v in state.items()},
            "next_step": {
                "number": step_def.step + 1,
                "is_llm_action": False,
            },
            "current_result": result,
            "waiting_for_agent": waiting,
            "is_complete": False,
        }


# ---------------------------------------------------------------------------
# 状态存储（支持 query_skill_state）
# ---------------------------------------------------------------------------

# 全局 skill 执行状态存储: session_id -> state
_SKILL_STATES: dict[str, dict] = {}


def save_skill_state(session_id: str, skill_id: str, state: dict, executed_steps: list[int]) -> None:
    """保存 skill 执行状态到全局存储。"""
    _SKILL_STATES[session_id] = {
        "skill_id": skill_id,
        "state": state,
        "executed_steps": executed_steps,
    }


def query_skill_state(session_id: str) -> dict:
    """查询指定 session 的 skill 执行状态。

    Args:
        session_id: 每次 run_skill 调用会返回一个新的 session_id，
                    用于后续 query_skill_state 查看累积状态。

    Returns:
        {
            "session_id": str,
            "skill_id": str,
            "state": {...},
            "executed_steps": [1, 2, 3, ...],
        }
        若 session 不存在返回 error。
    """
    entry = _SKILL_STATES.get(session_id)
    if entry is None:
        return {"error": f"session '{session_id}' not found or expired"}
    return {
        "session_id": session_id,
        "skill_id": entry["skill_id"],
        "state": entry["state"],
        "executed_steps": entry["executed_steps"],
    }


def clear_skill_state(session_id: str) -> None:
    """清除指定 session 的状态。"""
    _SKILL_STATES.pop(session_id, None)


# ---------------------------------------------------------------------------
# 工具注册（由 server.py 调用）
# ---------------------------------------------------------------------------

def register_executor_tools(**tool_funcs: callable) -> None:
    """注册 SkillExecutor 可调用的工具函数。

    用法:
        register_executor_tools(
            get_hitrace_path=fn1,
            convert_hitrace_to_sqlite=fn2,
            detect_rendering_pipeline=fn3,
        )
    """
    for name, fn in tool_funcs.items():
        _TOOL_CALLABLE[name] = fn
