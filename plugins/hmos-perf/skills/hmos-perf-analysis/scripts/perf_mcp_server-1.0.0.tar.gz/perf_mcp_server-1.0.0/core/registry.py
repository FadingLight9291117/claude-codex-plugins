"""指标 / Skill 注册中心。

启动时递归加载 config/indicators/**/*.yaml 与 config/skills/*.yaml，
解析为 IndicatorMeta / SkillDef 数据类，并完成校验:
- atomic 的 sql_params 必须覆盖 SQL 中所有 :xxx 占位符（除 template_vars）
- group 不能循环依赖
- 指标名必须是合法标识符
- result_schema 必须为 array / object / scalar
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Optional

import yaml


# ---------------------------------------------------------------------------
# 数据类
# ---------------------------------------------------------------------------

@dataclass
class SQLParam:
    """单个 SQL 参数自描述。"""

    name: str
    type: str                          # number / string / integer / boolean
    required: bool
    description: str = ""
    default: Any = None
    enum: Optional[list[Any]] = None


@dataclass
class InputParam:
    """Skill 输入参数自描述。"""

    name: str
    type: str = "string"               # string / number / integer / boolean
    required: bool = True
    description: str = ""
    default: Any = None
    example: Any = None
    enum: Optional[list[Any]] = None


@dataclass
class IndicatorMeta:
    """原子或组合指标的元数据。"""

    name: str
    type: Literal["atomic", "group"]
    display_name: str
    category: str
    description: str
    unit: str
    default_granularity: str

    # atomic 特有
    sql: Optional[str] = None
    sql_params: list[SQLParam] = field(default_factory=list)
    result_schema: dict = field(default_factory=dict)
    template_vars: dict = field(default_factory=dict)
    preprocess: Optional[dict] = None  # 预处理引擎声明（如 flamegraph_collapse）
    empty_reason: Optional[str] = None  # 空数据时返回给 Agent 的提示文案
    digest_label: Optional[str] = None  # Agent 友好化：headline_digest 行前缀（spec §4.4）

    # group 特有
    expands_to: list[dict] = field(default_factory=list)  # [{name, override_params}]
    reasoning_hints: list[str] = field(default_factory=list)
    default_indicator_params: Optional[dict] = None  # 各指标的默认参数

    # 通用
    related: list[str] = field(default_factory=list)


@dataclass
class SkillStep:
    """Skill 工作流单步。"""

    step: int
    tool: Optional[str] = None
    action: Optional[str] = None       # llm_reasoning / llm_decision
    args: dict = field(default_factory=dict)
    output: str = ""
    iterate: Optional[str] = None
    parallel_iterate: Optional[str] = None
    instruction: Optional[str] = None
    default_indicator_params: Optional[dict] = None
    preprocess: Optional[dict] = None


@dataclass
class SkillDef:
    """Skill 工作流定义。"""

    skill_id: str
    name: str
    triggers: list[str]
    input_params: list[InputParam]
    steps: list[SkillStep]
    rules: list[str]
    description: str = ""
    priority: str = "high"             # high / low（low 用于 fallback）


# ---------------------------------------------------------------------------
# 注册中心
# ---------------------------------------------------------------------------

class ConfigRegistry:
    """YAML 配置加载、解析、校验、展开。"""

    def __init__(self, config_dir: str | Path = "config"):
        self.config_path = Path(config_dir)
        self.indicators: dict[str, IndicatorMeta] = {}
        self.atomic_indicators: dict[str, IndicatorMeta] = {}
        self.group_indicators: dict[str, IndicatorMeta] = {}
        self.skills: dict[str, SkillDef] = {}
        self._load_all()

    # ---------- 加载 ----------

    def _load_all(self) -> None:
        """递归加载 indicators 与 skills，加载完成后做整体校验。"""
        self.indicators.clear()
        self.atomic_indicators.clear()
        self.group_indicators.clear()
        self.skills.clear()

        # 加载 indicators
        ind_root = self.config_path / "indicators"
        if ind_root.exists():
            for yaml_file in sorted(ind_root.rglob("*.yaml")):
                data = yaml.safe_load(yaml_file.read_text(encoding="utf-8")) or {}
                for item in data.get("indicators", []):
                    meta = self._parse_indicator(item)
                    self.indicators[meta.name] = meta
                    if meta.type == "atomic":
                        self.atomic_indicators[meta.name] = meta
                    else:
                        self.group_indicators[meta.name] = meta

        # 加载 skills
        skill_root = self.config_path / "skills"
        if skill_root.exists():
            for yaml_file in sorted(skill_root.glob("*.yaml")):
                data = yaml.safe_load(yaml_file.read_text(encoding="utf-8")) or {}
                if not data:
                    continue
                skill = self._parse_skill(data)
                self.skills[skill.skill_id] = skill

        self._validate()

    def _parse_indicator(self, item: dict) -> IndicatorMeta:
        # 解析 expands_to，支持 str 和 dict 两种形式
        raw_expands = item.get("expands_to", [])
        expands_to: list[dict] = []
        for e in raw_expands:
            if isinstance(e, str):
                expands_to.append({"name": e, "override_params": {}})
            elif isinstance(e, dict):
                expands_to.append({
                    "name": e["name"],
                    "override_params": e.get("override_params", {}),
                })

        return IndicatorMeta(
            name=item["name"],
            type=item["type"],
            display_name=item.get("display_name", item["name"]),
            category=item.get("category", "misc"),
            description=item.get("description", ""),
            unit=item.get("unit", ""),
            default_granularity=item.get("default_granularity", "raw"),
            sql=item.get("sql"),
            sql_params=[SQLParam(**p) for p in item.get("sql_params", [])],
            result_schema=item.get("result_schema", {}),
            template_vars=item.get("template_vars", {}),
            preprocess=item.get("preprocess"),
            empty_reason=item.get("empty_reason"),
            digest_label=item.get("digest_label"),
            expands_to=expands_to,
            reasoning_hints=item.get("reasoning_hints", []),
            related=item.get("related", []),
            default_indicator_params=item.get("default_indicator_params"),
        )

    def _parse_skill(self, data: dict) -> SkillDef:
        steps = [self._parse_step(s) for s in data.get("steps", [])]
        return SkillDef(
            skill_id=data["skill_id"],
            name=data["name"],
            triggers=data.get("triggers", []),
            input_params=self._parse_input_params(data.get("input_params", [])),
            steps=steps,
            rules=data.get("rules", []),
            description=data.get("description", ""),
            priority=data.get("priority", "high"),
        )

    def _parse_input_params(self, raw: list) -> list[InputParam]:
        """解析 input_params，支持字符串和结构化两种 YAML 写法。"""
        result = []
        for item in raw:
            if isinstance(item, str):
                result.append(InputParam(
                    name=item,
                    type="string",
                    required=True,
                    description="",
                ))
            elif isinstance(item, dict):
                result.append(InputParam(
                    name=item["name"],
                    type=item.get("type", "string"),
                    required=item.get("required", True),
                    description=item.get("description", ""),
                    default=item.get("default"),
                    example=item.get("example"),
                    enum=item.get("enum"),
                ))
        return result

    def _parse_step(self, item: dict) -> SkillStep:
        return SkillStep(
            step=item["step"],
            tool=item.get("tool"),
            action=item.get("action"),
            args=item.get("args", {}),
            output=item.get("output", ""),
            iterate=item.get("iterate"),
            parallel_iterate=item.get("parallel_iterate"),
            instruction=item.get("instruction"),
            default_indicator_params=item.get("default_indicator_params")
            or item.get("indicator_params"),
            preprocess=item.get("preprocess"),
        )

    # ---------- 校验 ----------

    def _validate(self) -> None:
        """校验 sql_params 占位符一致性 + group 循环依赖。"""
        self._validate_sql_params_coverage()
        self._validate_no_cyclic_groups()
        # Todo: 校验 result_schema 合法性（type ∈ {array, object, scalar}）
        # Todo: 校验指标名必须是合法标识符
        # Todo: 校验 enum 值的类型一致性

    def _validate_sql_params_coverage(self) -> None:
        for name, meta in self.atomic_indicators.items():
            if not meta.sql:
                continue
            declared = {p.name for p in meta.sql_params} | set(meta.template_vars.keys())
            placeholders = set(re.findall(r":(\w+)", meta.sql))
            missing = placeholders - declared
            if missing:
                raise ValueError(
                    f"指标 {name} 的 SQL 占位符 {missing} 未在 sql_params/template_vars 中声明"
                )

    def _validate_no_cyclic_groups(self) -> None:
        visited: set[str] = set()

        def dfs(n: str, path: set[str]) -> None:
            if n in path:
                raise ValueError(f"Group 循环依赖: {' -> '.join(path)} -> {n}")
            if n in visited or n not in self.group_indicators:
                return
            path.add(n)
            for child in self.group_indicators[n].expands_to:
                dfs(child["name"], path)
            path.remove(n)
            visited.add(n)

        for name in self.group_indicators:
            dfs(name, set())

    # ---------- 展开 ----------

    def expand_indicators(
        self, names: list[str],
    ) -> list[tuple[str, dict, list[str], dict]]:
        """展开 group 为 [(atomic_name, override_params, group_chain, group_defaults), ...]。

        - group_chain 记录该 atomic 来自哪些 group（用于追溯原始 agent_params）
        - group_defaults 记录沿途所有 group 的 default_indicator_params（合并，外层优先）
        - 去重保序
        - 合并嵌套 group 的 override_params（外层优先级高于内层）
        """
        result: list[tuple[str, dict, list[str], dict]] = []
        seen: set[str] = set()

        def _expand(n: str, overrides: dict, group_chain: list[str], group_defaults: dict) -> None:
            if n in seen:
                return
            seen.add(n)

            meta = self.indicators.get(n)
            if not meta:
                raise ValueError(f"未知指标: {n}")

            if meta.type == "atomic":
                result.append((n, overrides or {}, group_chain, group_defaults))
            else:
                # 合并当前 group 的 default_indicator_params（外层覆盖内层）
                current_defaults = getattr(meta, "default_indicator_params", None) or {}
                merged_defaults = {**group_defaults, **current_defaults}
                for child in meta.expands_to:
                    child_name = child["name"]
                    child_overrides = child.get("override_params", {}) or {}
                    merged = {**child_overrides, **(overrides or {})}
                    _expand(child_name, merged, group_chain + [n], merged_defaults)

        for n in names:
            _expand(n, {}, [], {})

        return result

    # ---------- 工具方法 ----------

    def get_indicator(self, name: str) -> Optional[IndicatorMeta]:
        return self.indicators.get(name)

    def get_skill(self, skill_id: str) -> Optional[SkillDef]:
        return self.skills.get(skill_id)

    def reload(self) -> None:
        """热加载入口，被 watchdog 触发或外部手动调用。"""
        self._load_all()
