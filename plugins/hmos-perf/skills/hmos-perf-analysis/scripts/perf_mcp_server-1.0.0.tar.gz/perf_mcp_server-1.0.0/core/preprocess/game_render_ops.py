"""游戏渲染帧解析算子。

游戏渲染链路（鸿蒙容器架构）：
    游戏进程(se.party.huawei) --Binder--> 容器进程(shell_assistant)
      anco_service_br (DequeueBuffer/QueueBuffer)
        --Binder--> RS进程(render_service)
          OS_IPC_0_2114 (FlushBuffer/DoFlushBuffer)
          -> AcquireBuffer -> CommitLayers -> presentFenceIndex
          -> Waiting for PresentFence (上屏完成)

核心算法：
    1. 自动识别游戏 Surface queueId（从 CommitLayers 提取 SurfaceView layer name）
    2. 按 (queueId, sequence) 关联 FlushBuffer ↔ AcquireBuffer
    3. 以 SendVsyncTo conn:rs 为帧边界划分帧
    4. 计算 PresentFence 结束间隔，复用 _get_refresh_rate_tag 判定丢帧
    5. 连续丢帧合并（最多5帧）为丢帧区间
    6. 每丢帧区间：唤醒链追溯 + sched_slice 非 Sleep 耗时扫描 → 瓶颈线程
"""
from __future__ import annotations

import re
from bisect import bisect_left, bisect_right
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

import pandas as pd

from core.observability import get_observability_logger
from core.preprocess.base import PreprocessContext, PreprocessError, register_operator
from core.preprocess.frame_ops import _resolve_app_name
from core.preprocess.jank_interval_ops import PRESENT_FENCE_RE
from core.preprocess.marker_ops import _NO_PARENT
# 注意：build_wakeup_chain 已从本模块下线（方案 L 后不再贡献 pid 和 priority），
# wakeup_chain.py 仍保留供其他 skill 通过 core.preprocess.wakeup_chain 直接 import。
# 游戏丢帧使用独立间隔阈值判定（>= 2x 平均帧周期），不依赖 frame_ops 中的帧率标签逻辑

_log = get_observability_logger("game_render_ops")

# ---------------------------------------------------------------------------
# 正则表达式
# ---------------------------------------------------------------------------

# H:SendVsyncTo conn: rs, now:323460335435, refreshRate:0
SEND_VSYNC_RE = re.compile(r"H:SendVsyncTo conn:\s*(\S+),\s*now:(\d+)")

# H:FlushBuffer name: xxx queueId: 7181185319022 sequence: 466223197
FLUSH_BUFFER_RE = re.compile(
    r"H:FlushBuffer name:\s*(?P<name>.*?)queueId:\s*(?P<queueId>\d+)\s+sequence:\s*(?P<sequence>\d+)"
)

# H:DoFlushBuffer name: xxx queueId: 7181185319022 seq: 466223197
DO_FLUSH_RE = re.compile(
    r"H:DoFlushBuffer name:\s*(?P<name>.*?)queueId:\s*(?P<queueId>\d+)\s+seq:\s*(?P<sequence>\d+)"
)

# H:AcquireBuffer name: xxx queueId: 7181185319022
ACQUIRE_BUFFER_RE = re.compile(
    r"H:AcquireBuffer name:\s*(?P<name>.*?)queueId:\s*(?P<queueId>\d+)"
)

# H:acquire buffer sequence: 466223195 desiredPresentTimestamp: ...
ACQUIRE_SEQUENCE_RE = re.compile(
    r"H:acquire buffer sequence:\s*(?P<sequence>\d+)"
)

# H:CommitLayers rate:60,now:323460335435,vsyncId:16130,size:4,Names:...
COMMIT_LAYERS_RE = re.compile(
    r"H:CommitLayers rate:(?P<rate>\d+),now:(?P<now>\d+),vsyncId:(?P<vsyncId>\d+)"
)

# H:presentFenceIndex_ = 0
PRESENT_FENCE_INDEX_RE = re.compile(r"H:presentFenceIndex_\s*=\s*(?P<index>\d+)")

# H:Waiting for Present Fence 352（旧格式，空格分隔，352 是 fenceId）
WAIT_PRESENT_FENCE_RE = re.compile(r"H:Waiting for Present Fence (?P<fenceId>\d+)")

# H:Waiting for PresentFence_0 106122（新格式，_0 是 fence index，106122 是序列号）
WAIT_PRESENT_FENCE_NEW_RE = re.compile(r"H:Waiting for PresentFence_\d+\s+(?P<fenceId>\d+)")

# H:ReceiveVsync name:rs dataCount: 24bytes now:... expectedEnd:... vsyncId:124350, fd:22
RECV_VSYNC_RE = re.compile(
    r"H:ReceiveVsync name:(?P<name>\S+).*?vsyncId:(?P<vsyncId>\d+)"
)

# ---------------------------------------------------------------------------
# 数据结构
# ---------------------------------------------------------------------------


@dataclass
class BottleneckThread:
    """瓶颈线程信息。"""

    pid: int
    tid: int
    thread_name: str = ""
    process_name: str = ""
    begin_ms: float = 0.0
    end_ms: float = 0.0
    active_ms: float = 0.0
    # cpu_active_ms 只累加 cpu_profile 路径（thread_state Running+Runnable）的 interval，
    # 不含 callstack_active 的 trace marker 区间。
    # 用作 priority 排序键，确保排到 priority 1 的是真实占 CPU 的线程。
    cpu_active_ms: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pid": self.pid,
            "tid": self.tid,
            "thread_name": self.thread_name,
            "process_name": self.process_name,
            "begin_ms": round(self.begin_ms, 6),
            "end_ms": round(self.end_ms, 6),
            "active_ms": round(self.active_ms, 3),
            "cpu_active_ms": round(self.cpu_active_ms, 3),
        }


# ns → ms 转换因子（统一全文常量，避免重复字面量）
_NS_PER_MS = 1_000_000.0


def _round_opt(x: Optional[float], n: int) -> Optional[float]:
    """None 安全的 round：None 或非 float 透传，否则 round(x, n)。"""
    return round(x, n) if x is not None else None


def _frame_rs_period_ms(gf: "GameFrame", rs_period_ms: Optional[float]) -> Optional[float]:
    """该帧实际使用的 RS 周期（spec §3.2 动态）：优先用 gf.commit_layers_rate，回退全局 rs_period_ms。"""
    if gf.commit_layers_rate and gf.commit_layers_rate > 0:
        return 1000.0 / gf.commit_layers_rate
    return rs_period_ms


@dataclass
class GameFrame:
    """单个游戏渲染帧。"""

    vsync_id: Optional[int] = None
    present_id: Optional[int] = None
    present_fence_end_ms: Optional[float] = None
    frame_interval_ms: Optional[float] = None
    flush_buffer_ms: Optional[float] = None
    flush_buffer_interval_ms: Optional[float] = None
    jank: bool = False
    display: bool = False
    commit_layers_ms: Optional[float] = None
    present_fence_ms: Optional[float] = None
    flush_sequence: Optional[str] = None    # FlushBuffer 的 sequence，用于精确关联 AcquireBuffer
    acquire_delay_ms: Optional[float] = None  # acquire_ts(sequence) - flush_ts
    jank_class: Optional[str] = None       # producer_jank / consumer_jank / phase_drift / unclassified
    commit_layers_rate: Optional[int] = None  # 该帧 commit_layers 的 rate（动态 RS 周期，spec §3.2）
    consumer_duration_ms: Optional[float] = None  # present_fence_end - gvs(流水线深度)
    stage_render_ms: Optional[float] = None       # 渲染级: gvs -> CommitLayers 开始
    stage_commit_ms: Optional[float] = None       # 提交级: CommitLayers dur
    stage_present_ms: Optional[float] = None      # 送显级: PresentFence begin -> end

    def to_dict(self) -> Dict[str, Any]:
        return {
            "vsync_id": self.vsync_id,
            "present_id": self.present_id,
            "present_fence_end_ms": _round_opt(self.present_fence_end_ms, 6),
            "frame_interval_ms": _round_opt(self.frame_interval_ms, 3),
            "flush_buffer_ms": _round_opt(self.flush_buffer_ms, 6),
            "flush_buffer_interval_ms": _round_opt(self.flush_buffer_interval_ms, 3),
            "jank": self.jank,
            "jank_class": self.jank_class,
            "display": self.display,
            "commit_layers_ms": _round_opt(self.commit_layers_ms, 6),
            "present_fence_ms": _round_opt(self.present_fence_ms, 6),
            "consumer_duration_ms": _round_opt(self.consumer_duration_ms, 3),
            "stage_render_ms": _round_opt(self.stage_render_ms, 3),
            "stage_commit_ms": _round_opt(self.stage_commit_ms, 3),
            "stage_present_ms": _round_opt(self.stage_present_ms, 3),
        }


@dataclass
class JankInterval:
    """丢帧区间。"""

    present_id: int = 0  # 区间最后一帧的 present_id，唯一标识
    frame_count: int = 0
    duration_ms: float = 0.0
    jank_class: str = ""
    cause_evidence: Dict[str, Any] = field(default_factory=dict)
    window_start_ms: Optional[float] = None
    window_end_ms: Optional[float] = None
    bottleneck_threads: List[BottleneckThread] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "present_id": self.present_id,
            "frame_count": self.frame_count,
            "duration_ms": round(self.duration_ms, 3),
            "jank_class": self.jank_class,
            "cause_evidence": self.cause_evidence,
            "bottleneck_threads": [bt.to_dict() for bt in self.bottleneck_threads],
        }


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------


def _compute_rs_period_ms(
    recv_vsync_events: List[Tuple],
    commit_layers: List[Tuple],
    ctx,
) -> Optional[float]:
    """计算 RS 上屏周期（spec §3.2）。

    RS 上屏周期 = 显示刷新率倒数（120Hz → 8.333ms）。

    1. 首选：commit_layers rate 字段（显式刷新率，最准确）
       — recv_vsync name:rs 实测为 60Hz（游戏生产节律），非上屏节律
    2. 回退：recv_vsync 按线程分组取中位数（rate 不可用时）
    3. 都拿不到：返回 None
    """
    import statistics

    # 首选：commit_layers rate 众数（spec §3.2 全局 main rate，已实现）
    # 用众数而非 max：60Hz→120Hz 切换时，若 60Hz 段更长，众数=60（正确），
    # max 永远返回 120（错）。众数是统计阈值（jank_threshold/flush_threshold/tol_ms）
    # 的稳定基准。每帧分类时用该帧自己的 commit_layers_rate 计算 frame_rs_period_ms
    # （见 _classify_jank_cause / step 6 evidence），spec §3.2 动态频率检测已落地。
    # 平局（count 相同）时取较大 rate（更保守的高频基准），保证确定性。
    if commit_layers:
        rate_counter = Counter(c[2] for c in commit_layers if len(c) > 2 and c[2])
        if rate_counter:
            # 平局时取较大 rate，确保确定性（与 max 行为一致；非平局时取众数）
            main_rate = max(rate_counter.items(), key=lambda x: (x[1], x[0]))[0]
            if main_rate > 0:
                return 1000.0 / main_rate

    # 回退：recv_vsync 按线程分组取中位数
    rs_intervals = _compute_recv_vsync_intervals(recv_vsync_events)
    if rs_intervals:
        median = statistics.median(rs_intervals)
        if median > 0:
            return float(median)

    return None


def _compute_recv_vsync_intervals(recv_vsync_events: List[Tuple]) -> List[float]:
    """计算 RS 主线程 ReceiveVsync 事件相邻 ts 差值（ms）。

    recv_vsync_events 已在解析时过滤 name=="rs"（game_render_ops.py:644），
    但同一 vsyncId 有多次唤醒（多线程），需按 callstack_id (r[6]) 分组，
    取事件数最多的线程作为 RS 主线程，避免跨线程差值污染中位数。
    供 _compute_rs_period_ms（取中位数）和 _compute_tol_ms（取标准差）复用。

    元组格式：(ts, now, expected_end, vsync_id, dur, name, row_id)
    r[6] = callstack_id（row_id），用于线程分组。
    """
    if not recv_vsync_events:
        return []
    by_thread: Dict[int, List[int]] = {}
    for r in recv_vsync_events:
        if len(r) <= 6:
            continue  # 元组格式不符（缺 callstack_id），跳过而非静默归零
        callstack_id = r[6]
        by_thread.setdefault(callstack_id, []).append(r[0])
    if not by_thread:
        return []
    # 取事件数最多的线程（RS 主线程）
    main_tid = max(by_thread.keys(), key=lambda k: len(by_thread[k]))
    ts_list = sorted(by_thread[main_tid])
    if len(ts_list) < 2:
        return []
    return [(ts_list[i + 1] - ts_list[i]) / 1_000_000.0
            for i in range(len(ts_list) - 1)]


def _compute_tol_ms(
    intervals: List[float], rs_period_ms: Optional[float], ctx,
) -> float:
    """容差由 recv_vsync 间隔标准差推导（spec §3.2）。

    2σ 覆盖 ≈95% 正常抖动；上限 0.25×period 保证相邻 k 匹配区间不重叠；
    下限 tol_min_ms 防止 σ 极小时容差过紧。
    """
    import statistics

    if not intervals or rs_period_ms is None:
        return float(ctx.params.get("tol_default_ms", 1.5))
    sigma = statistics.stdev(intervals) if len(intervals) >= 2 else 0.0
    lower = float(ctx.params.get("tol_min_ms", 1.0))
    upper = float(ctx.params.get("tol_max_ratio", 0.25)) * rs_period_ms
    return max(lower, min(2 * sigma, upper))


def _compute_min_threshold(rs_period_ms: Optional[float], ctx) -> float:
    """阈值下限动态绑定 rs_period（spec §3.3）。

    rs_period 可用 → 0.8×period；不可用 → 回退常量。
    """
    if rs_period_ms and rs_period_ms > 0:
        ratio = float(ctx.params.get("min_threshold_ratio", 0.8))
        return ratio * rs_period_ms
    return float(ctx.params.get("min_interval_threshold_ms", 8.3))


def _compute_flush_threshold_ms(
    present_frames: List["GameFrame"],
    rs_period_ms: Optional[float],
    ctx,
    ratio: Optional[float] = None,
    min_samples: Optional[int] = None,
) -> Optional[float]:
    """计算生产者 FlushBuffer 间隔稳定性阈值（spec §3.3）。

    P10×ratio 作为 baseline；样本不足返回 None。
    """
    ratio = ratio if ratio is not None else float(ctx.params.get("flush_stable_ratio", 1.5))
    min_samples = (min_samples if min_samples is not None
                   else int(ctx.params.get("flush_stable_min_samples", 10)))
    intervals = sorted(
        f.flush_buffer_interval_ms
        for f in present_frames
        if f.flush_buffer_interval_ms
    )
    if len(intervals) < min_samples:
        return None
    p10_idx = max(len(intervals) * 10 // 100, 0)
    return max(intervals[p10_idx] * ratio, _compute_min_threshold(rs_period_ms, ctx))


def _check_flush_stability(
    gf: "GameFrame", flush_threshold_ms: Optional[float],
) -> Optional[bool]:
    """单帧生产者稳定性三态判定（spec §3.5）。

    True=稳定, False=不稳定, None=数据缺失（保守，落 unclassified）。
    """
    if flush_threshold_ms is None or gf.flush_buffer_interval_ms is None:
        return None
    return gf.flush_buffer_interval_ms < flush_threshold_ms


def _build_vsync_consumed_seqs(
    index: Dict[str, Any],
    recv_vsync_with_id: List[Tuple[int, int]],
) -> Dict[int, List[Tuple[str, str]]]:
    """从 acquire buffer sequence 向上找 ReceiveVsync，建 vsyncId → [(queue_id, sequence)]（spec §3.4）。

    一个 vsyncId 子树可能有多个 AcquireBuffer（实测 4181 的 vsyncId 362203 有 3 个），
    故映射值是 List。queue_id 从 parent 链的 AcquireBuffer 事件名解析（实测 parent 即
    AcquireBuffer，1 hop）。复用 ACQUIRE_SEQUENCE_RE / ACQUIRE_BUFFER_RE / _NO_PARENT
    （黄金规则 29）。
    """
    id_to_name = index["id_to_name"]
    parent_of = index["parent_of"]
    recv_id_to_vsync: Dict[int, int] = {nid: vid for nid, vid in recv_vsync_with_id}

    vsync_to_seqs: Dict[int, List[Tuple[str, str]]] = {}
    for nid, name in id_to_name.items():
        m = ACQUIRE_SEQUENCE_RE.search(name)
        if not m:
            continue
        seq = m.group("sequence")
        pid = parent_of.get(nid)
        queue_id: Optional[str] = None
        for _ in range(30):
            if pid is None or pid == _NO_PARENT or pid <= 0:
                break
            if pid in recv_id_to_vsync:
                vid = recv_id_to_vsync[pid]
                vsync_to_seqs.setdefault(vid, []).append((queue_id or "", seq))
                break
            # 从 parent 事件名解析 queue_id（AcquireBuffer 事件）
            if queue_id is None:
                p_name = id_to_name.get(pid, "")
                am = ACQUIRE_BUFFER_RE.search(p_name)
                if am:
                    queue_id = am.group("queueId")
            pid = parent_of.get(pid)
    return vsync_to_seqs


def _match_flush_buffers_to_frames(
    frames: List["GameFrame"],
    flush_buffers: List[Tuple[int, str, str, int, str]],
    vsync_to_seqs: Dict[int, List[Tuple[str, str]]],
) -> None:
    """消耗式匹配 FlushBuffer 到 RS 帧（spec §3.4 修正：环形复用一对一消耗）。

    消耗式匹配（替代旧版 _pick_best_sequence + fallback 贪心扫，已移除）。参考用户提供算法：
      surface_map[queue_id][sequence] = FlushBuffer ts（单槽，同 sequence 来新的覆盖）
      RS 帧到来时 del surface_map[queue_id][sequence]（一对一消耗）

    flush_buffers 元组 (ts_ns, sequence, name, callid_val, queue_id)，queue_id 已在
    _parse_events 解析时存入元组第 5 位（不再从 name 重新解析）。
    frames 按 present_fence_ms（pf_ts）排序后和 flush_buffers 一起按 ts 混合排序遍历：
    FlushBuffer ts < 当前 RS 帧 pf_ts 时入池（单槽覆盖），RS 帧到达时按
    vsync_to_seqs[vid] 拿 [(queue_id, sequence), ...] 逐个 pop 消耗。
    flush_buffer_ms 取消耗到的 FlushBuffer 中 ts 最大者（参考 link_frames append 多个的语义）。
    匹配失败（池子无对应 (queue_id, sequence)，或 FlushBuffer ts >= pf_ts 未入池）
    → flush_buffer_ms 保持 None，不 fallback 贪心扫。
    """
    if not frames:
        return

    # 预提取 flush_buffers 的 (ts_ns, queue_id, sequence) 三元组，按 ts 排序
    fb_sorted: List[Tuple[int, str, str]] = []
    for fb in flush_buffers:
        ts_ns, seq, qid = fb[0], fb[1], fb[4] if len(fb) > 4 else ""
        fb_sorted.append((ts_ns, qid, seq))
    fb_sorted.sort(key=lambda x: x[0])

    # frames 按 pf_ts 排序（present_fence_ms 是 ms，×_NS_PER_MS 还原 ns）
    frames_sorted = sorted(frames, key=lambda f: (f.present_fence_ms or 0) * _NS_PER_MS)

    # 混合遍历：FlushBuffer 进池子（单槽覆盖），RS 帧消耗（pop）
    surface_map: Dict[str, Dict[str, int]] = {}  # queue_id → sequence → ts(ns)
    fb_idx = 0
    for gf in frames_sorted:
        pf_ts_ns = int((gf.present_fence_ms or 0) * _NS_PER_MS)
        # 先把所有 ts < pf_ts 的 FlushBuffer 入池（同 sequence 单槽覆盖，留最新 ts）
        while fb_idx < len(fb_sorted) and fb_sorted[fb_idx][0] < pf_ts_ns:
            _, qid, seq = fb_sorted[fb_idx]
            surface_map.setdefault(qid, {})[seq] = fb_sorted[fb_idx][0]
            fb_idx += 1
        # RS 帧消耗 vsync_to_seqs 里的所有 (queue_id, sequence)，逐个 pop
        candidates = vsync_to_seqs.get(gf.vsync_id or -1, [])
        best_ts_ms: Optional[float] = None
        best_seq: Optional[str] = None
        for qid, seq in candidates:
            slot = surface_map.get(qid, {}).pop(seq, None)
            if slot is not None:
                ts_ms = slot / _NS_PER_MS
                if best_ts_ms is None or ts_ms > best_ts_ms:
                    best_ts_ms = ts_ms
                    best_seq = seq
        if best_ts_ms is not None:
            gf.flush_buffer_ms = best_ts_ms
            gf.flush_sequence = best_seq


def _matches_rs_period(
    signal: Optional[float], rs_period_ms: float, tol_ms: float,
) -> bool:
    """信号是否匹配整数个 RS 周期（spec §3.5）。

    判据：signal > 0.5×period（剔除噪声级残差），且存在 k≥1 使
    |signal - k×rs_period_ms| ≤ tol_ms。
    """
    if signal is None or signal <= rs_period_ms * 0.5:
        return False
    k = round(signal / rs_period_ms)
    if k < 1:
        return False
    return abs(signal - k * rs_period_ms) <= tol_ms


def _compute_delay_jump_with_lookback(
    gf: "GameFrame",
    present_frames: List["GameFrame"],
    cur_idx: int,
    max_lookback: int = 3,
) -> Optional[float]:
    """B2 跳变基准向前回溯（spec §3.5）。

    从 cur_idx-1 向前找第一个 acquire_delay_ms 非 None 的帧作为基准，
    返回 gf.acquire_delay_ms - prev.acquire_delay_ms。回溯不超过 max_lookback 帧，
    无可用基准时返回 None。
    """
    for back in range(1, max_lookback + 1):
        prev_idx = cur_idx - back
        if prev_idx < 0:
            break
        prev_gf = present_frames[prev_idx]
        if prev_gf.acquire_delay_ms is not None:
            return gf.acquire_delay_ms - prev_gf.acquire_delay_ms
    return None


def _build_vsync_gvs_map(
    send_vsync: List[Tuple[int, int]],
    recv_vsync_events: List[Tuple],
) -> Dict[int, float]:
    """SendVsyncTo conn:rs 的 now ↔ ReceiveVsync name:rs 的 now 匹配,建 vsync_id → gvs_ts(ms)。

    实测 7 条游戏 trace 匹配率 100%。未匹配的 ReceiveVsync 忽略。
    """
    now2send = {now: ts for ts, now in send_vsync}
    return {
        r[3]: now2send[r[1]] / _NS_PER_MS
        for r in recv_vsync_events
        if len(r) > 3 and r[1] in now2send
    }


def _fill_consumer_durations(
    frames: List["GameFrame"],
    send_vsync: List[Tuple[int, int]],
    recv_vsync_events: List[Tuple],
    commit_layers: List[Tuple],
) -> None:
    """填充每帧 consumer_duration(gvs→pf_end)与三级流水耗时(spec §5.1)。

    cd 是流水线深度(延迟),不是吞吐;判异常必须用稳态基线,见 _classify_jank_cause。
    """
    vid2gvs = _build_vsync_gvs_map(send_vsync, recv_vsync_events)
    vid2commit = {c[4]: (c[0] / _NS_PER_MS, c[1] / _NS_PER_MS)
                  for c in commit_layers if len(c) > 4}
    for gf in frames:
        g = vid2gvs.get(gf.vsync_id or -1)
        if g is None or gf.present_fence_end_ms is None:
            continue
        gf.consumer_duration_ms = gf.present_fence_end_ms - g
        cm = vid2commit.get(gf.vsync_id or -1)
        if cm is not None:
            gf.stage_render_ms = cm[0] - g
            gf.stage_commit_ms = cm[1]
        if gf.present_fence_ms is not None:
            gf.stage_present_ms = gf.present_fence_end_ms - gf.present_fence_ms


@dataclass
class ConsumerContext:
    """consumer 稳态基线(spec §5.1/5.5)。"""
    p50: float
    sigma: float
    band: float
    steady_lo: float
    steady_hi: float
    steady_lookback: int = 5
    upstream_lookback: int = 20


def _compute_consumer_baseline(
    present_frames: List["GameFrame"], ctx,
) -> Optional[ConsumerContext]:
    """cd 稳态基线:P50 ± max(2σ, band_min)。样本 < 10 返回 None(判据整体跳过)。"""
    import statistics
    min_samples = int(ctx.params.get("consumer_baseline_min_samples", 10))
    cds = sorted(f.consumer_duration_ms for f in present_frames
                 if f.consumer_duration_ms is not None)
    if len(cds) < min_samples:
        return None
    p50 = statistics.median(cds)
    sigma = statistics.stdev(cds) if len(cds) >= 2 else 0.0
    band = max(2 * sigma, float(ctx.params.get("consumer_band_min_ms", 3.0)))
    return ConsumerContext(
        p50=p50, sigma=sigma, band=band,
        steady_lo=p50 - band, steady_hi=p50 + band,
        steady_lookback=int(ctx.params.get("consumer_steady_lookback", 5)),
        upstream_lookback=int(ctx.params.get("consumer_upstream_lookback", 20)),
    )


def _compute_consumer_delta(
    present_frames: List["GameFrame"], cur_idx: int, cctx: ConsumerContext,
) -> Optional[float]:
    """prev-steady 基准的 consumer delta(spec §5.2):跳过异常快帧(追赶快帧),
    取最近一个 cd 落在稳态带内的帧作基准。无基准返回 None(判据跳过)。"""
    cur = present_frames[cur_idx].consumer_duration_ms
    if cur is None:
        return None
    for back in range(1, cctx.steady_lookback + 1):
        prev_idx = cur_idx - back
        if prev_idx < 0:
            break
        pcd = present_frames[prev_idx].consumer_duration_ms
        if pcd is not None and cctx.steady_lo <= pcd <= cctx.steady_hi:
            return cur - pcd
    return None


def _classify_jank_cause(
    gf: "GameFrame",
    present_frames: List["GameFrame"],
    cur_idx: int,
    flush_threshold_ms: Optional[float],
    rs_period_ms: Optional[float],
    tol_ms: float,
    consumer_ctx: Optional[ConsumerContext] = None,
) -> str:
    """丢帧根因分类（spec §3.5 / §5.2）。

    Returns: 'producer_jank' / 'consumer_jank' / 'phase_drift' / 'unclassified'

    顺序：
      1. stability=False → producer_jank；None → unclassified（额外发现 2）
      2. stability=True 且 consumer_ctx 可用时先判 consumer_jank（spec §5.2）
      3. stability=True 且 rs_period_ms 可用时按 A→B1→B2 顺序匹配相位判据
      4. 判据 A 需 flush_buffer_interval_ms 非 None，避免 ``or 0`` 误判（额外发现 1）
    """
    stability = _check_flush_stability(gf, flush_threshold_ms)

    # 额外发现 2: 必须先证明 stable is True 才进相位判据
    if stability is False:
        return "producer_jank"
    if stability is None:
        return "unclassified"

    if rs_period_ms:
        # spec §3.2: 每帧动态 RS 周期 — 优先用该帧 commit_layers_rate，无则 fallback 全局 rs_period_ms
        frame_rs_period_ms = _frame_rs_period_ms(gf, rs_period_ms)
        # 判据 C(消费者,spec §5.2):双条件 — cd 超稳态上限 且 prev-steady delta 解释超出量
        if consumer_ctx is not None and gf.consumer_duration_ms is not None:
            excess = gf.frame_interval_ms - frame_rs_period_ms
            d_cons = _compute_consumer_delta(present_frames, cur_idx, consumer_ctx)
            if (excess > 0
                    and gf.consumer_duration_ms > consumer_ctx.steady_hi
                    and d_cons is not None
                    and d_cons >= excess - tol_ms):
                return "consumer_jank"
        # 判据 A（主）: 相位残差 = 整数个 RS 周期
        # 额外发现 1: flush_interval 缺失时跳过（避免 or 0 误判）
        if gf.flush_buffer_interval_ms is not None:
            residual = gf.frame_interval_ms - gf.flush_buffer_interval_ms
            if _matches_rs_period(residual, frame_rs_period_ms, tol_ms):
                return "phase_drift"

        # 判据 B1（帧内自证）: acquire_delay 本身即 k×rs_period
        if gf.acquire_delay_ms is not None:
            if _matches_rs_period(gf.acquire_delay_ms, frame_rs_period_ms, tol_ms):
                return "phase_drift"

        # 判据 B2（跳变回溯）: delay 跳变 = 整数个 RS 周期
        if gf.acquire_delay_ms is not None:
            delay_jump = _compute_delay_jump_with_lookback(
                gf, present_frames, cur_idx, max_lookback=3,
            )
            if delay_jump is not None and _matches_rs_period(
                delay_jump, frame_rs_period_ms, tol_ms
            ):
                return "phase_drift"

    return "unclassified"


def _detect_realignment(
    present_frames: List["GameFrame"], idx: int, cctx: ConsumerContext,
) -> bool:
    """追赶重对齐(spec §5.3):本帧 cd 在稳态带内、前一帧为异常追赶快帧。

    producer_jank 帧自身即根因,跳过(避免双重标注)。
    """
    gf = present_frames[idx]
    if gf.jank_class == "producer_jank" or gf.consumer_duration_ms is None:
        return False
    if not (cctx.steady_lo <= gf.consumer_duration_ms <= cctx.steady_hi):
        return False
    if idx <= 0:
        return False
    prev_cd = present_frames[idx - 1].consumer_duration_ms
    return prev_cd is not None and prev_cd < cctx.steady_lo


def _build_realign_hint(
    pf: "GameFrame",
    present_frames: List["GameFrame"],
    idx: int,
    cctx: ConsumerContext,
    jank_history: List[Dict[str, Any]],
    rs_period_ms: float,
    tol_ms: float,
) -> Tuple[str, str, Optional["GameFrame"]]:
    """三分支根因归因(spec §5.3)。返回 (branch, hint, upstream_frame)。

    Args:
        pf: 当前 realign 帧。
        present_frames: 当前窗口全部 present 帧。保留以提供帧上下文,
            但本实现通过 jank_history 回溯,未直接扫描 present_frames。
        idx: pf 在 present_frames 中的下标。保留以统一接口,供后续扩展使用。
        cctx: 消费者稳态上下文。
        jank_history: 已解析的丢帧 / realign 历史,链式继承信息来源。
        rs_period_ms: RS 周期(ms)。
        tol_ms: 周期匹配容差(ms)。

    分支 A:回溯 ≤ upstream_lookback 帧(present_id 差),取最近 producer_jank;
            若先遇到分支 A 的 realign 帧则链式继承其根因(覆盖连锁簇)。
    分支 B:无上游,某一级流水 > period + tol → 指向该级。
    分支 C:各级均正常 → 送显栅格相位重对齐,非病态。
    """
    upstream: Optional["GameFrame"] = None
    for pr in reversed(jank_history):
        # 链式继承优先:分支 A 的 realign 帧已解析根因,直接继承可覆盖连锁簇,
        # 即使其本身略超 upstream_lookback(根因帧在更远处时仍有效)。
        # 此顺序为有意设计:必须先命中已解析的链式 realign 簇,再检查 lookback
        # 距离,不可调换。测试 test_branch_a_chain_inheritance 覆盖该行为。
        if pr.get("branch") == "A" and pr.get("upstream") is not None:
            upstream = pr["upstream"]
            break
        if pf.present_id - pr["present_id"] > cctx.upstream_lookback:
            break
        if pr["jank_class"] == "producer_jank":
            upstream = pr["gf"]
            break

    if upstream is not None:
        ts = upstream.flush_buffer_ms or 0.0
        return "A", (f"本帧滑移系前序生产者(PresentFence{upstream.present_id})"
                     f"卡顿后的追赶重对齐,根因在上游生产者(ts={ts:.3f})断供"), upstream

    stage_over = [(name, v) for name, v in (
        ("渲染级", pf.stage_render_ms), ("提交级", pf.stage_commit_ms),
        ("送显级", pf.stage_present_ms))
        if v is not None and v > rs_period_ms + tol_ms]
    if stage_over:
        name, v = stage_over[0]
        return "B", (f"本帧滑移系追赶重对齐;前序无生产者断供,"
                     f"{name}耗时({v:.1f}ms)超帧周期({rs_period_ms:.3f}ms),疑似该级瓶颈"), None

    def _fmt(v): return f"{v:.1f}" if v is not None else "NA"
    return "C", (f"本帧滑移系追赶重对齐,RS 各级流水耗时正常"
                 f"(渲染{_fmt(pf.stage_render_ms)}/提交{_fmt(pf.stage_commit_ms)}/"
                 f"送显{_fmt(pf.stage_present_ms)} ms),系送显栅格(120Hz)相位重对齐,非病态"), None


def _bottleneck_stage(
    gf: "GameFrame", stage_p50s: Dict[str, float], tol_ms: float,
) -> Optional[str]:
    """相对分级稳态基线超出最多(ratio≥2 且绝对超出≥tol)的级名(spec §5.4)。

    禁止用超帧周期绝对阈值:真阳性帧渲染级 17.97ms < period+tol,但是该级 P50 的 5 倍。
    """
    best, best_ratio = None, 2.0
    for key, val in (("render", gf.stage_render_ms),
                     ("commit", gf.stage_commit_ms),
                     ("present", gf.stage_present_ms)):
        p50 = stage_p50s.get(key)
        if val is None or not p50 or p50 <= 0:
            continue
        if val - p50 < tol_ms:
            continue
        ratio = val / p50
        if ratio >= best_ratio:
            best, best_ratio = key, ratio
    return best


def _compute_stage_p50s(present_frames: List["GameFrame"]) -> Dict[str, float]:
    """三级流水各自 P50(spec §5.4 分级稳态基线)。"""
    import statistics
    out: Dict[str, float] = {}
    for key, attr in (("render", "stage_render_ms"),
                      ("commit", "stage_commit_ms"),
                      ("present", "stage_present_ms")):
        vals = sorted(getattr(f, attr) for f in present_frames
                      if getattr(f, attr) is not None)
        if vals:
            out[key] = statistics.median(vals)
    return out


def _identify_game_queue_id(df: pd.DataFrame) -> Tuple[Optional[str], Optional[str]]:
    """从 FlushBuffer/AcquireBuffer/ReleaseBuffer 事件提取非系统图层的 queueId。

    通用算法（不依赖 SurfaceView 关键字或包名白名单）：
    1. 从所有含 `name:...queueId:` 的事件提取 (layer_name, queueId)
    2. 排除系统图层：ScreenNode, RCDTopSurfaceNode, RCDBottomSurfaceNode
    3. 剩余图层中取出现次数最多的 = 游戏图层

    兼容：
    - miHoYo: ShellAssistantAnco_..._SurfaceView[com.miHoYo.hkrpg/...]#11_9Surface
    - League: UnityPlayerSurface

    性能优化（规则 32）: 用 str.contains + str.extractall 向量化替代 iterrows，
    实测 3146 行: 284ms → ~30ms (-90%)。

    Returns:
        (queue_id, layer_name)，找不到非系统图层时返回 (None, None)
    """
    if df.empty:
        _log.info("no_game_layer_found")
        return None, None

    # 向量化筛选含 FlushBuffer/AcquireBuffer/ReleaseBuffer 的事件
    name_series = df["name"].astype(str)
    buf_mask = name_series.str.contains(
        "FlushBuffer|AcquireBuffer|ReleaseBuffer", na=False, regex=True
    )
    if not buf_mask.any():
        _log.info("no_game_layer_found")
        return None, None

    buf_names = name_series[buf_mask]

    # 向量化提取 name:...queueId: 模式
    # extractall 一次匹配所有行，返回 MultiIndex (row_id, match_id) + 列
    extracted = buf_names.str.extractall(
        r"name:\s*(?P<lname>.*?)\s+queueId:\s*(?P<qid>\d+)"
    )
    if extracted.empty:
        _log.info("no_game_layer_found")
        return None, None

    lnames = extracted["lname"].str.strip()
    qids = extracted["qid"]

    # 系统图层黑名单过滤
    sys_mask = lnames.str.startswith("ScreenNode") | lnames.str.startswith("RCD")
    lnames = lnames[~sys_mask]
    qids = qids[~sys_mask]
    if lnames.empty:
        _log.info("no_game_layer_found")
        return None, None

    # 按图层名分组计数，取出现次数最多的
    layer_counts = lnames.value_counts().to_dict()
    game_layer = max(layer_counts, key=layer_counts.get)
    # 取该图层最后一次出现的 queueId（value_counts 不保留顺序，需从原索引取）
    game_layer_mask = lnames == game_layer
    game_qid = str(qids[game_layer_mask].iloc[-1])

    _log.info(
        "identified_game_layer",
        layer=game_layer,
        queue_id=game_qid,
        count=layer_counts[game_layer],
        total_candidates=len(layer_counts),
    )
    return game_qid, game_layer


def _parse_events(df: pd.DataFrame, game_queue_id: str) -> Dict[str, List]:
    """从 DataFrame 解析游戏渲染事件。

    Returns:
        {
            'send_vsync': [(ts, now), ...],
            'flush_buffers': [(ts, sequence, name, callid, queue_id), ...],
            'acquire_buffers': {sequence: [ts, ...]},  # 环形复用下同 sequence 多次 acquire，按 ts 升序
            'commit_layers': [(ts, dur, rate, now, vsync_id, name), ...],
            'present_fence_index': [(ts, dur, index), ...],
            'wait_present_fence': [(ts, dur, fence_id), ...],
            'present_fence_events': [(ts, dur, screen_id, fence_id, row_id), ...],
            'recv_vsync': [(ts, now, expected_end, vsync_id, dur, name, row_id), ...],
        }

    性能优化（规则 19/32）:
        - 主循环改用 numpy 数组 + Python zip 迭代，避免 pandas iterrows 的 Series 装箱开销
        - acquire_buffers 关联改用 bisect_right + 预提取 ts 数组，从 O(N×M) 降到 O(N×logM)
    """
    send_vsync: List[Tuple[int, int]] = []
    flush_buffers: List[Tuple[int, str, str, int, str]] = []  # [(ts, sequence, name, callid, queue_id), ...]
    acquire_buf_raw: List[Tuple[int, str, str]] = []  # (ts, queueId, name)
    acquire_sequences: List[Tuple[int, str]] = []  # (ts, sequence)
    commit_layers: List[Tuple[int, int, int, int, int, str]] = []
    present_fence_index: List[Tuple[int, int, int]] = []  # (ts, dur, index)
    wait_present_fence: List[Tuple[int, int, int]] = []
    present_fence_events: List[Tuple[int, int, int, int, int]] = []  # (ts, dur, screen_id, fence_id, row_id)
    recv_vsync: List[Tuple[int, int, int, int, int, str, int]] = []  # (ts, now, expected_end, vsync_id, dur, name, row_id)

    # 预提取为 Python 原生类型数组（避免 pandas Series 装箱开销，规则 32）
    ts_arr = df["ts"].astype("int64").to_numpy()
    dur_arr = df["dur"].fillna(0).astype("int64").to_numpy()
    name_arr = df["name"].astype(str).to_numpy()
    callid_arr = df["callid"].astype("int64").to_numpy() if "callid" in df.columns else None
    id_arr = df["id"].astype("int64").to_numpy() if "id" in df.columns else None

    for i in range(len(ts_arr)):
        ts = int(ts_arr[i])
        dur = int(dur_arr[i])
        name = str(name_arr[i])

        # SendVsyncTo conn: rs
        m = SEND_VSYNC_RE.search(name)
        if m and m.group(1) == "rs":
            send_vsync.append((ts, int(m.group(2))))
            continue

        # FlushBuffer (仅游戏 queueId)
        m = FLUSH_BUFFER_RE.search(name)
        if m and m.group("queueId") == game_queue_id:
            callid_val = int(callid_arr[i]) if callid_arr is not None else 0
            flush_buffers.append((ts, m.group("sequence"), name, callid_val, m.group("queueId")))
            continue

        # DoFlushBuffer
        m = DO_FLUSH_RE.search(name)
        if m and m.group("queueId") == game_queue_id:
            continue  # DoFlushBuffer 不消费（do_flush 列表已移除，调用方未使用）

        # AcquireBuffer
        m = ACQUIRE_BUFFER_RE.search(name)
        if m and m.group("queueId") == game_queue_id:
            acquire_buf_raw.append((ts, m.group("queueId"), name))
            continue

        # acquire buffer sequence (AcquireBuffer 子事件)
        m = ACQUIRE_SEQUENCE_RE.search(name)
        if m:
            acquire_sequences.append((ts, m.group("sequence")))
            continue

        # CommitLayers
        m = COMMIT_LAYERS_RE.search(name)
        if m:
            commit_layers.append((
                ts, dur,
                int(m.group("rate")),
                int(m.group("now")),
                int(m.group("vsyncId")),
                name,
            ))
            continue

        # presentFenceIndex
        m = PRESENT_FENCE_INDEX_RE.search(name)
        if m:
            present_fence_index.append((ts, dur, int(m.group("index"))))
            continue

        # H:PresentFence_0 106861（帧锚点，在 CommitLayers 子树里，能通过 parent 链拿 vsyncId）
        m = PRESENT_FENCE_RE.search(name)
        if m:
            screen_id = int(m.group(1))
            fence_id = int(m.group(2))
            row_id = int(id_arr[i]) if id_arr is not None else i
            present_fence_events.append((ts, dur, screen_id, fence_id, row_id))
            continue

        # H:ReceiveVsync name:rs ... vsyncId:N（RS 主线程接收 vsync，用于游戏帧判定）
        m = RECV_VSYNC_RE.search(name)
        if m and m.group("name") == "rs":
            vsync_id = int(m.group("vsyncId"))
            now_m = re.search(r"now:(\d+)", name)
            end_m = re.search(r"expectedEnd:\s*(\d+)", name)
            now_val = int(now_m.group(1)) if now_m else 0
            expected_end = int(end_m.group(1)) if end_m else 0
            row_id = int(id_arr[i]) if id_arr is not None else i
            recv_vsync.append((ts, now_val, expected_end, vsync_id, dur, m.group("name"), row_id))
            continue

        # Waiting for Present Fence（兼容两种格式）
        # 旧: H:Waiting for Present Fence 352
        # 新: H:Waiting for PresentFence_0 106122
        m = WAIT_PRESENT_FENCE_RE.search(name)
        if m:
            wait_present_fence.append((ts, dur, int(m.group("fenceId"))))
            continue
        m = WAIT_PRESENT_FENCE_NEW_RE.search(name)
        if m:
            wait_present_fence.append((ts, dur, int(m.group("fenceId"))))
            continue

    # 将 AcquireBuffer 与 acquire buffer sequence 子事件按时间关联
    # 规则 32 优化：bisect_right + 预提取 ts 数组，O(N×logM) 替代 O(N×M)
    # sequence 环形复用（实测游戏队列仅 5 个 sequence 反复使用），同 sequence 会
    # acquire 多次，必须保留全部 ts 列表（升序），由消费方按 flush_ts 取其后第一次
    # acquire；单槽覆盖会让所有帧拿到 trace 末尾的最后一次 acquire，导致
    # acquire_delay_ms 虚高至秒级。
    acquire_buffers: Dict[str, List[int]] = {}
    if acquire_buf_raw and acquire_sequences:
        seq_ts_only = [s[0] for s in acquire_sequences]  # 预提取 ts 数组
        for aq_ts, _queue_id, aq_name in acquire_buf_raw:
            # 找时间上最近且紧随其后的 acquire buffer sequence 事件
            # bisect_right 定位第一个 > aq_ts 的位置
            idx = bisect_right(seq_ts_only, aq_ts)
            if idx < len(acquire_sequences):
                seq_ts, sequence = acquire_sequences[idx]
                diff = seq_ts - aq_ts
                if 0 < diff < 500_000:  # 500us 内
                    acquire_buffers.setdefault(sequence, []).append(aq_ts)

    return {
        "send_vsync": send_vsync,
        "flush_buffers": flush_buffers,
        "acquire_buffers": acquire_buffers,
        "commit_layers": commit_layers,
        "present_fence_index": present_fence_index,
        "wait_present_fence": wait_present_fence,
        "present_fence_events": present_fence_events,
        "recv_vsync": recv_vsync,
    }


def _build_callstack_index(ctx: PreprocessContext) -> Optional[Dict[str, Any]]:
    """一次全表加载 callstack，内存构建 parent/name 索引。

    所有 parent 链查询都通过此索引进行 O(1) 查找，
    禁止用 N 次递归 CTE（trace1 实测 614 秒）。

    返回:
        {
            "id_to_name": {id: name},
            "parent_of": {id: parent_id},
        }
        sqlite_conn 不可用或表为空时返回 None。

    性能（trace1 实测，642421 行）:
        - TraceDataCache 已预加载 callstack，零 SQL 开销
        - 内存建树: ~0.18s

    注：children_of 字典已移除（下游 _build_game_vsync_set 和
        _get_presentfence_vsyncid_inmem 仅用 parent_of 向上查找，
        从未使用 children_of）。
    """
    cache = ctx.trace_cache
    if cache is not None:
        # TraceDataCache 路径：从 cache.callstack_all() 内存构建索引
        # cache.callstack tuple: (callid, ts, dur, name, depth, parent_id, id, cookie, argsetid)
        all_cs = cache.callstack_all()
        if not all_cs:
            return None
        id_to_name: Dict[int, str] = {}
        parent_of: Dict[int, Optional[int]] = {}
        for itid, rows in all_cs.items():
            for r in rows:
                # r = (callid, ts, dur, name, depth, parent_id, id, cookie, argsetid)
                row_id = r[6]       # id
                name = r[3]         # name
                p_id = r[5]         # parent_id
                id_to_name[row_id] = name or ""
                parent_of[row_id] = p_id
        if not id_to_name:
            return None
        _log.info("callstack_index_built_from_cache", nodes=len(id_to_name))
        return {"id_to_name": id_to_name, "parent_of": parent_of}

    # Fallback：sqlite_conn 路径（测试兼容）
    if ctx.sqlite_conn is None:
        return None

    old_factory = ctx.sqlite_conn.row_factory
    try:
        ctx.sqlite_conn.row_factory = None
        try:
            rows = ctx.sqlite_conn.execute(
                "SELECT id, name, parent_id FROM callstack"
            ).fetchall()
        except Exception as e:
            _log.info("callstack_index_load_failed", error=str(e))
            return None
    finally:
        ctx.sqlite_conn.row_factory = old_factory

    if not rows:
        return None

    id_to_name_fb: Dict[int, str] = {}
    parent_of_fb: Dict[int, Optional[int]] = {}
    for nid, name, pid in rows:
        id_to_name_fb[nid] = name or ""
        parent_of_fb[nid] = pid

    _log.info("callstack_index_built", nodes=len(id_to_name_fb))
    return {"id_to_name": id_to_name_fb, "parent_of": parent_of_fb}


def _build_game_vsync_set(
    index: Dict[str, Any],
    recv_vsync_with_id: List[Tuple[int, int]],
) -> Set[int]:
    """反向标记法：从 AcquireBuffer 向上找 ReceiveVsync，标记为游戏帧。

    不用"对每个 ReceiveVsync 查子树"（正向，需遍历大子树），
    而是"从 AcquireBuffer 反向向上找 ReceiveVsync"（反向，路径短且稳定）。

    性能（trace1 实测）:
        - AcquireBuffer 3414 条，每条向上走 ≤30 层
        - 总耗时: 0.03s

    Args:
        index: _build_callstack_index 返回的索引
        recv_vsync_with_id: RS 主线程 ReceiveVsync 的 (callstack_id, vsync_id) 列表

    Returns:
        游戏帧的 vsyncId 集合
    """
    id_to_name = index["id_to_name"]
    parent_of = index["parent_of"]

    # 预构建 recv_id → vsync_id 映射（O(1) 查找）
    recv_id_to_vsync: Dict[int, int] = {}
    for nid, vsync_id in recv_vsync_with_id:
        recv_id_to_vsync[nid] = vsync_id

    game_vsncs: Set[int] = set()

    # 遍历所有节点，找到 AcquireBuffer 事件，向上找最近的 ReceiveVsync(rs)
    for nid, name in id_to_name.items():
        if "AcquireBuffer" not in name:
            continue
        # 向上找最近的 ReceiveVsync(rs)
        pid = parent_of.get(nid)
        for _ in range(30):  # 最多 30 层（实测深度 5-15）
            if pid is None or pid == _NO_PARENT or pid <= 0:
                break
            if pid in recv_id_to_vsync:
                game_vsncs.add(recv_id_to_vsync[pid])
                break
            pid = parent_of.get(pid)

    _log.info(
        "game_vsncs_identified",
        count=len(game_vsncs),
        total_recv=len(recv_vsync_with_id),
    )
    return game_vsncs


def _get_presentfence_vsyncid_inmem(
    index: Dict[str, Any],
    pf_row_id: int,
) -> Optional[int]:
    """从 H:PresentFence_0 (callstack.id) 向上查 parent 链找 H:CommitLayers vsyncId:N。

    性能（trace1 实测）:
        - 1114 个 PresentFence × 5 层内存字典查询
        - 总耗时: 0.002s（vs N 次 SQL 176 秒）
    """
    parent_of = index["parent_of"]
    id_to_name = index["id_to_name"]

    pid = parent_of.get(pf_row_id)
    for _ in range(5):  # PresentFence_0 → Repaint → CommitLayers（最多 5 层）
        if pid is None or pid == _NO_PARENT or pid <= 0:
            return None
        name = id_to_name.get(pid, "")
        m = re.search(r"vsyncId:\s*(\d+)", name)
        if m:
            return int(m.group(1))
        pid = parent_of.get(pid)
    return None


# ---------------------------------------------------------------------------
# 唤醒链追溯（build_wakeup_chain）已下线：方案 L 重构后 target_pids 完全由
# _collect_static_target_pids 白名单决定，wakeup_chain 不再贡献 pid 也不参与
# priority 排序（改用 cpu_active_ms），保留只会增加 SQL 开销无实际收益。
# ---------------------------------------------------------------------------


def _scan_cpu_bottlenecks(
    ctx: PreprocessContext,
    window_start_ns: int,
    window_end_ns: int,
    target_pids: List[int],
    threshold_ratio: float = 0.30,
) -> List[Dict[str, Any]]:
    """在丢帧区间内通过 thread_state 扫描 Running + Runnable 耗时占比高的线程。

    使用 thread_state 表（state IN ('Running', 'R', 'R+')）而非 sched_slice，
    因为 sched_slice.end_state 仅记录 slice 结束后的状态转换，Running 的 slice
    结束后 end_state='S'，导致 end_state IN ('R','R+') 只查到 Runnable 而漏掉
    所有 Running 时间。返回 intervals 列表供跨源 union。
    """
    if ctx.sqlite_conn is None or not target_pids:
        _log.info("sqlite_conn_unavailable_for_cpu_scan")
        return []

    placeholders = ",".join("?" * len(target_pids))
    sql = f"""
    SELECT ts.ts, ts.dur, ts.itid,
           ts.tid, t.name AS tname,
           p.pid, p.name AS pname
    FROM thread_state ts
    JOIN thread t ON ts.itid = t.itid
    JOIN process p ON t.ipid = p.ipid
    WHERE ts.state IN ('Running', 'R', 'R+')
      AND ts.ts < ?
      AND (ts.ts + COALESCE(ts.dur, 0)) > ?
      AND p.pid IN ({placeholders})
    """

    try:
        rows = ctx.sqlite_conn.execute(
            sql,
            [int(window_end_ns), int(window_start_ns)] + target_pids,
        ).fetchall()
    except Exception as e:
        _log.info("cpu_scan_sql_error", error=str(e))
        return []

    if not rows:
        return []

    # 性能优化(规则 32): 纯 Python dict 分组替代 pandas groupby+iterrows
    # 实测 2269 行: pandas 47ms → 纯 Python 2ms (-96%)
    # pandas 在小数据上开销大(DataFrame 构造 + groupby 索引 + iterrows 装箱)
    total_time_ns = float(window_end_ns - window_start_ns)

    # 按 (pid, itid) 分组，记录 intervals + 元数据
    groups: Dict[Tuple[int, int], List[Tuple[int, int]]] = {}
    group_meta: Dict[Tuple[int, int], Tuple[int, str, str]] = {}
    for r in rows:
        ts = int(r["ts"])
        dur_raw = r["dur"]
        dur = int(dur_raw) if dur_raw is not None else 0
        if dur <= 0:
            continue
        s = max(ts, window_start_ns)
        e = min(ts + dur, window_end_ns)
        if e > s:
            pid = int(r["pid"])
            itid = int(r["itid"])
            key = (pid, itid)
            groups.setdefault(key, []).append((s, e))
            if key not in group_meta:
                group_meta[key] = (
                    int(r["tid"]),
                    str(r["tname"] or ""),
                    str(r["pname"] or "").strip(),
                )

    bottlenecks = []
    for (pid, itid), intervals in groups.items():
        merged = _union_intervals(intervals)
        active_ns = sum(b - a for a, b in merged)
        active_ms = active_ns / 1_000_000.0
        ratio = active_ns / total_time_ns if total_time_ns > 0 else 0

        if ratio <= threshold_ratio:
            continue

        tid, tname, pname = group_meta[(pid, itid)]
        bottlenecks.append({
            "pid": pid,
            "tid": tid,
            "thread_name": tname,
            "process_name": pname,
            "begin_ns": merged[0][0],
            "end_ns": merged[-1][1],
            "active_ms": round(active_ms, 3),
            "intervals": merged,
        })

    return bottlenecks


def _union_intervals(intervals: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
    """区间并集，去掉重叠。"""
    if not intervals:
        return []
    sorted_iv = sorted(intervals)
    merged = [sorted_iv[0]]
    for s, e in sorted_iv[1:]:
        if s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))
    return merged


def _compute_noise_tids(
    ctx: PreprocessContext,
    cs_density_threshold: float = 0.30,
    run_ratio_threshold: float = 0.15,
) -> Set[int]:
    """基于全 trace 预计算噪声线程 itid 集合。

    噪声线程定义：callstack depth=0 活动占比 > cs_density_threshold
    且 thread_state Running 时间占 callstack 时间比例 < run_ratio_threshold。

    这类线程的 callstack slice 是 trace marker（如 H:RecvDynamicLayers）或
    阻塞调用（如 binder reply），其 begin/end 配对跨越线程睡眠时间，
    导致 callstack 看似"全程活跃"但 CPU 几乎不跑。
    用 thread_state Running 作为真实 CPU 活动基准可精准识别。

    需要 thread_state 表存在；缺失时返回空集（graceful fallback）。

    返回 itid 集合，供 _scan_callstack_active 过滤。
    """
    if ctx.sqlite_conn is None and ctx.trace_cache is None:
        return set()

    # 检查 thread_state 表存在
    cache = ctx.trace_cache
    if cache is not None:
        # TraceDataCache 路径：从 cache 数据判断 thread_state 是否可用
        if not cache.thread_state_all():
            return set()
    else:
        try:
            cursor = ctx.sqlite_conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='thread_state' LIMIT 1"
            )
            if cursor.fetchone() is None:
                return set()
        except Exception as e:
            _log.info("noise_tids_thread_state_check_failed", error=str(e))
            return set()

    # 取 trace 时间范围 + 各线程 callstack depth=0 总时长
    # 注意：必须用 callstack MIN/MAX 而非 trace_range 表。trace_range 可能包含
    # 采集前后的空闲时段（实测 fixture 中 trace_range=20050ms 但实际数据仅 3284ms，
    # 5x 偏差），导致 cs_pct 被稀释到阈值以下，噪声线程漏检。
    # cs_total 来自 callstack，比值应在同数据范围内计算。
    trace_start_ns: Optional[int] = None
    trace_end_ns: Optional[int] = None
    cs_by_itid: Dict[int, float] = {}  # itid → cs_total

    if cache is not None:
        # TraceDataCache 路径：从 cache.callstack_all() 内存计算
        # cache.callstack tuple: (callid, ts, dur, name, depth, parent_id, id, cookie, argsetid)
        all_cs = cache.callstack_all()
        for itid, rows in all_cs.items():
            for r in rows:
                if r[4] == 0:  # depth == 0
                    ts_val = r[1]
                    dur_val = r[2] or 0
                    if trace_start_ns is None or ts_val < trace_start_ns:
                        trace_start_ns = ts_val
                    end_val = ts_val + dur_val
                    if trace_end_ns is None or end_val > trace_end_ns:
                        trace_end_ns = end_val
                    cs_by_itid[itid] = cs_by_itid.get(itid, 0.0) + dur_val
        if trace_start_ns is None or trace_end_ns is None:
            # 降级：用 trace_range 表
            if ctx.sqlite_conn is not None:
                try:
                    row = ctx.sqlite_conn.execute(
                        "SELECT start_ts, end_ts FROM trace_range LIMIT 1"
                    ).fetchone()
                    if row and row[0] is not None and row[1] is not None:
                        trace_start_ns, trace_end_ns = int(row[0]), int(row[1])
                except Exception as e:
                    _log.info("noise_tids_trace_range_fallback_failed", error=str(e))
            if trace_start_ns is None or trace_end_ns is None:
                return set()
    else:
        # Fallback：sqlite_conn 路径
        try:
            row = ctx.sqlite_conn.execute(
                "SELECT MIN(ts), MAX(ts) FROM callstack WHERE depth=0"
            ).fetchone()
            if not row or row[0] is None or row[1] is None:
                row = ctx.sqlite_conn.execute(
                    "SELECT start_ts, end_ts FROM trace_range LIMIT 1"
                ).fetchone()
                if not row or row[0] is None or row[1] is None:
                    return set()
            trace_start_ns, trace_end_ns = int(row[0]), int(row[1])
        except Exception as e:
            _log.info("noise_tids_trace_range_failed", error=str(e))
            return set()

        try:
            cs_rows = ctx.sqlite_conn.execute(
                """
                SELECT callid AS itid, SUM(COALESCE(dur, 0)) AS cs_total
                FROM callstack
                WHERE depth = 0
                GROUP BY callid
                """
            ).fetchall()
        except Exception as e:
            _log.info("noise_tids_callstack_query_failed", error=str(e))
            return set()

        if not cs_rows:
            return set()
        cs_by_itid = {int(r[0]): float(r[1] or 0) for r in cs_rows}

    if not cs_by_itid:
        return set()

    trace_dur_ns = trace_end_ns - trace_start_ns
    if trace_dur_ns <= 0:
        return set()

    # 各线程 thread_state Running 总时长
    run_by_itid: Dict[int, float] = {}
    if cache is not None:
        # TraceDataCache 路径：从 cache.thread_state_all() 内存计算
        all_ts = cache.thread_state_all()
        for itid, rows in all_ts.items():
            total = 0.0
            for r in rows:
                # thread_state tuple: (ts, dur, state, cpu, tid, pid, itid, arg_setid)
                if r[2] == 'Running' and r[1]:
                    total += r[1] or 0
            if total > 0:
                run_by_itid[itid] = total
    else:
        # Fallback：sqlite_conn 路径
        try:
            run_rows = ctx.sqlite_conn.execute(
                """
                SELECT itid, SUM(COALESCE(dur, 0)) AS run_total
                FROM thread_state
                WHERE state = 'Running'
                GROUP BY itid
                """
            ).fetchall()
        except Exception as e:
            _log.info("noise_tids_thread_state_query_failed", error=str(e))
            return set()
        run_by_itid = {int(r[0]): float(r[1] or 0) for r in run_rows}

    noise_tids: Set[int] = set()
    for itid, cs_total in cs_by_itid.items():
        if cs_total <= 0:
            continue
        cs_density = cs_total / trace_dur_ns
        if cs_density <= cs_density_threshold:
            continue  # callstack 活动占比不够，不算噪声
        run_total = run_by_itid.get(itid, 0.0)
        run_ratio = run_total / cs_total if cs_total > 0 else 0
        if run_ratio < run_ratio_threshold:
            noise_tids.add(itid)

    # 硬编码噪声线程名补充：callstack 占比低但属于 trace marker 的线程。
    # VSyncGenerator: H:VSyncGenerator 是 VSync 分发标记，begin/end 跨越等待时间，
    # run_ratio 在不同 trace 中波动大(9%~54%)，统计阈值无法稳定覆盖，
    # 但业务上 VSyncGenerator 不是帧渲染瓶颈，需主动剔除。
    # OS_FFRT_*: FFRT (Function Flow Runtime) 工作线程，执行异步数据库/IO 任务，
    # cpu_active=0（跨睡眠 trace marker），与游戏渲染无关，需主动剔除。
    # 用前缀匹配（OS_FFRT_2_125 / OS_FFRT_3_44 等），不是精确名。
    _NOISE_THREAD_NAMES: Set[str] = {"VSyncGenerator"}
    _NOISE_THREAD_PREFIXES: Tuple[str, ...] = ("OS_FFRT_",)
    if cache is not None:
        meta_all = cache.thread_meta_all()
        for itid_val, (tname, _tid, _ipid) in meta_all.items():
            if not tname:
                continue  # thread.name 可为 NULL（实测 trace 触发 NoneType 崩溃）
            if tname in _NOISE_THREAD_NAMES:
                noise_tids.add(itid_val)
            elif any(tname.startswith(p) for p in _NOISE_THREAD_PREFIXES):
                noise_tids.add(itid_val)
    else:
        try:
            for name in _NOISE_THREAD_NAMES:
                rows = ctx.sqlite_conn.execute(
                    "SELECT itid FROM thread WHERE name = ?", (name,)
                ).fetchall()
                for r in rows:
                    noise_tids.add(int(r[0]))
            # FFRT 前缀匹配（SQL LIKE）
            rows = ctx.sqlite_conn.execute(
                "SELECT itid FROM thread WHERE name LIKE 'OS_FFRT_%'"
            ).fetchall()
            for r in rows:
                noise_tids.add(int(r[0]))
        except Exception:
            pass  # thread 表缺失时忽略

    _log.info(
        "noise_tids_computed",
        trace_dur_ms=round(trace_dur_ns / 1_000_000.0, 2),
        cs_candidate_count=sum(1 for cs in cs_by_itid.values() if cs / trace_dur_ns > cs_density_threshold),
        noise_tid_count=len(noise_tids),
        cs_density_threshold=cs_density_threshold,
        run_ratio_threshold=run_ratio_threshold,
    )
    return noise_tids


def _scan_callstack_active(
    ctx: PreprocessContext,
    window_start_ns: int,
    window_end_ns: int,
    target_pids: List[int],
    threshold_ratio: float = 0.30,
    noise_tids: Optional[Set[int]] = None,
) -> List[Dict[str, Any]]:
    """扫描 callstack depth=0 区间，识别窗口内有 trace 活动的线程。

    noise_tids：基于全 trace 预计算的噪声 itid 集合，这些线程的 callstack slice
    多为 trace marker / 阻塞调用，跨越睡眠时间，不反映真实 CPU 活动，需排除。
    """
    if not target_pids:
        _log.info("callstack_active_scan_skipped", reason="no_pids")
        return []

    cache = ctx.trace_cache
    target_pid_set = set(target_pids)

    if cache is not None:
        # TraceDataCache 路径：遍历 cache.callstack_all() + 区间交集
        # cache.callstack tuple: (callid, ts, dur, name, depth, parent_id, id, cookie, argsetid)
        all_cs = cache.callstack_all()
        thread_meta_all = cache.thread_meta_all()
        process_name_all = cache.process_name_all()

        # 批量拿 ipid→pid 映射（process 表未纳入 cache，一次 SQL 查全表）
        ipid_to_pid: Dict[int, int] = {}
        if ctx.sqlite_conn is not None:
            try:
                pid_rows = ctx.sqlite_conn.execute(
                    "SELECT ipid, pid FROM process"
                ).fetchall()
                ipid_to_pid = {int(r[0]): int(r[1]) for r in pid_rows if r[1]}
            except Exception:
                pass

        groups: Dict[Tuple[int, int], List[Tuple[int, int]]] = {}
        group_meta: Dict[Tuple[int, int], Tuple[int, str, str]] = {}

        for itid, _rows_all in all_cs.items():
            if noise_tids and itid in noise_tids:
                continue
            # 区间交集过滤（规则 30）
            intersected = cache.callstack(itid, window_start_ns, window_end_ns)
            if not intersected:
                continue
            meta = thread_meta_all.get(itid)
            if meta is None:
                continue
            tname, tid_val, ipid = meta
            pid = ipid_to_pid.get(ipid, 0)
            if pid not in target_pid_set:
                continue
            pname = process_name_all.get(ipid, "").strip()

            for r in intersected:
                if r[4] != 0:  # depth != 0
                    continue
                ts = r[1]
                dur_raw = r[2]
                dur = int(dur_raw) if dur_raw is not None else 0
                if dur <= 0:
                    continue
                s = max(ts, window_start_ns)
                e = min(ts + dur, window_end_ns)
                if e > s:
                    key = (pid, itid)
                    groups.setdefault(key, []).append((s, e))
                    if key not in group_meta:
                        group_meta[key] = (tid_val, tname or "", pname)

        if not groups:
            return []

        bottlenecks = []
        total_time_ns = float(window_end_ns - window_start_ns)
        for (pid, itid), intervals in groups.items():
            merged = _union_intervals(intervals)
            active_ns = sum(b - a for a, b in merged)
            active_ms = active_ns / 1_000_000.0
            ratio = active_ns / total_time_ns if total_time_ns > 0 else 0

            if ratio <= threshold_ratio:
                continue

            tid_val, tname, pname = group_meta[(pid, itid)]
            bottlenecks.append({
                "pid": pid,
                "tid": tid_val,
                "thread_name": tname,
                "process_name": pname,
                "begin_ns": merged[0][0],
                "end_ns": merged[-1][1],
                "active_ms": round(active_ms, 3),
                "intervals": merged,
            })

        return bottlenecks

    # Fallback：sqlite_conn 路径
    if ctx.sqlite_conn is None:
        _log.info("callstack_active_scan_skipped", reason="no_conn")
        return []

    placeholders = ",".join("?" * len(target_pids))
    sql = f"""
    SELECT c.ts, c.dur, c.callid AS itid, t.tid, t.name AS tname,
           p.pid, p.name AS pname
    FROM callstack c
    JOIN thread t ON c.callid = t.itid
    JOIN process p ON t.ipid = p.ipid
    WHERE c.depth = 0
      AND c.ts < ?
      AND (c.ts + COALESCE(c.dur, 0)) > ?
      AND p.pid IN ({placeholders})
    """

    try:
        rows = ctx.sqlite_conn.execute(
            sql,
            [int(window_end_ns), int(window_start_ns)] + target_pids,
        ).fetchall()
    except Exception as e:
        _log.info("callstack_active_scan_sql_error", error=str(e))
        return []

    if not rows:
        return []

    if noise_tids:
        rows = [r for r in rows if int(r[2]) not in noise_tids]
        if not rows:
            return []

    total_time_ns = float(window_end_ns - window_start_ns)

    groups_fb: Dict[Tuple[int, int], List[Tuple[int, int]]] = {}
    group_meta_fb: Dict[Tuple[int, int], Tuple[int, str, str]] = {}
    for r in rows:
        ts = int(r["ts"])
        dur_raw = r["dur"]
        dur = int(dur_raw) if dur_raw is not None else 0
        if dur <= 0:
            continue
        s = max(ts, window_start_ns)
        e = min(ts + dur, window_end_ns)
        if e > s:
            pid = int(r["pid"])
            itid = int(r["itid"])
            key = (pid, itid)
            groups_fb.setdefault(key, []).append((s, e))
            if key not in group_meta_fb:
                group_meta_fb[key] = (
                    int(r["tid"]),
                    str(r["tname"] or ""),
                    str(r["pname"] or "").strip(),
                )

    bottlenecks_fb = []
    for (pid, itid), intervals in groups_fb.items():
        merged = _union_intervals(intervals)
        active_ns = sum(b - a for a, b in merged)
        active_ms = active_ns / 1_000_000.0
        ratio = active_ns / total_time_ns if total_time_ns > 0 else 0

        if ratio <= threshold_ratio:
            continue

        tid_val, tname, pname = group_meta_fb[(pid, itid)]
        bottlenecks_fb.append({
            "pid": pid,
            "tid": tid_val,
            "thread_name": tname,
            "process_name": pname,
            "begin_ns": merged[0][0],
            "end_ns": merged[-1][1],
            "active_ms": round(active_ms, 3),
            "intervals": merged,
        })

    return bottlenecks_fb


def _merge_bottlenecks(
    cpu_threads: List[Dict[str, Any]],
    callstack_threads: List[Dict[str, Any]],
    window_start_ns: int,
    window_end_ns: int,
) -> List[BottleneckThread]:
    """两路合并：cpu_profile + callstack_active。

    按 (pid, tid) 分组，跨源区间求真 union（去重不重复计算）。
    不再区分 source，两路合并后只看 union active_ms。
    所有 interval 都 clamp 到 [window_start_ns, window_end_ns]。
    """
    grouped: Dict[Tuple[int, int], Dict[str, Any]] = {}

    def _ensure_key(pid: int, tid: int) -> Dict[str, Any]:
        key = (pid, tid)
        if key not in grouped:
            grouped[key] = {
                "intervals": [],
                "cpu_intervals": [],
                "thread_name": "",
                "process_name": "",
            }
        return grouped[key]

    # cpu_profile：intervals 已在 _scan_cpu_bottlenecks 内 clamp 到 window
    # 只累加到 cpu_intervals，用于 cpu_active_ms 排序（真实 CPU 占用）
    for ct in cpu_threads:
        pid = ct.get("pid") or 0
        tid = ct.get("tid") or 0
        if pid == 0 or tid == 0:
            continue
        info = _ensure_key(pid, tid)
        if not info["thread_name"]:
            info["thread_name"] = ct.get("thread_name", "")
        if not info["process_name"]:
            info["process_name"] = ct.get("process_name", "")
        info["intervals"].extend(ct.get("intervals", []))
        info["cpu_intervals"].extend(ct.get("intervals", []))

    # callstack_active：intervals 已在 _scan_callstack_active 内 clamp 到 window
    # callstack_active 含 trace marker 区间，不是真实 CPU 占用，不计入 cpu_active_ms
    for cct in callstack_threads:
        pid = cct.get("pid") or 0
        tid = cct.get("tid") or 0
        if pid == 0 or tid == 0:
            continue
        info = _ensure_key(pid, tid)
        if not info["thread_name"]:
            info["thread_name"] = cct.get("thread_name", "")
        if not info["process_name"]:
            info["process_name"] = cct.get("process_name", "")
        info["intervals"].extend(cct.get("intervals", []))

    # 对每个 (pid, tid) 求区间并集，并从 merged_intervals 取首尾作为 begin/end
    result: List[BottleneckThread] = []
    for (pid, tid), info in grouped.items():
        merged_intervals = _union_intervals(info["intervals"])
        active_ns = sum(b - a for a, b in merged_intervals)
        active_ms = active_ns / 1_000_000.0
        # cpu_active_ms 只累加 cpu_profile 路径，作 priority 排序键
        cpu_merged = _union_intervals(info["cpu_intervals"])
        cpu_active_ns = sum(b - a for a, b in cpu_merged)
        cpu_active_ms = cpu_active_ns / 1_000_000.0
        if merged_intervals:
            begin_ns = merged_intervals[0][0]
            end_ns = merged_intervals[-1][1]
        else:
            begin_ns = 0
            end_ns = 0
        result.append(BottleneckThread(
            pid=pid,
            tid=tid,
            thread_name=info["thread_name"],
            process_name=info["process_name"],
            begin_ms=begin_ns / 1_000_000.0,
            end_ms=end_ns / 1_000_000.0,
            active_ms=active_ms,
            cpu_active_ms=cpu_active_ms,
        ))
    return result


# ---------------------------------------------------------------------------
# TargetPids 白名单预计算（方案 L + v4 (e) 反查 top1）
# ---------------------------------------------------------------------------

# 游戏辅助进程黑名单：game_accelerate / hms.gameservice / i.gameperceptio 等
# 这些进程与游戏相关但不是游戏渲染进程本身，纳入 target_pids 会引入噪声
_GAME_AUXILIARY_PROCESS_KEYWORDS: Set[str] = {
    "game_accelerate",
    "hms.gameservice",
    "gameservice_ser",
    "i.gameperceptio",
    "gameperceptio",
}


def _is_excluded_pname(pname: Optional[str]) -> bool:
    """检查 pname 是否应被排除（render_service / system_server / 游戏辅助进程）。

    Args:
        pname: 进程名；None 表示 native 进程

    Returns:
        True 表示应排除，False 表示保留
    """
    if not pname:
        return False  # native 进程（pname=None）保留
    pname_lower = pname.lower()
    if "render_service" in pname_lower:
        return True
    if "system_server" in pname_lower:
        return True
    for kw in _GAME_AUXILIARY_PROCESS_KEYWORDS:
        if kw in pname_lower:
            return True
    return False


def _preload_pnames(ctx: PreprocessContext, pids: Iterable[int]) -> Dict[int, str]:
    """一次性批量预取多个 pid 的 pname（规则 19: 禁止 N+1 查询）。

    性能（实测 trace1）：N 个 pid 单条 SQL IN(...) 查询 ~5ms，
    替代循环内 N 次 SELECT...WHERE pid=? 的 ~5*N ms。

    Args:
        ctx: PreprocessContext
        pids: 待查询的 pid 集合

    Returns:
        {pid: pname} 字典，查不到的 pid 不在字典中。
        sqlite_conn 不可用或查询失败时返回空字典。
    """
    pid_set = {int(p) for p in pids if p and int(p) > 0}
    if not pid_set or ctx.sqlite_conn is None:
        return {}
    result: Dict[int, str] = {}
    try:
        placeholders = ",".join("?" * len(pid_set))
        rows = ctx.sqlite_conn.execute(
            f"SELECT pid, name FROM process WHERE pid IN ({placeholders})",
            list(pid_set),
        ).fetchall()
        for pid, name in rows:
            result[int(pid)] = name or "(None)"
    except Exception as e:
        _log.info("preload_pnames_failed", error=str(e))
    return result


def _classify_pid(
    pid: int,
    unity_pids: Set[int],
    gpu_pids: Set[int],
    anco_pids: Set[int],
    d_peer_pids: Set[int],
    e_peer_pids: Set[int],
) -> List[str]:
    """分类 pid 属于哪些白名单类别（维测日志用）。"""
    cats: List[str] = []
    if pid in unity_pids:
        cats.append("(a) unity")
    if pid in gpu_pids:
        cats.append("(b) gpu")
    if pid in anco_pids:
        cats.append("(c) anco")
    if pid in d_peer_pids:
        cats.append("(d) flushbuffer_peer")
    if pid in e_peer_pids:
        cats.append("(e) reverse_top1")
    return cats


def _collect_static_target_pids(ctx: PreprocessContext) -> Set[int]:
    """Trace 级预计算五类白名单 pid 集合（方案 L + v4 (e) 反查 top1）。

    在 build_game_render_frames 主算子的丢帧区间循环外调用一次，
    所有丢帧区间共用此结果。

    五类 pid：
      (a) Unity 游戏进程 - Unity 框架线程 pid（UnityMain / UnityGfxDeviceW）
      (b) GPU 进程 - H:Waiting for Acquire Fence callstack 所在 pid
      (c) 容器 Binder - anco_service_br 线程名所在 pid
      (d) FlushBuffer binder 对端 - H:FlushBuffer name 父节点 binder reply 的
          args key=27 对端 pid
      (e) (d) top1 pid 反查对端 - (d) 命中频次最高的对端 pid 内 binder reply 的
          args key=27 反查更深一层的对端 pid（通常反查到游戏进程）

    所有类别都排除 render_service 进程。(e) 额外通过百分比阈值 (>50% total_cnt)
    过滤噪声，并排除 system_server 和游戏辅助进程。

    性能优化（方案 L，vs 朴素 5 个独立 SQL 加速 2x）：
      - 一次扫 callstack（OR 合并 3 个 name 模式），避免重复全表扫
      - Python 侧 dict 内存分类，O(1) 查找 parent_id → argsetid
      - 一次扫 args 查 (d) 对端 pid
      - 复用 Step 1 的 binder_reply_callids 字典做 (e) 反查，避免重新扫 callstack
    """
    if ctx.sqlite_conn is None and ctx.trace_cache is None:
        return set()

    cache = ctx.trace_cache

    # ---- Step 1: 一次扫 callstack，拿所有需要的 marker ----
    # cache.callstack tuple: (callid, ts, dur, name, depth, parent_id, id, cookie, argsetid)
    flush_buffers: List[int] = []  # FlushBuffer 的 parent_id 列表
    acquire_fence_callids: Set[int] = set()
    binder_reply_argsets: Dict[int, int] = {}  # id -> argsetid
    binder_reply_callids: Dict[int, int] = {}  # id -> callid (用于 (e) 反查)

    if cache is not None:
        # TraceDataCache 路径：从 cache.callstack_all() 内存过滤
        all_cs = cache.callstack_all()
        for itid, rows in all_cs.items():
            for r in rows:
                name = r[3] or ""  # callstack.name 可为 NULL，防御 NoneType 崩溃
                if name.startswith('H:FlushBuffer name:'):
                    parent_id = r[5]
                    if parent_id and parent_id > 0:
                        flush_buffers.append(parent_id)
                elif 'Waiting for Acquire Fence' in name:
                    acquire_fence_callids.add(r[0])  # callid = itid
                elif name == 'binder reply':
                    argsetid = r[8]  # argsetid at index 8
                    if argsetid:
                        binder_reply_argsets[r[6]] = argsetid  # r[6] = id
                        binder_reply_callids[r[6]] = r[0]       # callid
    else:
        # Fallback：sqlite_conn 路径
        try:
            rows = ctx.sqlite_conn.execute(
                "SELECT id, name, parent_id, argsetid, callid FROM callstack "
                "WHERE name LIKE 'H:FlushBuffer name:%' "
                "OR name = 'binder reply' "
                "OR name LIKE 'H:Waiting for Acquire Fence%'"
            ).fetchall()
        except Exception as e:
            _log.info("static_pids_callstack_scan_failed", error=str(e))
            return set()

        for nid, name, parent_id, argsetid, callid in rows:
            if name.startswith('H:FlushBuffer name:'):
                # SQL 已用 LIKE 'H:FlushBuffer name:%' 排除 H:NativeWindowFlushBuffer
                if parent_id and parent_id > 0:
                    flush_buffers.append(parent_id)
            elif 'Waiting for Acquire Fence' in name:
                acquire_fence_callids.add(callid)
            elif name == 'binder reply' and argsetid:
                binder_reply_argsets[nid] = argsetid
                binder_reply_callids[nid] = callid

    # (d) FlushBuffer binder 对端 argsetid：parent_id 在 binder_reply_argsets 字典里查
    argsets_d: Set[int] = set()
    for pid in flush_buffers:
        if pid in binder_reply_argsets:
            argsets_d.add(binder_reply_argsets[pid])

    # ---- Step 3: 单独查 (a) Unity 线程 pid + (c) anco_service_br pid ----
    pids: Set[int] = set()
    unity_pids: Set[int] = set()

    try:
        unity_rows = ctx.sqlite_conn.execute(
            "SELECT DISTINCT p.pid FROM thread t "
            "JOIN process p ON t.ipid = p.ipid "
            "WHERE t.name IN ('UnityGfxDeviceW', 'UnityMain') "
            "AND (p.name IS NULL OR p.name NOT LIKE '%render_service%')"
        ).fetchall()
        unity_pids = {int(r[0]) for r in unity_rows if r[0]}
        pids.update(unity_pids)
    except Exception as e:
        _log.info("static_pids_unity_query_failed", error=str(e))

    anco_pids: Set[int] = set()
    try:
        anco_rows = ctx.sqlite_conn.execute(
            "SELECT DISTINCT p.pid FROM thread t "
            "JOIN process p ON t.ipid = p.ipid "
            "WHERE t.name LIKE '%anco_service_br%'"
        ).fetchall()
        anco_pids = {int(r[0]) for r in anco_rows if r[0]}
        pids.update(anco_pids)
    except Exception as e:
        _log.info("static_pids_binder_query_failed", error=str(e))

    # ---- Step 4: (b) GPU 进程 pid 通过 callid IN 查 thread ----
    gpu_pids: Set[int] = set()
    if acquire_fence_callids:
        try:
            placeholders = ",".join("?" * len(acquire_fence_callids))
            gpu_rows = ctx.sqlite_conn.execute(
                f"SELECT DISTINCT p.pid FROM thread t "
                f"JOIN process p ON t.ipid = p.ipid "
                f"WHERE t.itid IN ({placeholders}) "
                f"AND (p.name IS NULL OR p.name NOT LIKE '%render_service%')",
                list(acquire_fence_callids)
            ).fetchall()
            gpu_pids = {int(r[0]) for r in gpu_rows if r[0]}
            pids.update(gpu_pids)
        except Exception as e:
            _log.info("static_pids_gpu_fence_query_failed", error=str(e))

    # ---- Step 5: (d) FlushBuffer binder 对端 + (e) 一次扫 args key=27 ----
    # 规则 31+19 优化：args 表 3.25M 行无索引，IN(3139) 查询和 IN(3315) 查询都是全表扫
    # 实测两次 IN 查询 353ms vs 一次全表扫 key=27 仅 206ms（不用 IN 过滤更快）
    # 策略：一次拿全部 key=27 的 (argset, value)，Python 侧内存分类 d/e
    peer_pid_counts: Dict[int, int] = {}
    deep_peer_counts: Dict[int, int] = {}
    argset_to_values: Dict[int, List[int]] = {}
    if argsets_d:
        try:
            # 一次扫 args key=27，拿全部 (argset, value)
            all_kv_rows = ctx.sqlite_conn.execute(
                "SELECT argset, value FROM args WHERE key = 27"
            ).fetchall()
            for argset, value in all_kv_rows:
                if value and value > 0:
                    argset_to_values.setdefault(int(argset), []).append(int(value))
        except Exception as e:
            _log.info("static_pids_args_key27_scan_failed", error=str(e))

        # 内存分类：argsets_d → peer_pid_counts
        for argset in argsets_d:
            for val in argset_to_values.get(argset, []):
                peer_pid_counts[val] = peer_pid_counts.get(val, 0) + 1

    # 维测：记录 (d) 每个 peer_pid 的详细信息（pid + cnt + pname + 是否保留）
    # 规则 19: 批量预取所有 peer_pid 的 pname，避免循环内 N+1 查询 process 表
    d_pname_cache: Dict[int, str] = _preload_pnames(ctx, peer_pid_counts.keys())
    d_peer_details = [
        {
            "pid": pid,
            "cnt": cnt,
            "pname": d_pname_cache.get(pid, "(unknown)"),
            "kept": (pid not in pids
                     and not _is_excluded_pname(d_pname_cache.get(pid))),
        }
        for pid, cnt in sorted(peer_pid_counts.items(), key=lambda x: -x[1])
    ]
    _log.info("d_peer_pid_details", details=d_peer_details)

    # 过滤 (d) 对端 pid：排除 render_service / system_server / 游戏辅助进程
    d_peer_pids_filtered: Set[int] = set()
    for pid in peer_pid_counts:
        if pid in pids:
            continue
        pname = d_pname_cache.get(pid)
        if not _is_excluded_pname(pname):
            d_peer_pids_filtered.add(pid)
    pids.update(d_peer_pids_filtered)

    # ---- Step 6: (e) (d) top1 pid 反查对端 - 复用 Step 1 字典优化版 ----
    # 策略：反查 (d) top1 pid 的 binder reply，按百分比阈值 >50% 总 cnt 过滤
    e_peer_pids: Set[int] = set()
    e_reverse_info: Dict[str, Any] = {}
    if peer_pid_counts:
        top1_pid = max(peer_pid_counts, key=peer_pid_counts.get)
        e_reverse_info["top1_pid"] = top1_pid
        e_reverse_info["top1_cnt"] = peer_pid_counts[top1_pid]
        # top1_pname 在下面批量预取后填入
        try:
            # Step 6a: 查 top1_pid 进程的所有 itid
            itid_rows = ctx.sqlite_conn.execute(
                "SELECT t.itid FROM thread t "
                "JOIN process p ON t.ipid = p.ipid "
                "WHERE p.pid = ?",
                (top1_pid,)
            ).fetchall()
            top1_itids = {int(r[0]) for r in itid_rows if r[0]}
            e_reverse_info["top1_itid_count"] = len(top1_itids)

            # Step 6b: 内存过滤 - 从 binder_reply_argsets 里挑 callid in top1_itids
            # 复用 Step 1 已经扫到的 binder_reply 字典，避免重新扫 callstack
            argsets_e: Set[int] = set()
            for nid, argsetid in binder_reply_argsets.items():
                if binder_reply_callids.get(nid) in top1_itids:
                    argsets_e.add(argsetid)
            e_reverse_info["argsets_e_count"] = len(argsets_e)

            # Step 6c: 内存合并 d + e 的 peer_pid_counts → deep_peer_counts
            # 规则 31+19 优化：Step 5 已一次扫 args key=27 拿到 argset_to_values，
            # 这里直接内存累加 argsets_e 部分，避免再次全表扫 args（省 ~180ms）
            deep_peer_counts = peer_pid_counts.copy()
            for argset in argsets_e:
                for val in argset_to_values.get(argset, []):
                    deep_peer_counts[val] = deep_peer_counts.get(val, 0) + 1

            # Step 6d: 百分比阈值过滤 - cnt > total_cnt * pct_threshold
            # 阈值通过 ctx.params 暴露为可配置参数（默认 0.5 = 50%）
            pct_threshold = float(ctx.params.get("e_reverse_pct_threshold", 0.5))
            total_cnt = sum(deep_peer_counts.values())
            threshold = total_cnt * pct_threshold

            # 规则 19: 批量预取 deep_peer + top1_pid 的 pname，避免循环内 N+1 查询
            e_pname_cache: Dict[int, str] = _preload_pnames(
                ctx, set(deep_peer_counts.keys()) | {top1_pid}
            )
            # 回填 top1_pname（上方 Step 6 开头已占位）
            e_reverse_info["top1_pname"] = e_pname_cache.get(top1_pid, "(unknown)")

            e_reverse_info["deep_peer_details"] = [
                {
                    "pid": deep_pid,
                    "cnt": cnt,
                    "pct": round(cnt / total_cnt * 100, 1) if total_cnt > 0 else 0,
                    "pname": e_pname_cache.get(deep_pid, "(unknown)"),
                    "kept": (cnt > threshold
                             and deep_pid > 0
                             and deep_pid not in pids
                             and not _is_excluded_pname(e_pname_cache.get(deep_pid))),
                }
                for deep_pid, cnt in sorted(deep_peer_counts.items(),
                                              key=lambda x: -x[1])
            ]
            e_reverse_info["total_cnt"] = total_cnt
            e_reverse_info["pct_threshold"] = pct_threshold
            e_reverse_info["threshold"] = threshold

            for deep_pid, cnt in deep_peer_counts.items():
                if cnt <= threshold or deep_pid <= 0 or deep_pid in pids:
                    continue
                pname = e_pname_cache.get(deep_pid)
                if not _is_excluded_pname(pname):
                    pids.add(deep_pid)
                    e_peer_pids.add(deep_pid)
        except Exception as e:
            _log.info("static_pids_e_reverse_query_failed", error=str(e))
            e_reverse_info["error"] = str(e)

    # 规则 19: 批量预取所有最终 pids 的 pname，避免日志循环内 N+1 查询
    final_pname_cache: Dict[int, str] = _preload_pnames(ctx, pids)
    _log.info(
        "static_target_pids_collected",
        total=len(pids),
        pids=sorted(pids),
        pid_details=[
            {"pid": pid, "pname": final_pname_cache.get(pid, "(unknown)"),
             "categories": _classify_pid(
                 pid, unity_pids, gpu_pids, anco_pids,
                 d_peer_pids_filtered, e_peer_pids
             )}
            for pid in sorted(pids)
        ],
        categories_breakdown={
            "(a) unity": sorted(unity_pids),
            "(b) gpu_acq_fence": sorted(gpu_pids),
            "(c) anco_service_br": sorted(anco_pids),
            "(d) flushbuffer_binder_peer": sorted(d_peer_pids_filtered),
            "(e) reverse_top1_peer": sorted(e_peer_pids),
        },
        flushbuffer_count=len(flush_buffers),
        binder_reply_count=len(binder_reply_argsets),
        acquire_fence_count=len(acquire_fence_callids),
        argsets_d_count=len(argsets_d),
        d_peer_pid_counts=peer_pid_counts,
        e_reverse_info=e_reverse_info,
    )
    return pids


# ---------------------------------------------------------------------------
# 主算子
# ---------------------------------------------------------------------------


@register_operator("build_game_render_frames")
def build_game_render_frames(ctx: PreprocessContext) -> PreprocessContext:
    """构建游戏渲染帧链路主算子。

    输入:
        ctx.data: dict {"callstack": DataFrame, "instant": DataFrame}
            callstack 含列 ts / dur / name / callid
            instant 含列 ts / ref / wakeup_from

    输出:
        ctx.data: {"summary": {...}, "frames": [...]}
    """
    data = ctx.data
    if isinstance(data, dict):
        df_callstack = data.get("callstack", data.get("data", pd.DataFrame()))
    elif isinstance(data, pd.DataFrame):
        df_callstack = data
    else:
        raise PreprocessError(
            f"build_game_render_frames: ctx.data 应为 DataFrame，实际为 {type(data)}"
        )

    if not isinstance(df_callstack, pd.DataFrame):
        df_callstack = pd.DataFrame(df_callstack)

    # 主算子只做 callstack 解析；thread_state / instant 表通过 sqlite_conn 在子函数内按需查询

    if df_callstack.empty:
        ctx.data = {
            "summary": {
                "total_frames": 0,
                "total_jank_frames": 0,
                "jank_rate": 0.0,
                "avg_frame_interval_ms": 0.0,
                "max_frame_interval_ms": 0.0,
                "app_name": "",
                "jank_class_breakdown": {
                    "producer_jank": 0,
                    "phase_drift": 0,
                    "unclassified": 0,
                    "consumer_jank": 0,
                },
                "jank_intervals": [],
            },
            "frames": [],
        }
        return ctx

    # ---- step 1: 自动识别游戏 Surface 的 queueId 和包名 ----
    game_queue_id, game_layer_name = _identify_game_queue_id(df_callstack)
    # 从 layer_name 提取 app_pkg（兼容 miHoYo SurfaceView 格式；League UnityPlayerSurface 无包名 → None）
    app_pkg = None
    if game_layer_name:
        m_pkg = re.search(r"SurfaceView\[([^/\]]+/[^\]]+)\]", game_layer_name)
        if m_pkg:
            app_pkg = m_pkg.group(1)
    if game_queue_id is None:
        raise PreprocessError("无法识别游戏 Surface queueId：未找到 SurfaceView layer")

    # ---- step 2: 解析事件 ----
    events = _parse_events(df_callstack, game_queue_id)
    send_vsync = sorted(events["send_vsync"], key=lambda x: x[0])
    flush_buffers: List = sorted(events["flush_buffers"], key=lambda x: x[0])
    acquire_buffers: dict = events["acquire_buffers"]
    commit_layers: List = sorted(events["commit_layers"], key=lambda x: x[0])
    wait_present_fence: List = sorted(events["wait_present_fence"], key=lambda x: x[0])
    present_fence_index: List = sorted(events["present_fence_index"], key=lambda x: x[0])

    _log.info(
        "events_parsed",
        send_vsync=len(send_vsync),
        flush_buffers=len(flush_buffers),
        acquire_buffers=len(acquire_buffers),
        commit_layers=len(commit_layers),
        wait_present_fence=len(wait_present_fence),
        present_fence_index=len(present_fence_index),
        game_queue_id=game_queue_id,
    )

    # ---- step 2.5: 游戏帧过滤（通过 PresentFence → CommitLayers → ReceiveVsync → AcquireBuffer ID 关联链）----
    # 帧锚点从 H:Waiting for PresentFence_0 切换为 H:PresentFence_0（在 CommitLayers 子树里）
    # 通过 parent 链取 vsyncId，用 game_vsncs 过滤系统帧（无 AcquireBuffer 的 RS 帧）
    # 降级：sqlite_conn 不可用 / callstack 无 id 列 / game_vsncs 为空 → 回退到原有 wait_present_fence 锚点
    present_fence_events = sorted(events["present_fence_events"], key=lambda x: x[0])
    recv_vsync_events = events["recv_vsync"]

    callstack_index = _build_callstack_index(ctx)
    use_layer_filter = (
        callstack_index is not None
        and present_fence_events
        and recv_vsync_events
    )

    game_vsncs: Set[int] = set()
    if use_layer_filter:
        # 构建 recv_vsync_with_id: [(callstack_id, vsync_id), ...]
        recv_vsync_with_id = [(r[6], r[3]) for r in recv_vsync_events]
        game_vsncs = _build_game_vsync_set(callstack_index, recv_vsync_with_id)
        if not game_vsncs:
            # game_vsncs 为空 = 无法判定游戏帧（可能 trace 缺 AcquireBuffer）
            # 回退到原有逻辑，不比现状更差
            _log.warning("game_vsncs_empty_fallback_to_original_anchor")
            use_layer_filter = False

    if use_layer_filter:
        _log.info(
            "layer_filter_enabled",
            present_fence_events=len(present_fence_events),
            game_vsncs=len(game_vsncs),
            total_recv_vsync=len(recv_vsync_events),
        )

    # 帧锚点选择：
    # - 启用图层过滤时：用 H:PresentFence_0（在 CommitLayers 子树，能通过 parent 链拿 vsyncId）
    # - 降级时：用 H:Waiting for PresentFence_0（原有逻辑，不过滤游戏帧）
    # - 最终 fallback：presentFenceIndex（OpenHarmony ftrace 旧格式）
    frame_anchors_pf: List[Tuple[int, int, int, int, int]] = []  # 仅 use_layer_filter=True 时填充
    if use_layer_filter:
        # 新帧锚点：H:PresentFence_0 事件，元组 (ts, dur, screen_id, fence_id, row_id)
        # present_fence_end_ms 通过 fence_id 关联到 H:Waiting for PresentFence_0 的 end
        wait_pf_end_by_fence: Dict[int, float] = {}
        for wts, wdur, wfid in wait_present_fence:
            wait_pf_end_by_fence[wfid] = (wts + wdur) / 1_000_000.0

        frame_anchors_pf = present_fence_events  # (ts, dur, screen_id, fence_id, row_id)
        frame_anchors: List[Tuple[int, int, int]] = wait_present_fence if wait_present_fence else present_fence_index
    else:
        wait_pf_end_by_fence: Dict[int, float] = {}
        frame_anchors: List[Tuple[int, int, int]] = wait_present_fence if wait_present_fence else present_fence_index

    # 提前返回检查：use_layer_filter 时实际迭代目标是 frame_anchors_pf，而非 frame_anchors
    if not send_vsync or not (frame_anchors_pf if use_layer_filter else frame_anchors):
        ctx.data = {
            "summary": {
                "total_frames": 0,
                "total_jank_frames": 0,
                "jank_rate": 0.0,
                "avg_frame_interval_ms": 0.0,
                "max_frame_interval_ms": 0.0,
                "app_name": _resolve_app_name((app_pkg or "").split("/")[0] if app_pkg else None),
                "jank_class_breakdown": {
                    "producer_jank": 0,
                    "phase_drift": 0,
                    "unclassified": 0,
                    "consumer_jank": 0,
                },
                "jank_intervals": [],
            },
            "frames": [],
        }
        return ctx

    # ---- step 2.6: vsyncId → [(queue_id, sequence)] 映射（spec §3.4）----
    # 用于 step 3 的消耗式匹配（_match_flush_buffers_to_frames）。
    # flush_buffers 不再建 dict（环形复用会覆盖），直接传 list 给消耗式匹配。
    vsync_to_seqs: Dict[int, List[Tuple[str, str]]] = {}
    if use_layer_filter and callstack_index is not None:
        vsync_to_seqs = _build_vsync_consumed_seqs(callstack_index, recv_vsync_with_id)

    # ---- step 3: 以帧锚点关联前序事件 ----
    # 启用图层过滤时用 H:PresentFence_0 锚点（CommitLayers 子树），否则用原有锚点
    frames: List[GameFrame] = []
    flush_idx = 0
    commit_idx = 0

    if use_layer_filter:
        # 新逻辑：H:PresentFence_0 锚点 + 游戏帧过滤
        # 先构建 frames 列表（不含 flush_buffer_ms），循环结束后用 _match_flush_buffers_to_frames
        # 批量消耗式匹配（spec §3.4 修正：环形复用 sequence 一对一消耗）
        for pf_ts, _pf_dur, _screen_id, fence_id, pf_row_id in frame_anchors_pf:
            # 1. 内存 parent 链拿 vsyncId（PresentFence → Repaint → CommitLayers）
            vsync_id_from_pf = _get_presentfence_vsyncid_inmem(callstack_index, pf_row_id)
            if vsync_id_from_pf is None:
                continue  # 无法关联 CommitLayers，跳过

            # 2. 游戏帧过滤：vsyncId 必须在 game_vsncs 中（子树含 AcquireBuffer）
            if vsync_id_from_pf not in game_vsncs:
                continue  # 系统帧，跳过

            # 3. 上屏完成时间（用户体验）：通过 fence_id 关联 H:Waiting for PresentFence_0 的 end
            present_fence_end_ms = wait_pf_end_by_fence.get(fence_id)
            if present_fence_end_ms is None:
                continue  # 无上屏等待事件，帧未真正上屏，跳过

            # 4. 关联 CommitLayers（贪心扫，按 ts）
            frame_commit_ms = None
            frame_commit_rate: Optional[int] = None
            frame_vsync_id = vsync_id_from_pf  # 优先用 parent 链拿到的 vsyncId
            while commit_idx < len(commit_layers) and commit_layers[commit_idx][0] < pf_ts:
                frame_commit_ms = commit_layers[commit_idx][0] / 1_000_000.0
                frame_commit_rate = commit_layers[commit_idx][2] if len(commit_layers[commit_idx]) > 2 else None
                commit_idx += 1
            if frame_commit_ms is None and commit_idx > 0:
                frame_commit_ms = commit_layers[commit_idx - 1][0] / 1_000_000.0
                frame_commit_rate = commit_layers[commit_idx - 1][2] if len(commit_layers[commit_idx - 1]) > 2 else None

            gf = GameFrame(
                vsync_id=frame_vsync_id,
                present_id=fence_id,
                present_fence_end_ms=present_fence_end_ms,
                commit_layers_ms=frame_commit_ms,
                commit_layers_rate=frame_commit_rate,
                present_fence_ms=pf_ts / 1_000_000.0,
                display=True,
            )
            frames.append(gf)

        # FlushBuffer 关联：消耗式匹配（spec §3.4 修正）
        # 替代 _pick_best_sequence + fallback 贪心扫，解决 sequence 环形复用导致的 dict 覆盖 bug
        _match_flush_buffers_to_frames(frames, flush_buffers, vsync_to_seqs)
    else:
        # 原有逻辑（降级）：H:Waiting for PresentFence_0 / presentFenceIndex 锚点
        for pf_ts, pf_dur, fence_id in frame_anchors:
            pf_end = pf_ts + pf_dur

            # 找前一个 FlushBuffer（按时间先后，每个 PF 对应一个放行）
            frame_flush_ms = None
            while flush_idx < len(flush_buffers) and flush_buffers[flush_idx][0] < pf_ts:
                frame_flush_ms = flush_buffers[flush_idx][0] / 1_000_000.0
                flush_idx += 1
            if frame_flush_ms is None and flush_idx > 0:
                frame_flush_ms = flush_buffers[flush_idx - 1][0] / 1_000_000.0

            # 找前一个 CommitLayers
            frame_commit_ms = None
            frame_commit_rate: Optional[int] = None
            frame_vsync_id = None
            while commit_idx < len(commit_layers) and commit_layers[commit_idx][0] < pf_ts:
                frame_commit_ms = commit_layers[commit_idx][0] / 1_000_000.0
                frame_commit_rate = commit_layers[commit_idx][2] if len(commit_layers[commit_idx]) > 2 else None
                frame_vsync_id = commit_layers[commit_idx][4]
                commit_idx += 1
            if frame_commit_ms is None and commit_idx > 0:
                frame_commit_ms = commit_layers[commit_idx - 1][0] / 1_000_000.0
                frame_commit_rate = commit_layers[commit_idx - 1][2] if len(commit_layers[commit_idx - 1]) > 2 else None
                frame_vsync_id = commit_layers[commit_idx - 1][4]

            gf = GameFrame(
                vsync_id=frame_vsync_id,
                present_id=fence_id,
                present_fence_end_ms=pf_end / 1_000_000.0,
                flush_buffer_ms=frame_flush_ms,
                commit_layers_ms=frame_commit_ms,
                commit_layers_rate=frame_commit_rate,
                present_fence_ms=pf_ts / 1_000_000.0,
                display=True,
            )
            frames.append(gf)

    # ---- step 4: 计算帧间隔 ----
    for i, gf in enumerate(frames):
        if gf.present_fence_end_ms is not None and i > 0:
            prev = frames[i - 1]
            if prev.present_fence_end_ms is not None:
                gf.frame_interval_ms = gf.present_fence_end_ms - prev.present_fence_end_ms

        if gf.flush_buffer_ms is not None and i > 0:
            prev = frames[i - 1]
            if prev.flush_buffer_ms is not None:
                gf.flush_buffer_interval_ms = gf.flush_buffer_ms - prev.flush_buffer_ms

    # ---- step 4.5: acquire_delay 后处理（spec §3.4）----
    # sequence 环形复用：取 flush_ts 之后第一次 acquire（bisect_left 于升序 ts 列表），
    # 即消费本次 flush 的那个 RS acquire；旧实现单槽覆盖拿到全局最后一次 acquire，
    # 导致 acquire_delay_ms 虚高至秒级。
    for gf in frames:
        if gf.flush_sequence and gf.flush_sequence in acquire_buffers:
            if gf.flush_buffer_ms is not None:
                flush_ts_ns = int(gf.flush_buffer_ms * _NS_PER_MS)
                acq_ts_list = acquire_buffers[gf.flush_sequence]
                acq_idx = bisect_left(acq_ts_list, flush_ts_ns)
                if acq_idx < len(acq_ts_list):
                    gf.acquire_delay_ms = (acq_ts_list[acq_idx] - flush_ts_ns) / _NS_PER_MS

    # ---- step 4.6: consumer 耗时与三级流水(spec §5.1)----
    _fill_consumer_durations(frames, send_vsync, recv_vsync_events, commit_layers)

    # ---- step 5: 丢帧判定（间隔阈值：>= 1.5x P10 帧周期即为丢帧）----
    # P10 作为最优帧周期，排除异常偏小/偏大的值
    present_frames = [f for f in frames if f.frame_interval_ms is not None]
    if present_frames:
        intervals_ms = sorted([f.frame_interval_ms for f in present_frames if f.frame_interval_ms])
        if intervals_ms:
            p10_idx = max(len(intervals_ms) * 10 // 100, 0)
            best_interval_ms = intervals_ms[p10_idx]
            # spec §3.6: jank_threshold 加动态下限（黄金规则 6）
            rs_period_ms = _compute_rs_period_ms(recv_vsync_events, commit_layers, ctx)
            min_threshold = _compute_min_threshold(rs_period_ms, ctx)
            jank_threshold_ms = max(best_interval_ms * 1.5, min_threshold)

        for gf in present_frames:
            if gf.frame_interval_ms and gf.frame_interval_ms >= jank_threshold_ms:
                gf.jank = True

        # spec §3.6 + R3: 仅 use_layer_filter=True 时分类（降级路径关闭）
        consumer_ctx: Optional[ConsumerContext] = None
        tol_ms = float(ctx.params.get("tol_default_ms", 1.5))
        if use_layer_filter:
            flush_threshold_ms = _compute_flush_threshold_ms(present_frames, rs_period_ms, ctx)
            # tol_ms 由 recv_vsync 间隔标准差推导（复用 _compute_rs_period_ms 的过滤逻辑）
            rs_intervals = _compute_recv_vsync_intervals(recv_vsync_events)
            tol_ms = _compute_tol_ms(rs_intervals, rs_period_ms, ctx)
            consumer_ctx = _compute_consumer_baseline(present_frames, ctx)
            for i, gf in enumerate(present_frames):
                if gf.jank:
                    gf.jank_class = _classify_jank_cause(
                        gf, present_frames, i,
                        flush_threshold_ms, rs_period_ms, tol_ms,
                        consumer_ctx=consumer_ctx,
                    )

        _log.info(
            "jank_detection",
            best_interval_ms=round(best_interval_ms, 3),
            jank_threshold_ms=round(jank_threshold_ms, 3),
            total_frames=len(present_frames),
        )

    # ---- step 6: 每个丢帧单独输出一个 jank_interval（spec §4.2）----
    jank_intervals: List[JankInterval] = []
    jank_history: List[Dict[str, Any]] = []
    stage_p50s = _compute_stage_p50s(present_frames)
    for idx, pf in enumerate(present_frames):
        if not pf.jank:
            continue
        branch = None
        upstream = None
        # 构建 cause_evidence（spec §4.2）
        evidence: Dict[str, Any] = {
            "frame_interval_ms": _round_opt(pf.frame_interval_ms, 3),
            "flush_interval_ms": _round_opt(pf.flush_buffer_interval_ms, 3),
        }
        if pf.frame_interval_ms is not None and pf.flush_buffer_interval_ms is not None:
            evidence["residual_ms"] = round(pf.frame_interval_ms - pf.flush_buffer_interval_ms, 3)
        # spec §3.2: evidence.rs_period_ms 反映该帧实际使用的 RS 周期（动态）
        frame_rs_period_ms = _frame_rs_period_ms(pf, rs_period_ms)
        if frame_rs_period_ms:
            evidence["rs_period_ms"] = round(frame_rs_period_ms, 3)
        if pf.acquire_delay_ms is not None:
            evidence["acquire_delay_ms"] = round(pf.acquire_delay_ms, 3)
        # consumer 证据（spec §5.1/5.4）
        if pf.consumer_duration_ms is not None:
            evidence["consumer_duration_ms"] = round(pf.consumer_duration_ms, 3)
            evidence["steady_baseline_ms"] = round(consumer_ctx.p50, 3) if consumer_ctx else None
        for k, v in (("stage_render_ms", pf.stage_render_ms),
                     ("stage_commit_ms", pf.stage_commit_ms),
                     ("stage_present_ms", pf.stage_present_ms)):
            if v is not None:
                evidence[k] = round(v, 3)
        if pf.jank_class == "consumer_jank" and consumer_ctx is not None:
            d_cons = _compute_consumer_delta(present_frames, idx, consumer_ctx)
            if d_cons is not None:
                evidence["consumer_delta_ms"] = round(d_cons, 3)
            if frame_rs_period_ms:
                evidence["excess_ms"] = round(pf.frame_interval_ms - frame_rs_period_ms, 3)
            bs = _bottleneck_stage(pf, stage_p50s, tol_ms)
            if bs:
                evidence["bottleneck_stage"] = bs
        elif consumer_ctx is not None and _detect_realignment(present_frames, idx, consumer_ctx):
            branch, hint, upstream = _build_realign_hint(
                pf, present_frames, idx, consumer_ctx, jank_history,
                frame_rs_period_ms or 16.667, tol_ms)
            evidence["realignment_detected"] = True
            evidence["root_cause_hint"] = hint
            if upstream is not None:
                evidence["upstream_present_id"] = upstream.present_id
                evidence["upstream_ts_ms"] = round(upstream.flush_buffer_ms or 0.0, 3)
        # skipped_vsync_ids（spec §4.2 两个列表）
        if idx > 0 and pf.vsync_id is not None:
            prev_pf = present_frames[idx - 1]
            if prev_pf.vsync_id is not None:
                gap = pf.vsync_id - prev_pf.vsync_id
                if gap > 1:
                    skipped_system: List[int] = []
                    skipped_game: List[int] = []
                    for vid in range(prev_pf.vsync_id + 1, pf.vsync_id):
                        if vid in game_vsncs:
                            skipped_game.append(vid)
                        else:
                            skipped_system.append(vid)
                    evidence["skipped_system_vsync_ids"] = skipped_system
                    evidence["skipped_game_vsync_ids"] = skipped_game
        jank_history.append({"present_id": pf.present_id or 0,
                             "jank_class": pf.jank_class or "",
                             "branch": evidence.get("realignment_detected") and branch or None,
                             "upstream": upstream if evidence.get("realignment_detected") else None,
                             "gf": pf})
        jank_intervals.append(JankInterval(
            present_id=pf.present_id or 0,
            frame_count=1,
            duration_ms=round(pf.frame_interval_ms or 16.7, 3),
            jank_class=pf.jank_class or "",
            cause_evidence=evidence,
        ))

    # ---- step 7: 每丢帧区间：sched_slice 瓶颈扫描 ----
    # 预计算噪声线程集合（基于全 trace），供 _scan_callstack_active 过滤
    # 这类线程 callstack slice 多为 trace marker/阻塞调用，跨越睡眠时间，需排除
    noise_tids: Set[int] = _compute_noise_tids(ctx)

    # trace 级预计算五类白名单 pid 集合（方案 L + v4 (e) 反查 top1）
    # 包含 (a) Unity 线程 / (b) GPU Acquire Fence / (c) anco_service_br /
    # (d) FlushBuffer binder 对端 / (e) (d) top1 反查，严格排除 render_service
    static_target_pids: Set[int] = _collect_static_target_pids(ctx)

    for interval in jank_intervals:
        # 用 present_id 定位丢帧帧在 present_frames 中的位置（每帧独立，无需合并）
        int_idx = None
        for idx, pf in enumerate(present_frames):
            if pf.present_id == interval.present_id:
                int_idx = idx
                break

        if int_idx is None:
            continue

        # sched_slice 耗时扫描：窗口从上一帧 flush 到当前帧 flush
        # 瓶颈发生在当前帧 flushBuffer 之前
        # fallback：flush_buffer_ms 为 None 时用 PresentFence 时间兜底
        if int_idx > 0:
            prev_frame = present_frames[int_idx - 1]
        else:
            prev_frame = frames[0]  # 首个有interval的帧之前的那帧（无interval但有flushBuffer）
        end_frame = present_frames[int_idx]

        # spec §4.3 + §5.1: window 边界写入 interval（ms 单位）
        interval.window_start_ms = (
            prev_frame.flush_buffer_ms or prev_frame.present_fence_ms
        )
        interval.window_end_ms = (
            end_frame.flush_buffer_ms or end_frame.present_fence_ms
        )

        # spec §4.3: phase_drift 跳过应用侧瓶颈扫描
        if interval.jank_class == "phase_drift":
            _log.info(
                "skip_bottleneck_scan_phase_drift",
                present_id=interval.present_id,
            )
            continue

        window_start_ns = int(
            (prev_frame.flush_buffer_ms or prev_frame.present_fence_ms) * 1_000_000
        ) if (prev_frame.flush_buffer_ms or prev_frame.present_fence_ms) else 0
        window_end_ns = int(
            (end_frame.flush_buffer_ms or end_frame.present_fence_ms) * 1_000_000
        ) if (end_frame.flush_buffer_ms or end_frame.present_fence_ms) else 0

        # target_pids 完全由 trace 级预计算决定，包含五类白名单 pid。
        # FlushBuffer 线程本身在 render_service，已排除；其 binder 对端在 (d) 中处理。
        target_pids: List[int] = list(static_target_pids)

        # 窗口有效性检查：window 为 0 或 target_pids 为空时跳过瓶颈扫描
        window_duration_ms = (window_end_ns - window_start_ns) / 1_000_000.0

        if window_duration_ms <= 0 or not target_pids:
            _log.info(
                "skip_bottleneck_scan",
                reason="invalid_window_or_pids",
                window_duration_ms=round(window_duration_ms, 3),
                target_pids_count=len(target_pids),
            )
            continue

        cpu_threshold = float(ctx.params.get("cpu_bottleneck_threshold", 0.30))
        cpu_threads = _scan_cpu_bottlenecks(
            ctx, window_start_ns, window_end_ns, target_pids, cpu_threshold
        )

        callstack_threads = _scan_callstack_active(
            ctx, window_start_ns, window_end_ns, target_pids,
            threshold_ratio=float(ctx.params.get("callstack_active_threshold", 0.30)),
            noise_tids=noise_tids,
        )

        # 两路合并：真区间 union，删除 source 区分
        merged = _merge_bottlenecks(
            cpu_threads, callstack_threads,
            window_start_ns, window_end_ns,
        )
        # spec §5: 拦截点 3 守卫——cpu_active_ms==0 的纯 marker 线程过滤
        # 默认关闭（0）：UnityGfxDeviceW 等 GPU 工作线程合法地 cpu_active=0
        # （主要走 callstack_active 路径），开启会误伤。OS_FFRT_2_125 的过滤
        # 由 phase_drift 分类跳过扫描 + _compute_noise_tids（trace 级）处理。
        # 需要时可通过 ctx.params["filter_zero_cpu_bottleneck"]=1 显式开启。
        if float(ctx.params.get("filter_zero_cpu_bottleneck", 0)):
            merged = [bt for bt in merged if bt.cpu_active_ms > 0]
        min_active_ms = window_duration_ms * 0.20
        merged = [bt for bt in merged if bt.active_ms >= min_active_ms]
        # priority 排序用 cpu_active_ms（真实 CPU 占用）
        merged.sort(key=lambda bt: bt.cpu_active_ms, reverse=True)
        # 只保留 Top1/Top2 瓶颈线程（原 Top3，减少 step5 iterate 次数约 33%）
        interval.bottleneck_threads = merged[:2]

    # ---- step 8: 构建 summary ----
    jank_frames = [f for f in present_frames if f.jank]
    intervals_ms = [f.frame_interval_ms for f in present_frames if f.frame_interval_ms is not None]

    avg_interval = round(sum(intervals_ms) / len(intervals_ms), 3) if intervals_ms else 0.0
    avg_fps = round(1000.0 / avg_interval, 1) if avg_interval > 0 else 0.0
    p99_idx = int(len(intervals_ms) * 0.99) if intervals_ms else 0
    p99_low_ms = round(sorted(intervals_ms)[p99_idx - 1], 3) if intervals_ms and p99_idx > 0 else 0.0

    # spec §4.5: 按根因拆分
    jank_class_breakdown = {"producer_jank": 0, "phase_drift": 0, "unclassified": 0, "consumer_jank": 0}
    for ji in jank_intervals:
        cls = ji.jank_class or "unclassified"
        if cls not in jank_class_breakdown:
            jank_class_breakdown[cls] = 0
        jank_class_breakdown[cls] += 1

    summary = {
        "total_frames": len(present_frames),
        "total_jank_frames": len(jank_frames),
        "jank_rate": round(len(jank_frames) / len(present_frames), 3)
        if present_frames
        else 0.0,
        "avg_fps": avg_fps,
        "avg_frame_interval_ms": avg_interval,
        "p99_frame_interval_ms": p99_low_ms,
        "app_name": _resolve_app_name((app_pkg or "").split("/")[0] if app_pkg else None),
        "jank_class_breakdown": jank_class_breakdown,
        "jank_intervals": [ji.to_dict() for ji in jank_intervals],
    }

    # ---- step 9: 构建 thread_queries（spec §4.4 窗口边界修正）----
    thread_queries: List[Dict[str, Any]] = []
    for ji in jank_intervals:
        for rank, bt in enumerate(ji.bottleneck_threads, start=1):
            thread_queries.append({
                "tag": ji.present_id,
                "start_ms": round(ji.window_start_ms, 3) if ji.window_start_ms is not None else round(bt.begin_ms, 3),
                "end_ms": round(ji.window_end_ms, 3) if ji.window_end_ms is not None else round(bt.end_ms, 3),
                "tid": bt.tid,
                "thread_name": bt.thread_name,
                "query_reason": "bottleneck",
                "priority": rank,
                "active_ms": bt.active_ms,
            })

    ctx.data = {
        "summary": summary,
        "thread_queries": thread_queries,
    }

    _log.info(
        "game_render_frames_done",
        total_frames=len(frames),
        jank_frames=len(jank_frames),
        jank_intervals=len(jank_intervals),
        game_queue_id=game_queue_id,
    )

    return ctx
