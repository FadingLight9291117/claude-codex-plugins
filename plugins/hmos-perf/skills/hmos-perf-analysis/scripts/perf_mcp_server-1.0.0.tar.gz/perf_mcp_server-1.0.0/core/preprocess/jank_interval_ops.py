"""PresentFence 丢帧区间检测算子。

基于 PresentFence 事件构建丢帧区间，计算帧间隔和 severity。

依赖（可选，在 ctx.meta 中提供）：
- frame_rate_records: 帧率记录列表，由 query_frame_rate_records 算子提供
  - 如果未提供或为空，算子会自动调用 _get_frame_rate_records(conn) 从数据库查询
  - 如果数据库查询也为空，则使用默认帧率 60

输出格式：
{
    "jank_intervals": [{
        "screen_id": 0,
        "presentFenceId": "PresentFence_0 8825",
        "rsVsyncId": "vsyncId:745267",
        "start_ts": 1234567890,
        "end_ts": 1234567891,
        "dur_ms": 8.33,
        "jank_severity": "minor"
    }],
    "summary": {
        "total_intervals": 100,
        "minor_count": 80,
        "major_count": 15,
        "severe_count": 5,
        "avg_intervals_per_screen": 100
    }
}
"""
from __future__ import annotations

from core.observability import get_module_logger
import re
import time
from typing import Any, Dict, List, Optional, Tuple

from .base import PreprocessContext, register_operator
from .frame_rate_ops import _get_frame_rate_records, _match_frame_rate, _compute_jank_severity

log = get_module_logger(__name__)

# ---------------------------------------------------------------------------
# 正则常量
# ---------------------------------------------------------------------------

# H:Waiting for PresentFence_0 8825 → screenId=0, fenceId=8825
WAIT_PRESENT_RE = re.compile(r'H:Waiting\s+for\s+PresentFence_(\d+)\s+(\d+)')

# H:PresentFence_0 8825 → screenId=0, fenceId=8825
PRESENT_FENCE_RE = re.compile(r'H:PresentFence_(\d+)\s+(\d+)')

# vsyncId:745267 (some traces have space after 'vsyncId:', use \s* to be tolerant)
VSYNC_ID_RE = re.compile(r'vsyncId:\s*(\d+)')

# ---------------------------------------------------------------------------
# 算子实现
# ---------------------------------------------------------------------------


def _parse_wait_present(name: str) -> Optional[Tuple[int, int]]:
    """解析 'H:Waiting for PresentFence_X Y'，返回 (screenId, fenceId) 或 None。"""
    if not name:
        return None
    m = WAIT_PRESENT_RE.search(name)
    if m:
        return int(m.group(1)), int(m.group(2))
    return None


def _parse_present_fence(name: str) -> Optional[Tuple[int, int]]:
    """解析 'H:PresentFence_X Y'，返回 (screenId, fenceId) 或 None。"""
    if not name:
        return None
    m = PRESENT_FENCE_RE.search(name)
    if m:
        return int(m.group(1)), int(m.group(2))
    return None


def _extract_vsync_id(name: str) -> Optional[str]:
    """从函数名中提取 vsyncId:NNNN 格式的字符串。"""
    if not name:
        return None
    m = VSYNC_ID_RE.search(name)
    if m:
        return f"vsyncId:{m.group(1)}"
    return None


def _find_vsync_id_recursive(
    event_id: int,
    callstack_by_id: Dict[int, Dict[str, Any]],
    depth: int = 0,
    max_depth: int = 20,
) -> Optional[str]:
    """递归查询 parent_id 链，查找包含 vsyncId 的函数名。

    使用预加载的 callstack_by_id 字典进行内存查找，避免逐条递归 SQL 查询。

    终止条件：
    - 找到包含 vsyncId:xxx 的函数名（如 H:CommitLayers...vsyncId:744406）
    - depth >= max_depth（防止无限递归）
    - event_id 为 None 或 0
    - callstack_by_id 中查无此行
    """
    if depth >= max_depth or not event_id:
        return None

    entry = callstack_by_id.get(event_id)
    if not entry:
        return None

    name = entry["name"]
    parent_id = entry["parent_id"]

    # 检查当前函数名是否包含 vsyncId
    vsync_id = _extract_vsync_id(name)
    if vsync_id:
        return vsync_id

    # 递归查询父函数
    return _find_vsync_id_recursive(parent_id, callstack_by_id, depth + 1, max_depth)





# ---------------------------------------------------------------------------
# 算子实现
# ---------------------------------------------------------------------------


@register_operator("build_jank_intervals")
def build_jank_intervals(ctx: PreprocessContext) -> PreprocessContext:
    """构建 PresentFence 丢帧区间。

    执行顺序：
    1. 从 callstack 表解析 'H:Waiting for PresentFence_X Y' → 提取 screenId/fenceId
    2. 计算相邻帧的间隔（两帧 end_ts 差值 = 上屏间隔）
    3. 从 ctx.meta 读取 frame_rate_records（由 query_frame_rate_records 提供）
    4. 通过 fenceId 匹配 PresentFence，再通过 parent_id self-join 提取 vsyncId
    5. 根据帧率计算 severity（minor<2x, major<5x, severe>=5x）

    依赖（必须在 ctx.meta 中提供）：
    - frame_rate_records: 帧率记录列表，由 query_frame_rate_records 算子提供

    参数（来自 ctx.params）：
    - minor_threshold: minor/major 分界倍数，默认 2.0
    - major_threshold: major/severe 分界倍数，默认 5.0

    输出 ctx.data:
    {
        "jank_intervals": [{
            "screen_id": 0,
            "presentFenceId": "PresentFence_0 8825",
            "rsVsyncId": "vsyncId:745267",
            "start_ts": 1234567890,
            "end_ts": 1234567891,
            "dur_ms": 8.33,
            "jank_severity": "minor"
        }],
        "summary": {
            "total_intervals": 100,
            "minor_count": 80,
            "major_count": 15,
            "severe_count": 5,
            "avg_intervals_per_screen": 100
        }
    }
    """
    # sqlite_conn 为 None 时返回空数据
    if not ctx.sqlite_conn:
        ctx.data = {
            "jank_intervals": [],
            "summary": {
                "total_intervals": 0,
                "minor_count": 0,
                "major_count": 0,
                "severe_count": 0,
                "avg_intervals_per_screen": 0,
            },
        }
        return ctx

    conn = ctx.sqlite_conn
    # 从 ctx.params 读取动态卡顿阈值（暂未使用，当前使用硬编码）
    # minor_threshold = float(ctx.params.get("minor_threshold", 2.0))
    # major_threshold = float(ctx.params.get("major_threshold", 5.0))

    try:
        # -------------------- 1. 查询 Waiting for PresentFence 事件 --------------------
        cur_wait = conn.execute("""
            SELECT id, ts, dur, name
            FROM callstack
            WHERE name LIKE '%Waiting for PresentFence%'
            ORDER BY ts
        """)
        wait_events = [
            {"id": r[0], "ts": r[1], "dur": r[2], "name": r[3]}
            for r in cur_wait.fetchall()
        ]
        log.info("build_jank_intervals: Waiting for PresentFence 事件数=%d", len(wait_events))

        if not wait_events:
            ctx.data = {
                "jank_intervals": [],
                "summary": {
                    "total_intervals": 0,
                    "minor_count": 0,
                    "major_count": 0,
                    "severe_count": 0,
                    "avg_intervals_per_screen": 0,
                },
            }
            return ctx

        # -------------------- 2. 查询 PresentFence 事件 + parent_id self-join 提取 vsyncId --------------------
        cur_pf = conn.execute("""
            SELECT c.id, c.ts, c.dur, c.name, c.parent_id, p.name as parent_name
            FROM callstack c
            LEFT JOIN callstack p ON c.parent_id = p.id
            WHERE c.name LIKE 'H:PresentFence%'
            ORDER BY c.ts
        """)
        presentfence_events = [
            {
                "id": r[0],
                "ts": r[1],
                "dur": r[2],
                "name": r[3],
                "parent_id": r[4],
                "parent_name": r[5],
            }
            for r in cur_pf.fetchall()
        ]
        log.info("build_jank_intervals: PresentFence 事件数=%d", len(presentfence_events))

        # -------------------- 预加载 callstack 到内存 --------------------
        # 使用递归 CTE 一次性加载所有 PresentFence 及其完整 parent 链
        # 替代逐条递归 SQL 查询（原来 2362 个事件 × 20 层递归 ≈ 1162s → 现在 <1s）
        t0 = time.time()
        log.info("build_jank_intervals: 预加载 callstack parent 链到内存...")
        cur_all = conn.execute("""
            WITH RECURSIVE ancestors AS (
                SELECT id, name, parent_id FROM callstack WHERE name LIKE 'H:PresentFence%'
                UNION ALL
                SELECT c.id, c.name, c.parent_id
                FROM callstack c
                INNER JOIN ancestors a ON c.id = a.parent_id
                WHERE a.parent_id IS NOT NULL AND a.parent_id > 0 AND a.parent_id < 2147483647
            )
            SELECT DISTINCT id, name, parent_id FROM ancestors
        """)
        callstack_by_id: Dict[int, Dict[str, Any]] = {}
        for row in cur_all.fetchall():
            callstack_by_id[row[0]] = {"name": row[1], "parent_id": row[2]}
        log.info("build_jank_intervals: 预加载 %d 条记录到内存, 耗时 %.2fs", len(callstack_by_id), time.time() - t0)

        # -------------------- 3. 构建 fenceId → PresentFence 事件的映射 --------------------
        # key: (screenId, fenceId), value: event dict
        pf_by_fence: Dict[Tuple[int, int], Dict[str, Any]] = {}
        for pf in presentfence_events:
            parsed = _parse_present_fence(pf["name"])
            if parsed:
                pf_by_fence[parsed] = pf

        # -------------------- 4. 查询帧率数据（H:PreferredFrameRate） --------------------
        # 从 ctx.meta 读取 frame_rate_records（优先使用）
        frame_rate_records: Optional[List[Dict[str, Any]]] = ctx.meta.get("frame_rate_records")
        if frame_rate_records is None or len(frame_rate_records) == 0:
            # 如果未提供或为空，直接查询数据库获取帧率数据
            frame_rate_records = _get_frame_rate_records(ctx.sqlite_conn)
            if len(frame_rate_records) == 0:
                log.warning("build_jank_intervals: 未查询到帧率数据，使用默认帧率 60")
            else:
                log.info("build_jank_intervals: 从数据库查询到 %d 条帧率记录", len(frame_rate_records))
        else:
            log.info("build_jank_intervals: 帧率记录数=%d (来自 ctx.meta)", len(frame_rate_records))

        # -------------------- 5. 按 screenId 分组 Waiting for PresentFence 事件 --------------------
        # 计算相邻帧间隔，构造 jank_intervals
        screen_events: Dict[int, List[Dict[str, Any]]] = {}
        for ev in wait_events:
            parsed = _parse_wait_present(ev["name"])
            if parsed:
                screen_id, fence_id = parsed
                ev["screen_id"] = screen_id
                ev["fence_id"] = fence_id
                if screen_id not in screen_events:
                    screen_events[screen_id] = []
                screen_events[screen_id].append(ev)

        # -------------------- 6. 构建 jank_intervals --------------------
        jank_intervals: List[Dict[str, Any]] = []

        for screen_id, events in screen_events.items():
            # 按 ts 排序
            events_sorted = sorted(events, key=lambda e: e["ts"])

            for i, ev in enumerate(events_sorted):
                # 当前事件的结束点（dur 可能为 None，默认为 0）
                dur = ev.get("dur") or 0
                current_end_ts = ev["ts"] + dur

                if i == 0:
                    # 第一个事件：开始点 = 当前事件结束点 - 默认帧间隔
                    start_ts = current_end_ts - 8_333_333
                else:
                    # 后续事件：开始点 = 上一事件结束点，结束点 = 当前事件结束点
                    prev_ev = events_sorted[i - 1]
                    prev_dur = prev_ev.get("dur") or 0
                    start_ts = prev_ev["ts"] + prev_dur

                end_ts = current_end_ts
                dur_ms = round((end_ts - start_ts) / 1_000_000, 3)

                # 匹配帧率
                matched_rate = _match_frame_rate(start_ts, frame_rate_records)
                if matched_rate is None:
                    matched_rate = 60  # 默认帧率

                # 计算 severity
                severity = _compute_jank_severity(dur_ms, matched_rate)

                # 通过 fenceId 匹配 PresentFence
                fence_id = ev.get("fence_id")
                screen_id_from_ev = ev.get("screen_id", screen_id)
                pf_key = (screen_id_from_ev, fence_id) if fence_id else None
                pf_event = pf_by_fence.get(pf_key) if pf_key else None

                # 构建 presentFenceId
                present_fence_id = f"PresentFence_{screen_id_from_ev} {fence_id}" if fence_id else ""

                # 优化：只对 major/severe 帧匹配 rsVsyncId，minor 帧跳过递归查找
                rs_vsync_id = None
                if severity in ("minor", "major", "severe") and pf_event:
                    pf_id = pf_event.get("id")
                    if pf_id:
                        rs_vsync_id = _find_vsync_id_recursive(pf_id, callstack_by_id)

                jank_interval = {
                    "screen_id": screen_id_from_ev,
                    "presentFenceId": present_fence_id,
                    "rsVsyncId": rs_vsync_id,
                    "start_ts": start_ts,
                    "end_ts": end_ts,
                    "dur_ms": dur_ms,
                    "jank_severity": severity,
                    "frame_rate": matched_rate,
                }
                # 输出所有 jank 帧（包括 minor），只过滤 normal 帧
                if severity in ("minor", "major", "severe"):
                    jank_intervals.append(jank_interval)

        # -------------------- 7. 统计摘要 --------------------
        # jank_intervals 包含所有 jank 帧（minor/major/severe）
        total_intervals = len(jank_intervals)
        minor_count = sum(1 for i in jank_intervals if i.get("jank_severity") == "minor")
        major_count = sum(1 for i in jank_intervals if i.get("jank_severity") == "major")
        severe_count = sum(1 for i in jank_intervals if i.get("jank_severity") == "severe")

        screen_count = len(screen_events)
        avg_intervals_per_screen = (
            total_intervals / screen_count if screen_count > 0 else total_intervals
        )

        ctx.data = {
            "jank_intervals": jank_intervals,
            "summary": {
                "total_intervals": total_intervals,
                "minor_count": minor_count,
                "major_count": major_count,
                "severe_count": severe_count,
                "avg_intervals_per_screen": round(avg_intervals_per_screen, 2),
            },
        }

        log.info(
            "build_jank_intervals: 完成, total=%d, minor=%d, major=%d, severe=%d",
            total_intervals, minor_count, major_count, severe_count,
        )

    except Exception as e:
        log.error("build_jank_intervals: 执行失败: %s", e)
        ctx.data = {
            "jank_intervals": [],
            "summary": {
                "total_intervals": 0,
                "minor_count": 0,
                "major_count": 0,
                "severe_count": 0,
                "avg_intervals_per_screen": 0,
            },
        }

    return ctx
