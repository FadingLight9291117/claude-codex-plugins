"""游戏关键线程调度分析算子。

分析游戏引擎关键线程的调度状态：
- UE: WorkerThread_Ue(游戏主线程), RenderThread(渲染), AuxiliaryRHI(GPU命令), FAsyncLoading(异步加载)
- Unity: UnityMain(游戏主线程), UnityGfxDeviceW(渲染), UnityWorker(物理/音频/AI)

核心指标：
- 各关键线程的 CPU 占用率、Running/Runnable/Sleeping 时间分布
- 调度延迟（wakeup latency）统计
- CPU 亲和性（大核/小核分布）
- 迁移次数和频率

与通用 thread_sched_ops.py 的差异：
- 仅分析游戏关键线程（而非全部线程）
- 增加线程角色标签（role）方便 Agent 理解
- 支持引擎类型自动识别
"""
from __future__ import annotations

from typing import Dict, Set

import pandas as pd

from core.game_engine_detector import (
    GameEngineInfo,
    _classify_thread,
    detect_game_engine,
)
from core.observability import get_observability_logger
from core.preprocess.base import PreprocessContext, PreprocessError, register_operator

# 游戏调度问题检测阈值（可通过 ctx.params 覆盖）
#
# 注意：游戏线程的运行模式与服务器不同。游戏渲染是周期性工作：
# - 渲染线程每帧预算 16.67ms（60fps），帧内只需运行 2~4ms
# - running_pct 低不代表问题，关键是帧内运行时间是否超出帧预算
# - sleeping 需区分"主动等待"（wait_for_work，正常）和"被动阻塞"（锁/IO，异常）
# - 仅凭 RunState 数据无法判断 sleeping 类型，需结合 d_state 和 runnable_ms
#
DEFAULT_SCHED_THRESHOLDS = {
    "running_pct_min": 30,            # 主线程 CPU 占用下限（注意：仅对主线程有意义，渲染线程不适用）
    "migration_count_max": 50,        # 主线程迁移次数上限（跨簇迁移才有意义，同簇迁移影响小）
    "d_state_ms_max": 500,            # 渲染线程 D-state 上限（不可中断睡眠 = 内核阻塞）
    "sleeping_ms_max": 10000,          # 异步加载线程 Sleeping 上限（仅作提示，需区分主动/被动）
}
# 内部筛选阈值（不在 YAML 中暴露）
DEFAULT_RUNNING_THRESHOLD_MS = 5.0    # Running 时间 > 5ms 才保留
DEFAULT_MAX_UE_MAIN = 5               # UE 主线程保留上限

_log = get_observability_logger("game_sched_ops")

# 线程角色中文标签
ROLE_LABELS = {
    "ue_main": "UE游戏主线程(WorkerThread_Ue)",
    "ue_render": "UE渲染线程(RenderThread)",
    "ue_rhi": "UE RHI线程(AuxiliaryRHI)",
    "ue_async_loading": "UE异步加载(FAsyncLoading)",
    "ue_slate": "UE Slate加载(SlateLoading)",
    "unity_main": "Unity主线程(UnityMain)",
    "unity_render": "Unity渲染线程(UnityGfxDeviceW)",
    "unity_worker": "Unity工作线程(UnityWorker)",
    "game_main": "游戏主线程(GameThread)",
    "render": "渲染线程(RenderThread)",
    "worker": "工作线程(WorkerThread)",
}


@register_operator("detect_game_engine_threads")
def detect_game_engine_threads(ctx: PreprocessContext) -> PreprocessContext:
    """检测游戏引擎类型并识别关键线程。

    从 thread 表查询线程信息，调用 game_engine_detector 进行引擎检测。
    结果写入 ctx.meta["engine_info"]。
    """
    conn = ctx.sqlite_conn
    if conn is None:
        raise PreprocessError("detect_game_engine_threads 需要 sqlite_conn")

    cur = conn.cursor()

    # 查询游戏进程的线程列表
    # 从 params 获取 ipid 或从 data 获取
    ipid = ctx.params.get("ipid")
    if ipid is None and isinstance(ctx.data, pd.DataFrame) and not ctx.data.empty:
        # 尝试从 data 中获取第一个 ipid
        if "ipid" in ctx.data.columns:
            ipid = ctx.data["ipid"].iloc[0]

    if ipid is None:
        # 尝试自动检测：查找包含游戏线程特征的进程
        try:
            cur.execute("""
                SELECT p.ipid, t.name, t.tid, t.itid
                FROM thread t
                JOIN process p ON t.ipid = p.ipid
                WHERE t.name LIKE '%WorkerThread_Ue%'
                   OR t.name LIKE '%UnityMain%'
                   OR t.name LIKE '%GameThread%'
                LIMIT 1
            """)
            row = cur.fetchone()
            if row:
                ipid = row[0]
        except Exception:
            pass

    if ipid is not None:
        cur.execute("""
            SELECT name, tid, itid FROM thread WHERE ipid = ?
        """, (ipid,))
        rows = cur.fetchall()
        thread_df = pd.DataFrame(rows, columns=["name", "tid", "itid"])
    else:
        # 查询所有线程
        cur.execute("SELECT name, tid, itid FROM thread")
        rows = cur.fetchall()
        thread_df = pd.DataFrame(rows, columns=["name", "tid", "itid"])

    engine_info = detect_game_engine(thread_df)
    ctx.meta["engine_info"] = engine_info

    _log.info("game_engine_detected", engine_type=engine_info.engine_type,
              confidence=engine_info.confidence, key_threads=engine_info.key_threads)
    return ctx


@register_operator("compute_game_thread_sched")
def compute_game_thread_sched(ctx: PreprocessContext) -> PreprocessContext:
    """计算游戏关键线程的调度状态分布。

    从 sched_slice 和 thread_state 表查询关键线程的调度信息，
    计算 Running/Runnable/Sleeping/Uninterruptible 时间占比。

    结果写入 ctx.data，格式为：
    [{
        "role": str, "thread_name": str, "tid": int, "itid": int,
        "running_ms": float, "runnable_ms": float, "sleeping_ms": float,
        "d_state_ms": float, "running_pct": float, "wakeup_latency_p50_ms": float,
        "migration_count": int
    }]
    """
    conn = ctx.sqlite_conn
    if conn is None:
        raise PreprocessError("compute_game_thread_sched 需要 sqlite_conn")

    engine_info: GameEngineInfo = ctx.meta.get("engine_info", GameEngineInfo(
        engine_type="UNKNOWN", confidence=0.0, key_threads={}, matched_patterns=[]
    ))

    if not engine_info.is_game or not engine_info.key_threads:
        ctx.data = []
        ctx.meta["warnings"] = ctx.meta.get("warnings", []) + ["未检测到游戏引擎或关键线程"]
        return ctx

    cur = conn.cursor()
    start_ms = ctx.params.get("start_ms")
    end_ms = ctx.params.get("end_ms")

    time_filter = ""
    params_list: list = []
    if start_ms is not None and end_ms is not None:
        start_ns = int(start_ms * 1e6)
        end_ns = int(end_ms * 1e6)
        time_filter = "AND ts BETWEEN ? AND ?"
        params_list = [start_ns, end_ns]

    # 收集所有关键线程的 tid（key_threads 中存的是 thread.tid）
    # 需要转换为 itid（sched_slice/thread_state 表的 key）
    all_tids: Set[int] = set()
    for tids in engine_info.key_threads.values():
        all_tids.update(tids)

    if not all_tids:
        ctx.data = []
        return ctx

    # 构建 tid -> itid 映射（tid 在 trace 中唯一）
    tid_to_itid: Dict[int, int] = {}
    itid_to_tid: Dict[int, int] = {}
    try:
        placeholders = ",".join(["?"] * len(all_tids))
        cur.execute(f"""
            SELECT tid, itid, name FROM thread WHERE tid IN ({placeholders})
        """, list(all_tids))
        for row in cur.fetchall():
            tid_val, itid_val, name_val = row
            tid_to_itid[tid_val] = itid_val
            itid_to_tid[itid_val] = tid_val
    except Exception as e:
        _log.warning("query_thread_tid_itid_map_failed", error=str(e))

    # 转换为 itid 集合用于调度表查询
    all_itids: Set[int] = set(tid_to_itid.values())

    # 构建线程名映射 itid -> thread_name
    itid_to_name: Dict[int, str] = {}
    try:
        if all_itids:
            ip = ",".join(["?"] * len(all_itids))
            cur.execute(f"SELECT itid, name FROM thread WHERE itid IN ({ip})", list(all_itids))
            for row in cur.fetchall():
                itid_to_name[row[0]] = str(row[1] or "")
    except Exception as e:
        _log.warning("query_thread_names_failed", error=str(e))

    # 查询调度状态
    results = []
    itid_list = sorted(all_itids)
    placeholders = ",".join(["?"] * len(itid_list))

    # ── Running 时间：从 sched_slice 查（thread_state 的 R 状态 dur 不完整）──
    running_ns_map: Dict[int, int] = {}
    try:
        cur.execute(f"""
            SELECT itid, SUM(dur) AS running_ns
            FROM sched_slice
            WHERE itid IN ({placeholders})
            {time_filter}
            GROUP BY itid
        """, itid_list + params_list)
        for row in cur.fetchall():
            running_ns_map[row[0]] = row[1] or 0
    except Exception as e:
        _log.warning("query_sched_slice_running_failed", error=str(e))

    # ── Sleeping/D-state/Runnable：从 thread_state 查（这些状态在 sched_slice 中无记录）──
    state_agg: Dict[int, Dict[str, int]] = {}
    try:
        cur.execute(f"""
            SELECT itid,
                   SUM(CASE WHEN state LIKE 'S%' OR state = 'Sleeping' THEN dur ELSE 0 END) AS sleeping_ns,
                   SUM(CASE WHEN state = 'D' OR state LIKE 'D%' THEN dur ELSE 0 END) AS d_state_ns,
                   SUM(CASE WHEN state = 'Runnable' THEN dur ELSE 0 END) AS runnable_ns,
                   COUNT(CASE WHEN state = 'Runnable' THEN 1 END) AS wakeup_count
            FROM thread_state
            WHERE itid IN ({placeholders})
            {time_filter}
            GROUP BY itid
        """, itid_list + params_list)
        for row in cur.fetchall():
            state_agg[row[0]] = {
                "sleeping_ns": row[1] or 0,
                "d_state_ns": row[2] or 0,
                "runnable_ns": row[3] or 0,
                "wakeup_count": row[4] or 0,
            }
    except Exception as e:
        _log.warning("query_thread_state_failed", error=str(e))

    # 合并两表数据为统一 state_rows 格式
    all_itids_set = set(running_ns_map.keys()) | set(state_agg.keys())
    state_rows = []
    for itid_val in all_itids_set:
        sa = state_agg.get(itid_val, {})
        state_rows.append((
            itid_val,
            running_ns_map.get(itid_val, 0),  # running_ns (from sched_slice)
            sa.get("runnable_ns", 0),
            sa.get("sleeping_ns", 0),
            sa.get("d_state_ns", 0),
            0,  # running_count (不再从 thread_state 取)
            sa.get("wakeup_count", 0),
        ))

    # 查询迁移次数
    migration_counts: Dict[int, int] = {}
    try:
        cur.execute(f"""
            SELECT itid, COUNT(*) AS migration_count
            FROM (
                SELECT itid, ts, cpu,
                       LAG(cpu) OVER (PARTITION BY itid ORDER BY ts) AS prev_cpu
                FROM sched_slice
                WHERE itid IN ({placeholders})
                {time_filter}
            )
            WHERE prev_cpu IS NOT NULL AND cpu != prev_cpu
            GROUP BY itid
        """, itid_list + params_list)
        for row in cur.fetchall():
            migration_counts[row[0]] = row[1]
    except Exception:
        pass

    # 构建 itid -> role 映射（key_threads 存的是 tid，需要用 tid_to_itid 转换）
    itid_to_role: Dict[int, str] = {}
    for role, tids in engine_info.key_threads.items():
        for tid in tids:
            itid_val = tid_to_itid.get(tid)
            if itid_val:
                itid_to_role[itid_val] = role

    # 调度状态查询结果中，按 itid 分组统计 running 时间
    # 用于 ue_main 线程筛选：只保留有实际 CPU 消耗的线程（排除大量 Sleeping 的空闲线程）
    state_rows_running: Dict[int, float] = {}
    for row in state_rows:
        itid = row[0]
        running_ns = row[1] or 0
        state_rows_running[itid] = running_ns

    # ue_main 线程太多时（UE 有 38 个 WorkerThread_Ue），只保留有活跃 CPU 消耗的：
    # - Running 时间最长的前 N 个（默认 5 个）
    # - 加上 Running 时间虽短但 D-state > 50ms 的（可能有等待问题）
    ue_main_itids = [itid for itid, role in itid_to_role.items() if role == "ue_main"]
    running_threshold_ms = ctx.params.get("running_threshold_ms", DEFAULT_RUNNING_THRESHOLD_MS)
    max_ue_main = ctx.params.get("max_ue_main", DEFAULT_MAX_UE_MAIN)

    if len(ue_main_itids) > max_ue_main:
        # 按 Running 时间降序
        sorted_ue_main = sorted(ue_main_itids, key=lambda x: state_rows_running.get(x, 0), reverse=True)
        # 保留 Top N + D-state > 50ms 的 + Running > 5ms 的
        allowed_ue_main = set(sorted_ue_main[:max_ue_main])
        for itid in ue_main_itids:
            running_ms = (state_rows_running.get(itid, 0)) / 1e6
            # D-state 查询（如果已查到）
            d_state_ms = 0.0
            for row in state_rows:
                if row[0] == itid:
                    d_state_ms = (row[4] or 0) / 1e6
                    break
            if running_ms > running_threshold_ms or d_state_ms > 50:
                allowed_ue_main.add(itid)
        # 最终保留：TopN + Running>阈值 + D-state>阈值
        for itid in sorted_ue_main[max_ue_main:]:
            if itid not in allowed_ue_main:
                itid_to_role.pop(itid, None)
        _log.info("ue_main_threads_filtered", total=len(ue_main_itids),
                  selected=len(allowed_ue_main), threshold_ms=running_threshold_ms)

    for row in state_rows:
        itid = row[0]

        # 过滤：只保留 itid_to_role 中有标记的线程
        if itid not in itid_to_role:
            continue

        running_ns = row[1] or 0
        runnable_ns = row[2] or 0
        sleeping_ns = row[3] or 0
        d_state_ns = row[4] or 0
        wakeup_count = row[6] or 0

        thread_name = itid_to_name.get(itid, "")
        # 优先用预标识的 engine role，回退到 _classify_thread
        role = itid_to_role.get(itid) or _classify_thread(thread_name) or "unknown"
        tid = itid_to_tid.get(itid, 0)

        total_ns = running_ns + runnable_ns + sleeping_ns + d_state_ns

        results.append({
            "role": role,
            "role_label": ROLE_LABELS.get(role, role),
            "thread_name": thread_name,
            "tid": tid,
            "running_ms": round(running_ns / 1e6, 2),
            "runnable_ms": round(runnable_ns / 1e6, 2),
            "sleeping_ms": round(sleeping_ns / 1e6, 2),
            "d_state_ms": round(d_state_ns / 1e6, 2),
            "running_pct": round(running_ns / total_ns * 100, 1) if total_ns > 0 else 0,
            "wakeup_count": wakeup_count,
            "migration_count": migration_counts.get(itid, 0),
        })

    ctx.data = results
    ctx.meta["game_thread_count"] = len(results)
    _log.info("game_thread_sched_computed", thread_count=len(results))
    return ctx


@register_operator("detect_game_sched_issues")
def detect_game_sched_issues(ctx: PreprocessContext) -> PreprocessContext:
    """检测游戏线程调度问题。

    问题类型：
    - 主线程 CPU 占用过低（< 30%，仅对主线程有意义，渲染线程不适用）
    - 渲染线程 D-state 过长（> 500ms）：内核阻塞（I/O、锁等待）
    - 主线程跨簇迁移次数过多（> 50）：影响 L1/L2 缓存命中率
    - 异步加载线程 Sleeping 过长（仅作提示，需结合 d_state/runnable 判断是被动阻塞还是主动等待）

    重要说明：
    - 游戏线程是周期性工作，running_pct 低不代表有问题（如渲染线程每帧只运行 2~4ms）
    - sleeping 需结合 d_state 和 runnable_ms 判断：d_state 高说明内核阻塞，runnable 高说明等待调度
    - 跨簇迁移（big→little 或 little→big）才有意义，同簇迁移影响较小

    结果写入 ctx.meta["sched_issues"]。
    """
    threads = ctx.data if isinstance(ctx.data, list) else []
    issues = []

    # 从 ctx.params 读取问题检测阈值（YAML 声明的参数优先，否则使用默认值）
    thresholds = {
        k: ctx.params.get(f"sched_{k}", v)
        for k, v in DEFAULT_SCHED_THRESHOLDS.items()
    }

    # 获取主线程 tid（用于区分主线程 vs 工作线程）
    engine_info = ctx.meta.get("engine_info")
    main_tid = engine_info.main_tid if engine_info else None

    for thread in threads:
        role = thread.get("role", "")
        tid = thread.get("tid", 0)
        running_pct = thread.get("running_pct", 0)
        migration_count = thread.get("migration_count", 0)
        sleeping_ms = thread.get("sleeping_ms", 0)
        is_main_thread = (tid == main_tid)

        # 主线程 CPU 占用过低
        if is_main_thread and running_pct < thresholds["running_pct_min"]:
            issues.append({
                "role": role,
                "issue": "主线程CPU占用过低",
                "detail": f"running_pct={running_pct}%, 预期>{thresholds['running_pct_min']}%",
                "severity": "major",
                "thread_name": thread.get("thread_name", ""),
            })

        # 主线程迁移次数过多
        if is_main_thread and migration_count > thresholds["migration_count_max"]:
            issues.append({
                "role": role,
                "issue": "主线程调度不亲和",
                "detail": f"migration_count={migration_count}, 阈值50",
                "severity": "minor",
                "thread_name": thread.get("thread_name", ""),
            })

        # 工作线程 CPU 占用过低（仅提示级别，不报 major）
        if role in ("ue_main", "unity_main", "game_main") and not is_main_thread and running_pct < 5:
            issues.append({
                "role": role,
                "issue": "工作线程CPU占用极低",
                "detail": f"running_pct={running_pct}%, 主线程外的工作线程可能空闲",
                "severity": "suggestion",
                "thread_name": thread.get("thread_name", ""),
            })

        # 异步加载 Sleeping 过长（需区分主动等待 vs 被动阻塞）
        # 主动等待：d_state 低 + runnable 低 → 线程无任务可做，正常空闲
        # 被动阻塞：d_state 高 → 内核 I/O 阻塞；runnable 高 → 等待调度
        if role in ("ue_async_loading",) and sleeping_ms > thresholds["sleeping_ms_max"]:
            # 结合 d_state 判断阻塞类型
            d_state = thread.get("d_state_ms", 0)
            runnable_ms = thread.get("runnable_ms", 0)
            if d_state > 500:
                blocking_type = "内核阻塞（I/O等待/锁竞争）"
            elif runnable_ms > 100:
                blocking_type = "调度等待（runnable高，CPU过载或优先级低）"
            else:
                blocking_type = "主动等待（无任务可做，正常空闲）"

            issues.append({
                "role": role,
                "issue": "异步加载线程Sleeping过长",
                "detail": f"sleeping_ms={sleeping_ms}ms, 阈值{thresholds['sleeping_ms_max']}ms, "
                          f"类型: {blocking_type}",
                "severity": "suggestion",
                "thread_name": thread.get("thread_name", ""),
            })

    ctx.meta["sched_issues"] = issues
    _log.info("game_sched_issues_detected", issue_count=len(issues))
    return ctx


@register_operator("format_game_sched_summary")
def format_game_sched_summary(ctx: PreprocessContext) -> PreprocessContext:
    """格式化游戏线程调度分析结果。

    输出 ctx.data 为结构化字典：
    {
        "engine_info": {"engine_type": ..., "key_threads": ...},
        "threads": [...],
        "issues": [...],
    }
    """
    engine_info = ctx.meta.get("engine_info")
    threads = ctx.data if isinstance(ctx.data, list) else []
    issues = ctx.meta.get("sched_issues", [])

    ctx.data = {
        "engine_info": {
            "engine_type": engine_info.engine_type if engine_info else "UNKNOWN",
            "confidence": engine_info.confidence if engine_info else 0.0,
            "key_threads": engine_info.key_threads if engine_info else {},
            "main_tid": engine_info.main_tid if engine_info else None,
            "render_tid": engine_info.render_tid if engine_info else None,
        },
        "threads": threads,
        "issues": issues,
    }

    return ctx
