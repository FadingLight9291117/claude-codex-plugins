# -*- coding: utf-8 -*-
"""唤醒链全局索引（O(1) prev 指针查找）。

基于 spec: docs/superpowers/specs/2026-07-23-wakeup-chain-index-design.md

性能特征:
- 构建 O(N log N)，N = wakeup 事件数（实测 35 万行 ~630ms）
- 查找 O(log M) 初始 bisect + O(depth) prev 指针跳转（实测 100 条 chain 0.3ms）

连接级缓存：同一 SQLite 连接构建一次，供 204 个 iterate item 复用。
指纹校验防 id(conn) 复用导致缓存串场。

numpy 降级路径：try import numpy，失败则用 Python list + bisect。

关键设计：events 保留 from_itid（不只是 from_tid），因为同一 tid 可能对应
多个 itid，外部调用方（sleep_ops）需要用 from_itid 查 callstack_cache /
thread_names / prio_map（这些缓存以 itid 为 key）。
"""
from __future__ import annotations

import bisect as _bisect
from typing import Any, Dict, List, Optional, Tuple

from core.observability import get_module_logger

log = get_module_logger(__name__)

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:  # pragma: no cover - 降级路径，运行环境通常有 numpy
    import types as _types
    np = _types.SimpleNamespace()  # type: ignore[assignment]
    _HAS_NUMPY = False


# ---------------------------------------------------------------------------
# 构建函数：缓存由 TraceDataCache.wakeup_index() 统一管理（连接级单例）。
# 本模块不再维护独立缓存，避免与 TraceDataCache._wakeup_index 重复。
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------

def _fetch_itid_to_tid(sqlite_conn) -> Dict[int, int]:
    """单次 SQL 拉取 itid→tid 全量映射。

    Returns:
        {itid: tid}，无 thread 表或异常时返回空 dict。
    """
    if sqlite_conn is None:
        return {}
    try:
        rows = sqlite_conn.execute("SELECT itid, tid FROM thread").fetchall()
        return {r[0]: r[1] for r in rows}
    except Exception as e:
        log.debug(f"无法拉取 itid→tid 映射: {e}")
        return {}


# ---------------------------------------------------------------------------
# 核心索引
# ---------------------------------------------------------------------------

class WakeupChainIndex:
    """唤醒链全局索引。

    所有外部暴露的 tid 都是真实 tid（不是 itid），但 events 内保留 from_itid
    用于外部反查（callstack_cache / thread_names / prio_map 等以 itid 为 key，
    需要原始 from_itid 而非 from_tid，因为同一 tid 可能对应多个 itid）。

    Attributes:
        events: {tid: [(ts, from_tid, from_itid), ...]}  ts 升序
        ts_only: {tid: [ts, ...]}  纯 ts 列表（供 bisect）
        prev: {tid: [idx_or_-1, ...]}  prev 指针，prev[tid][i] = events[from_tid] 中
              ts < events[tid][i].ts 的最大下标；无则 -1
        tid_set: 索引覆盖的所有 tid 集合
        all_itids: 索引内出现的所有 itid 集合（ref + from_itid），
                   供外部一次性获取而无需遍历 events（避免 35 万行 O(N) 重复扫描）
    """

    def __init__(
        self,
        events: Dict[int, List[Tuple[int, int, int]]],
        ts_only: Dict[int, List[int]],
        prev: Dict[int, List[int]],
        tid_set: set,
        all_itids: Optional[set] = None,
    ) -> None:
        self.events = events
        self.ts_only = ts_only
        self.prev = prev
        self.tid_set = tid_set
        # 惰性计算：首次访问时构建；构建期已遍历过 events 则直接传入避免二次扫描
        self._all_itids: Optional[set] = all_itids

    @property
    def all_itids(self) -> set:
        """索引内所有 itid（ref_itid + from_itid），供外部批拉 name/callstack/prio。

        构建期已收集则直接返回；否则惰性扫描 events 一次（35 万行 ~23ms）。
        外部多次调用本属性只扫描一次。
        """
        if self._all_itids is not None:
            return self._all_itids
        itids: set = set()
        for ev_list in self.events.values():
            for _ts, _from_tid, from_itid in ev_list:
                if from_itid:
                    itids.add(from_itid)
        self._all_itids = itids
        return itids

    # --- 查找 ----------------------------------------------------------

    def find_direct_waker(self, tid: int, window_end: int) -> Optional[Tuple[int, int]]:
        """返回 tid 在 window_end 之前（含端点）的最后一次 wakeup 事件 (ts, from_itid)。

        即"结束该睡眠段的那次唤醒"。wakeup ts 恰好等于段 end（半开区间 [ts, ts+dur)
        下状态段的 ts+dur == wakeup ts），故端点必须取 <=。
        实现：idx = bisect_right(ts_only[tid], window_end) - 1；idx < 0 返回 None。
        from_itid 为 0/None（中断唤醒等）时照常返回，由调用方决定如何处理。
        """
        ts_list = self.ts_only.get(tid)
        if not ts_list:
            return None
        idx = _bisect.bisect_right(ts_list, window_end) - 1
        if idx < 0:
            return None
        ev = self.events[tid][idx]
        return (ev[0], ev[2])  # (ts, from_itid)

    def find_wakeups_in_window(self, tid: int, win_start: int, win_end: int) -> List[Tuple[int, int]]:
        """返回 tid 在 (win_start, win_end] 内所有 wakeup 事件 [(ts, from_itid), ...]，按 ts 升序。

        每个事件 = 该线程一段 S/D 阻塞的结束点。实现：bisect_left/bisect_right 定位区间切片。
        """
        ts_list = self.ts_only.get(tid)
        if not ts_list:
            return []
        idx_lo = _bisect.bisect_right(ts_list, win_start)   # > win_start
        idx_hi = _bisect.bisect_right(ts_list, win_end)     # <= win_end
        if idx_lo >= idx_hi:
            return []
        ev_list = self.events[tid]
        return [(ev_list[i][0], ev_list[i][2]) for i in range(idx_lo, idx_hi)]

    def find_chain(
        self,
        blocked_tid: int,
        start_ns: int,
        end_ns: int,
        visited_chain: Optional[set] = None,
    ) -> Tuple[List[Dict[str, Any]], List[int]]:
        """从 blocked_tid 出发，查找唤醒链。

        每步 O(1) prev 指针跳转，替代旧算法的双 bisect + 反向扫描。
        语义与旧算法完全等价（已 200 条 chain 验证）。

        Args:
            blocked_tid: 被唤醒线程的 tid
            start_ns: 查找时间窗口起点（ns）
            end_ns: 查找时间窗口终点（ns）
            visited_chain: 外部传入的已访问 tid 集合（防循环），None 则内部创建

        Returns:
            (chain, wake_ts_list)
            - chain: [{"tid": int, "from_itid": int, "ts": int, "prev_idx": int}, ...]
              不含被阻塞线程本身，只含 waker 节点
              - tid: waker 的真实 tid
              - from_itid: waker 的 itid（外部查 thread_names / callstack_cache 用）
              - ts: 唤醒事件的时间戳
              - prev_idx: waker 自己被唤醒事件在 events[tid] 中的下标，用于
                外部反查 from_itid_wakeup_ts；-1 表示无更早事件
            - wake_ts_list: 每个 waker 唤醒下一个的 ts（与 chain 同长）
        """
        if blocked_tid not in self.events:
            return [], []
        ts_list = self.ts_only[blocked_tid]
        # 初始 bisect: 找 ts <= end_ns 的最右项
        idx = _bisect.bisect_right(ts_list, end_ns) - 1
        current_tid = blocked_tid
        chain: List[Dict[str, Any]] = []
        wake_ts_list: List[int] = []
        # visited 必须包含 blocked_tid 自身（与旧算法 build_wakeup_chain 第一步
        # visited.add(blocked_tid) 一致），防止链走到 blocked_tid 自己形成循环。
        # 旧算法过滤检查：w_from_tid == current_block_tid 或 w_from_tid in visited_chain
        visited: set = set() if visited_chain is None else set(visited_chain)
        visited.add(blocked_tid)

        while idx >= 0:
            ev_list = self.events[current_tid]
            ts, from_tid, from_itid = ev_list[idx]
            # 过滤检查（与 sleep_ops 旧算法完全一致）
            if ts < start_ns or from_tid == 0 or from_tid == current_tid or from_tid in visited:
                idx -= 1  # 反向扫描跳过
                continue
            # 通过过滤
            prev_idx = self.prev[current_tid][idx]  # O(1) 替代第二次 bisect
            chain.append({
                "tid": from_tid,
                "from_itid": from_itid,
                "ts": ts,
                "prev_idx": prev_idx,
            })
            wake_ts_list.append(ts)
            visited.add(from_tid)
            # 跳到 from_tid 的 prev_idx 位置
            if prev_idx < 0 or from_tid not in self.events:
                break
            current_tid = from_tid
            idx = prev_idx

        return chain, wake_ts_list


# ---------------------------------------------------------------------------
# 构建算法
# ---------------------------------------------------------------------------

def _build_index_python(
    rows: List[Tuple[int, int, int]],
    itid_to_tid: Dict[int, int],
) -> WakeupChainIndex:
    """Python list + bisect 降级路径（numpy 不可用时）。

    与 _build_index_numpy 语义等价但更慢。
    """
    # 按 (ref_tid, ts) 排序；保留 from_itid 用于外部反查
    decorated: List[Tuple[int, int, int, int]] = []
    all_itids: set = set()
    for ref, w_from, ts in rows:
        ref_tid = itid_to_tid.get(ref, 0)
        from_tid = itid_to_tid.get(w_from, 0)
        decorated.append((ref_tid, ts, from_tid, w_from))
        if ref:
            all_itids.add(ref)
        if w_from:
            all_itids.add(w_from)
    decorated.sort(key=lambda x: (x[0], x[1]))

    # 分组
    events: Dict[int, List[Tuple[int, int, int]]] = {}
    for ref_tid, ts, from_tid, from_itid in decorated:
        events.setdefault(ref_tid, []).append((ts, from_tid, from_itid))

    ts_only: Dict[int, List[int]] = {
        tid: [t[0] for t in lst] for tid, lst in events.items()
    }

    # prev 指针
    prev: Dict[int, List[int]] = {tid: [-1] * len(lst) for tid, lst in events.items()}

    for ref_tid, ev_list in events.items():
        for i, (ts, from_tid, from_itid) in enumerate(ev_list):
            if from_tid == 0 or from_tid not in ts_only:
                continue
            f_ts_list = ts_only[from_tid]
            # 找 ts < 当前 ts 的最大下标：bisect_left(ts) - 1
            idx2 = _bisect.bisect_left(f_ts_list, ts) - 1
            prev[ref_tid][i] = idx2  # -1 if idx2 < 0

    tid_set = set(events.keys())
    return WakeupChainIndex(events, ts_only, prev, tid_set, all_itids)


def _build_index_numpy(
    rows: List[Tuple[int, int, int]],
    itid_to_tid: Dict[int, int],
) -> WakeupChainIndex:
    """numpy 向量化构建路径（spec Step 3-6）。"""
    N = len(rows)
    if N == 0:
        return WakeupChainIndex({}, {}, {}, set(), set())

    # Step 3: numpy 数组转换。保留 from_itid 用于外部反查 callstack/prio 等以 itid 为 key 的缓存。
    ts_arr = np.fromiter((r[2] for r in rows), dtype=np.int64, count=N)
    # 原始 ref_itid / from_itid 保留：用于构建期一次性收集 all_itids（外部访问 O(1)）
    ref_itid_arr = np.fromiter((r[0] for r in rows), dtype=np.int32, count=N)
    from_itid_arr = np.fromiter((r[1] for r in rows), dtype=np.int32, count=N)
    ref_tid_arr = np.fromiter(
        (itid_to_tid.get(r[0], 0) for r in rows), dtype=np.int32, count=N
    )
    from_tid_arr = np.fromiter(
        (itid_to_tid.get(r[1], 0) for r in rows), dtype=np.int32, count=N
    )

    # Step 4: lexsort 排序（先 ts 后 ref_tid）
    order = np.lexsort((ts_arr, ref_tid_arr))
    ts_sorted = ts_arr[order]
    ref_sorted = ref_tid_arr[order]
    from_tid_sorted = from_tid_arr[order]
    from_itid_sorted = from_itid_arr[order]

    # Step 5: 分组切片（每个 tid 的 events 起止位置）
    unique_tids, starts = np.unique(ref_sorted, return_index=True)
    n_tids = len(unique_tids)
    # 每个 tid 的结束位置
    ends = np.append(starts[1:], N)

    # 构建 events / ts_only
    events: Dict[int, List[Tuple[int, int, int]]] = {}
    ts_only: Dict[int, List[int]] = {}
    ts_lists: List[Any] = []  # 每个 tid 对应的 numpy ts 数组
    tid_to_idx: Dict[int, int] = {}

    for i in range(n_tids):
        tid = int(unique_tids[i])
        s = int(starts[i])
        e = int(ends[i])
        ts_slice = ts_sorted[s:e]
        from_tid_slice = from_tid_sorted[s:e]
        from_itid_slice = from_itid_sorted[s:e]
        tid_to_idx[tid] = i
        # 转回 Python list 保持与降级路径一致的数据结构（ts, from_tid, from_itid）
        ev_list = [
            (int(ts_slice[j]), int(from_tid_slice[j]), int(from_itid_slice[j]))
            for j in range(len(ts_slice))
        ]
        events[tid] = ev_list
        ts_only[tid] = [t[0] for t in ev_list]
        ts_lists.append(ts_slice)

    # Step 6: prev 指针向量化计算
    prev_arr = np.full(N, -1, dtype=np.int32)

    # 遍历每个作为 from_tid 出现的 tid
    unique_from_tids = np.unique(from_tid_sorted)
    for from_tid_np in unique_from_tids:
        from_tid = int(from_tid_np)
        if from_tid == 0:
            continue
        f_idx = tid_to_idx.get(from_tid)
        if f_idx is None:
            continue
        f_ts_list = ts_lists[f_idx]
        mask = from_tid_sorted == from_tid
        ts_for_from = ts_sorted[mask]
        # 对每个 ts_for_from 元素，在 f_ts_list 中找 < ts 的最大下标
        # searchsorted(side='left') 返回第一个 >= ts 的位置，-1 即为 < ts 的最大下标
        idx_in_f = np.searchsorted(f_ts_list, ts_for_from, side='left') - 1
        # 写回 prev_arr 对应位置
        prev_arr[mask] = idx_in_f

    # 将 prev 按 ref_tid 分组转回 Python list
    prev: Dict[int, List[int]] = {}
    for i in range(n_tids):
        tid = int(unique_tids[i])
        s = int(starts[i])
        e = int(ends[i])
        prev[tid] = [int(x) for x in prev_arr[s:e]]

    # 收集所有 itid（ref + from_itid），供外部一次性获取而无需遍历 events
    # numpy 去重：拼起来 unique 一次，比 Python set 快 ~3x 在 35 万行规模
    all_itids_np = np.unique(np.concatenate([ref_itid_arr, from_itid_arr]))
    all_itids = {int(x) for x in all_itids_np if int(x) != 0}

    tid_set = set(events.keys())
    return WakeupChainIndex(events, ts_only, prev, tid_set, all_itids)


def build_wakeup_index(sqlite_conn) -> WakeupChainIndex:
    """构建唤醒链全局索引。

    Args:
        sqlite_conn: SQLite 连接（trace.db）

    Returns:
        WakeupChainIndex 实例。sqlite_conn 为 None 或无 wakeup 事件时返回空索引。
    """
    if sqlite_conn is None:
        return WakeupChainIndex({}, {}, {}, set(), set())

    # Step 1: 单次 SQL 拉取全量 wakeup 事件
    try:
        rows = sqlite_conn.execute(
            "SELECT ref, wakeup_from, ts FROM instant "
            "WHERE name='sched_wakeup' AND wakeup_from > 0"
        ).fetchall()
    except Exception as e:
        log.debug(f"无法拉取 wakeup 事件: {e}")
        return WakeupChainIndex({}, {}, {}, set(), set())

    if not rows:
        return WakeupChainIndex({}, {}, {}, set(), set())

    # Step 2: 批量拉 itid→tid 映射
    itid_to_tid = _fetch_itid_to_tid(sqlite_conn)
    if not itid_to_tid:
        # 无 thread 表，所有 itid 映射为 0
        log.debug("itid→tid 映射为空，索引将全为 from_tid=0")

    # Step 3-6: 构建索引（numpy 优先，降级用 Python）
    if _HAS_NUMPY:
        try:
            return _build_index_numpy(rows, itid_to_tid)
        except Exception as e:
            log.debug(f"numpy 构建失败，降级 Python: {e}")
    return _build_index_python(rows, itid_to_tid)


def get_wakeup_index(sqlite_conn) -> WakeupChainIndex:
    """构建唤醒链全局索引。

    缓存由 TraceDataCache.wakeup_index() 统一管理（连接级单例），
    本函数只负责构建，不做缓存。

    Args:
        sqlite_conn: SQLite 连接

    Returns:
        WakeupChainIndex 实例
    """
    if sqlite_conn is None:
        return WakeupChainIndex({}, {}, {}, set(), set())

    return build_wakeup_index(sqlite_conn)
