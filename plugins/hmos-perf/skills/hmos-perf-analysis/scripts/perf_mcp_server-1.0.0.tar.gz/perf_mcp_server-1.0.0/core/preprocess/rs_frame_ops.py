"""RS 帧链路构建算子。

从 RS 渲染链路（SendVsyncTo → ReceiveVsync → Render）重建帧数据，
支持按 vsyncId 或时间范围筛选，基于 frame_rate 动态计算 jank severity。

输出格式：
{
    "rs_frames": [{
        "rsVsyncId": "vsyncId:745265",
        "start_ts": 51572462086670,
        "end_ts": 51572470420003,
        "dur_ms": 8.353,
        "jank_severity": "minor",
        "thread_list": [{"tid": 33461, "name": "rs"}],
        "process_name": "com.tencent.wechat",
        "package_name": "微信"
    }],
    "summary": {
        "total_frames": 50,
        "jank_count": 10,
        "minor_count": 5,
        "major_count": 3,
        "severe_count": 2
    }
}
"""
from __future__ import annotations

from core.observability import get_module_logger
import re
from typing import Any, Dict, List, Optional, Tuple

from .base import PreprocessContext, register_operator
from .frame_ops import load_tid_process_map
from utils.process_name import get_process_name
from .frame_rate_ops import _compute_jank_severity, _get_frame_rate_records, _match_frame_rate, clip_frame_overlaps

log = get_module_logger(__name__)

# ---------------------------------------------------------------------------
# 正则常量
# ---------------------------------------------------------------------------

# H:SendVsyncTo conn: rs, now:18273727806980
# Note: some traces have space after 'now:' colon, use \s* to be tolerant
SEND_VSYNC_RS_RE = re.compile(r'H:SendVsyncTo\s+conn:\s*rs,\s*now:\s*(\d+)')

# H:ReceiveVsync name:rs dataCount: 24bytes now: 18273727806980 expectedEnd: 18273744511742 vsyncId: 627321
# Note: some traces have space after 'now:' and 'vsyncId:' colons, use \s* to be tolerant
RECV_VSYNC_RS_RE = re.compile(
    r'H:ReceiveVsync\s+name:rs\s+dataCount:\s*\d+\s*bytes\s+now:\s*(\d+).*?expectedEnd:\s*(\d+).*?vsyncId:\s*(\d+)'
)

# H:Render vsyncId: 524136  (some traces have space after 'vsyncId:', use \s* to be tolerant)
RENDER_RE = re.compile(r'H:Render\s+vsyncId:\s*(\d+)')

# H:CommitLayers rate:72,now:18273736159911,vsyncId:524136,size:3
# Note: some traces have space after 'vsyncId:', use \s* to be tolerant
COMMIT_LAYERS_RE = re.compile(r'H:CommitLayers.*?vsyncId:\s*(\d+)')

# H:Acquire Fence 875492 (or H:Acquire Fence 875492|I38)
ACQUIRE_FENCE_RE = re.compile(r'H:Acquire\s+Fence\s+(\d+)')

# H:Waiting for Acquire Fence 875492 (or with |I38 suffix)
WAIT_ACQUIRE_FENCE_RE = re.compile(r'H:Waiting\s+for\s+Acquire\s+Fence\s+(\d+)')


# ---------------------------------------------------------------------------
# 解析函数
# ---------------------------------------------------------------------------


def _parse_send_vsync(name: str) -> Optional[int]:
    """解析 SendVsyncTo conn: rs, 返回 now_value。

    注意：ts 来自 SQL 查询的 callstack.ts，不是正则提取的。
    此函数仅从 name 中提取 now 值。

    Returns:
        now_value 或 None —— 调用方负责组装 ts
    """
    if not name:
        return None
    m = SEND_VSYNC_RS_RE.search(name)
    if m:
        return int(m.group(1))
    return None


def _parse_recv_vsync(name: str) -> Optional[Tuple[int, int, str]]:
    """解析 ReceiveVsync name:rs, 返回 (now_value, expected_end, rs_vsync_id)。

    ts 来自 SQL 查询的 callstack.ts。

    Returns:
        (now_value, expected_end, rs_vsync_id_str) 或 None
    """
    if not name:
        return None
    m = RECV_VSYNC_RS_RE.search(name)
    if m:
        now_value = int(m.group(1))
        expected_end = int(m.group(2))
        vsync_id_str = m.group(3)
        return (now_value, expected_end, vsync_id_str)
    return None


def _parse_render(name: str) -> Optional[int]:
    """解析 Render vsyncId:NNN, 返回 vsync_id。

    ts 和 dur 来自 SQL 查询的 callstack.ts / callstack.dur。

    Returns:
        vsync_id 数值 或 None
    """
    if not name:
        return None
    m = RENDER_RE.search(name)
    if m:
        return int(m.group(1))
    return None


def _parse_commit_layers(name: str) -> Optional[int]:
    """解析 H:CommitLayers ... vsyncId:NNN, 返回 vsync_id。

    用于和 Render 的 vsyncId 精确匹配。

    Returns:
        vsync_id 数值 或 None
    """
    if not name:
        return None
    m = COMMIT_LAYERS_RE.search(name)
    if m:
        return int(m.group(1))
    return None


def _parse_acquire_fence_id(name: str) -> Optional[int]:
    """解析 H:Acquire Fence <id>, 返回 fence_id。

    用于从 Render callstack 子树中提取 fence_id。
    """
    if not name:
        return None
    m = ACQUIRE_FENCE_RE.search(name)
    if m:
        return int(m.group(1))
    return None


def _parse_wait_acquire_fence_id(name: str) -> Optional[int]:
    """解析 H:Waiting for Acquire Fence <id>, 返回 fence_id。

    用于匹配 Acquire Fence 线程上的 GPU 等待事件。
    """
    if not name:
        return None
    m = WAIT_ACQUIRE_FENCE_RE.search(name)
    if m:
        return int(m.group(1))
    return None


# ---------------------------------------------------------------------------
# 匹配函数
# ---------------------------------------------------------------------------


def _match_send_recv(
    send_list: List[Tuple[int, int, int, str]],
    recv_list: List[Tuple[int, int, int, str, int, str, int]],
    time_window_ns: int = 1_000_000,
) -> List[Tuple[int, int, int, str, int, str, int]]:
    """通过 now 时间戳差 < 1ms 匹配 SendVsyncTo 和 ReceiveVsync。

    Args:
        send_list: [(ts, now_value, tid, thread_name), ...]
        recv_list: [(ts, now_value, expected_end, rs_vsync_id_str, tid, thread_name, dur), ...]
        time_window_ns: now 时间戳允许的最大偏差（默认 1ms）

    Returns:
        [(send_ts, recv_ts, expected_end, rs_vsync_id_str, recv_tid, recv_thread_name, recv_dur), ...]
    """
    result: List[Tuple[int, int, int, str, int, str, int]] = []
    used_recv: set = set()

    for s_ts, s_now, _s_tid, _s_thread_name in send_list:
        best_idx = -1
        best_diff = time_window_ns + 1

        for r_idx, (r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name, _r_dur) in enumerate(recv_list):
            if r_idx in used_recv:
                continue
            diff = abs(s_now - r_now)
            if diff < best_diff:
                best_diff = diff
                best_idx = r_idx

        if best_idx >= 0 and best_diff <= time_window_ns:
            used_recv.add(best_idx)
            r_ts, _r_now, r_end, r_vsync, r_tid, r_thread_name, r_dur = recv_list[best_idx]
            result.append((s_ts, r_ts, r_end, r_vsync, r_tid, r_thread_name, r_dur))

    return result


def _match_recv_render(
    recv_matched: List[Tuple[int, int, int, str, int, str, int]],
    render_list: List[Tuple[int, int, int, int, str]],
) -> List[Tuple[int, int, int, str, int, str, int, int, int, str]]:
    """通过 vsyncId 精确匹配 ReceiveVsync 和 Render。

    Args:
        recv_matched: [(send_ts, recv_ts, expected_end, rs_vsync_id_str, recv_tid, recv_thread_name, recv_dur), ...]
        render_list: [(ts, dur, vsync_id_int, tid, thread_name), ...]

    Returns:
        [(send_ts, recv_ts, expected_end, rs_vsync_id_str, recv_tid, recv_thread_name, recv_dur,
          render_ts, render_dur, render_tid, render_thread_name), ...]
        如果没有匹配到 Render，render_ts/render_dur/render_tid/render_thread_name 为 0
    """
    result: List[Tuple[int, int, int, str, int, str, int, int, int, int, str]] = []
    used_render: set = set()

    for s_ts, r_ts, r_end, r_vsync_str, r_tid, r_thread_name, r_dur in recv_matched:
        best_idx = -1
        # vsyncId 精确匹配
        for r_idx, (re_ts, re_dur, re_vsync, re_tid, re_thread_name) in enumerate(render_list):
            if r_idx in used_render:
                continue
            if str(re_vsync) == r_vsync_str:
                best_idx = r_idx
                break

        if best_idx >= 0:
            used_render.add(best_idx)
            re_ts, re_dur, _re_vsync, re_tid, re_thread_name = render_list[best_idx]
            result.append((s_ts, r_ts, r_end, r_vsync_str, r_tid, r_thread_name, r_dur,
                           re_ts, re_dur, re_tid, re_thread_name))
        else:
            # 没有 Render 匹配，保留 recv 信息
            result.append((s_ts, r_ts, r_end, r_vsync_str, r_tid, r_thread_name, r_dur,
                           0, 0, 0, ""))

    return result


def _match_send_render(
    send_list: List[Tuple[int, int, int, str]],
    render_list: List[Tuple[int, int, int, int, str]],
    time_window_ns: int = 5_000_000,
) -> List[Tuple[int, int, int, str, int, str]]:
    """通过时间窗口匹配 SendVsyncTo 和 Render（用于没有 ReceiveVsync 的帧）。

    Args:
        send_list: [(ts, now_value, tid, thread_name), ...]
        render_list: [(ts, dur, vsync_id_int, tid, thread_name), ...]
        time_window_ns: SendVsyncTo 和 Render 之间允许的最大时间差（默认 5ms）

    Returns:
        [(send_ts, render_ts, render_dur, render_vsync_id_str, render_tid, render_thread_name), ...]
    """
    result: List[Tuple[int, int, int, str, int, str]] = []
    used_render: set = set()

    for s_ts, s_now, _s_tid, _s_thread_name in send_list:
        best_idx = -1
        best_diff = time_window_ns + 1

        for r_idx, (re_ts, re_dur, re_vsync, re_tid, re_thread_name) in enumerate(render_list):
            if r_idx in used_render:
                continue
            # 使用 SendVsyncTo 的 ts 和 Render 的 ts 计算时间差
            diff = abs(s_ts - re_ts)
            if diff < best_diff:
                best_diff = diff
                best_idx = r_idx

        if best_idx >= 0 and best_diff <= time_window_ns:
            used_render.add(best_idx)
            re_ts, re_dur, re_vsync, re_tid, re_thread_name = render_list[best_idx]
            result.append((s_ts, re_ts, re_dur, str(re_vsync), re_tid, re_thread_name))

    return result


def _match_render_commit(
    render_list: List[Tuple[int, int, int, int, str]],
    commit_list: List[Tuple[int, int, int, int, str]],
) -> Dict[int, Tuple[int, int, int, str]]:
    """通过 vsyncId 精确匹配 Render 和 CommitLayers。

    Args:
        render_list: [(ts, dur, vsync_id_int, tid, thread_name), ...]
        commit_list: [(ts, dur, vsync_id_int, tid, thread_name), ...]

    Returns:
        {render_vsync_id_int: (commit_ts, commit_dur, commit_tid, commit_thread_name), ...}
        未匹配的 render 不在字典中。
    """
    result: Dict[int, Tuple[int, int, int, str]] = {}
    used_commit: set = set()

    for _re_ts, _re_dur, re_vsync, _re_tid, _re_thread_name in render_list:
        for c_idx, (c_ts, c_dur, c_vsync, c_tid, c_thread_name) in enumerate(commit_list):
            if c_idx in used_commit:
                continue
            if c_vsync == re_vsync:
                used_commit.add(c_idx)
                result[re_vsync] = (c_ts, c_dur, c_tid, c_thread_name)
                break

    return result


def _find_acquire_fence_tids(
    conn,
    render_ts: int,
    render_dur: int,
    render_callid: int,
    fence_cache: Optional[Dict[int, List[Tuple[int, str, int]]]] = None,
) -> List[Tuple[int, str, int]]:
    """从 Render 帧 callstack 子树中提取 H:Acquire Fence <id> 的 fence_id，
    然后用 fence_id 精确匹配 H:Waiting for Acquire Fence <id> 事件，
    返回对应的 Acquire Fence 线程 (tid, thread_name, dur_ns) 列表。

    callstack 父子关系：
        H:Render vsyncId:xxx
          └─ H:RenderFrame
               └─ H:Acquire Fence <id>          ← fence_id
        另一个线程上:
          H:Waiting for Acquire Fence <id>      ← 同一 fence_id

    Args:
        conn: SQLite 连接
        render_ts: Render 事件 ts（用于辅助定位）
        render_dur: Render 事件 dur
        render_callid: Render 事件的 callid（用于从子树查找）
        fence_cache: 预加载的 {fence_id: [(tid, thread_name, dur_ns), ...]} 映射（可选）
                     如果提供，跳过 SQL 查询直接从缓存查找

    Returns:
        [(tid, thread_name, dur_ns), ...] Acquire Fence 线程列表（去重）
        dur_ns 是该线程上 Waiting for Acquire Fence 事件耗时，用于 thread_list 排序
    """
    # 如果有预加载缓存，直接用时间窗口匹配 fence_id（完全内存操作）
    if fence_cache is not None:
        return _find_acquire_fence_tids_from_cache(render_ts, render_dur, fence_cache)

    if not render_callid:
        return []

    # 无缓存时的回退方案（单帧查询，性能较差）
    acquire_fence_ids: set = set()
    try:
        if render_dur is None or render_dur <= 0:
            return []
        render_end = render_ts + render_dur
        acq_end = render_end + 50_000_000  # 50ms

        acq_sql = """
            SELECT c.id, c.ts, c.dur, c.name, c.parent_id, c.callid
            FROM callstack c
            WHERE c.name LIKE 'H:Acquire Fence%'
              AND c.ts >= ? AND c.ts < ?
        """
        acq_rows = conn.execute(acq_sql, (render_ts, acq_end)).fetchall()

        for _c_id, _c_ts, _c_dur, c_name, _c_parent_id, _c_callid in acq_rows:
            fence_id = _parse_acquire_fence_id(c_name)
            if fence_id is not None:
                if _is_in_render_subtree(conn, _c_id, render_ts, render_dur):
                    acquire_fence_ids.add(fence_id)

    except Exception as e:
        log.warning("_find_acquire_fence_tids: Step A 查询失败: %s", e)
        return []

    if not acquire_fence_ids:
        return []

    result: List[Tuple[int, str, int]] = []
    seen_tids: set = set()
    for fence_id in acquire_fence_ids:
        wait_sql = """
            SELECT DISTINCT t.tid, t.name as thread_name, MAX(c.dur) as max_dur
            FROM callstack c
            JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE ?
            GROUP BY t.tid, t.name
            LIMIT 5
        """
        pattern = f"H:Waiting for Acquire Fence {fence_id}%"
        try:
            wait_rows = conn.execute(wait_sql, (pattern,)).fetchall()
        except Exception as e:
            log.warning("_find_acquire_fence_tids: Step B 查询 fence_id=%s 失败: %s", fence_id, e)
            continue
        for tid, thread_name, max_dur in wait_rows:
            if tid and tid not in seen_tids:
                result.append((tid, thread_name or "", max_dur or 0))
                seen_tids.add(tid)

    return result


def _load_fence_cache(conn) -> Dict[int, List[Tuple[int, str, int]]]:
    """预加载所有 H:Acquire Fence 和 H:Waiting for Acquire Fence 事件到内存映射。

    返回:
        {fence_id: [(tid, thread_name, dur_ns), ...]} 映射
        dur_ns 是 H:Waiting for Acquire Fence 事件耗时，用于 thread_list 排序
    """
    cache: Dict[int, List[Tuple[int, str, int]]] = {}
    try:
        # 一次性加载所有 H:Waiting for Acquire Fence 事件
        wait_sql = """
            SELECT c.name, c.dur, t.tid, t.name as thread_name
            FROM callstack c
            JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE 'H:Waiting for Acquire Fence%'
        """
        wait_rows = conn.execute(wait_sql).fetchall()
        for name, dur, tid, thread_name in wait_rows:
            fence_id = _parse_wait_acquire_fence_id(name)
            if fence_id is not None and tid:
                cache.setdefault(fence_id, []).append((tid, thread_name or "", dur or 0))
        log.info("_load_fence_cache: 加载 %d 个 H:Waiting for Acquire Fence 事件, %d 个 fence_id",
                 len(wait_rows), len(cache))
    except Exception as e:
        log.warning("_load_fence_cache: 加载失败: %s", e)
    return cache


def _find_acquire_fence_tids_from_cache(
    render_ts: int,
    render_dur: int,
    fence_cache: Dict[int, List[Tuple[int, str, int]]],
) -> List[Tuple[int, str, int]]:
    """从预加载的缓存中查找 Render 帧对应的 Acquire Fence 线程。

    使用 fence_id 匹配（完全内存操作，无 SQL 查询）。

    Args:
        render_ts: Render 事件 ts（未使用，保留接口兼容）
        render_dur: Render 事件 dur（未使用，保留接口兼容）
        fence_cache: {fence_id: [(tid, thread_name, dur_ns), ...]} 预加载映射

    Returns:
        [(tid, thread_name, dur_ns), ...] Acquire Fence 线程列表（去重）
        dur_ns 是该线程上所有 Waiting for Acquire Fence 事件的最大耗时

    说明:
        由于 H:Waiting for Acquire Fence 通常只在一个 Acquire Fence 线程上，
        且 SQL6 用 t.tid = :tid 过滤，只有 Acquire Fence 线程条目才命中 GPU 等待，
        所以这里直接返回所有缓存中的 Acquire Fence 线程（去重）。
        dur_ns 取该线程上所有 fence 事件的最大耗时，用于 thread_list 排序。
    """
    if not fence_cache:
        return []

    # tid → (thread_name, max_dur_ns)
    tid_map: Dict[int, Tuple[str, int]] = {}
    for fence_id, tid_list in fence_cache.items():
        for tid, thread_name, dur_ns in tid_list:
            if tid not in tid_map or dur_ns > tid_map[tid][1]:
                tid_map[tid] = (thread_name, dur_ns)

    return [(tid, name, dur) for tid, (name, dur) in tid_map.items()]


def _is_in_render_subtree(
    conn,
    acq_id: int,
    render_ts: int,
    render_dur: int,
    max_depth: int = 30,
) -> bool:
    """沿 parent_id 链向上查找，判断 Acquire Fence 节点是否在 Render 子树中。

    判断标准：祖先节点中存在 H:Render vsyncId: 且 ts 在 [render_ts, render_ts+render_dur] 范围内。

    Args:
        conn: SQLite 连接
        acq_id: Acquire Fence 的 callstack.id
        render_ts: Render 事件 ts
        render_dur: Render 事件 dur
        max_depth: 最大递归深度（防止循环引用）

    Returns:
        True 如果在 Render 子树中
    """
    if max_depth <= 0:
        return False

    current_id = acq_id
    render_end = render_ts + (render_dur or 0)

    for _ in range(max_depth):
        try:
            row = conn.execute(
                "SELECT name, parent_id, ts FROM callstack WHERE id = ?",
                (current_id,),
            ).fetchone()
        except Exception:
            return False
        if not row:
            return False
        name, parent_id, ts = row
        # 如果当前节点本身就是 Render 节点，且 ts 在 Render 范围内
        if name and "H:Render" in name and "vsyncId:" in name:
            if ts is not None and render_ts <= ts <= render_end:
                return True
        if not parent_id or parent_id <= 0:
            return False
        current_id = parent_id

    return False


# ---------------------------------------------------------------------------
# 算子实现
# ---------------------------------------------------------------------------


@register_operator("build_rs_frames")
def build_rs_frames(ctx: PreprocessContext) -> PreprocessContext:
    """构建 RS 帧链路（SendVsyncTo → ReceiveVsync → Render）。

    参数（来自 ctx.params）：
    - rs_vsync_ids: list | None，帧号列表 ["vsyncId:745265"]，非空时按帧号筛选
    - start_ts: int | None，时间范围起始 ns
    - end_ts: int | None，时间范围结束 ns
    - frame_rate: int = 60

    rs_vsync_ids 优先于 start_ts/end_ts：
    - rs_vsync_ids 非空时，按帧号筛选（通过匹配 ReceiveVsync 的 vsyncId 缩小查询范围）
    - rs_vsync_ids 为空时，按 start_ts/end_ts 时间范围筛选

    输出 ctx.data:
    {
        "rs_frames": [{
            "rsVsyncId": "vsyncId:745265",
            "start_ts": 51572462086670,
            "end_ts": 51572470420003,
            "dur_ms": 8.353,
            "jank_severity": "minor",
            "thread_list": [{"tid": 33461, "name": "rs"}],
            "process_name": "com.tencent.wechat",
            "package_name": "微信"
        }],
        "summary": {
            "total_frames": 50,
            "jank_count": 10,
            "minor_count": 5,
            "major_count": 3,
            "severe_count": 2
        }
    }
    """
    # sqlite_conn 为 None 时返回空数据
    if not ctx.sqlite_conn:
        ctx.data = _empty_result()
        return ctx

    conn = ctx.sqlite_conn
    params = ctx.params

    rs_vsync_ids: Optional[List[str]] = params.get("rs_vsync_ids")
    start_ts: Optional[int] = params.get("start_ts")
    end_ts: Optional[int] = params.get("end_ts")
    default_frame_rate: int = int(params.get("frame_rate", 60))
    # 优先从 ctx.meta 读取帧率记录（由上游算子注入）
    frame_rate_records: Optional[List[Dict[str, Any]]] = ctx.meta.get("frame_rate_records")
    # 如果为空，调用公共函数查询
    if not frame_rate_records:
        frame_rate_records = _get_frame_rate_records(conn)

    # 预加载 tid → process_name 映射（用于帧的 process_name/package_name 字段）
    tid_process_map = load_tid_process_map(conn)

    try:
        # -------------------- 1. 查询 SendVsyncTo conn: rs --------------------
        send_sql = """
            SELECT c.id, c.ts, c.dur, c.name, t.tid, t.name as thread_name
            FROM callstack c
            LEFT JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE '%H:SendVsyncTo conn: rs%'
        """
        send_rows = conn.execute(send_sql).fetchall()
        log.info("build_rs_frames: SendVsyncTo 行数=%d", len(send_rows))

        send_list: List[Tuple[int, int, int, str]] = []  # (ts, now_value, tid, thread_name)
        for row in send_rows:
            _id, ts, _dur, name, tid, thread_name = row
            now_val = _parse_send_vsync(name)
            if now_val is not None:
                send_list.append((ts, now_val, tid, thread_name))

        # -------------------- 2. 查询 ReceiveVsync name:rs --------------------
        recv_sql = """
            SELECT c.id, c.ts, c.dur, c.name, t.tid, t.name as thread_name
            FROM callstack c
            LEFT JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE '%H:ReceiveVsync name:rs%'
        """
        recv_rows = conn.execute(recv_sql).fetchall()
        log.info("build_rs_frames: ReceiveVsync 行数=%d", len(recv_rows))

        recv_list: List[Tuple[int, int, int, str, int, str, int]] = []  # (ts, now_value, expected_end, vsync_id_str, tid, thread_name, dur)
        for row in recv_rows:
            _id, ts, dur, name, tid, thread_name = row
            parsed = _parse_recv_vsync(name)
            if parsed is not None:
                now_val, expected_end, vsync_id_str = parsed
                recv_list.append((ts, now_val, expected_end, vsync_id_str, tid, thread_name, dur))

        # -------------------- 3. 查询 Render vsyncId: --------------------
        render_sql = """
            SELECT c.id, c.ts, c.dur, c.name, c.callid, t.tid, t.name as thread_name
            FROM callstack c
            LEFT JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE '%H:Render vsyncId:%'
        """
        render_rows = conn.execute(render_sql).fetchall()
        log.info("build_rs_frames: Render 行数=%d", len(render_rows))

        # render_list: (ts, dur, vsync_id_int, tid, thread_name, callid)
        # callid 用于后续子树查询（Acquire Fence 提取）
        render_list: List[Tuple[int, int, int, int, str, int]] = []
        for row in render_rows:
            _id, ts, dur, name, callid, tid, thread_name = row
            vsync_id = _parse_render(name)
            if vsync_id is not None:
                render_list.append((ts, dur, vsync_id, tid or 0, thread_name or "", callid or 0))

        # -------------------- 3.1 查询 CommitLayers --------------------
        commit_sql = """
            SELECT c.ts, c.dur, c.name, t.tid, t.name as thread_name
            FROM callstack c
            LEFT JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE '%H:CommitLayers%'
        """
        commit_rows = conn.execute(commit_sql).fetchall()
        log.info("build_rs_frames: CommitLayers 行数=%d", len(commit_rows))

        commit_list: List[Tuple[int, int, int, int, str]] = []  # (ts, dur, vsync_id_int, tid, thread_name)
        for row in commit_rows:
            ts, dur, name, tid, thread_name = row
            vsync_id = _parse_commit_layers(name)
            if vsync_id is not None:
                commit_list.append((ts, dur or 0, vsync_id, tid or 0, thread_name or ""))

        # -------------------- 3.2 预加载 Acquire Fence 缓存（避免 N² 查询）--------------------
        fence_cache: Optional[Dict[int, List[Tuple[int, str]]]] = _load_fence_cache(conn)

        # -------------------- 4. 匹配 Send → Recv → Render --------------------
        # render_list 6 元组（含 callid），匹配函数接受 5 元组，需投影
        render_list_5: List[Tuple[int, int, int, int, str]] = [
            (ts, dur, vsync, tid, tname) for ts, dur, vsync, tid, tname, _callid in render_list
        ]
        # vsync_id → render entry（含 callid），用于后续 Acquire Fence 子树查询
        render_by_vsync: Dict[int, Tuple[int, int, int, int, str, int]] = {
            entry[2]: entry for entry in render_list
        }

        matched_sr = _match_send_recv(send_list, recv_list)
        matched_all = _match_recv_render(matched_sr, render_list_5)

        log.info(
            "build_rs_frames: 匹配结果 send=%d, recv=%d, matched_sr=%d, matched_all=%d",
            len(send_list), len(recv_list), len(matched_sr), len(matched_all),
        )

        # -------------------- 4.1 匹配 Render → CommitLayers (通过 vsyncId) --------------------
        render_commit_map = _match_render_commit(render_list_5, commit_list)
        log.info(
            "build_rs_frames: Render→CommitLayers 匹配=%d / render=%d / commit=%d",
            len(render_commit_map), len(render_list), len(commit_list),
        )

        # -------------------- 4.5. 匹配 Send → Render (用于没有 ReceiveVsync 的帧) --------------------
        # 找出未匹配的 SendVsyncTo 事件
        matched_send_ts = {s_ts for s_ts, _, _, _, _, _, _, _, _, _, _ in matched_all}
        unmatched_send = [s for s in send_list if s[0] not in matched_send_ts]

        # 使用 _match_send_render 匹配这些未匹配的 SendVsyncTo
        matched_send_render = _match_send_render(unmatched_send, render_list_5)

        log.info(
            "build_rs_frames: Send→Render 匹配结果 unmatched_send=%d, matched_send_render=%d",
            len(unmatched_send), len(matched_send_render),
        )

        # -------------------- 5. 筛选 vs rs_vsync_ids / start_ts / end_ts --------------------
        # 如果 rs_vsync_ids 非空，提取数值集合用于过滤
        target_vsync_ids: Optional[set] = None
        if rs_vsync_ids:
            target_vsync_ids = set()
            for vid in rs_vsync_ids:
                # 兼容整数和字符串类型的 vsyncId
                vid_str = str(vid)
                # "vsyncId:745265" → "745265"
                numeric = vid_str.replace("vsyncId:", "") if vid_str.startswith("vsyncId:") else vid_str
                target_vsync_ids.add(numeric)

        rs_frames: List[Dict[str, Any]] = []

        # 处理主路径匹配的帧 (Send → Recv → Render)
        for (s_ts, r_ts, expected_end, rs_vsync_id_str, recv_tid, recv_thread_name, recv_dur,
             render_ts, render_dur, render_tid, render_thread_name) in matched_all:
            # rs_vsync_ids 优先筛选
            if target_vsync_ids is not None:
                if rs_vsync_id_str not in target_vsync_ids:
                    continue
            else:
                # 时间范围筛选（基于 SendVsyncTo 的 ts）
                if start_ts is not None and s_ts < start_ts:
                    continue
                if end_ts is not None and s_ts > end_ts:
                    continue

            # start_ts = SendVsyncTo 的 callstack.ts
            frame_start_ts = s_ts

            # 查找 CommitLayers 匹配（通过 vsyncId）
            rs_vsync_int = int(rs_vsync_id_str) if rs_vsync_id_str.isdigit() else 0
            commit_match = render_commit_map.get(rs_vsync_int)
            commit_ts = 0
            commit_dur = 0
            commit_tid = 0
            commit_thread_name = ""
            if commit_match:
                commit_ts, commit_dur, commit_tid, commit_thread_name = commit_match

            # end_ts 优先用 CommitLayers 结束（覆盖 GPU 执行区间），
            # 回退到 Render 结束，再回退到 ReceiveVsync 结束
            if commit_ts and commit_dur and commit_ts > 0 and commit_dur > 0:
                frame_end_ts = commit_ts + commit_dur
            elif render_ts and render_dur and render_ts > 0 and render_dur > 0:
                frame_end_ts = render_ts + render_dur
            else:
                # 回退方案：使用 ReceiveVsync 的 (ts + dur)
                frame_end_ts = r_ts + (recv_dur or 0)

            dur_ms = round((frame_end_ts - frame_start_ts) / 1_000_000, 3)

            # 收集线程信息（去重），每个线程附带自身耗时用于后续 Top N 截断
            thread_list: List[Dict[str, Any]] = []
            seen_tids: set = set()
            # RecvVsync 的线程（耗时 = recv_dur）
            if recv_tid and recv_tid not in seen_tids:
                thread_list.append({"tid": recv_tid, "name": recv_thread_name,
                                    "dur_ms": round((recv_dur or 0) / 1_000_000, 3)})
                seen_tids.add(recv_tid)
            # Render 的线程（耗时 = render_dur）
            if render_tid and render_tid not in seen_tids:
                thread_list.append({"tid": render_tid, "name": render_thread_name,
                                    "dur_ms": round((render_dur or 0) / 1_000_000, 3)})
                seen_tids.add(render_tid)
            # CommitLayers 的线程（通常是 CompThread_0，耗时 = commit_dur）
            if commit_tid and commit_tid not in seen_tids:
                thread_list.append({"tid": commit_tid, "name": commit_thread_name,
                                    "dur_ms": round((commit_dur or 0) / 1_000_000, 3)})
                seen_tids.add(commit_tid)
            # Acquire Fence 线程（GPU 等待的直接载体，通过 fence ID 精确匹配）
            render_entry = render_by_vsync.get(rs_vsync_int)
            if render_entry:
                _re_ts, _re_dur, _re_vsync, _re_tid, _re_tname, re_callid = render_entry
                acquire_fence_tids = _find_acquire_fence_tids(
                    conn, _re_ts, _re_dur, re_callid, fence_cache=fence_cache,
                )
                for acq_tid, acq_tname, acq_dur_ns in acquire_fence_tids:
                    if acq_tid and acq_tid not in seen_tids:
                        thread_list.append({"tid": acq_tid, "name": acq_tname,
                                            "dur_ms": round((acq_dur_ns or 0) / 1_000_000, 3)})
                        seen_tids.add(acq_tid)

            # 使用动态帧率计算 severity
            effective_rate = _match_frame_rate(frame_start_ts, frame_rate_records)
            if effective_rate is None:
                effective_rate = default_frame_rate
            severity = _compute_jank_severity(dur_ms, float(effective_rate))

            # RS 帧的进程名：H:ReceiveVsync name:rs 事件对应的线程所属进程
            _proc_name = tid_process_map.get(recv_tid, "")
            rs_frames.append({
                "rsVsyncId": f"vsyncId:{rs_vsync_id_str}",
                "start_ts": frame_start_ts,
                "end_ts": frame_end_ts,
                "dur_ms": dur_ms,
                "jank_severity": severity,
                "frame_rate": int(effective_rate),
                "thread_list": thread_list,
                "process_name": _proc_name,
                "package_name": get_process_name(_proc_name) if _proc_name else "",
            })

        # 处理后备路径匹配的帧 (Send → Render，没有 ReceiveVsync)
        for (s_ts, render_ts, render_dur, rs_vsync_id_str, render_tid, render_thread_name) in matched_send_render:
            # rs_vsync_ids 优先筛选
            if target_vsync_ids is not None:
                if rs_vsync_id_str not in target_vsync_ids:
                    continue
            else:
                # 时间范围筛选（基于 SendVsyncTo 的 ts）
                if start_ts is not None and s_ts < start_ts:
                    continue
                if end_ts is not None and s_ts > end_ts:
                    continue

            # start_ts = SendVsyncTo 的 callstack.ts
            frame_start_ts = s_ts

            # 查找 CommitLayers 匹配（通过 vsyncId）
            rs_vsync_int = int(rs_vsync_id_str) if rs_vsync_id_str.isdigit() else 0
            commit_match = render_commit_map.get(rs_vsync_int)
            commit_ts = 0
            commit_dur = 0
            commit_tid = 0
            commit_thread_name = ""
            if commit_match:
                commit_ts, commit_dur, commit_tid, commit_thread_name = commit_match

            # end_ts 优先用 CommitLayers 结束，回退到 Render 结束
            if commit_ts and commit_dur and commit_ts > 0 and commit_dur > 0:
                frame_end_ts = commit_ts + commit_dur
            else:
                frame_end_ts = render_ts + render_dur

            dur_ms = round((frame_end_ts - frame_start_ts) / 1_000_000, 3)

            # 收集线程信息（去重），每个线程附带自身耗时用于后续 Top N 截断
            thread_list: List[Dict[str, Any]] = []
            seen_tids: set = set()
            # Render 的线程（耗时 = render_dur）
            if render_tid and render_tid not in seen_tids:
                thread_list.append({"tid": render_tid, "name": render_thread_name,
                                    "dur_ms": round((render_dur or 0) / 1_000_000, 3)})
                seen_tids.add(render_tid)
            # CommitLayers 的线程（通常是 CompThread_0，耗时 = commit_dur）
            if commit_tid and commit_tid not in seen_tids:
                thread_list.append({"tid": commit_tid, "name": commit_thread_name,
                                    "dur_ms": round((commit_dur or 0) / 1_000_000, 3)})
                seen_tids.add(commit_tid)
            # Acquire Fence 线程（GPU 等待的直接载体，通过 fence ID 精确匹配）
            render_entry = render_by_vsync.get(rs_vsync_int)
            if render_entry:
                _re_ts, _re_dur, _re_vsync, _re_tid, _re_tname, re_callid = render_entry
                acquire_fence_tids = _find_acquire_fence_tids(
                    conn, _re_ts, _re_dur, re_callid, fence_cache=fence_cache,
                )
                for acq_tid, acq_tname, acq_dur_ns in acquire_fence_tids:
                    if acq_tid and acq_tid not in seen_tids:
                        thread_list.append({"tid": acq_tid, "name": acq_tname,
                                            "dur_ms": round((acq_dur_ns or 0) / 1_000_000, 3)})
                        seen_tids.add(acq_tid)

            # 使用动态帧率计算 severity
            effective_rate = _match_frame_rate(frame_start_ts, frame_rate_records)
            if effective_rate is None:
                effective_rate = default_frame_rate
            severity = _compute_jank_severity(dur_ms, float(effective_rate))

            # 后备路径 RS 帧的进程名：H:Render 事件对应的线程所属进程
            _proc_name = tid_process_map.get(render_tid, "")
            rs_frames.append({
                "rsVsyncId": f"vsyncId:{rs_vsync_id_str}",
                "start_ts": frame_start_ts,
                "end_ts": frame_end_ts,
                "dur_ms": dur_ms,
                "jank_severity": severity,
                "frame_rate": int(effective_rate),
                "thread_list": thread_list,
                "process_name": _proc_name,
                "package_name": get_process_name(_proc_name) if _proc_name else "",
            })

        # -------------------- 5.5 帧范围裁剪：防止流水线重叠 --------------------
        # 前一帧未完成时，当前帧的 vsync 已下发，start_ts 可能早于上一帧 end_ts，
        # 导致查询窗口包含上一帧数据。裁剪并重算 severity。
        clip_frame_overlaps(rs_frames, frame_rate_records, default_frame_rate)

        # -------------------- 6. 统计摘要 --------------------
        total_frames = len(rs_frames)
        normal_count = sum(1 for f in rs_frames if f["jank_severity"] == "normal")
        minor_count = sum(1 for f in rs_frames if f["jank_severity"] == "minor")
        major_count = sum(1 for f in rs_frames if f["jank_severity"] == "major")
        severe_count = sum(1 for f in rs_frames if f["jank_severity"] == "severe")
        jank_count = minor_count + major_count + severe_count

        ctx.data = {
            "rs_frames": rs_frames,
            "summary": {
                "total_frames": total_frames,
                "jank_count": jank_count,
                "normal_count": normal_count,
                "minor_count": minor_count,
                "major_count": major_count,
                "severe_count": severe_count,
            },
        }

        log.info(
            "build_rs_frames: 完成, total=%d, normal=%d, minor=%d, major=%d, severe=%d",
            total_frames, normal_count, minor_count, major_count, severe_count,
        )

    except Exception as e:
        log.error("build_rs_frames: 执行失败: %s", e)
        ctx.data = _empty_result()

    return ctx


def _empty_result() -> Dict[str, Any]:
    """返回空结果结构。"""
    return {
        "rs_frames": [],
        "summary": {
            "total_frames": 0,
            "jank_count": 0,
            "normal_count": 0,
            "minor_count": 0,
            "major_count": 0,
            "severe_count": 0,
        },
    }
