"""Flutter 帧链路构建算子。

从 Flutter 渲染链路（SendVsyncTo → ReceiveVsync → VsyncProcessCallback → DrawToSurfaces）重建帧数据，
支持按 vsyncId 或时间范围筛选，基于 frame_rate 动态计算 jank severity。

    输出格式：
{
    "flutter_frames": [{
        "flutterVsyncId": "vsyncId:745265",
        "start_ts": 51572462086670,
        "end_ts": 51572470420003,
        "dur_ms": 8.353,
        "jank_severity": "minor",
        "thread_list": [{"tid": 33461, "name": "1.ui"}],
        "process_name": "com.tencent.wechat",
        "package_name": "微信"
    }],
    "summary": {
        "total_frames": 50,
        "jank_count": 10,
        "minor_count": 5,
        "major_count": 3,
        "severe_count": 2
    }
}
"""
from __future__ import annotations

from core.observability import get_module_logger
import re
from typing import Any, Dict, List, Optional, Tuple

from .base import PreprocessContext, register_operator
from .frame_ops import load_tid_process_map
from utils.process_name import get_process_name
from .frame_rate_ops import _compute_jank_severity, _get_frame_rate_records, _match_frame_rate, clip_frame_overlaps

log = get_module_logger(__name__)

# ---------------------------------------------------------------------------
# 正则常量
# ---------------------------------------------------------------------------

# H:SendVsyncTo conn: flutterSyncName, now:18273727806980
# Note: some traces have space after 'now:', use \s* to be tolerant
SEND_VSYNC_FLUTTER_RE = re.compile(r'H:SendVsyncTo\s+conn:\s*(\S+),\s*now:\s*(\d+)')

# H:ReceiveVsync name:flutterSyncName dataCount: 24bytes now:18273727806980 expectedEnd: 18273744511742 vsyncId: 627321
# Note: some traces have space after 'now:' colon, use \s* to be tolerant
RECV_VSYNC_FLUTTER_RE = re.compile(
    r'H:ReceiveVsync\s+name:\s*(\S+)\s+dataCount:\s*\d+\s*bytes\s+now:\s*(\d+).*?expectedEnd:\s*(\d+).*?vsyncId:\s*(\d+)'
)

# flutter::VsyncProcessCallback StartTime:XXX TargetTime:XXX|M62
VSYNC_CALLBACK_RE = re.compile(
    r'flutter::VsyncProcessCallback\s+StartTime:(\d+)\s+TargetTime:(\d+)'
)

# flutter::Rasterizer::DrawToSurfaces|M62
DRAW_TO_SURFACES_RE = re.compile(r'flutter::Rasterizer::DrawToSurfaces')


# ---------------------------------------------------------------------------
# 解析函数
# ---------------------------------------------------------------------------


def _parse_send_vsync(name: str) -> Optional[int]:
    """解析 SendVsyncTo conn: flutterSyncName, 返回 now_value。

    Args:
        name: callstack.name 字符串

    Returns:
        now_value 或 None
    """
    if not name:
        return None
    m = SEND_VSYNC_FLUTTER_RE.search(name)
    if m:
        return int(m.group(2))
    return None


def _parse_recv_vsync(name: str) -> Optional[Tuple[int, int, str]]:
    """解析 ReceiveVsync name:flutterSyncName, 返回 (now_value, expected_end, vsync_id)。

    Args:
        name: callstack.name 字符串

    Returns:
        (now_value, expected_end, vsync_id_str) 或 None
    """
    if not name:
        return None
    m = RECV_VSYNC_FLUTTER_RE.search(name)
    if m:
        now_value = int(m.group(2))
        expected_end = int(m.group(3))
        vsync_id_str = m.group(4)
        return (now_value, expected_end, vsync_id_str)
    return None


def _parse_vsync_callback(name: str) -> Optional[Tuple[int, int]]:
    """解析 flutter::VsyncProcessCallback StartTime:XXX TargetTime:XXX。

    Args:
        name: callstack.name 字符串

    Returns:
        (start_time, target_time) 或 None
    """
    if not name:
        return None
    m = VSYNC_CALLBACK_RE.search(name)
    if m:
        start_time = int(m.group(1))
        target_time = int(m.group(2))
        return (start_time, target_time)
    return None


def _parse_draw_to_surfaces(name: str) -> bool:
    """解析 flutter::Rasterizer::DrawToSurfaces。

    Args:
        name: callstack.name 字符串

    Returns:
        True 或 False
    """
    if not name:
        return False
    return DRAW_TO_SURFACES_RE.search(name) is not None


# ---------------------------------------------------------------------------
# 匹配函数
# ---------------------------------------------------------------------------


def _match_send_recv(
    send_list: List[Tuple[int, int, int, str]],
    recv_list: List[Tuple[int, int, int, str, int, str]],
    time_window_ns: int = 1_000_000,
) -> List[Tuple[int, int, int, int, str, int, str]]:
    """通过 now 时间戳差 < time_window_ns 匹配 SendVsyncTo 和 ReceiveVsync。

    Args:
        send_list: [(ts, now_value, tid, thread_name), ...]
        recv_list: [(ts, now_value, expected_end, vsync_id_str, tid, thread_name), ...]
        time_window_ns: now 时间戳允许的最大偏差（默认 1ms）

    Returns:
        [(send_ts, recv_ts, recv_now, expected_end, vsync_id_str, recv_tid, recv_thread_name), ...]
        recv_now 保留 Flutter 时钟的 now 值，供下游 _match_recv_callback 精确匹配使用。
    """
    result: List[Tuple[int, int, int, int, str, int, str]] = []
    used_recv: set = set()

    for s_ts, s_now, _s_tid, _s_thread_name in send_list:
        best_idx = -1
        best_diff = time_window_ns + 1

        for r_idx, (r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name) in enumerate(recv_list):
            if r_idx in used_recv:
                continue
            diff = abs(s_now - r_now)
            if diff < best_diff:
                best_diff = diff
                best_idx = r_idx

        if best_idx >= 0 and best_diff <= time_window_ns:
            used_recv.add(best_idx)
            r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name = recv_list[best_idx]
            result.append((s_ts, r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name))

    return result


def _match_recv_callback(
    recv_list: List[Tuple[int, int, int, int, str, int, str]],
    callback_list: List[Tuple[int, int, int, int, int, str]],
    time_window_ns: int = 50_000_000,
) -> List[Tuple[int, int, int, int, str, int, str, int, int, int, int, int, str]]:
    """匹配 ReceiveVsync 和 VsyncProcessCallback。

    匹配策略（优先级递减）：
    1. Flutter 时钟精确匹配：ReceiveVsync.now == VsyncProcessCallback.StartTime
       两者属于同一 Flutter 引擎内部时钟，可以精确匹配。
    2. callstack.ts 近邻回退：当精确匹配失败时，使用同属系统时钟的 callstack.ts
       在 time_window_ns 窗口内查找最近邻。

    注意：callstack.ts 是系统时钟，StartTime/now 是 Flutter 引擎内部时钟，
    两者存在固定偏移（通常约万亿纳秒级），绝不能跨时钟源比较。

    Args:
        recv_list: [(send_ts, recv_ts, recv_now, expected_end, vsync_id_str, recv_tid, recv_thread_name), ...]
        callback_list: [(ts, start_time, target_time, dur, tid, thread_name), ...]
        time_window_ns: callstack.ts 回退匹配的最大时间差（默认 50ms，覆盖 ui 线程调度延迟）

    Returns:
        [(send_ts, recv_ts, recv_now, expected_end, vsync_id_str, recv_tid, recv_thread_name,
          callback_ts, start_time, target_time, dur, callback_tid, callback_thread_name), ...]
        如果没有匹配到 callback，callback_ts/start_time/target_time/dur/callback_tid/callback_thread_name 为 0/""。
    """
    result: List[Tuple[int, int, int, int, str, int, str, int, int, int, int, int, str]] = []
    used_callback: set = set()

    # 构建 start_time -> callback_list index 的查找表，用于 Flutter 时钟精确匹配
    start_time_index: Dict[int, int] = {}
    for c_idx, (c_ts, c_start, c_target, c_dur, c_tid, c_thread_name) in enumerate(callback_list):
        if c_start not in start_time_index:
            start_time_index[c_start] = c_idx

    for s_ts, r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name in recv_list:
        matched = False

        # 策略1: Flutter 时钟精确匹配 — ReceiveVsync.now == VsyncProcessCallback.StartTime
        if r_now in start_time_index:
            c_idx = start_time_index[r_now]
            if c_idx not in used_callback:
                used_callback.add(c_idx)
                c_ts, c_start, c_target, c_dur, c_tid, c_thread_name = callback_list[c_idx]
                result.append((s_ts, r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name,
                               c_ts, c_start, c_target, c_dur, c_tid, c_thread_name))
                matched = True

        # 策略2: callstack.ts 近邻回退
        if not matched:
            best_idx = -1
            best_diff = time_window_ns + 1

            for c_idx, (c_ts, c_start, c_target, c_dur, c_tid, c_thread_name) in enumerate(callback_list):
                if c_idx in used_callback:
                    continue
                diff = abs(c_ts - r_ts)
                if diff < best_diff:
                    best_diff = diff
                    best_idx = c_idx

            if best_idx >= 0 and best_diff <= time_window_ns:
                used_callback.add(best_idx)
                c_ts, c_start, c_target, c_dur, c_tid, c_thread_name = callback_list[best_idx]
                result.append((s_ts, r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name,
                               c_ts, c_start, c_target, c_dur, c_tid, c_thread_name))
                matched = True

        if not matched:
            result.append((s_ts, r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name,
                           0, 0, 0, 0, 0, ""))

    return result


def _match_callback_draw(
    callback_list: List[Tuple[int, int, int, int, str, int, str, int, int, int, int, int, str]],
    draw_list: List[Tuple[int, int, int, str]],
    time_window_ns: int = 5_000_000,
) -> List[Tuple[int, int, int, int, str, int, str, int, int, int, int, int, str, int, int, int, str]]:
    """通过时间窗口匹配 VsyncProcessCallback 和 DrawToSurfaces。

    使用 callstack.ts（系统时钟）构建时间窗口，因为 c_start/c_target 是 Flutter 引擎
    内部时钟，与 DrawToSurfaces 的 callstack.ts 存在固定偏移，不能跨时钟源比较。

    Args:
        callback_list: [(send_ts, recv_ts, recv_now, expected_end, vsync_id_str, recv_tid, recv_thread_name,
                         callback_ts, start_time, target_time, dur, callback_tid, callback_thread_name), ...]
        draw_list: [(ts, dur, tid, thread_name), ...]
        time_window_ns: 时间窗口容差（默认 5ms），用于匹配 DrawToSurfaces

    Returns:
        [(send_ts, recv_ts, recv_now, expected_end, vsync_id_str, recv_tid, recv_thread_name,
          callback_ts, start_time, target_time, dur, callback_tid, callback_thread_name,
          draw_ts, draw_dur, draw_tid, draw_thread_name), ...]
        如果没有匹配到 DrawToSurfaces，draw_ts/draw_dur/draw_tid/draw_thread_name 为 0/"".
    """
    result: List[Tuple[int, int, int, int, str, int, str, int, int, int, int, int, str, int, int, int, str]] = []
    used_draw: set = set()

    for (s_ts, r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name,
         c_ts, c_start, c_target, c_dur, cb_tid, cb_thread_name) in callback_list:
        best_idx = -1
        # 使用 callstack.ts 构建时间窗口（同属系统时钟）。
        # 窗口: [c_ts, c_ts + c_dur + time_window_ns]
        window_start = c_ts
        window_end = (c_ts + c_dur + time_window_ns) if c_ts > 0 and c_dur > 0 else 0

        for d_idx, (d_ts, d_dur, d_tid, d_thread_name) in enumerate(draw_list):
            if d_idx in used_draw:
                continue
            # 检查 DrawToSurfaces 是否在时间窗口内
            if window_start <= d_ts <= window_end:
                best_idx = d_idx
                break  # 找到第一个匹配的 DrawToSurfaces

        if best_idx >= 0:
            used_draw.add(best_idx)
            d_ts, d_dur, d_tid, d_thread_name = draw_list[best_idx]
            result.append((s_ts, r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name,
                           c_ts, c_start, c_target, c_dur, cb_tid, cb_thread_name,
                           d_ts, d_dur, d_tid, d_thread_name))
        else:
            result.append((s_ts, r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name,
                           c_ts, c_start, c_target, c_dur, cb_tid, cb_thread_name,
                           0, 0, 0, ""))

    return result


# ---------------------------------------------------------------------------
# 算子实现
# ---------------------------------------------------------------------------


@register_operator("build_flutter_frames")
def build_flutter_frames(ctx: PreprocessContext) -> PreprocessContext:
    """构建 Flutter 帧链路（SendVsyncTo → ReceiveVsync → VsyncProcessCallback → DrawToSurfaces）。

    参数（来自 ctx.params）：
    - flutter_vsync_ids: list | None，帧号列表 ["vsyncId:745265"]，非空时按帧号筛选
    - start_ts: int | None，时间范围起始 ns
    - end_ts: int | None，时间范围结束 ns
    - frame_rate: int = 60

    输出 ctx.data:
    {
        "flutter_frames": [{
            "flutterVsyncId": "vsyncId:745265",
            "start_ts": 51572462086670,
            "end_ts": 51572470420003,
            "dur_ms": 8.353,
            "jank_severity": "minor",
            "thread_list": [{"tid": 33461, "name": "1.ui"}]
        }],
        "summary": {
            "total_frames": 50,
            "jank_count": 10,
            "minor_count": 5,
            "major_count": 3,
            "severe_count": 2
        }
    }
    """
    # sqlite_conn 为 None 时返回空数据
    if not ctx.sqlite_conn:
        ctx.data = _empty_result()
        return ctx

    conn = ctx.sqlite_conn
    params = ctx.params

    flutter_vsync_ids: Optional[List[str]] = params.get("flutter_vsync_ids")
    start_ts: Optional[int] = params.get("start_ts")
    end_ts: Optional[int] = params.get("end_ts")
    default_frame_rate: int = int(params.get("frame_rate", 60))
    # 优先从 ctx.meta 读取帧率记录（由上游算子注入）
    frame_rate_records: Optional[List[Dict[str, Any]]] = ctx.meta.get("frame_rate_records")
    # 如果为空，调用公共函数查询
    if not frame_rate_records:
        frame_rate_records = _get_frame_rate_records(conn)

    # 预加载 tid → process_name 映射（用于帧的 process_name/package_name 字段）
    tid_process_map = load_tid_process_map(conn)

    try:
        # -------------------- 1. 查询 SendVsyncTo（Flutter conn） --------------------
        send_sql = """
            SELECT c.id, c.ts, c.dur, c.name, t.tid, t.name as thread_name
            FROM callstack c
            LEFT JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE '%H:SendVsyncTo conn: flutterSyncName%'
        """
        send_rows = conn.execute(send_sql).fetchall()
        log.info("build_flutter_frames: SendVsyncTo 行数=%d", len(send_rows))

        send_list: List[Tuple[int, int, int, str]] = []  # (ts, now_value, tid, thread_name)
        for row in send_rows:
            _id, ts, _dur, name, tid, thread_name = row
            now_val = _parse_send_vsync(name)
            if now_val is not None:
                send_list.append((ts, now_val, tid or 0, thread_name or ""))

        # -------------------- 2. 查询 ReceiveVsync（Flutter name） --------------------
        recv_sql = """
            SELECT c.id, c.ts, c.dur, c.name, t.tid, t.name as thread_name
            FROM callstack c
            LEFT JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE '%H:ReceiveVsync name:flutterSyncName%'
        """
        recv_rows = conn.execute(recv_sql).fetchall()
        log.info("build_flutter_frames: ReceiveVsync 行数=%d", len(recv_rows))

        recv_list: List[Tuple[int, int, int, str, int, str]] = []  # (ts, now_value, expected_end, vsync_id_str, tid, thread_name)
        for row in recv_rows:
            _id, ts, _dur, name, tid, thread_name = row
            parsed = _parse_recv_vsync(name)
            if parsed is not None:
                now_val, expected_end, vsync_id_str = parsed
                recv_list.append((ts, now_val, expected_end, vsync_id_str, tid or 0, thread_name or ""))

        # -------------------- 3. 查询 VsyncProcessCallback --------------------
        callback_sql = """
            SELECT c.id, c.ts, c.dur, c.name, t.tid, t.name as thread_name
            FROM callstack c
            LEFT JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE '%flutter::VsyncProcessCallback%'
        """
        callback_rows = conn.execute(callback_sql).fetchall()
        log.info("build_flutter_frames: VsyncProcessCallback 行数=%d", len(callback_rows))

        callback_list: List[Tuple[int, int, int, int, int, str]] = []  # (ts, start_time, target_time, dur, tid, thread_name)
        for row in callback_rows:
            _id, ts, _dur, name, tid, thread_name = row
            parsed = _parse_vsync_callback(name)
            if parsed is not None:
                start_time, target_time = parsed
                callback_list.append((ts, start_time, target_time, _dur or 0, tid or 0, thread_name or ""))

        # -------------------- 4. 查询 DrawToSurfaces --------------------
        draw_sql = """
            SELECT c.id, c.ts, c.dur, c.name, t.tid, t.name as thread_name
            FROM callstack c
            LEFT JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE '%flutter::Rasterizer::DrawToSurfaces%'
        """
        draw_rows = conn.execute(draw_sql).fetchall()
        log.info("build_flutter_frames: DrawToSurfaces 行数=%d", len(draw_rows))

        draw_list: List[Tuple[int, int, int, str]] = []  # (ts, dur, tid, thread_name)
        for row in draw_rows:
            _id, ts, dur, _name, tid, thread_name = row
            draw_list.append((ts, dur or 0, tid or 0, thread_name or ""))

        # -------------------- 5. 匹配链路 --------------------
        matched_sr = _match_send_recv(send_list, recv_list)
        matched_src = _match_recv_callback(matched_sr, callback_list)
        matched_all = _match_callback_draw(matched_src, draw_list)

        log.info(
            "build_flutter_frames: 匹配结果 send=%d, recv=%d, matched_sr=%d, matched_src=%d, matched_all=%d",
            len(send_list), len(recv_list), len(matched_sr), len(matched_src), len(matched_all),
        )

        # -------------------- 6. 筛选 --------------------
        target_vsync_ids: Optional[set] = None
        if flutter_vsync_ids:
            target_vsync_ids = set()
            for vid in flutter_vsync_ids:
                vid_str = str(vid)
                numeric = vid_str.replace("vsyncId:", "") if vid_str.startswith("vsyncId:") else vid_str
                target_vsync_ids.add(numeric)

        flutter_frames: List[Dict[str, Any]] = []

        for (s_ts, r_ts, r_now, expected_end, vsync_id_str, recv_tid, recv_thread_name,
             c_ts, c_start, c_target, c_dur, cb_tid, cb_thread_name,
             d_ts, d_dur, d_tid, d_thread_name) in matched_all:
            # flutter_vsync_ids 优先筛选
            if target_vsync_ids is not None:
                if vsync_id_str not in target_vsync_ids:
                    continue
            else:
                if start_ts is not None and s_ts < start_ts:
                    continue
                if end_ts is not None and s_ts > end_ts:
                    continue

            # start_ts = SendVsyncTo 的 callstack.ts（系统时钟）
            frame_start_ts = s_ts

            # end_ts 使用系统时钟的 callstack.ts 计算：
            # max(VsyncProcessCallback.end, DrawToSurfaces.end)
            # VsyncProcessCallback.end = c_ts + c_dur
            # DrawToSurfaces.end = d_ts + d_dur
            callback_end = 0
            if c_ts > 0 and c_dur > 0:
                callback_end = c_ts + c_dur

            draw_end = 0
            if d_ts > 0 and d_dur > 0:
                draw_end = d_ts + d_dur

            if callback_end > 0 or draw_end > 0:
                frame_end_ts = max(callback_end, draw_end)
            else:
                # 无 callback/draw 匹配时，使用 ReceiveVsync.ts 作为帧结束
                # （不能使用 expected_end 或 c_target，它们是 Flutter 时钟值）
                frame_end_ts = r_ts

            dur_ms = round((frame_end_ts - frame_start_ts) / 1_000_000, 3)
            # 使用动态帧率计算 severity
            effective_rate = _match_frame_rate(frame_start_ts, frame_rate_records)
            if effective_rate is None:
                effective_rate = default_frame_rate
            severity = _compute_jank_severity(dur_ms, float(effective_rate))

            # 收集线程信息（按 tid 去重）
            thread_list: List[Dict[str, Any]] = []
            seen_tids: set = set()
            # ReceiveVsync 的线程
            if recv_tid and recv_tid not in seen_tids:
                thread_list.append({"tid": recv_tid, "name": recv_thread_name})
                seen_tids.add(recv_tid)
            # VsyncProcessCallback 的线程
            if cb_tid and cb_tid not in seen_tids:
                thread_list.append({"tid": cb_tid, "name": cb_thread_name})
                seen_tids.add(cb_tid)
            # DrawToSurfaces 的线程
            if d_tid and d_tid not in seen_tids:
                thread_list.append({"tid": d_tid, "name": d_thread_name})
                seen_tids.add(d_tid)

            # Flutter 帧的进程名：flutter::VsyncProcessCallback 事件对应的线程所属进程
            _proc_name = tid_process_map.get(cb_tid, "") if cb_tid else ""
            flutter_frames.append({
                "flutterVsyncId": f"vsyncId:{vsync_id_str}",
                "start_ts": frame_start_ts,
                "end_ts": frame_end_ts,
                "dur_ms": dur_ms,
                "jank_severity": severity,
                "frame_rate": int(effective_rate),
                "thread_list": thread_list,
                "process_name": _proc_name,
                "package_name": get_process_name(_proc_name) if _proc_name else "",
            })

        # -------------------- 6.5 帧范围裁剪：防止流水线重叠 --------------------
        # 前一帧未完成时，当前帧的 vsync 已下发，start_ts 可能早于上一帧 end_ts，
        # 导致查询窗口包含上一帧数据。裁剪并重算 severity。
        clip_frame_overlaps(flutter_frames, frame_rate_records, default_frame_rate)

        # -------------------- 7. 统计摘要 --------------------
        total_frames = len(flutter_frames)
        minor_count = sum(1 for f in flutter_frames if f["jank_severity"] == "minor")
        major_count = sum(1 for f in flutter_frames if f["jank_severity"] == "major")
        severe_count = sum(1 for f in flutter_frames if f["jank_severity"] == "severe")
        jank_count = minor_count + major_count + severe_count

        ctx.data = {
            "flutter_frames": flutter_frames,
            "summary": {
                "total_frames": total_frames,
                "jank_count": jank_count,
                "minor_count": minor_count,
                "major_count": major_count,
                "severe_count": severe_count,
            },
        }

        log.info(
            "build_flutter_frames: 完成, total=%d, minor=%d, major=%d, severe=%d",
            total_frames, minor_count, major_count, severe_count,
        )

    except Exception as e:
        log.error("build_flutter_frames: 执行失败: %s", e)
        ctx.data = _empty_result()

    return ctx


def _empty_result() -> Dict[str, Any]:
    """返回空结果结构。"""
    return {
        "flutter_frames": [],
        "summary": {
            "total_frames": 0,
            "jank_count": 0,
            "minor_count": 0,
            "major_count": 0,
            "severe_count": 0,
        },
    }
