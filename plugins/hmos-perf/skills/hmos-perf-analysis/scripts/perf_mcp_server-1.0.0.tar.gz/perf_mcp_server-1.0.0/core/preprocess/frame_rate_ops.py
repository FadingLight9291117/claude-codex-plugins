"""帧率查询与 jank severity 辅助函数。

提供：
- ``query_frame_rate_records`` 算子：从 process_measure 表查询 H:PreferredFrameRate 事件
- ``_get_frame_rate_records``：从 process_measure 表查询 H:PreferredFrameRate 事件（公共函数）
- ``_match_frame_rate``：根据区间起始时间匹配帧率
- ``_compute_jank_severity``：根据帧间隔时长和帧率计算 jank severity

其他模块（jank_interval_ops, rs_frame_ops, flutter_frame_ops）从此处导入辅助函数。
"""
from __future__ import annotations

from core.observability import get_module_logger
from typing import Any, Dict, List, Optional

from .base import PreprocessContext, register_operator

log = get_module_logger(__name__)


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------


def _match_frame_rate(start_ts: int, frame_rate_records: List[Dict[str, Any]]) -> Optional[int]:
    """根据区间起始时间匹配帧率。

    查找 ts <= start_ts AND ts + dur > start_ts 的记录。
    返回匹配的帧率值（如 60, 90, 120），或 None。
    """
    if not frame_rate_records:
        return None

    for record in frame_rate_records:
        ts = record.get("ts", 0)
        dur = record.get("dur", 0)
        rate = record.get("rate")
        if rate is None or dur is None:
            continue
        # 检查 start_ts 是否在当前记录的覆盖范围内
        if ts <= start_ts < ts + dur:
            return int(rate)
    return None


def _compute_jank_severity(dur_ms: float, rate: float) -> str:
    """根据帧间隔时长和帧率计算 jank severity.

    规则（基于帧间隔相对于帧率的倍数）：
    - normal:  帧间隔 < 1.5x 理论帧间隔
    - minor:   帧间隔 >= 1.5x 且 < 2x 理论帧间隔
    - major:   帧间隔 >= 2x 且 < 6x 理论帧间隔
    - severe:  帧间隔 >= 6x 理论帧间隔
    """
    if rate <= 0:
        rate = 60  # 默认 60Hz

    # 理论帧间隔（毫秒）
    theoretical_interval_ms = 1000.0 / rate

    # 计算帧间隔相对于理论帧间隔的倍数
    ratio = dur_ms / theoretical_interval_ms if theoretical_interval_ms > 0 else 0

    if ratio < 1.5:
        return "normal"
    elif ratio < 2.0:
        return "minor"
    elif ratio < 6.0:
        return "major"
    else:
        return "severe"


def _get_frame_rate_records(conn) -> List[Dict[str, Any]]:
    """从 process_measure 表查询 H:PreferredFrameRate 事件。

    这是公共的帧率查询函数，供多个算子共享使用。

    SQL:
        SELECT m.ts, m.dur, m.value
        FROM process_measure m
        JOIN process_measure_filter mf ON m.filter_id = mf.id
        WHERE mf.name LIKE '%H:PreferredFrameRate%'
        ORDER BY m.ts

    返回:
        [{"ts": int, "dur": int, "rate": int}, ...]

    无事件时返回空列表。
    """
    if not conn:
        return []

    try:
        cur = conn.execute("""
            SELECT m.ts, m.dur, m.value
            FROM process_measure m
            JOIN process_measure_filter mf ON m.filter_id = mf.id
            WHERE mf.name LIKE '%H:PreferredFrameRate%'
            ORDER BY m.ts
        """)
        frame_rate_records = [
            {"ts": r[0], "dur": r[1], "rate": r[2]}
            for r in cur.fetchall()
        ]
        log.info("_get_frame_rate_records: 帧率记录数=%d", len(frame_rate_records))
        return frame_rate_records

    except Exception as e:
        log.warning("_get_frame_rate_records: 帧率查询失败: %s", e)
        return []


def clip_frame_overlaps(
    frames: List[Dict[str, Any]],
    frame_rate_records: Optional[List[Dict[str, Any]]] = None,
    default_frame_rate: int = 60
) -> None:
    """裁剪帧范围并计算 jank_severity。

    防止流水线重叠导致数据污染，同时用裁剪后的 dur_ms 正确计算 severity。

    做法：
    1. 按 start_ts 排序
    2. 裁剪 start_ts = max(raw, prev_end_ts)
    3. 用裁剪后的 dur_ms + effective_rate 计算 jank_severity
    4. 就地修改 frames 列表

    Args:
        frames: 帧列表，每项需含 start_ts, end_ts；函数会写入 dur_ms, jank_severity
        frame_rate_records: 帧率记录（可选，用于动态帧率）
        default_frame_rate: 默认帧率（默认60）
    """
    frames.sort(key=lambda f: f["start_ts"])
    _prev_end_ns = 0
    for f in frames:
        if f["start_ts"] < _prev_end_ns:
            f["start_ts"] = _prev_end_ns
        # 用裁剪后的值计算 dur_ms 和 severity（一次正确）
        dur_ms = round(max(0, f["end_ts"] - f["start_ts"]) / 1_000_000, 3)
        f["dur_ms"] = dur_ms
        # 动态帧率
        effective_rate = _match_frame_rate(f["start_ts"], frame_rate_records) if frame_rate_records else default_frame_rate
        f["jank_severity"] = _compute_jank_severity(dur_ms, float(effective_rate or default_frame_rate))
        if f["end_ts"] > _prev_end_ns:
            _prev_end_ns = f["end_ts"]


# ---------------------------------------------------------------------------
# 算子实现
# ---------------------------------------------------------------------------


@register_operator("query_frame_rate_records")
def query_frame_rate_records(ctx: PreprocessContext) -> PreprocessContext:
    """从 process_measure 表查询 H:PreferredFrameRate 事件。

    输出 ctx.data:
        {"frame_rate_records": [{"ts": int, "dur": int, "rate": int}, ...]}

    无事件时返回空列表。
    """
    frame_rate_records = _get_frame_rate_records(ctx.sqlite_conn)
    ctx.data = {"frame_rate_records": frame_rate_records}
    return ctx
