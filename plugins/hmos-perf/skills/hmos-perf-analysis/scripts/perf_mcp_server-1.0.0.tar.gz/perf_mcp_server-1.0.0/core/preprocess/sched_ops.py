# -*- coding: utf-8 -*-
"""调度线程状态时长与延迟后处理算子（pipeline 形态）。

基于 OSS thread_running_info.py 的核心算法：
1. 从 thread_state 表构建状态转换链
2. 对每个线程计算 running / runnable / D-state / sleeping 时长
3. 基于状态链计算唤醒延迟分布

关键概念（line_common.py STATE_* 常量）：
    STATE_RUNNING = 0          → thread_state.state='Running'
    STATE_RUNNABLE = 1         → thread_state.state='R' 或 'R+'
    STATE_SLEEPING = 2         → thread_state.state='S' / 'I' / 'X' / 'Z'
    STATE_UNINTERUPTABLE_SLEEPING = 3 → thread_state.state='D'/'D-NIO'/'D-IO'
    STATE_BLOCK_IO = 4         → D-IO 时 block_io_flag=1

Runnable 时间计算逻辑：
    R 条目表示线程进入就绪队列，Running 条目表示线程被调度执行。
    Runnable 时间 = Running 开始时刻 - R 条目时刻。
    如果 R 后紧接 Running（同一时刻或极短间隔），则 runnable 时间为 0。

Running 时间计算逻辑：
    所有 thread_state.state='Running' 条目的 dur 之和。

D-State 时间计算逻辑：
    从 D 条目开始计时，下一个非 D 条目（R/Running/S）时结束。
    如果连续多个 D 条目，视为同一段 D-state。

Sleep 时间计算逻辑：
    从 S 条目开始计时，下一个非 S 条目时结束。
"""
from __future__ import annotations

from core.observability import get_module_logger
from typing import Any

import numpy as np
import pandas as pd

from .base import PreprocessContext, PreprocessError, register_operator

log = get_module_logger(__name__)


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def _state_code(state: str) -> int:
    """将 thread_state.state 字符串映射为 OSS 状态常量。"""
    s = state.strip()
    if s == "Running":
        return 0   # STATE_RUNNING
    if s in ("R", "R+"):
        return 1   # STATE_RUNNABLE
    if s in ("S", "I", "X", "Z"):
        return 2   # STATE_SLEEPING
    if s in ("D", "D-NIO", "D-IO", "D|W"):
        return 3   # STATE_UNINTERUPTABLE_SLEEPING
    return -1  # 未知状态


def _is_runnable(state: str) -> bool:
    s = state.strip()
    return s in ("R", "R+")


def _is_running(state: str) -> bool:
    return state.strip() == "Running"


def _is_dstate(state: str) -> bool:
    s = state.strip()
    return s in ("D", "D-NIO", "D-IO", "D|W")


def _is_sleeping(state: str) -> bool:
    s = state.strip()
    return s in ("S", "I", "X", "Z")


def _percentile(data: list[float], p: float) -> float:
    """线性插值百分位数。"""
    if not data:
        return 0.0
    sorted_data = sorted(data)
    n = len(sorted_data)
    idx = p / 100.0 * (n - 1)
    lo = int(idx)
    hi = min(lo + 1, n - 1)
    frac = idx - lo
    return round(sorted_data[lo] + frac * (sorted_data[hi] - sorted_data[lo]), 3)


# ---------------------------------------------------------------------------
# thread_state_durations: Layer 1 - 基于状态链计算各状态时长
# ---------------------------------------------------------------------------

@register_operator("compute_thread_state_durations")
def compute_thread_state_durations(ctx: PreprocessContext) -> PreprocessContext:
    """从 thread_state 数据计算每个线程的 running/runnable/D-state/sleeping 时长。

    输入:
        ctx.data: DataFrame 含列 ts / dur / itid / tid / pid / state
                  ts: ns 时间戳
                  dur: ns 持续时间
                  state: 'Running' | 'R' | 'R+' | 'S' | 'D-IO' | 'D-NIO' | ...
    输出:
        ctx.data: DataFrame 含列 itid / running_ms / runnable_ms / dstate_ms / sleeping_ms /
                              runnable_events / dstate_events / ipid / tname
        ctx.meta["thread_count"]: 活跃线程数
        ctx.meta["total_running_ms"]: 总 running 时长
        ctx.meta["total_runnable_ms"]: 总 runnable 时长
        ctx.meta["total_dstate_ms"]: 总 D-state 时长
        ctx.meta["total_sleeping_ms"]: 总 sleeping 时长
    """
    df = ctx.data
    required = {"ts", "itid", "state"}
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(
            f"compute_thread_state_durations 输入缺少列: {sorted(missing)}; "
            f"请确认 SQL 输出已包含 {sorted(required)}"
        )

    if not len(df):
        ctx.meta["thread_count"] = 0
        ctx.meta["total_running_ms"] = 0.0
        ctx.meta["total_runnable_ms"] = 0.0
        ctx.meta["total_dstate_ms"] = 0.0
        ctx.meta["total_sleeping_ms"] = 0.0
        ctx.data = pd.DataFrame(columns=[
            "itid", "ipid", "running_ms", "runnable_ms", "dstate_ms",
            "sleeping_ms", "runnable_events", "dstate_events", "tname"
        ])
        return ctx

    df = df.copy()
    df = df.sort_values(["itid", "ts"]).reset_index(drop=True)

    # 按线程分组计算状态时长
    # 注意：使用 while 循环以便在处理连续 D/S 条目时能正确跳过
    results: list[dict[str, Any]] = []
    for itid, group in df.groupby("itid"):
        group = group.sort_values("ts").reset_index(drop=True)
        n = len(group)

        running_ms = 0.0
        runnable_ms = 0.0
        runnable_events = 0
        dstate_ms = 0.0
        dstate_events = 0
        sleeping_ms = 0.0

        ipid = int(group["pid"].iloc[0]) if "pid" in group.columns else 0
        tid = int(group["tid"].iloc[0]) if "tid" in group.columns else itid

        # 提前转 numpy 数组，避免 iloc 在 while 循环中产生 Series 开销
        # 保留 NaN（不 fillna）：dur=NULL 表示"该状态切片时长未知"
        # 累加时跳过 NaN 行（不污染整线程，不当作 0），同线程其他正常行保留
        ts_arr = group["ts"].values.astype(float)
        state_arr = group["state"].values.astype(str)
        if "dur" in group.columns:
            dur_arr = pd.to_numeric(group["dur"], errors="coerce").values.astype(float)
        else:
            dur_arr = np.zeros(n, dtype=float)

        # 最近一个 R 条目的时间戳（用于计算 runnable 时间）
        last_r_ts: float | None = None

        i = 0
        while i < n:
            ts = ts_arr[i]
            state = state_arr[i]
            dur = dur_arr[i]
            dur_is_nan = pd.isna(dur)

            if _is_running(state):
                if not dur_is_nan:
                    running_ms += dur / 1_000_000.0
                if last_r_ts is not None:
                    gap_ms = (ts - last_r_ts) / 1_000_000.0
                    if gap_ms >= 0:
                        runnable_ms += gap_ms
                        runnable_events += 1
                    last_r_ts = None
                i += 1

            elif _is_runnable(state):
                last_r_ts = ts
                i += 1

            elif _is_dstate(state):
                dstate_start = ts
                j = i + 1
                while j < n and _is_dstate(state_arr[j]):
                    j += 1
                if j < n:
                    dstate_end = ts_arr[j]
                elif not dur_is_nan:
                    dstate_end = ts + dur
                else:
                    # dur 为 NaN 时无法计算 dstate 时长，跳过
                    i = j
                    continue
                dstate_duration = max(0.0, dstate_end - dstate_start) / 1_000_000.0
                dstate_ms += dstate_duration
                dstate_events += 1
                i = j  # 跳到下一个非 D 条目继续处理

            elif _is_sleeping(state):
                sleep_start = ts
                j = i + 1
                while j < n and _is_sleeping(state_arr[j]):
                    j += 1
                if j < n:
                    sleep_end = ts_arr[j]
                elif not dur_is_nan:
                    sleep_end = ts + dur
                else:
                    # dur 为 NaN 时无法计算 sleeping 时长，跳过
                    i = j
                    continue
                sleeping_duration = max(0.0, sleep_end - sleep_start) / 1_000_000.0
                sleeping_ms += sleeping_duration
                i = j  # 跳到下一个非 S 条目继续处理

            else:
                i += 1

        results.append({
            "itid": int(itid),
            "ipid": ipid,
            "tid": tid,
            "running_ms": round(running_ms, 3),
            "runnable_ms": round(runnable_ms, 3),
            "dstate_ms": round(dstate_ms, 3),
            "sleeping_ms": round(sleeping_ms, 3),
            "runnable_events": runnable_events,
            "dstate_events": dstate_events,
        })

    if not results:
        ctx.data = pd.DataFrame(columns=pd.Index([
            "itid", "ipid", "running_ms", "runnable_ms", "dstate_ms",
            "sleeping_ms", "runnable_events", "dstate_events", "tname"
        ]))
        ctx.meta["thread_count"] = 0
        ctx.meta["total_running_ms"] = 0.0
        ctx.meta["total_runnable_ms"] = 0.0
        ctx.meta["total_dstate_ms"] = 0.0
        ctx.meta["total_sleeping_ms"] = 0.0
        return ctx

    result_df = pd.DataFrame(results)

    # 从 thread 表获取线程名
    if ctx.sqlite_conn and len(result_df):
        try:
            itids = result_df["itid"].tolist()
            placeholders = ",".join("?" * len(itids))
            rows = ctx.sqlite_conn.execute(
                f"SELECT itid, name FROM thread WHERE itid IN ({placeholders})",
                itids,
            ).fetchall()
            name_map = {r[0]: r[1] for r in rows}
            result_df["tname"] = result_df["itid"].apply(lambda x: name_map.get(x, ""))
        except Exception:
            result_df["tname"] = ""

        # ---- Priority 增强：从 sched_slice 获取每个线程的优先级 ----
        try:
            prio_rows = ctx.sqlite_conn.execute(
                f"SELECT itid, priority FROM ("
                f"  SELECT itid, priority, ROW_NUMBER() OVER (PARTITION BY itid ORDER BY ts) as rn "
                f"  FROM sched_slice WHERE itid IN ({placeholders})"
                f") WHERE rn = 1",
                itids,
            ).fetchall()
            prio_map: dict[int, int] = {r[0]: r[1] for r in prio_rows}
            result_df["priority"] = result_df["itid"].apply(
                lambda x: prio_map.get(x, 0)
            )
            result_df["is_rt"] = result_df["priority"].apply(lambda p: 40 < p < 100)
        except Exception:
            log.debug("无法从 sched_slice 获取优先级")
            result_df["priority"] = 0
            result_df["is_rt"] = False

        # ---- Waker 信息：从 instant 表获取主要唤醒者 ----
        try:
            waker_rows = ctx.sqlite_conn.execute(
                f"SELECT ref as itid, wakeup_from, cnt FROM ("
                f"  SELECT ref, wakeup_from, COUNT(*) as cnt, "
                f"    ROW_NUMBER() OVER (PARTITION BY ref ORDER BY COUNT(*) DESC) as rn "
                f"  FROM instant WHERE name='sched_wakeup' AND ref IN ({placeholders}) "
                f"  GROUP BY ref, wakeup_from"
                f") WHERE rn = 1",
                itids,
            ).fetchall()
            waker_map: dict[int, int] = {r[0]: r[1] for r in waker_rows}
            result_df["waker_tid"] = result_df["itid"].apply(
                lambda x: waker_map.get(x, 0)
            )
            # 获取 waker 线程名
            waker_itids = [v for v in waker_map.values() if v]
            waker_name_map: dict[int, str] = {}
            if waker_itids:
                wp = ",".join("?" * len(waker_itids))
                wn_rows = ctx.sqlite_conn.execute(
                    f"SELECT itid, name FROM thread WHERE itid IN ({wp})",
                    waker_itids,
                ).fetchall()
                waker_name_map = {r[0]: r[1] for r in wn_rows}
            result_df["waker_name"] = result_df["waker_tid"].apply(
                lambda x: waker_name_map.get(x, "") if x else ""
            )
        except Exception:
            log.debug("无法从 instant 表获取 waker 信息")
            result_df["waker_itid"] = 0
            result_df["waker_name"] = ""

        # ---- Migration/Preemption 统计：从 sched_slice 推导 ----
        try:
            mig_rows = ctx.sqlite_conn.execute(
                f"SELECT itid, "
                f"  SUM(CASE WHEN cpu != prev_cpu THEN 1 ELSE 0 END) as migration_count, "
                f"  SUM(CASE WHEN end_state = 'R+' THEN 1 ELSE 0 END) as preemption_count "
                f"FROM ("
                f"  SELECT itid, cpu, end_state, "
                f"    LAG(cpu) OVER (PARTITION BY itid ORDER BY ts) as prev_cpu "
                f"  FROM sched_slice WHERE itid IN ({placeholders})"
                f") GROUP BY itid",
                itids,
            ).fetchall()
            mig_map: dict[int, int] = {r[0]: r[1] for r in mig_rows}
            preempt_map: dict[int, int] = {r[0]: r[2] for r in mig_rows}
            result_df["migration_count"] = result_df["itid"].apply(
                lambda x: mig_map.get(x, 0)
            )
            result_df["preemption_count"] = result_df["itid"].apply(
                lambda x: preempt_map.get(x, 0)
            )
        except Exception:
            log.debug("无法从 sched_slice 获取 migration/preemption 统计")
            result_df["migration_count"] = 0
            result_df["preemption_count"] = 0
    else:
        result_df["tname"] = ""
        result_df["priority"] = 0
        result_df["is_rt"] = False
        result_df["waker_itid"] = 0
        result_df["waker_name"] = ""
        result_df["migration_count"] = 0
        result_df["preemption_count"] = 0

    result_df = result_df.sort_values("running_ms", ascending=False).reset_index(drop=True)

    ctx.meta["thread_count"] = len(result_df)
    ctx.meta["total_running_ms"] = round(float(result_df["running_ms"].sum()), 3)
    ctx.meta["total_runnable_ms"] = round(float(result_df["runnable_ms"].sum()), 3)
    ctx.meta["total_dstate_ms"] = round(float(result_df["dstate_ms"].sum()), 3)
    ctx.meta["total_sleeping_ms"] = round(float(result_df["sleeping_ms"].sum()), 3)
    ctx.data = result_df
    return ctx


# ---------------------------------------------------------------------------
# thread_state_durations: Layer 2 - 收敛线程状态时长摘要
# ---------------------------------------------------------------------------

@register_operator("format_thread_state_summary")
def format_thread_state_summary(ctx: PreprocessContext) -> PreprocessContext:
    """收敛线程状态时长为 LLM 友好摘要。

    输入:
        ctx.data: compute_thread_state_durations 输出的聚合 DataFrame
        ctx.meta: 包含 total_running_ms 等统计信息
    输出:
        ctx.data: dict 含 meta / per_state_summary / top_threads
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {
                "type": "thread_state_durations_summary",
                "thread_count": 0,
                "total_running_ms": 0.0,
                "total_runnable_ms": 0.0,
                "total_dstate_ms": 0.0,
                "total_sleeping_ms": 0.0,
            },
            "per_state_summary": {},
            "top_threads": [],
        }
        return ctx

    thread_count = ctx.meta.get("thread_count", len(df))
    total_running = ctx.meta.get("total_running_ms", 0.0)
    total_runnable = ctx.meta.get("total_runnable_ms", 0.0)
    total_dstate = ctx.meta.get("total_dstate_ms", 0.0)
    total_sleeping = ctx.meta.get("total_sleeping_ms", 0.0)

    # 每个状态的统计
    per_state_summary = {}
    for col, label in [
        ("running_ms", "Running"),
        ("runnable_ms", "Runnable"),
        ("dstate_ms", "D-State"),
        ("sleeping_ms", "Sleeping"),
    ]:
        if col in df.columns:
            raw_vals = df[col].dropna()
            # 确保所有值都是数值类型
            float_vals: list[float] = []
            for v in raw_vals.tolist():
                try:
                    float_vals.append(float(v))
                except (TypeError, ValueError):
                    pass
            if float_vals:
                per_state_summary[label] = {
                    "p50": _percentile(float_vals, 50),
                    "p90": _percentile(float_vals, 90),
                    "p99": _percentile(float_vals, 99),
                    "min": round(min(float_vals), 3),
                    "max": round(max(float_vals), 3),
                    "avg": round(sum(float_vals) / len(float_vals), 3),
                }

    # Top N 线程（按 running 时间排序）
    top_n = int(ctx.params.get("top_n", 50))
    top_df = df.head(top_n)

    top_threads = []
    for _, row in top_df.iterrows():
        entry = {
            "tid": int(row["tid"]),
            "pid": int(row["pid"]) if "pid" in row and pd.notna(row["pid"]) else None,
            "tname": str(row.get("tname", "")),
            "running_ms": float(row["running_ms"]),
            "runnable_ms": float(row["runnable_ms"]),
            "dstate_ms": float(row["dstate_ms"]),
            "sleeping_ms": float(row["sleeping_ms"]),
            "runnable_events": int(row.get("runnable_events", 0)),
            "dstate_events": int(row.get("dstate_events", 0)),
            "ipid": int(row["ipid"]) if "ipid" in row and pd.notna(row["ipid"]) else None,
            "priority": int(row["priority"]) if "priority" in row and pd.notna(row["priority"]) else 0,
            "is_rt": bool(row.get("is_rt", False)),
            "waker_tid": int(row["waker_tid"]) if "waker_tid" in row and pd.notna(row.get("waker_tid", 0)) else 0,
            "waker_name": str(row.get("waker_name", "")),
            "migration_count": int(row.get("migration_count", 0)),
            "preemption_count": int(row.get("preemption_count", 0)),
        }
        top_threads.append(entry)

    ctx.data = {
        "meta": {
            "type": "thread_state_durations_summary",
            "thread_count": thread_count,
            "total_running_ms": total_running,
            "total_runnable_ms": total_runnable,
            "total_dstate_ms": total_dstate,
            "total_sleeping_ms": total_sleeping,
        },
        "per_state_summary": per_state_summary,
        "top_threads": top_threads,
    }
    return ctx


# ---------------------------------------------------------------------------
# sched_wakeup_latency: Layer 1 - 计算 R→Running 唤醒延迟
# ---------------------------------------------------------------------------

@register_operator("compute_wakeup_latency")
def compute_wakeup_latency(ctx: PreprocessContext) -> PreprocessContext:
    """从 thread_state 计算 R→Running 唤醒延迟（线程等待调度的时长）。

    输入:
        ctx.data: DataFrame 含列 ts / tid / state
    输出:
        ctx.data: DataFrame 含列 ts / tid / wakeup_latency_ms
        ctx.meta["latency_list"]: 延迟值列表(ms)
        ctx.meta["total_events"]: 事件数
    """
    df = ctx.data
    required = {"ts", "tid", "state"}
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(
            f"compute_wakeup_latency 输入缺少列: {sorted(missing)}; "
            f"请确认 SQL 输出已包含 {sorted(required)}"
        )

    if not len(df):
        ctx.meta["total_events"] = 0
        ctx.meta["latency_list"] = []
        return ctx

    df = df.copy()
    df = df.sort_values(["tid", "ts"]).reset_index(drop=True)

    latency_records: list[dict[str, Any]] = []

    for tid_val, group in df.groupby("tid"):
        group = group.sort_values("ts").reset_index(drop=True)
        n = len(group)

        # 提前转 numpy 数组
        ts_arr = group["ts"].values.astype(float)
        state_arr = group["state"].values.astype(str)

        for i in range(n):
            state = state_arr[i]

            if _is_runnable(state):
                r_ts = ts_arr[i]
                # 找下一个 Running 条目
                j = i + 1
                while j < n:
                    next_state = state_arr[j]
                    if _is_running(next_state):
                        running_ts = ts_arr[j]
                        latency_ms = (running_ts - r_ts) / 1_000_000.0
                        if latency_ms > 0:
                            latency_records.append({
                                "ts": int(r_ts / 1_000_000),  # 转为 ms
                                "tid": int(tid_val),
                                "wakeup_latency_ms": round(latency_ms, 3),
                            })
                        break
                    elif _is_runnable(next_state):
                        # 被其他线程抢占后重新进入 R，清除之前的 R
                        break
                    j += 1

    latency_df = pd.DataFrame(latency_records)
    latency_list = latency_df["wakeup_latency_ms"].tolist() if len(latency_df) else []

    ctx.meta["total_events"] = len(latency_list)
    ctx.meta["latency_list"] = latency_list
    ctx.data = latency_df if len(latency_df) else pd.DataFrame(
        columns=["ts", "tid", "wakeup_latency_ms"])
    return ctx


# ---------------------------------------------------------------------------
# sched_wakeup_latency: Layer 2 - 收敛延迟分布摘要
# ---------------------------------------------------------------------------

@register_operator("format_latency_summary")
def format_latency_summary(ctx: PreprocessContext) -> PreprocessContext:
    """收敛唤醒延迟为 LLM 友好分布摘要。

    输入:
        ctx.meta["latency_list"]: 延迟值列表
        ctx.data: 详细数据 DataFrame
    输出:
        ctx.data: dict 含 meta / distribution / top_latency_events
    """
    latency_list = ctx.meta.get("latency_list", [])
    total_events = ctx.meta.get("total_events", 0)

    if not latency_list:
        ctx.data = {
            "meta": {
                "type": "sched_wakeup_latency_summary",
                "total_events": 0,
            },
            "distribution": {},
            "top_latency_events": [],
        }
        return ctx

    sorted_lat = sorted(latency_list)
    distribution = {
        "p50": _percentile(sorted_lat, 50),
        "p90": _percentile(sorted_lat, 90),
        "p99": _percentile(sorted_lat, 99),
        "min": round(sorted_lat[0], 3),
        "max": round(sorted_lat[-1], 3),
        "avg": round(sum(sorted_lat) / len(sorted_lat), 3),
    }

    top_n = int(ctx.params.get("top_n", 20))
    df = ctx.data
    if isinstance(df, pd.DataFrame) and len(df):
        top_events = (
            df.nlargest(top_n, "wakeup_latency_ms")[["ts", "tid", "wakeup_latency_ms"]]
            .to_dict(orient="records")
        )
    else:
        top_events = []

    ctx.data = {
        "meta": {
            "type": "sched_wakeup_latency_summary",
            "total_events": total_events,
        },
        "distribution": distribution,
        "top_latency_events": top_events,
    }
    return ctx


# ---------------------------------------------------------------------------
# thread_runtime: Layer 1 - 按线程聚合运行时长（兼容旧接口）
# ---------------------------------------------------------------------------

@register_operator("aggregate_thread_runtime")
def aggregate_thread_runtime(ctx: PreprocessContext) -> PreprocessContext:
    """按线程聚合运行（running）时长，兼容原有接口。

    输入:
        ctx.data: DataFrame 含列 tid / dur / ts（来自 sched_slice + thread JOIN）
    输出:
        ctx.data: 聚合后的 DataFrame
        ctx.meta["thread_count"]: 活跃线程数
        ctx.meta["total_runtime_ms"]: 所有线程总 running 时长
    """
    df = ctx.data
    required = {"tid", "dur"}
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(
            f"aggregate_thread_runtime 输入缺少列: {sorted(missing)}"
        )

    if not len(df):
        ctx.meta["thread_count"] = 0
        ctx.meta["total_runtime_ms"] = 0.0
        return ctx

    df = df.copy()
    df["runtime_ms"] = df["dur"] / 1_000_000.0

    agg_df = df.groupby("tid", as_index=False, sort=False).agg(
        runtime_ms=("runtime_ms", "sum"),
        slice_count=("dur", "count"),
        tname=("tname", "first"),
    )
    agg_df["runtime_ms"] = agg_df["runtime_ms"].round(3)
    agg_df = agg_df.sort_values("runtime_ms", ascending=False).reset_index(drop=True)

    ctx.meta["thread_count"] = len(agg_df)
    ctx.meta["total_runtime_ms"] = round(float(agg_df["runtime_ms"].sum()), 3)
    ctx.data = agg_df
    return ctx


# ---------------------------------------------------------------------------
# thread_runtime: Layer 2 - 收敛线程运行时长摘要（兼容旧接口）
# ---------------------------------------------------------------------------

@register_operator("format_runtime_summary")
def format_runtime_summary(ctx: PreprocessContext) -> PreprocessContext:
    """把线程运行时长收敛为摘要（兼容原有接口）。"""
    df = ctx.data
    thread_count = ctx.meta.get("thread_count", 0)
    total_runtime_ms = ctx.meta.get("total_runtime_ms", 0.0)

    top_n = int(ctx.params.get("top_n", 50))

    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {
                "type": "thread_runtime_summary",
                "thread_count": 0,
                "total_runtime_ms": 0.0,
            },
            "top_threads": [],
        }
        return ctx

    top_df = df.head(top_n)

    thread_names: dict[int, str] = {}
    if ctx.sqlite_conn:
        try:
            tids = top_df["tid"].tolist()
            placeholders = ",".join("?" * len(tids))
            rows = ctx.sqlite_conn.execute(
                f"SELECT tid, name FROM thread WHERE tid IN ({placeholders})",
                tids,
            ).fetchall()
            thread_names = {r[0]: r[1] for r in rows}
        except Exception:
            log.debug("无法从 thread 表获取线程名")

    top_threads = []
    for _, row in top_df.iterrows():
        entry = {
            "tid": int(row["tid"]),
            "tname": thread_names.get(int(row["tid"]), "") or str(row.get("tname", "")),
            "runtime_ms": float(row["runtime_ms"]),
            "slice_count": int(row["slice_count"]),
        }
        top_threads.append(entry)

    ctx.data = {
        "meta": {
            "type": "thread_runtime_summary",
            "thread_count": thread_count,
            "total_runtime_ms": total_runtime_ms,
        },
        "top_threads": top_threads,
    }
    return ctx


# ---------------------------------------------------------------------------
# sched_affinity/sched_cgroup: 解析 next_info
# ---------------------------------------------------------------------------

# CGroup ID 映射表
CGROUP_MAP = {
    0: "/dev/cpuctl",
    1: "background",
    2: "foreground",
    3: "system-background",
    4: "top-app",
    5: "boost",
    6: "graphic",
    7: "key-background",
    8: "opt-background",
    9: "foreground-app",
    10: "nap-foreground",
    11: "nap-background",
    12: "self-render",
    13: "graphic-high",
    14: "graphic-normal",
    15: "low-background",
    16: "cam2stage",
    17: "system",
    18: "rt",
    19: "vip",
    20: "default",
    21: "safety-background",
    22: "system-default",
}


def _parse_next_info(num: int) -> tuple[str, int, int, int, int, int]:
    """解析 next_info 数值，返回 (affinity, load, group, restricted, expel, cgid)。

    next_info 编码规则（来自 parseSchedSwitchHmNew）:
    - 将数字拆分为高32位和低32位
    - 低32位的前4字节是 tmpAffinity
    - 高32位包含 load(10bit) / group(2bit) / restricted(1bit) / expel(3bit) / cgid(5bit)
    """
    # 拆分高低32位
    low = num & 0xFFFFFFFF
    high = (num >> 32) & 0xFFFFFFFF

    # 读取低32位作为 affinity（CPU亲和性掩码）
    affinity = format(low, "x")

    # 读取高32位解析各字段
    remaining = high

    load_mask = (1 << 10) - 1
    group_mask = (1 << 2) - 1
    restricted_mask = 1
    expel_mask = (1 << 3) - 1
    cgid_mask = (1 << 5) - 1

    load = ((remaining >> 0) & load_mask) << 1
    group = (remaining >> 10) & group_mask
    restricted = (remaining >> 12) & restricted_mask
    expel = (remaining >> 13) & expel_mask
    cgid = (remaining >> 16) & cgid_mask

    return affinity, int(load), int(group), int(restricted), int(expel), int(cgid)


def _affinity_to_cpu_list(affinity_hex: str) -> list[int]:
    """将 affinity 十六进制掩码转换为允许的 CPU 核心列表。

    例: affinity="7ff" -> [0,1,2,3,4,5,6,7,8,9,10]
    """
    try:
        mask = int(affinity_hex, 16)
    except (ValueError, TypeError):
        return []
    cpus: list[int] = []
    bit = 0
    while mask:
        if mask & 1:
            cpus.append(bit)
        mask >>= 1
        bit += 1
    return cpus


def _parse_next_info_comma(data_str: str) -> tuple[str, int, int, int, int, int] | None:
    """解析逗号分隔格式的 next_info 字符串，如 "f,94,0,0,0,3,0"。

    格式: affinity,load,group,restricted,expel,cgid
    """
    if not data_str or not isinstance(data_str, str):
        return None
    parts = data_str.strip().split(",")
    if len(parts) < 6:
        return None
    try:
        affinity = parts[0].strip()
        load = int(parts[1])
        group = int(parts[2])
        restricted = int(parts[3])
        expel = int(parts[4])
        cgid = int(parts[5])
        return affinity, load, group, restricted, expel, cgid
    except (ValueError, IndexError):
        return None


@register_operator("parse_sched_next_info")
def parse_sched_next_info(ctx: PreprocessContext) -> PreprocessContext:
    """从 sched_slice 的 arg_setid 解析 next_info，提取 affinity 和 cgroup 信息。

    输入:
        ctx.data: DataFrame 含列 tid / itid / arg_setid / cpu / ts
    输出:
        ctx.data: DataFrame 含列 tid / affinity / affinity_binary / cpu_count / cgid / cgroup_name
        ctx.meta["affinity_map"]: affinity -> count 映射
        ctx.meta["cgroup_map"]: cgid -> count 映射
    """
    df = ctx.data
    required = {"tid", "itid", "arg_setid"}
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(
            f"parse_sched_next_info 输入缺少列: {sorted(missing)}"
        )

    if not len(df):
        ctx.meta["affinity_map"] = {}
        ctx.meta["cgroup_map"] = {}
        ctx.data = pd.DataFrame(columns=[
            "tid", "affinity", "affinity_binary", "cpu_count", "cgid", "cgroup_name"
        ])
        return ctx

    df = df.copy()

    # 按线程聚合 arg_setid（取最新的）
    df = df.sort_values("ts", ascending=False).reset_index(drop=True)
    latest = df.groupby("tid", as_index=False).first()

    if not len(latest):
        ctx.meta["affinity_map"] = {}
        ctx.meta["cgroup_map"] = {}
        ctx.data = pd.DataFrame(columns=[
            "tid", "affinity", "affinity_binary", "cpu_count", "cgid", "cgroup_name"
        ])
        return ctx

    # 关联 args 表获取 next_info 原始值
    if ctx.sqlite_conn:
        try:
            arg_setids = latest["arg_setid"].tolist()
            placeholders = ",".join("?" * len(arg_setids))

            # args 表：argset 字段匹配 arg_setid，value 字段是 data_dict 的 id
            rows = ctx.sqlite_conn.execute(
                f"SELECT a.argset, a.value FROM args a WHERE a.argset IN ({placeholders})",
                arg_setids,
            ).fetchall()
            argset_to_value = {r[0]: r[1] for r in rows}

            # data_dict 表：id 匹配 value，data 字段是 next_info 原始值
            values = list(argset_to_value.values())
            if values:
                val_placeholders = ",".join("?" * len(values))
                data_rows = ctx.sqlite_conn.execute(
                    f"SELECT d.id, d.data FROM data_dict d WHERE d.id IN ({val_placeholders})",
                    values,
                ).fetchall()
                value_to_data = {r[0]: r[1] for r in data_rows}

                # 构建 itid -> next_info 解析结果
                results = []
                affinity_dist: dict[str, int] = {}
                cgroup_dist: dict[int, int] = {}

                for _, row in latest.iterrows():
                    tid_val = int(row["tid"])
                    arg_setid = int(row["arg_setid"])
                    value = argset_to_value.get(arg_setid)
                    if value is None:
                        continue
                    data_str = value_to_data.get(value)
                    if data_str is None:
                        continue

                    try:
                        data_str = str(data_str).strip()

                        # 优先尝试逗号分隔格式（如 "f,94,0,0,0,3,0"）
                        comma_result = _parse_next_info_comma(data_str)
                        if comma_result:
                            affinity, load, group, restricted, expel, cgid = comma_result
                        else:
                            # 尝试 bigint 格式
                            next_info_num = int(data_str)
                            affinity, load, group, restricted, expel, cgid = _parse_next_info(next_info_num)

                        # 计算 affinity 的二进制表示和 CPU 核心数
                        affinity_int = int(affinity, 16)
                        affinity_binary = bin(affinity_int).lstrip("0b").zfill(12)
                        cpu_count = affinity_binary.count("1")
                        affinity_cpus = _affinity_to_cpu_list(affinity)

                        cgroup_name = CGROUP_MAP.get(cgid, f"unknown({cgid})")

                        results.append({
                            "tid": tid_val,
                            "affinity": affinity,
                            "affinity_binary": affinity_binary,
                            "cpu_count": cpu_count,
                            "affinity_cpus": affinity_cpus,
                            "cgid": cgid,
                            "cgroup_name": cgroup_name,
                        })

                        # 统计分布
                        affinity_dist[affinity] = affinity_dist.get(affinity, 0) + 1
                        cgroup_dist[cgid] = cgroup_dist.get(cgid, 0) + 1
                    except (ValueError, TypeError) as e:
                        log.debug(f"解析 next_info 失败: {data_str}, error: {e}")
                        continue

                ctx.meta["affinity_map"] = affinity_dist
                ctx.meta["cgroup_map"] = cgroup_dist
                ctx.data = pd.DataFrame(results) if results else pd.DataFrame(columns=[
                    "tid", "affinity", "affinity_binary", "cpu_count", "affinity_cpus", "cgid", "cgroup_name"
                ])
                return ctx
        except Exception as e:
            log.debug(f"解析 next_info 失败: {e}")

    ctx.meta["affinity_map"] = {}
    ctx.meta["cgroup_map"] = {}
    ctx.data = pd.DataFrame(columns=[
        "tid", "affinity", "affinity_binary", "cpu_count", "cgid", "cgroup_name"
    ])
    return ctx


@register_operator("format_affinity_summary")
def format_affinity_summary(ctx: PreprocessContext) -> PreprocessContext:
    """收敛 affinity 解析结果为摘要。

    输入:
        ctx.data: parse_sched_next_info 输出的 DataFrame
        ctx.meta["affinity_map"]: affinity 分布统计
    输出:
        ctx.data: dict 含 meta / affinity_distribution / top_threads
    """
    df = ctx.data
    affinity_map = ctx.meta.get("affinity_map", {})

    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {
                "type": "sched_affinity_summary",
                "thread_count": 0,
                "affinity_distribution": {},
            },
            "top_threads": [],
        }
        return ctx

    # 线程名映射
    thread_names: dict[int, str] = {}
    if ctx.sqlite_conn:
        try:
            tids = df["tid"].tolist()
            placeholders = ",".join("?" * len(tids))
            rows = ctx.sqlite_conn.execute(
                f"SELECT tid, name FROM thread WHERE tid IN ({placeholders})",
                tids,
            ).fetchall()
            thread_names = {r[0]: r[1] for r in rows}
        except Exception:
            log.debug("无法从 thread 表获取线程名")

    # 亲和性分布
    affinity_distribution = {}
    for aff, count in sorted(affinity_map.items(), key=lambda x: -x[1])[:20]:
        aff_int = int(aff, 16)
        cpu_count = bin(aff_int).count("1")
        affinity_distribution[aff] = {
            "count": count,
            "cpu_count": cpu_count,
            "binary": bin(aff_int).lstrip("0b"),
            "affinity_cpus": _affinity_to_cpu_list(aff),
        }

    # Top N 线程
    top_n = int(ctx.params.get("top_n", 50))
    top_df = df.head(top_n)

    top_threads = []
    for _, row in top_df.iterrows():
        entry = {
            "tid": int(row["tid"]),
            "tname": thread_names.get(int(row["tid"]), ""),
            "affinity": str(row["affinity"]),
            "affinity_binary": str(row["affinity_binary"]),
            "cpu_count": int(row["cpu_count"]),
            "affinity_cpus": list(row["affinity_cpus"]) if "affinity_cpus" in row and isinstance(row["affinity_cpus"], list) else _affinity_to_cpu_list(str(row["affinity"])),
        }
        top_threads.append(entry)

    ctx.data = {
        "meta": {
            "type": "sched_affinity_summary",
            "thread_count": len(df),
            "affinity_distribution": affinity_distribution,
        },
        "top_threads": top_threads,
    }
    return ctx


@register_operator("format_cgroup_summary")
def format_cgroup_summary(ctx: PreprocessContext) -> PreprocessContext:
    """收敛 cgroup 解析结果为摘要。

    输入:
        ctx.data: parse_sched_next_info 输出的 DataFrame
        ctx.meta["cgroup_map"]: cgid 分布统计
    输出:
        ctx.data: dict 含 meta / cgroup_distribution / top_threads
    """
    df = ctx.data
    cgroup_map = ctx.meta.get("cgroup_map", {})

    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {
                "type": "sched_cgroup_summary",
                "cgroup_distribution": {},
            },
            "top_threads": [],
        }
        return ctx

    # 线程名映射
    thread_names: dict[int, str] = {}
    if ctx.sqlite_conn:
        try:
            tids = df["tid"].tolist()
            placeholders = ",".join("?" * len(tids))
            rows = ctx.sqlite_conn.execute(
                f"SELECT tid, name FROM thread WHERE tid IN ({placeholders})",
                tids,
            ).fetchall()
            thread_names = {r[0]: r[1] for r in rows}
        except Exception:
            log.debug("无法从 thread 表获取线程名")

    # CGroup 分布
    cgroup_distribution = {}
    for cgid, count in sorted(cgroup_map.items(), key=lambda x: -x[1]):
        cgroup_name = CGROUP_MAP.get(cgid, f"unknown({cgid})")
        cgroup_distribution[cgroup_name] = {
            "cgid": cgid,
            "count": count,
        }

    # Top N 线程
    top_n = int(ctx.params.get("top_n", 50))
    top_df = df.head(top_n)

    top_threads = []
    for _, row in top_df.iterrows():
        entry = {
            "tid": int(row["tid"]),
            "tname": thread_names.get(int(row["tid"]), ""),
            "cgid": int(row["cgid"]),
            "cgroup_name": str(row["cgroup_name"]),
            "count": 1,
        }
        top_threads.append(entry)

    ctx.data = {
        "meta": {
            "type": "sched_cgroup_summary",
            "cgroup_distribution": cgroup_distribution,
        },
        "top_threads": top_threads,
    }
    return ctx


