<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-06-11 -->

# core/preprocess — Preprocessing Operators

## Purpose
Composable, pure-function preprocessing operators that transform raw SQLite query results into analysis-ready structured data. Each operator follows the `(PreprocessContext) -> PreprocessContext` protocol. Operators are registered via `@register_operator` and assembled into pipelines declared in indicator YAML files. There are 15 operator modules covering all performance analysis domains.

## Key Files

| File | Description |
|------|-------------|
| `base.py` | Operator framework: PreprocessContext, PreprocessOperator protocol, OPERATORS registry, register_operator decorator, run_pipeline dispatcher |
| `__init__.py` | Re-exports from base.py; triggers side-effect imports of all operator modules to populate OPERATORS registry |
| `chip_config.py` | Chip identification: loads config/chips/chip_database.json, identifies SMT pairs, cluster names, matches chip by topology. Results cached by (sqlite_path, mtime). |
| `frame_ops.py` | Rendering frame reconstruction: builds cross-thread frame chains from VSync→UI→RS→Render→HWC→Present, matches via transaction flags and vsyncIds. Registers: build_frame_chains, compute_frame_durations, resolve_app_names. |
| `flutter_frame_ops.py` | Flutter 帧链路构建算子：从 Flutter 渲染链路（SendVsyncTo → ReceiveVsync → VsyncProcessCallback → DrawToSurfaces）重建帧数据，支持按 vsyncId 或时间范围筛选，基于 frame_rate 动态计算 jank severity。Registers: build_flutter_frames. |
| `jank_ops.py` | Jank/drop analysis: builds per-frame drop ranges with culprit identification (UI/RS/HWC stage), severity classification (light/medium/severe). Registers: build_drop_ranges, build_thread_queries. |
| `launch_ops.py` | App launch analysis: parses callstack events to reconstruct cold/warm launch phases (ProcessCreate→AttachApplication→ApplicationOnCreate→AbilityInit→AppInit→FirstFrame). Registers: pair_lifecycle_events, compute_phase_durations, identify_bottleneck_phase, format_phase_summary. |
| `sched_ops.py` | Scheduler state analysis: builds state transition chains from thread_state table, computes per-thread running/runnable/D-state/sleeping durations and wakeup latency distributions. Based on OSS thread_running_info.py algorithm. |
| `cpu_load_ops.py` | CPU load aggregation: three-layer pipeline (per-core→total→LLM-friendly summary). Load = 1 - (idle_time / total_time). Registers: load_aggregate_per_core, load_aggregate_total, format_cpu_load_summary. |
| `smt_ops.py` | SMT residency analysis: computes MT/ST time per CPU core using sweep-line interval merging. Uses sibling CPU info from chip_config. Registers: compute_smt_residency. |
| `marker_ops.py` | Hitrace marker analysis (HarmonyOS): builds tree from flat trace intervals, computes self-time, aggregates by path. Contains FUNCTION_TAG_MAP mapping trace patterns to Chinese labels. Registers: build_marker_tree, compute_marker_self_time, aggregate_marker_paths, finalize_marker. |
| `sleep_ops.py` | Sleep/wakeup chain analysis: builds S-state chains, backtraces wakeup chains, computes chain depth, supply frequency, blocking function names. Based on OSS wakeup_link_helper.py. |
| `pmu_ops.py` | PMU counter analysis: reads PMU deltas from phase_task_delta table, maps via delta_mapping, computes IPC/MPKI/cache miss rates with percentile distributions. |
| `io_ops.py` | IO performance analysis: P50/P90/P95/P99 latency percentiles, peak concurrent IO, IO size distribution bucketing, read/write ratio. Processes filesystem_io table. |
| `flamegraph_ops.py` | Flame graph pipeline operators: wraps core.flamegraph_collapse functions as PreprocessOperator steps for granular pipeline control. |
| `hiperf_ops.py` | HiPerf hot path analysis: builds callchains from flat SQL, normalizes function names, collapses ArkTs stubs and system libraries, aggregates functions/paths/binaries. Uses tree-based _HotpathNode. |
| `uninterruptible_ops.py` | D-state analysis: computes D-IO/D-NIO/D-state durations from thread_state, resolves blocking function names via args→data_dict join chain. |

## For AI Agents

### Working In This Directory
- ⚠️ **After modifying any operator, add or update corresponding tests** in `tests/test_preprocess_pipeline.py`.
- Follow the `(PreprocessContext) -> PreprocessContext` protocol exactly.
- Use `@register_operator("name")` to register new operators.
- Import new operator modules in `__init__.py` to ensure registration.
- Operators should be pure functions: no side effects, no global state mutation.
- Write diagnostics (warnings, stats) to `ctx.meta`, not stdout.

### Testing Requirements
- All operators must have unit test coverage in `tests/test_preprocess_pipeline.py`.
- Fixture-based regression tests: compare operator output against `tests/fixtures/<scenario>/expected.json`.
- Run `pytest tests/test_preprocess_pipeline.py -v --tb=short` after any operator change.

### Common Patterns
- `ctx.data` — input DataFrame (or list), modified and returned.
- `ctx.meta` — dict for diagnostics, warnings, intermediate results.
- `ctx.params` — parameters merged from YAML and agent input.
- `ctx.sqlite_conn` — read-only SQLite connection for auxiliary queries.
- `raise PreprocessError(message)` for recoverable non-fatal issues.

## Dependencies

### Internal
- `core/registry.py` — Resolves indicator metadata needed by operators
- `core/flamegraph_collapse.py` — Used by flamegraph_ops
- `core/rendering_pipeline.py` — Rendering detection (separate subsystem)
- `utils/process_name.py` — App name mapping used by frame_ops
- `config/chips/chip_database.json` — Chip topology data for chip_config

### External
- `pandas` — DataFrame operations
- `sqlite3` (stdlib) — Auxiliary queries
