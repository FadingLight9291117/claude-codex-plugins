"""Preprocess operators for BRBE sample analysis.

All operators read brbe_sample table (with denormalized symbol columns
populated by hiperf_extender) and do in-memory aggregation.
Zero JOIN in SQL -- symbols already resolved at extend time.

See docs/GOLDEN_RULES.md rule 24.
"""
from __future__ import annotations

from typing import Any

from core.observability import get_module_logger
from core.preprocess.base import PreprocessContext, register_operator

log = get_module_logger(__name__)


@register_operator("build_brbe_basic_blocks")
def build_brbe_basic_blocks(ctx: PreprocessContext) -> PreprocessContext:
    """Aggregate BRBE entries into basic blocks (oss_pmutools-compatible).

    Reads brbe_sample, pairs entries[i] with entries[i+1] (same perf_sample_id,
    sequence+1). BB key = (tid, bb_start_ip, bb_end_ip) -- same as
    (tid, prv.to_ip, curr.from_ip) in oss_pmutools.

    Aggregates by BB key:
        - SUM(cycles) across all visits
        - SUM(inst_per_visit) where inst_per_visit = max(1, (end-start)//4+1)
        - COUNT(visits)
        - IPC = round(total_inst / total_cycles, 3)

    Uses file_offset (not absolute vaddr) for the BB start/end, matching
    oss_pmutools output format. Falls back to from_ip/to_ip if file_offset
    is NULL (older schema without file_offset columns).

    Output: ctx.data = {"summary": {...}, "data": [...]}
    """
    conn = ctx.sqlite_conn
    tid = ctx.params.get("tid")
    top_n = ctx.params.get("top_n", 20)
    start_ms = ctx.params.get("start_ms")
    end_ms = ctx.params.get("end_ms")

    # Check if file_offset columns exist
    cursor = conn.execute("PRAGMA table_info(brbe_sample)")
    col_names = {row[1] for row in cursor.fetchall()}
    has_file_offset = "from_file_offset" in col_names and "to_file_offset" in col_names

    if has_file_offset:
        select_cols = (
            "perf_sample_id, sequence, thread_id, thread_name, "
            "from_ip, to_ip, is_mispredicted, cycles, "
            "from_symbol, from_binary, to_symbol, to_binary, "
            "from_file_offset, to_file_offset"
        )
    else:
        select_cols = (
            "perf_sample_id, sequence, thread_id, thread_name, "
            "from_ip, to_ip, is_mispredicted, cycles, "
            "from_symbol, from_binary, to_symbol, to_binary, "
            "NULL, NULL"
        )

    rows = conn.execute(
        f"SELECT {select_cols} "
        "FROM brbe_sample "
        "WHERE (:tid IS NULL OR thread_id = :tid) "
        "AND (:start_ms IS NULL OR timestamp_ns >= :start_ms * 1000000) "
        "AND (:end_ms IS NULL OR timestamp_ns < :end_ms * 1000000) "
        "ORDER BY perf_sample_id, sequence",
        {"tid": tid, "start_ms": start_ms, "end_ms": end_ms},
    ).fetchall()

    # Build BB pairs and aggregate by key
    # BB key = (tid, bb_start_ip, bb_end_ip) using virtual addresses
    # (same as oss_pmutools, which uses vaddr triple for dedup)
    # But output uses file_offset for the display columns
    bb_map: dict[tuple, dict[str, Any]] = {}

    for i in range(len(rows) - 1):
        curr = rows[i]
        nxt = rows[i + 1]
        # Must be same sample and adjacent sequence
        if (curr[0] != nxt[0]) or (curr[1] != nxt[1] - 1):
            continue

        # perf.data branch_stack is in reverse chronological order:
        #   entries[0] = most recent branch, entries[nr-1] = oldest.
        # oss_pmutools: BB key = (tid, prv.to_pc, curr.from_pc)
        #   where prv = older entry (higher sequence), curr = newer (lower sequence)
        # So for rows[i] (curr=newer, seq=i) and rows[i+1] (nxt=older, seq=i+1):
        #   BB start = nxt.to_ip (older branch's target = BB entry point)
        #   BB end   = curr.from_ip (newer branch's source = BB exit point)
        #   cycles   = curr.cycles (newer branch's cycles = time spent in BB)
        bb_start_ip = nxt[5]      # nxt.to_ip (older entry's target = BB start)
        bb_end_ip = curr[4]       # curr.from_ip (newer entry's source = BB end)
        bb_cycles = curr[7]       # newer entry's cycles

        # oss_pmutools does NOT filter BB pairs — all adjacent pairs are
        # aggregated. inst_per_visit = max(1, ...) handles negative ranges.
        # cycles can be 0 (just adds 0 to total).

        # Use virtual address triple as key (same as oss_pmutools)
        bb_key = (curr[2], bb_start_ip, bb_end_ip)

        # Compute file offsets for output (oss_pmutools format)
        # start = nxt.to_file_offset, end = curr.from_file_offset
        start_offset = nxt[13]    # to_file_offset of older entry (BB start)
        end_offset = curr[12]     # from_file_offset of newer entry (BB end)

        # Single-visit instruction count (same formula as oss_pmutools)
        inst_per_visit = max(1, (bb_end_ip - bb_start_ip) // 4 + 1)

        if bb_key not in bb_map:
            # First visit: capture symbol/binary from the BB start address
            # oss_pmutools uses begin_addr (prv.to_pc) for symbol
            symbol = nxt[10]   # to_symbol of older entry (BB start)
            binary = nxt[11]   # to_binary of older entry
            # Fall back to from_symbol of newer entry
            if symbol is None:
                symbol = curr[8]   # from_symbol of newer entry
            if binary is None:
                binary = curr[9]   # from_binary of newer entry

            bb_map[bb_key] = {
                "tid": curr[2],
                "tname": curr[3],
                "binary": binary,
                "symbol": symbol,
                "start_offset": hex(start_offset) if start_offset is not None else None,
                "end_offset": hex(end_offset) if end_offset is not None else None,
                "start_offset_int": start_offset,
                "end_offset_int": end_offset,
                "visits": 0,
                "inst_count": 0,
                "cycles": 0,
            }

        agg = bb_map[bb_key]
        agg["visits"] += 1
        agg["inst_count"] += inst_per_visit
        agg["cycles"] += bb_cycles

    # Compute IPC and build output list
    basic_blocks: list[dict[str, Any]] = []
    for bb in bb_map.values():
        ipc = (
            round(bb["inst_count"] / bb["cycles"], 3)
            if bb["cycles"] > 0
            else None
        )
        # Build output dict (remove internal fields)
        out = {
            "tid": bb["tid"],
            "tname": bb["tname"],
            "binary": bb["binary"],
            "symbol": bb["symbol"],
            "start_offset": bb["start_offset"],
            "end_offset": bb["end_offset"],
            "visits": bb["visits"],
            "inst_count": bb["inst_count"],
            "cycles": bb["cycles"],
            "ipc": ipc,
        }
        basic_blocks.append(out)

    # Sort by total_cycles DESC, take top N
    basic_blocks.sort(key=lambda x: x["cycles"], reverse=True)
    top_bbs = basic_blocks[:top_n]

    ipc_values = [b["ipc"] for b in basic_blocks if b["ipc"] is not None]
    avg_ipc = (sum(ipc_values) / len(ipc_values)) if ipc_values else 0.0

    ctx.data = {
        "summary": {
            "total_bb_pairs": len(basic_blocks),
            "returned_count": len(top_bbs),
            "avg_ipc": avg_ipc,
            "max_cycles_bb": top_bbs[0] if top_bbs else None,
            "filter_context": {"tid": tid, "top_n": top_n,
                                "start_ms": start_ms, "end_ms": end_ms},
        },
        "data": top_bbs,
    }
    return ctx


@register_operator("aggregate_brbe_functions")
def aggregate_brbe_functions(ctx: PreprocessContext) -> PreprocessContext:
    """Aggregate BRBE entries by (thread_id, from_symbol, from_binary).

    Computes per-function: sample_count, total_cycles, est_inst_count, IPC.
    est_inst_count approximates instructions in the function body spanned by
    each BRBE entry: (to_ip - from_ip) // 4 + 1 when to_ip > from_ip.

    Zero JOIN — from_symbol/from_binary already populated by hiperf_extender.
    """
    conn = ctx.sqlite_conn
    tid = ctx.params.get("tid")
    top_n = ctx.params.get("top_n", 10)
    start_ms = ctx.params.get("start_ms")
    end_ms = ctx.params.get("end_ms")

    rows = conn.execute(
        "SELECT thread_id, thread_name, from_symbol, from_binary, "
        "cycles, from_ip, to_ip "
        "FROM brbe_sample "
        "WHERE (:tid IS NULL OR thread_id = :tid) AND from_symbol IS NOT NULL "
        "AND (:start_ms IS NULL OR timestamp_ns >= :start_ms * 1000000) "
        "AND (:end_ms IS NULL OR timestamp_ns < :end_ms * 1000000)",
        {"tid": tid, "start_ms": start_ms, "end_ms": end_ms},
    ).fetchall()

    func_map: dict[tuple, dict[str, Any]] = {}
    for row in rows:
        key = (row[0], row[2], row[3])
        if key not in func_map:
            func_map[key] = {
                "tid": row[0],
                "tname": row[1],
                "symbol": row[2],
                "binary": row[3],
                "sample_count": 0,
                "total_cycles": 0,
                "est_inst_count": 0,
            }
        agg = func_map[key]
        agg["sample_count"] += 1
        agg["total_cycles"] += row[4]
        if row[6] > row[5]:  # to_ip > from_ip
            agg["est_inst_count"] += (row[6] - row[5]) // 4 + 1

    functions = list(func_map.values())
    for f in functions:
        f["ipc"] = (
            round(f["est_inst_count"] / f["total_cycles"], 3)
            if f["total_cycles"] > 0
            else None
        )

    functions.sort(key=lambda x: x["total_cycles"], reverse=True)
    top_funcs = functions[:top_n]

    ctx.data = {
        "summary": {
            "total_functions": len(functions),
            "returned_count": len(top_funcs),
            "filter_context": {"tid": tid, "top_n": top_n,
                                "start_ms": start_ms, "end_ms": end_ms},
        },
        "data": top_funcs,
    }
    return ctx


@register_operator("aggregate_brbe_mispredict")
def aggregate_brbe_mispredict(ctx: PreprocessContext) -> PreprocessContext:
    """Aggregate branch misprediction by (thread_id, from_ip, from_symbol).

    Computes per-branch-site: branch_count, mispredict_count, mispredict_rate.
    """
    conn = ctx.sqlite_conn
    tid = ctx.params.get("tid")
    top_n = ctx.params.get("top_n", 10)
    start_ms = ctx.params.get("start_ms")
    end_ms = ctx.params.get("end_ms")

    rows = conn.execute(
        "SELECT thread_id, thread_name, from_ip, from_symbol, from_binary, "
        "is_mispredicted "
        "FROM brbe_sample "
        "WHERE (:tid IS NULL OR thread_id = :tid) "
        "AND (:start_ms IS NULL OR timestamp_ns >= :start_ms * 1000000) "
        "AND (:end_ms IS NULL OR timestamp_ns < :end_ms * 1000000)",
        {"tid": tid, "start_ms": start_ms, "end_ms": end_ms},
    ).fetchall()

    branch_map: dict[tuple, dict[str, Any]] = {}
    for row in rows:
        key = (row[0], row[2], row[3])
        if key not in branch_map:
            branch_map[key] = {
                "tid": row[0],
                "tname": row[1],
                "from_ip": row[2],
                "symbol": row[3],
                "binary": row[4],
                "branch_count": 0,
                "mispredict_count": 0,
            }
        agg = branch_map[key]
        agg["branch_count"] += 1
        agg["mispredict_count"] += row[5]

    branches = list(branch_map.values())
    for b in branches:
        b["mispredict_rate"] = (
            round(b["mispredict_count"] / b["branch_count"] * 100, 2)
            if b["branch_count"] > 0
            else 0.0
        )

    branches.sort(key=lambda x: x["mispredict_count"], reverse=True)
    top_branches = branches[:top_n]

    ctx.data = {
        "summary": {
            "total_branch_sites": len(branches),
            "returned_count": len(top_branches),
            "total_mispredicts": sum(b["mispredict_count"] for b in branches),
            "filter_context": {"tid": tid, "top_n": top_n,
                                "start_ms": start_ms, "end_ms": end_ms},
        },
        "data": top_branches,
    }
    return ctx


@register_operator("aggregate_spe_miss")
def aggregate_spe_miss(ctx: PreprocessContext) -> PreprocessContext:
    """Aggregate SPE memory samples by (thread_id, pc, pc_symbol).

    Computes per-PC: l1d/llc/tlb access+miss counts and miss rates, plus
    average miss latency. SPE = Statistical Profiling Extension (ARM).

    Zero JOIN — pc_symbol/pc_binary already populated by hiperf_extender.
    """
    conn = ctx.sqlite_conn
    tid = ctx.params.get("tid")
    top_n = ctx.params.get("top_n", 10)
    start_ms = ctx.params.get("start_ms")
    end_ms = ctx.params.get("end_ms")

    rows = conn.execute(
        "SELECT thread_id, thread_name, pc, pc_symbol, pc_binary, "
        "op_type, reg_type, retired, l1d_access, l1d_miss, "
        "llc_access, llc_miss, tlb_access, tlb_miss, miss_latency_ns "
        "FROM spe_sample "
        "WHERE (:tid IS NULL OR thread_id = :tid) "
        "AND (:start_ms IS NULL OR timestamp_ns >= :start_ms * 1000000) "
        "AND (:end_ms IS NULL OR timestamp_ns < :end_ms * 1000000)",
        {"tid": tid, "start_ms": start_ms, "end_ms": end_ms},
    ).fetchall()

    pc_map: dict[tuple, dict[str, Any]] = {}
    for row in rows:
        key = (row[0], row[2], row[3])
        if key not in pc_map:
            pc_map[key] = {
                "tid": row[0], "tname": row[1], "pc": row[2],
                "symbol": row[3], "binary": row[4],
                "op_type": row[5], "reg_type": row[6],
                "retired": 0, "l1d_access": 0, "l1d_miss": 0,
                "llc_access": 0, "llc_miss": 0,
                "tlb_access": 0, "tlb_miss": 0,
                "miss_latencies": [],
            }
        agg = pc_map[key]
        agg["retired"] += row[7]
        agg["l1d_access"] += row[8]
        agg["l1d_miss"] += row[9]
        agg["llc_access"] += row[10]
        agg["llc_miss"] += row[11]
        agg["tlb_access"] += row[12]
        agg["tlb_miss"] += row[13]
        if row[14]:
            agg["miss_latencies"].append(row[14])

    pcs = list(pc_map.values())
    for p in pcs:
        p["l1d_miss_rate"] = (
            round(p["l1d_miss"] / p["l1d_access"] * 100, 2)
            if p["l1d_access"] > 0 else 0.0
        )
        p["llc_miss_rate"] = (
            round(p["llc_miss"] / p["llc_access"] * 100, 2)
            if p["llc_access"] > 0 else 0.0
        )
        p["tlb_miss_rate"] = (
            round(p["tlb_miss"] / p["tlb_access"] * 100, 2)
            if p["tlb_access"] > 0 else 0.0
        )
        p["avg_miss_latency_ns"] = (
            round(sum(p["miss_latencies"]) / len(p["miss_latencies"]), 2)
            if p["miss_latencies"] else 0.0
        )
        del p["miss_latencies"]

    pcs.sort(
        key=lambda x: x["l1d_miss"] + x["llc_miss"] + x["tlb_miss"],
        reverse=True,
    )
    top_pcs = pcs[:top_n]

    ctx.data = {
        "summary": {
            "total_pcs": len(pcs),
            "returned_count": len(top_pcs),
            "filter_context": {"tid": tid, "top_n": top_n,
                                "start_ms": start_ms, "end_ms": end_ms},
        },
        "data": top_pcs,
    }
    return ctx
