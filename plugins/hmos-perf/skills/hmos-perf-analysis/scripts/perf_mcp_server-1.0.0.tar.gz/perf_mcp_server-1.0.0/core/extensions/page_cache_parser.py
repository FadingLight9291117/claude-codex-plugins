"""Page Cache 事件解析器 - 解析 .ftrace 中的 mm_filemap 事件"""
from dataclasses import dataclass
from typing import List, Optional, Iterator
import re
from core.observability import get_module_logger

logger = get_module_logger(__name__)


@dataclass
class PageCacheEvent:
    """Page Cache 事件"""
    ts_ns: int          # 纳秒时间戳
    cpu: int            # CPU编号
    itid: int           # 内部线程ID (从括号中的数字)
    comm: str           # 进程/线程名
    pid: int            # 进程ID
    dev_major: int      # 设备主号
    dev_minor: int      # 设备次号
    i_ino: int          # inode号 (解析后为int)
    pfn: int            # 页帧号
    index: int          # 页索引
    offset: int         # 文件偏移量 (ofs)
    is_add: bool        # True=add_to_page_cache, False=delete_from_page_cache


# 解析 ftrace 行格式:
# OS_IPC_6389_919-9191    (    539) [002] .... 2573398.671607: mm_filemap_add_to_page_cache: dev 260:69 ino 1 page=0xffffffffffffffff pfn=1310211 ofs=1626112
# comm        pid    itid  cpu            ts(seconds)  event_type                                              dev        ino   pfn        ofs

FILTMAP_PATTERN = re.compile(
    r'^\s*(\S+)\s+'                    # comm (进程名)
    r'\((\s*\d+)\)\s+'                  # pid
    r'\[(\d+)\]\s+'                    # cpu
    r'\S+\s+'                           # 状态位
    r'(\d+\.\d+):\s+'                   # ts (秒)
    r'mm_filemap_(add_to_page_cache|delete_from_page_cache):\s+'
    r'dev\s+(\d+):(\d+)\s+'            # dev_major:dev_minor
    r'ino\s+([0-9a-fA-F]+)\s+'         # inode (hex)
    r'page=[^\s]+\s+'                   # page=xxx (忽略)
    r'pfn=(\d+)\s+'                    # pfn
    r'ofs=(\d+)'                       # offset
)


def parse_ftrace_line(line: str) -> Optional[PageCacheEvent]:
    """解析单行 ftrace，返回 PageCacheEvent 或 None"""
    match = FILTMAP_PATTERN.match(line)
    if not match:
        return None

    comm = match.group(1)
    pid = int(match.group(2).strip())
    cpu = int(match.group(3))
    ts_sec = float(match.group(4))
    event_type = match.group(5)  # "add_to_page_cache" or "delete_from_page_cache"
    dev_major = int(match.group(6))
    dev_minor = int(match.group(7))
    i_ino = int(match.group(8), 16)  # hex to int
    pfn = int(match.group(9))
    offset = int(match.group(10))

    return PageCacheEvent(
        ts_ns=int(ts_sec * 1e9),
        cpu=cpu,
        itid=pid,  # 用 pid 作为 itid (因为ftrace中tid就是pid)
        comm=comm,
        pid=pid,
        dev_major=dev_major,
        dev_minor=dev_minor,
        i_ino=i_ino,
        pfn=pfn,
        index=offset // 4096,  # 4KB page size, index = offset / page_size
        offset=offset,
        is_add=(event_type == "add_to_page_cache"),
    )


def parse_page_cache_events(ftrace_path: str) -> List[PageCacheEvent]:
    """解析整个 ftrace 文件，返回 PageCacheEvent 列表"""
    events = []
    total_lines = 0
    parsed_lines = 0

    with open(ftrace_path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            total_lines += 1
            if 'mm_filemap' in line:
                event = parse_ftrace_line(line)
                if event:
                    events.append(event)
                    parsed_lines += 1

    logger.info(f"Parsed {parsed_lines} page cache events from {total_lines} total lines")
    return events


def parse_page_cache_events_generator(ftrace_path: str) -> Iterator[PageCacheEvent]:
    """流式解析 ftrace 文件，yield PageCacheEvent (内存高效)"""
    with open(ftrace_path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if 'mm_filemap' in line:
                event = parse_ftrace_line(line)
                if event:
                    yield event
