"""SQLite 连接缓存（按 path+mtime 复用）。

性能优化：避免每次 QueryEngine.execute 都重新 sqlite3.connect，
保留 SQLite page cache 在多次调用之间复用。

缓存策略:
- key = (绝对路径, mtime)
- mtime 变化时关闭旧连接、开新连接
- LRU 淘汰，默认上限 8 个连接
- 线程不安全：调用方需保证单线程访问；query_engine 一次 execute 内串行使用

索引优化(规则 34, 性能优先):
- TraceStreamer 生成的 trace.db 无索引，大表(callstack/measure/thread_state)全表扫描
- 首次连接时自动创建索引(IF NOT EXISTS 幂等)，实测从 335ms/查询降到 17ms/查询
- thread_state 覆盖索引(state,ts,dur,cpu,itid,tid,pid): 覆盖索引避免回表
  cpu_load/uninterruptible_dstate: 26ms → 0.1ms (范围扫描)
  thread_sched branch2 (ts+dur>start): 84ms → 11ms (USING COVERING INDEX)
- args(argset, key, datatype, value) + data_dict(id, data) 覆盖索引
  服务 heap/hiperf YAML SQL 的 LEFT JOIN args + data_dict
- 已移除的索引：
  idx_callstack_callid（game_render_ops 用 itid JOIN 不走此索引）
  idx_callstack_ts_cookie_callid（trace_marker_hotpath 已迁移到 TraceDataCache）
  idx_callstack_depth_ts_callid_dur（game_render_ops 全部 callstack SQL 已迁移到 TraceDataCache）
- 索引创建耗时 ~2.5s(首次),DB 文件增量 ~90MB（性能优先,接受 DB 增大）
- IF NOT EXISTS 保证幂等,索引已存在时 0ms
"""
from __future__ import annotations

import sqlite3
import threading
from collections import OrderedDict
from pathlib import Path
from typing import Optional, Tuple

_MAX_CONN_CACHE = 8
_conn_cache: "OrderedDict[Tuple[str, float], sqlite3.Connection]" = OrderedDict()
_lock = threading.Lock()

# trace.db 关键索引(仅大表,小表全表扫已足够快)
# 规则 34: 只为已验证的高收益查询加索引
# - measure.filter_id: JOIN measure_filter ON m.filter_id = mf.id
# - thread_state(state, ts, dur, cpu, itid, tid, pid): 覆盖索引
#   服务 cpu_load / uninterruptible_dstate / thread_sched_analysis branch1+branch2
#   (state, ts) 命中范围扫描；dur/cpu/itid/tid/pid 让 SQLite 在索引内算 ts+dur 过滤，不回表
#   thread_sched branch2 (ts+dur>start): 84ms → 11ms (USING COVERING INDEX, 不回表)
# 小表(thread 1.5K / measure_filter 193 行)索引收益 <1ms,不加
_TRACE_DB_INDEXES = [
    # idx_callstack_depth_ts_callid_dur 已移除（game_render_ops 全部 callstack SQL 已迁移到 TraceDataCache）
    # idx_callstack_callid 已移除（game_render_ops 用 itid JOIN 不走此索引）
    # idx_callstack_ts_cookie_callid 已移除（trace_marker_hotpath 已迁移到 TraceDataCache）
    "CREATE INDEX IF NOT EXISTS idx_measure_filter_id ON measure(filter_id)",
    "CREATE INDEX IF NOT EXISTS idx_thread_state_state_ts ON thread_state(state, ts, dur, cpu, itid, tid, pid)",
    # args(data_dict) 覆盖索引：仍被 heap/hiperf YAML SQL 使用
    "CREATE INDEX IF NOT EXISTS idx_args_argset_key_datatype_value ON args(argset, key, datatype, value)",
    "CREATE INDEX IF NOT EXISTS idx_data_dict_id_data ON data_dict(id, data)",
]


def _make_conn(sqlite_path: str) -> sqlite3.Connection:
    """打开新连接，配置 row_factory 和 PRAGMA。

    注意：不启用 WAL 模式，避免修改 trace.db 文件头（保持 fixtures 不变）。
    """
    conn = sqlite3.connect(sqlite_path, timeout=30.0)
    conn.row_factory = sqlite3.Row
    # 只读场景下提升性能的 PRAGMA（不修改 .db 文件）
    try:
        conn.execute("PRAGMA cache_size=-65536")  # 64MB cache
        conn.execute("PRAGMA temp_store=MEMORY")
    except sqlite3.Error:
        pass
    # 首次连接时自动创建索引(规则 34: 只为已验证的高收益查询加索引)
    # IF NOT EXISTS 保证幂等,索引已存在时 0ms
    try:
        for ddl in _TRACE_DB_INDEXES:
            conn.execute(ddl)
        conn.commit()
    except sqlite3.Error:
        # 只读文件或无写权限: 索引创建失败不影响功能,退化为全表扫描
        pass
    return conn


def get_cached_connection(sqlite_path: str) -> sqlite3.Connection:
    """获取缓存的 SQLite 连接。

    若 path+mtime 命中缓存，直接返回已有连接；
    若 mtime 变化或新 path，关闭旧连接并开新连接；
    LRU 超限则淘汰最旧连接并关闭。
    """
    abs_path = str(Path(sqlite_path).resolve())
    try:
        mtime = Path(sqlite_path).stat().st_mtime
    except OSError:
        # 文件不存在或无法 stat，退化为不缓存
        return _make_conn(sqlite_path)

    cache_key = (abs_path, mtime)

    with _lock:
        # 命中缓存：移到末尾（LRU）
        if cache_key in _conn_cache:
            _conn_cache.move_to_end(cache_key)
            return _conn_cache[cache_key]

        # 同 path 不同 mtime：关闭旧连接
        old_key_to_remove: Optional[Tuple[str, float]] = None
        for k in _conn_cache:
            if k[0] == abs_path:
                old_key_to_remove = k
                break
        if old_key_to_remove is not None:
            old_conn = _conn_cache.pop(old_key_to_remove)
            try:
                old_conn.close()
            except sqlite3.Error:
                pass

        # LRU 淘汰
        while len(_conn_cache) >= _MAX_CONN_CACHE:
            _, evicted_conn = _conn_cache.popitem(last=False)
            try:
                evicted_conn.close()
            except sqlite3.Error:
                pass

        # 开新连接
        conn = _make_conn(sqlite_path)
        _conn_cache[cache_key] = conn
        return conn


def close_all() -> None:
    """关闭所有缓存连接（用于测试或程序退出前的清理）。"""
    with _lock:
        while _conn_cache:
            _, conn = _conn_cache.popitem(last=False)
            try:
                conn.close()
            except sqlite3.Error:
                pass


def cache_size() -> int:
    """当前缓存连接数（用于测试/调试）。"""
    with _lock:
        return len(_conn_cache)
