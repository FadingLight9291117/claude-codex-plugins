"""渲染帧解析算子：构建跨线程的渲染帧链路。

匹配逻辑：
1. VSyncGenerator:SendVsync(now) → RS:RecvVsync(now, vsyncId) 通过时间戳匹配
2. UI:MarshRSTransaction(transactionFlag:[tid,seq]) 在 UI RecvVsync 时间窗口内
3. RS:ProcessCommandUni([tid,seq]) 通过 transactionFlag 匹配 UI 帧
4. RS_render:RenderFrame 和 H:Render(vsyncId) 在 RS RecvVsync 时间窗口内，vsyncId 匹配
5. HWC:CommitLayers 的时间窗口内包含 Present(fenceId)
6. Present:Waiting for Present Fence(fenceId) 与 HwcPresentDisplay(fenceId) 匹配

Jank 判定：callstack 中存在 JANK_FRAME_FILTERED: skipppedFrameTime=xxx 事件
"""
from __future__ import annotations

from core.observability import get_module_logger
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set

from .base import PreprocessContext, PreprocessError, register_operator

log = get_module_logger(__name__)

# ---------------------------------------------------------------------------
# 进程名解析（线程名=进程名，主线程名映射到应用名）
# ---------------------------------------------------------------------------

_process_name_cache: Dict[str, Any] = {}


def _get_process_name_func():
    """延迟加载 get_window_name/get_process_name 函数。"""
    if "get_window_name" not in _process_name_cache:
        try:
            from utils.process_name import get_window_name, get_process_name
            _process_name_cache["get_window_name"] = get_window_name
            _process_name_cache["get_process_name"] = get_process_name
        except ImportError:
            _process_name_cache["get_window_name"] = lambda x: x or ""
            _process_name_cache["get_process_name"] = lambda x: x or ""
    return _process_name_cache["get_window_name"], _process_name_cache["get_process_name"]


def _resolve_app_name(thread_name: Optional[str]) -> str:
    """将线程名解析为中文应用名（线程名=进程名）。"""
    get_win, get_proc = _get_process_name_func()
    if not thread_name:
        return ""
    # 先尝试 window_name 映射（主窗口场景）
    name = get_win(thread_name)
    if name and name != thread_name:
        return name
    # 再尝试进程名映射
    return get_proc(thread_name)


def load_tid_process_map(conn) -> Dict[int, str]:
    """预加载 tid → process_name 映射。

    通过 thread 表 JOIN process 表获取每个 tid 对应的进程名。

    Returns:
        {tid: process_name, ...} 映射，查不到的 tid 不在字典中
    """
    tid_map: Dict[int, str] = {}
    try:
        rows = conn.execute("""
            SELECT t.tid, p.name as process_name
            FROM thread t
            LEFT JOIN process p ON t.ipid = p.ipid
        """).fetchall()
        for tid, process_name in rows:
            if tid is not None and process_name is not None:
                tid_map[tid] = process_name.strip()
    except Exception as e:
        log.warning("load_tid_process_map: 查询失败: %s", e)
    return tid_map


# ---------------------------------------------------------------------------
# 正则表达式
# ---------------------------------------------------------------------------

# SendVsyncTo: H:SendVsyncTo conn: WM_33461, now:18273727806980, refreshRate:0
SEND_VSYNC_RE = re.compile(r'H:SendVsyncTo conn:\s*(\S+), now:(\d+)')

# ReceiveVsync: H:ReceiveVsync name:WM_33461 dataCount: 24bytes now:18273727806980 expectedEnd: 18273744511742 vsyncId: 627321
# Note: some traces have space after 'now:'/'vsyncId:' colons, use \s* to be tolerant
RECV_VSYNC_RE = re.compile(
    r'H:ReceiveVsync(?: name:(\S+))?\s+dataCount:\s*\d+\s*bytes\s+now:\s*(\d+).*?expectedEnd:\s*(\d+).*?vsyncId:\s*(\d+)'
)

# MarshRSTransactionData: H:MarshRSTransactionData cmdCount: 51, transactionFlag:[33461,98], tid:33461, timestamp:18273727806980
MARSH_RS_RE = re.compile(
    r'H:MarshRSTransactionData.*transactionFlag:\[(\d+),(\d+)\]'
)

# ProcessCommandUni: H:RSMainThread::ProcessCommandUni [33461,97] [33461,98] ...
# 捕获所有 [tid,seq] 对
PROC_CMD_RE = re.compile(
    r'H:RSMainThread::ProcessCommandUni\s+((?:\[\d+,\d+\]\s*)+)'
)

# RenderFrame: H:RenderFrame
RENDER_FRAME_RE = re.compile(r'H:RenderFrame')

# H:Render: H:Render vsyncId: 524136 (some traces have space after 'vsyncId:', use \s* to be tolerant)
RENDER_RE = re.compile(r'H:Render vsyncId:\s*(\d+)')

# CommitLayers: H:CommitLayers rate:72,now:18273736159911,vsyncId:524136,size:3
# Note: some traces have space after 'now:'/'vsyncId:' colons, use \s* to be tolerant
COMMIT_LAYERS_RE = re.compile(
    r'H:CommitLayers.*?rate:\s*(\d+).*?now:\s*(\d+).*?vsyncId:\s*(\d+)'
)

# HwcPresentDisplay: H:HwcPresentDisplay
HWC_PRESENT_RE = re.compile(r'H:HwcPresentDisplay')

# Waiting for Present Fence: H:Waiting for Present Fence 307624
WAIT_PRESENT_RE = re.compile(r'H:Waiting\s+for\s+PresentFence_\d+\s+(\d+)')

# Waiting for Acquire Fence: H:Waiting for Acquire Fence 1680|I38
WAIT_ACQUIRE_FENCE_RE = re.compile(r'H:Waiting\s+for\s+Acquire\s+Fence\s+(\d+)\|')

# Acquire Fence: H:Acquire Fence 1680|I38
ACQUIRE_FENCE_RE = re.compile(r'H:Acquire\s+Fence\s+(\d+)\|')

# Jank event: JANK_FRAME_UNFILTERED: skipppedFrameTime=120(ms), windowName=aweme0
JANK_FRAME_RE = re.compile(r'JANK_FRAME_UNFILTERED:\s*skipppedFrameTime=(\d+).*windowName=(\S+)')

# Animate: H:Animate from pid [3483]
ANIMATE_RE = re.compile(r'H:Animate\s+from\s+pid\s+((?:\[\d+\]\s*)+)')

# ProcCmd.name 中所有 [tid,seq] 对（用于解析 ProcessCommandUni）
_TID_SEQ_RE = re.compile(r'\[(\d+),(\d+)\]')


# ---------------------------------------------------------------------------
# Jank 检测辅助函数
# ---------------------------------------------------------------------------

def _smooth_frame_rates(interval_arr: List[int], window_size: int) -> List[int]:
    """基于滑动窗口计算平滑帧率（调和平均）。

    对帧率序列做滑动窗口调和平均：smoothed[i] = len(window) / sum(1/rate_i for i in window)
    """
    rates = [_compute_actual_rate(iv) for iv in interval_arr]
    n = len(rates)
    half = window_size // 2
    smoothed = []
    for i in range(n):
        window_rates = rates[max(0, i - half):min(n, i + half + 1)]
        harmonic_sum = sum(1.0 / r for r in window_rates if r > 0)
        if harmonic_sum > 0:
            smoothed.append(int(len(window_rates) / harmonic_sum))
        else:
            smoothed.append(60)
    return smoothed


def _compute_actual_rate(interval_ns: int) -> int:
    """根据 present 间隔(ns) 计算实际帧率（离散档位）。

    公式: round(360 / round(interval_us / 2777) * 2777.77 / 2777)
    其中 interval_us = interval_ns / 1000（微秒）。
    结果落在 15/30/45/60/72/90/120Hz 等离散档位。
    """
    # 处理 NaN 或非正数间隔
    try:
        if interval_ns <= 0 or (isinstance(interval_ns, float) and interval_ns != interval_ns):
            return 60
    except (TypeError, ValueError):
        return 60
    interval_us = interval_ns / 1000
    normalized = int(round(interval_us / 2777) * 2777.77)
    return round(360 / round(normalized / 2777))


def _get_refresh_rate_tag(
    actual_rates: List[int],
    smooth_rates: List[int],
    is_anim: bool,
) -> str:
    """判断帧率趋势，返回 tag：稳定/上升/下降/无感知/帧率突变/跟手卡顿。

    actual_rates[2] 为当前帧对应位置。
    smooth_rates 长度为 9，前后各 4 帧，不足时填充 60。
    """
    if min(actual_rates) == max(actual_rates):
        return "稳定"
    # 当前帧帧率低于最低阈值，无论趋势如何都算帧率突变
    min_rate_threshold = 20 if is_anim else 30
    if actual_rates[2] < min_rate_threshold:
        return "帧率突变"
    # 当前帧是局部峰值，且与相邻帧差距不大 → 无感知（微抖动）
    if (actual_rates[2] >= actual_rates[1] and actual_rates[2] >= actual_rates[3] and
            actual_rates[2] - actual_rates[1] <= 5 and actual_rates[2] - actual_rates[3] <= 5):
        return "无感知"
    threshold = 30 if is_anim else 59
    left_max = max(smooth_rates[:4]) if smooth_rates[:4] else 60
    right_max = max(smooth_rates[5:]) if smooth_rates[5:] else 60
    if left_max <= threshold and right_max <= threshold:
        return "无感知"
    if left_max <= threshold:
        return "上升"
    if right_max <= threshold:
        return "下降"
    if actual_rates[0] <= actual_rates[1] <= actual_rates[2] <= actual_rates[3] <= actual_rates[4]:
        return "上升"
    if actual_rates[0] >= actual_rates[1] >= actual_rates[2] >= actual_rates[3] >= actual_rates[4]:
        return "下降"
    if actual_rates[2] >= actual_rates[1] and actual_rates[2] >= actual_rates[3]:
        return "无感知"
    return "帧率突变"


def _format_frame_rate_trend(actual_rates: List[int], cur_index: int = 2) -> str:
    """格式化帧率趋势字符串：60Hz -> 60Hz -> 60Hz(当前帧) -> 60Hz -> 60Hz"""
    parts = [f"{rate}Hz" for rate in actual_rates]
    parts[cur_index] += "(当前帧)"
    return " -> ".join(parts)


# ---------------------------------------------------------------------------
# 数据结构
# ---------------------------------------------------------------------------

@dataclass
class RenderFrame:
    """构建后的完整渲染帧。"""
    app_name: Optional[str] = None
    ui_vsync_id: Optional[int] = None
    rs_vsync_id: Optional[int] = None
    present_id: Optional[int] = None
    recv_vsync_ts: Optional[int] = None  # UI RecvVsync 的 ts（实际打点时间）

    ui_tid: Optional[int] = None
    ui_thread_name: Optional[str] = None
    ui_begin_ts: Optional[int] = None
    ui_recv_complete_ts: Optional[int] = None
    ui_dur_ns: Optional[int] = None
    ui_marsh_end_ts: Optional[int] = None  # marsh_ts + marsh_dur + 4ms

    rs_tid: Optional[int] = None
    rs_begin_ts: Optional[int] = None
    rs_complete_ts: Optional[int] = None
    rs_dur_ns: Optional[int] = None

    rs_render_tid: Optional[int] = None
    rs_render_begin_ts: Optional[int] = None
    rs_render_dur_ns: Optional[int] = None

    gpu_begin_ts: Optional[int] = None  # GPU 等待起始时间
    gpu_dur_ns: Optional[int] = None  # GPU 等待耗时

    hwc_begin_ts: Optional[int] = None
    hwc_dur_ns: Optional[int] = None

    present_begin_ts: Optional[int] = None
    present_dur_ns: Optional[int] = None

    pipeline_dur_ns: Optional[int] = None  # 整帧耗时：ui_begin_ts → present_end
    frame_interval_ns: Optional[int] = None  # 帧间隔：上次 present_end → 本次 present_end
    frame_rate: Optional[int] = None  # 实时帧率（Hz）
    jank: bool = False  # 是否 jank
    jank_type: Optional[str] = None  # "trace" / "interval" / "both"
    jank_tag: Optional[str] = None  # get_refresh_rate_tag 返回的 tag
    skipped_time_ms: Optional[int] = None  # Trace 打点跳帧时长
    jank_window: Optional[str] = None  # Trace 打点窗口名
    frame_rate_trend: Optional[str] = None  # 帧率趋势："60Hz -> 60Hz -> 60Hz(当前帧) -> 60Hz -> 60Hz"
    display: bool = False


# ---------------------------------------------------------------------------
# 事件解析
# ---------------------------------------------------------------------------

def _parse_callstack(callstack_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """解析 callstack 行，构建各类事件字典。

    Returns:
        {
            'send_vsync': {conn: [(ts, now, name), ...]},
            'recv_vsync': {conn: [(ts, now, expected_end, vsync_id, dur, name), ...]},
            'marsh': [(ts, tid, seq, timestamp, name), ...],
            'proc_cmd': [(ts, tid, seq, name), ...],   # 每条存一个 tid/seq
            'animate': [(ts, [tid, ...], name), ...],
            'render_frame': [(ts, dur, name), ...],
            'render': [(ts, dur, vsync_id, name), ...],
            'commit_layers': [(now_ts, vsync_id, dur, name), ...],
            'hwc_present': [(ts, dur, name), ...],
            'wait_present': [(fence_id, ts, dur, name), ...],
            'jank_frames': [(ts, skipped_time_ms, window_name, raw_name), ...],
        }
    """
    send_vsync: Dict[str, List] = {}
    recv_vsync: Dict[str, List] = {}
    marsh_events: List = []
    proc_cmd_events: List = []
    animate_events: List = []
    render_frame_events: List = []
    render_events: List = []
    commit_layers_events: List = []
    hwc_present_events: List = []
    wait_present_events: List = []
    wait_acquire_fence_events: List = []
    acquire_fence_events: List = []
    jank_frames: List = []

    # 辅助：解析 ProcCmd.name 中所有 [tid,seq] 对（正则在模块级已编译）

    for row in callstack_rows:
        # 支持 tuple (ts, dur, name, ...) 或 dict {ts, dur, name, ...}
        if isinstance(row, tuple):
            ts, dur = row[0], (row[1] or 0)
            name = row[2] if len(row) > 2 else ""
        else:
            ts = row.get("ts")
            name = row.get("name", "")
            dur = row.get("dur", 0) or 0

        # SendVsyncTo
        m = SEND_VSYNC_RE.search(name)
        if m:
            conn, now = m.group(1), int(m.group(2))
            if conn not in send_vsync:
                send_vsync[conn] = []
            send_vsync[conn].append((ts, now, name))
            continue

        # ReceiveVsync
        m = RECV_VSYNC_RE.search(name)
        if m:
            conn, now, expected_end, vsync_id = m.group(1) or "", int(m.group(2)), int(m.group(3)), int(m.group(4))
            if conn not in recv_vsync:
                recv_vsync[conn] = []
            recv_vsync[conn].append((ts, now, expected_end, vsync_id, dur, name))
            continue

        # MarshRSTransactionData
        m = MARSH_RS_RE.search(name)
        if m:
            tid, seq = int(m.group(1)), int(m.group(2))
            # 解析 timestamp
            ts_match = re.search(r'timestamp:(\d+)', name)
            timestamp = int(ts_match.group(1)) if ts_match else 0
            marsh_events.append((ts, tid, seq, timestamp, name, dur))
            continue

        # ProcessCommandUni: 解析所有 [tid,seq] 对，每对存一条
        if PROC_CMD_RE.search(name):
            for t, s in _TID_SEQ_RE.findall(name):
                proc_cmd_events.append((ts, int(t), int(s), name))
            continue

        # Animate: H:Animate from pid [3483] [3484] ...
        m = ANIMATE_RE.search(name)
        if m:
            tids = [int(x) for x in re.findall(r'\[(\d+)\]', m.group(1))]
            animate_events.append((ts, tids, name))
            continue

        # RenderFrame
        if RENDER_FRAME_RE.search(name):
            render_frame_events.append((ts, dur, name))
            continue

        # H:Render
        m = RENDER_RE.search(name)
        if m:
            vsync_id = int(m.group(1))
            render_events.append((ts, dur, vsync_id, name))
            continue

        # CommitLayers
        m = COMMIT_LAYERS_RE.search(name)
        if m:
            rate, now_ts, vsync_id = int(m.group(1)), int(m.group(2)), int(m.group(3))
            commit_layers_events.append((rate, now_ts, vsync_id, dur, name))
            continue

        # HwcPresentDisplay
        if HWC_PRESENT_RE.search(name):
            hwc_present_events.append((ts, dur, name))
            continue

        # Waiting for Present Fence
        m = WAIT_PRESENT_RE.search(name)
        if m:
            fence_id = int(m.group(1))
            wait_present_events.append((fence_id, ts, dur, name))
            continue

        # Waiting for Acquire Fence (GPU 等待耗时)
        m = WAIT_ACQUIRE_FENCE_RE.search(name)
        if m:
            fence_id = int(m.group(1))
            wait_acquire_fence_events.append((fence_id, ts, dur, name))
            continue

        # Acquire Fence (用于关联 fence_id)
        m = ACQUIRE_FENCE_RE.search(name)
        if m:
            fence_id = int(m.group(1))
            acquire_fence_events.append((ts, dur, fence_id, name))
            continue

        # JANK_FRAME_FILTERED
        m = JANK_FRAME_RE.search(name)
        if m:
            skipped_ms = int(m.group(1))
            window_name = m.group(2)
            jank_frames.append((ts, skipped_ms, window_name, name))
            continue

    return {
        "send_vsync": send_vsync,
        "recv_vsync": recv_vsync,
        "marsh": marsh_events,
        "proc_cmd": proc_cmd_events,
        "animate": animate_events,
        "render_frame": render_frame_events,
        "render": render_events,
        "commit_layers": commit_layers_events,
        "hwc_present": hwc_present_events,
        "wait_present": wait_present_events,
        "wait_acquire_fence": wait_acquire_fence_events,
        "acquire_fence": acquire_fence_events,
        "jank_frames": jank_frames,
    }


def _match_vsync_all(
    send_by_conn: Dict[str, List[tuple]],
    recv_by_conn: Dict[str, List[tuple]],
    time_window_ns: int = 1_000_000,
) -> Dict[str, List[tuple]]:
    """通过 now 时间戳匹配所有 SendVsync 和 RecvVsync（按 conn 分别匹配）。

    Args:
        send_by_conn: {conn: [(ts, now_ts, raw_name), ...]}
        recv_by_conn: {conn: [(ts, now_ts, expected_end, vsync_id, raw_name), ...]}
        time_window_ns: 允许的时间偏差（默认 1ms）

    Returns:
        {conn: [(send_ts, recv_ts, vsync_id, expected_end), ...]}
        每个 conn 的 vsync_id 是该 conn 的 RecvVsync 的 vsyncId
    """
    result: Dict[str, List[tuple]] = {}

    all_conns = sorted(set(send_by_conn.keys()) | set(recv_by_conn.keys()))

    for conn in all_conns:
        result[conn] = []
        send_list = send_by_conn.get(conn, [])
        recv_list = recv_by_conn.get(conn, [])

        if not send_list or not recv_list:
            continue

        for s_ts, s_now, s_name in send_list:
            best_recv = None
            best_diff = time_window_ns + 1
            for r_ts, r_now, r_end, r_vsync, r_dur, r_name in recv_list:
                diff = abs(s_now - r_now)
                if diff < best_diff:
                    best_diff = diff
                    best_recv = (r_ts, r_now, r_end, r_vsync, r_dur, r_now)
            if best_recv and best_diff <= time_window_ns:
                r_ts, r_now, r_end, r_vsync, r_dur, r_now = best_recv
                result[conn].append((s_ts, r_ts, r_vsync, r_end, r_dur, r_now))

    return result


def _compute_vsync_period(recv_list: List[tuple]) -> int:
    """从 RecvVsync 列表计算 vsync 周期。

    Returns:
        vsync 周期(ns)，默认 8.3ms (120Hz)
    """
    if len(recv_list) < 2:
        return 8_300_000  # 默认 120Hz
    # 按 now 时间排序，计算相邻差值
    sorted_list = sorted(recv_list, key=lambda x: x[1])  # 按 now 排序
    periods = []
    for i in range(1, len(sorted_list)):
        prev_now = sorted_list[i-1][1]
        curr_now = sorted_list[i][1]
        diff = curr_now - prev_now
        if 5_000_000 < diff < 20_000_000:  # 合理范围 5-20ms
            periods.append(diff)
    return int(sum(periods) / len(periods)) if periods else 8_300_000


def _find_marsh_by_tid_seq(
    tid: int,
    seq: int,
    marsh_list: List[tuple],
) -> Optional[tuple]:
    """通过 [tid, seq] 查找对应的 Marsh。

    Args:
        tid: 线程 ID
        seq: 序列号
        marsh_list: [(ts, tid, seq, timestamp, name, dur), ...]

    Returns:
        匹配的 Marsh 或 None
    """
    for m in marsh_list:
        if m[1] == tid and m[2] == seq:
            return m
    return None


def _find_ui_recv_vsync(
    marsh_timestamp: int,
    recv_vsync_by_conn: Dict[str, List[tuple]],
    preferred_tid: Optional[int] = None,
) -> Optional[tuple]:
    """用 Marsh.timestamp 找到对应的 UI RecvVsync。

    Args:
        marsh_timestamp: Marsh 的 timestamp 字段
        recv_vsync_by_conn: {conn: [(ts, now, expected_end, vsync_id, dur, name), ...]}
        preferred_tid: 优先匹配 conn name 包含此 tid 的 RecvVsync

    Returns:
        (conn, recv_vsync_tuple) 或 None
    """
    if marsh_timestamp == 0:
        return None

    # 优先找 conn name 包含 preferred_tid 的匹配
    if preferred_tid is not None:
        for conn, recvs in recv_vsync_by_conn.items():
            # conn 格式如 "WM_3483"，检查是否包含 tid
            if str(preferred_tid) in conn:
                for r in recvs:
                    if r[1] == marsh_timestamp:
                        return (conn, r)

    # 然后找任意匹配
    for conn, recvs in recv_vsync_by_conn.items():
        for r in recvs:
            if r[1] == marsh_timestamp:
                return (conn, r)
    return None


def _is_marsh_in_recv_window(
    marsh_ts: int,
    recv_ts: int,
    recv_dur: int,
) -> bool:
    """判断 Marsh.ts 是否在 RecvVsync [ts, ts+dur] 窗口内。

    Args:
        marsh_ts: Marsh 的 callstack.ts
        recv_ts: RecvVsync 的 callstack.ts
        recv_dur: RecvVsync 的 callstack.dur

    Returns:
        True if marsh_ts is in [recv_ts, recv_ts + recv_dur]
    """
    return recv_ts < marsh_ts <= recv_ts + recv_dur


def _match_proc_cmd(
    tid: int,
    seq: int,
    proc_cmd_list: List[tuple],
) -> Optional[tuple]:
    """通过 [tid, seq] 查找对应的 ProcCmd。

    Args:
        tid: 线程 ID
        seq: 序列号
        proc_cmd_list: [(ts, tid, seq, name), ...]

    Returns:
        匹配的 ProcCmd 或 None
    """
    for p in proc_cmd_list:
        if p[1] == tid and p[2] == seq:
            return p
    return None


def _match_render_by_vsync(
    render_events: List[tuple],  # [(ts, dur, vsync_id, name), ...]
    recv_vs: tuple,
    time_window_ns: int = 5_000_000,
) -> Optional[tuple]:
    """通过 vsyncId 匹配 RenderFrame 和 H:Render。

    Returns:
        (render_begin_ts, render_dur, vsync_id) 或 None
    """
    _, _, _, expected_vsync, _, _ = recv_vs
    for r_ts, r_dur, r_vsync, r_name in render_events:
        # vsyncId 差 1-3 在容忍范围内，且时间接近
        if abs(r_vsync - expected_vsync) <= 3:
            return (r_ts, r_dur, r_vsync)
    return None


def _build_frame_record(
    ui_vs: tuple,  # (send_ts, recv_ts, ui_vsync_id, ui_expected_end)
    rs_vs: tuple,  # (send_ts, recv_ts, rs_vsync_id, rs_expected_end)
    marsh: Optional[tuple],  # (ts, tid, seq)
    proc_cmd: Optional[tuple],
    render: Optional[tuple],  # (ts, dur, vsync_id)
    hwc_begin: Optional[int],
    hwc_dur: Optional[int],
    present_begin: Optional[int],
    present_dur: Optional[int],
    present_id: Optional[int],
    jank: bool,
    app_name: Optional[str] = None,
) -> Dict[str, Any]:
    """构建单条帧记录。"""
    frame = RenderFrame()
    frame.app_name = app_name

    # UI 信息
    if ui_vs:
        _, ui_recv_ts, ui_vsync_id, ui_end, _, _ = ui_vs
        frame.ui_vsync_id = ui_vsync_id
        frame.ui_begin_ts = ui_recv_ts  # 用 RecvVsync 的 now 时间作为起点
        frame.ui_recv_complete_ts = ui_recv_ts + (ui_end - ui_recv_ts)

    # Marsh 信息
    if marsh:
        m_ts, m_tid, _ = marsh
        frame.ui_tid = m_tid

    # RS 信息
    if rs_vs:
        _, rs_recv_ts, rs_vsync_id, _, rs_dur, rs_now = rs_vs
        frame.rs_vsync_id = rs_vsync_id
        frame.rs_begin_ts = rs_recv_ts
        if render:
            r_ts, r_dur, _ = render
            frame.rs_complete_ts = r_ts + r_dur
            frame.rs_dur_ns = frame.rs_complete_ts - frame.rs_begin_ts

    # Render 信息
    if render:
        r_ts, r_dur, _ = render
        frame.rs_render_begin_ts = r_ts
        frame.rs_render_dur_ns = r_dur

    # HWC 信息
    if hwc_begin is not None:
        frame.hwc_begin_ts = hwc_begin
        frame.hwc_dur_ns = hwc_dur

    # Present 信息
    if present_begin is not None:
        frame.present_begin_ts = present_begin
        frame.present_dur_ns = present_dur
        frame.present_id = present_id
        frame.display = present_id is not None

    # 整帧耗时
    if frame.ui_begin_ts and frame.present_begin_ts:
        present_end = frame.present_begin_ts + (frame.present_dur_ns or 0)
        frame.pipeline_dur_ns = present_end - frame.ui_begin_ts

    frame.jank = jank

    return {
        "app_name": frame.app_name,
        "ui_vsync_id": frame.ui_vsync_id,
        "rs_vsync_id": frame.rs_vsync_id,
        "present_id": frame.present_id,
        "recv_vsync_ts": frame.recv_vsync_ts,
        "ui_tid": frame.ui_tid,
        "ui_thread_name": frame.ui_thread_name,
        "ui_begin_ts": frame.ui_begin_ts,
        "ui_recv_complete_ts": frame.ui_recv_complete_ts,
        "ui_dur_ns": frame.ui_dur_ns,
        "ui_marsh_end_ts": frame.ui_marsh_end_ts,
        "rs_tid": frame.rs_tid,
        "rs_begin_ts": frame.rs_begin_ts,
        "rs_complete_ts": frame.rs_complete_ts,
        "rs_dur_ns": frame.rs_dur_ns,
        "rs_render_tid": frame.rs_render_tid,
        "rs_render_begin_ts": frame.rs_render_begin_ts,
        "rs_render_dur_ns": frame.rs_render_dur_ns,
        "gpu_dur_ns": frame.gpu_dur_ns,
        "gpu_begin_ts": frame.gpu_begin_ts,
        "hwc_begin_ts": frame.hwc_begin_ts,
        "hwc_dur_ns": frame.hwc_dur_ns,
        "present_begin_ts": frame.present_begin_ts,
        "present_dur_ns": frame.present_dur_ns,
        "pipeline_dur_ns": frame.pipeline_dur_ns,
        "frame_interval_ns": frame.frame_interval_ns,
        "frame_rate": frame.frame_rate,
        "jank": frame.jank,
        "jank_type": frame.jank_type,
        "jank_tag": frame.jank_tag,
        "skipped_time_ms": frame.skipped_time_ms,
        "jank_window": frame.jank_window,
        "display": frame.display,
    }


def _make_frame(
    ui_vsync_id: Optional[int],
    rs_vsync_id: Optional[int],
    present_id: Optional[int],
    recv_vsync_ts: Optional[int],
    ui_tid: Optional[int],
    ui_thread_name: Optional[str],
    ui_begin_ts: Optional[int],
    ui_recv_complete_ts: Optional[int],
    ui_dur_ns: Optional[int],
    ui_marsh_end_ts: Optional[int],
    rs_tid: Optional[int],
    rs_render_tid: Optional[int],
    rs_begin_ts: Optional[int],
    rs_complete_ts: Optional[int],
    render: Optional[tuple],  # (ts, dur, vsync_id)
    hwc_begin: Optional[int],
    hwc_dur_ns: Optional[int],
    present_begin: Optional[int],
    present_dur_ns: Optional[int],
    frame_interval_ns: Optional[int],
    gpu_begin_ts: Optional[int],
    gpu_dur_ns: Optional[int],
    frame_rate: Optional[int],
    jank: bool,
    jank_type: Optional[str],
    jank_tag: Optional[str],
    skipped_time_ms: Optional[int],
    jank_window: Optional[str],
    display: bool,
    tid_to_name: Dict[int, str],
) -> Dict[str, Any]:
    """构建单条帧记录。"""
    frame = RenderFrame()
    frame.app_name = _resolve_app_name(ui_thread_name)
    log.info(f"_make_frame: rs_tid={rs_tid}, rs_render_tid={rs_render_tid}")
    frame.ui_vsync_id = ui_vsync_id
    frame.rs_vsync_id = rs_vsync_id
    frame.present_id = present_id
    frame.recv_vsync_ts = recv_vsync_ts
    frame.ui_tid = ui_tid
    frame.ui_thread_name = ui_thread_name
    frame.ui_begin_ts = ui_begin_ts
    frame.ui_recv_complete_ts = ui_recv_complete_ts
    frame.ui_dur_ns = ui_dur_ns
    frame.ui_marsh_end_ts = ui_marsh_end_ts
    frame.rs_tid = rs_tid
    frame.rs_render_tid = rs_render_tid
    frame.rs_begin_ts = rs_begin_ts
    frame.rs_complete_ts = rs_complete_ts
    if rs_begin_ts is not None and rs_complete_ts is not None:
        frame.rs_dur_ns = rs_complete_ts - rs_begin_ts

    if render:
        r_ts, r_dur, r_vsync = render
        frame.rs_render_begin_ts = r_ts
        frame.rs_render_dur_ns = r_dur

    frame.gpu_dur_ns = gpu_dur_ns
    frame.gpu_begin_ts = gpu_begin_ts
    frame.hwc_begin_ts = hwc_begin
    frame.hwc_dur_ns = hwc_dur_ns
    frame.present_begin_ts = present_begin
    frame.present_dur_ns = present_dur_ns
    frame.frame_interval_ns = frame_interval_ns
    frame.frame_rate = frame_rate
    frame.display = display

    if present_begin:
        present_end = present_begin + (present_dur_ns or 0)
        if ui_begin_ts:
            frame.pipeline_dur_ns = present_end - ui_begin_ts
        elif rs_begin_ts:
            frame.pipeline_dur_ns = present_end - rs_begin_ts

    # Jank 判定结果由调用方传入（build_render_frames 统一计算后传入）
    frame.jank = jank
    frame.jank_type = jank_type
    frame.jank_tag = jank_tag
    frame.skipped_time_ms = skipped_time_ms
    frame.jank_window = jank_window

    return {
        "app_name": frame.app_name,
        "ui_vsync_id": frame.ui_vsync_id,
        "rs_vsync_id": frame.rs_vsync_id,
        "present_id": frame.present_id,
        "recv_vsync_ts": frame.recv_vsync_ts,
        "ui_tid": frame.ui_tid,
        "ui_thread_name": frame.ui_thread_name,
        "ui_begin_ts": frame.ui_begin_ts,
        "ui_recv_complete_ts": frame.ui_recv_complete_ts,
        "ui_dur_ns": frame.ui_dur_ns,
        "ui_marsh_end_ts": frame.ui_marsh_end_ts,
        "rs_tid": frame.rs_tid,
        "rs_begin_ts": frame.rs_begin_ts,
        "rs_complete_ts": frame.rs_complete_ts,
        "rs_dur_ns": frame.rs_dur_ns,
        "rs_render_tid": frame.rs_render_tid,
        "rs_render_begin_ts": frame.rs_render_begin_ts,
        "rs_render_dur_ns": frame.rs_render_dur_ns,
        "gpu_dur_ns": frame.gpu_dur_ns,
        "gpu_begin_ts": frame.gpu_begin_ts,
        "hwc_begin_ts": frame.hwc_begin_ts,
        "hwc_dur_ns": frame.hwc_dur_ns,
        "present_begin_ts": frame.present_begin_ts,
        "present_dur_ns": frame.present_dur_ns,
        "pipeline_dur_ns": frame.pipeline_dur_ns,
        "frame_interval_ns": frame.frame_interval_ns,
        "frame_rate": frame.frame_rate,
        "jank": frame.jank,
        "jank_type": frame.jank_type,
        "jank_tag": frame.jank_tag,
        "skipped_time_ms": frame.skipped_time_ms,
        "jank_window": frame.jank_window,
        "frame_rate_trend": frame.frame_rate_trend,
        "display": frame.display,
    }


@register_operator("build_render_frames")
def build_render_frames(ctx: PreprocessContext) -> PreprocessContext:
    """构建渲染帧链路。

    遍历顺序：以 RS RecvVsync 为单位。
    每帧输出 1 条或多条记录（有有效 UI Marsh 则按数量输出，否则 1 条）。
    """
    callstack_data = ctx.data
    if not isinstance(callstack_data, list):
        import pandas as pd
        if isinstance(callstack_data, pd.DataFrame):
            callstack_data = callstack_data.to_dict("records")
        else:
            raise PreprocessError(f"build_render_frames: ctx.data 应为 list，实际为 {type(callstack_data)}")

    if not callstack_data:
        ctx.data = []
        ctx.meta["frame_count"] = 0
        return ctx

    # 1. 解析 callstack 获取各类事件
    events = _parse_callstack(callstack_data)

    send_vsync = events["send_vsync"]
    recv_vsync = events["recv_vsync"]
    marsh_list = events["marsh"]          # [(ts, tid, seq, timestamp, name), ...]
    proc_cmd_list = events["proc_cmd"]    # [(ts, tid, seq, name), ...]
    animate_list = events["animate"]      # [(ts, [tid, ...], name), ...]
    render_frame_events = events["render_frame"]
    hwc_present = events["hwc_present"]
    wait_present = events["wait_present"]
    commit_layers = events["commit_layers"]  # [(rate, now_ts, vsync_id, dur, name), ...]
    wait_acquire_fence = events["wait_acquire_fence"]  # [(fence_id, ts, dur, name), ...]
    acquire_fence = events["acquire_fence"]            # [(ts, dur, fence_id, name), ...]

    # 构建 vsync_id → rate 映射
    rate_by_vsync_id: Dict[int, int] = {}
    for rate, _, vsync_id, _, _ in commit_layers:
        rate_by_vsync_id[vsync_id] = rate

    log.info(
        "事件解析: send_vsync=%d conns, recv_vsync=%d conns, marsh=%d, proc_cmd=%d, animate=%d, render_frame=%d, hwc=%d, wait_present=%d",
        len(send_vsync), len(recv_vsync), len(marsh_list), len(proc_cmd_list),
        len(animate_list), len(render_frame_events), len(hwc_present), len(wait_present)
    )

    # 2. 匹配 SendVsync → RecvVsync
    vs_matched = _match_vsync_all(send_vsync, recv_vsync)
    rs_vs_list = sorted(vs_matched.get("rs", []), key=lambda x: x[1])  # 按 recv_ts 排序

    # 3. 计算 vsync 周期
    all_recv = [r for recvs in recv_vsync.values() for r in recvs]
    period_ns = _compute_vsync_period(all_recv)
    log.info("VSync period: %.2f ms", period_ns / 1_000_000)

    # 4. 构建 HwcPresent + WaitPresent 配对
    wait_by_fence: Dict[int, tuple] = {}
    for fence_id, p_ts, p_dur, _ in wait_present:
        wait_by_fence[fence_id] = (p_ts, p_dur)

    # 计算每个 fence 的 frame_interval（按 present_end 排序）
    fence_intervals: Dict[int, int] = {}
    sorted_fences = sorted(wait_by_fence.items(), key=lambda x: x[1][0] + x[1][1])
    prev_present_end = 0
    for fence_id, (fence_ts, fence_dur) in sorted_fences:
        present_end = fence_ts + fence_dur
        if prev_present_end > 0:
            fence_intervals[fence_id] = present_end - prev_present_end
        prev_present_end = present_end

    # 构建 gpu_dur 映射 (fence_id → (gpu_begin_ts, gpu_dur))
    gpu_dur_by_fence: Dict[int, tuple] = {}
    for fence_id, g_ts, gpu_dur, _ in wait_acquire_fence:
        gpu_dur_by_fence[fence_id] = (g_ts, gpu_dur)

    hwc_events_sorted = sorted(hwc_present, key=lambda x: x[0])
    hwc_with_fence: List[tuple] = []
    for hwc_ts, hwc_dur, _ in hwc_events_sorted:
        for fence_id, (fence_ts, fence_dur) in wait_by_fence.items():
            if hwc_ts < fence_ts <= hwc_ts + period_ns * 3:
                hwc_with_fence.append((hwc_ts, hwc_dur, fence_id, fence_ts, fence_dur))
                break

    # 5. 收集 UI 线程名 → app_name
    tid_to_name: Dict[int, str] = {}
    if ctx.sqlite_conn is not None:
        all_tids = list({m[1] for m in marsh_list})
        if all_tids:
            placeholders = ",".join("?" * len(all_tids))
            rows = ctx.sqlite_conn.execute(
                f"SELECT tid, name FROM thread WHERE tid IN ({placeholders})",
                all_tids
            ).fetchall()
            for tid, name in rows:
                tid_to_name[tid] = name or ""

    # 5.1 构建 callid(itid) → thread.tid 映射
    callid_to_tid: Dict[int, int] = {}
    if ctx.sqlite_conn is not None:
        # 从 callstack 表中提取 callid → thread.tid 的映射
        # 找所有 RS 相关事件的 callid，再通过 thread.itid 匹配
        rows = ctx.sqlite_conn.execute(
            "SELECT DISTINCT c.callid, t.tid FROM callstack c "
            "JOIN thread t ON t.itid = c.callid "
            "WHERE c.name LIKE '%RenderFrame%' OR c.name LIKE '%RSMainThread%'"
        ).fetchall()
        for callid, tid in rows:
            if callid and tid:
                callid_to_tid[callid] = tid

    # 5.2 预构建 ts → callid 字典，消除循环内 N+1 SQL 查询
    renderframe_ts_to_callid: Dict[int, int] = {}
    rs_recv_vsync_ts_to_callid: Dict[int, int] = {}
    if ctx.sqlite_conn is not None:
        rows = ctx.sqlite_conn.execute(
            "SELECT ts, callid FROM callstack WHERE name LIKE '%RenderFrame%'"
        ).fetchall()
        for ts_val, callid in rows:
            if ts_val and callid:
                renderframe_ts_to_callid[ts_val] = callid
        rows = ctx.sqlite_conn.execute(
            "SELECT ts, callid FROM callstack WHERE name LIKE '%ReceiveVsync%' AND name LIKE '%rs%'"
        ).fetchall()
        for ts_val, callid in rows:
            if ts_val and callid:
                rs_recv_vsync_ts_to_callid[ts_val] = callid

    # 5.3 构建 RS recv_vsync ts → SendVsync.callstack_ts 映射
    rs_vsync_ts_to_send_ts: Dict[int, int] = {}
    for send_ts, recv_ts, vsync_id, exp_end, recv_dur, recv_now in vs_matched.get("rs", []):
        rs_vsync_ts_to_send_ts[recv_ts] = send_ts

    # 5.4 构建 UI (conn, recv_now) → SendVsync.callstack_ts 映射
    # 用于 ui_begin_ts = max(SendVsync.callstack_ts, prev_ui_recv_end)
    # _find_ui_recv_vsync 按 now=r[1] 匹配，vs_matched[conn] 存 (send_ts, recv_ts, ...)
    ui_now_to_send_ts: Dict[tuple, int] = {}  # {(conn, recv_now): send_ts}
    for conn, vs_list in vs_matched.items():
        for send_ts, recv_ts, vsync_id, exp_end, recv_dur, recv_now in vs_list:
            ui_now_to_send_ts[(conn, recv_now)] = send_ts

    # 6. 遍历 RS RecvVsync，逐帧构建
    frames: List[Dict[str, Any]] = []

    prev_rs_recv_end = None  # 上一帧 RS recv.ts + recv.dur
    prev_ui_recv_end: Dict[str, int] = {}  # {conn: 上一帧 expected_end}

    for rs_vs in rs_vs_list:
        rs_send_ts, rs_recv_ts, rs_vsync_id, rs_expected_end, rs_dur, rs_now = rs_vs

        # 6.1 在 RS 窗口内找 ProcCmd
        rs_window_end = rs_recv_ts + rs_dur
        proc_cmds_in_window = [
            p for p in proc_cmd_list
            if rs_recv_ts <= p[0] <= rs_window_end
        ]

        # 6.2 在 RS 窗口内找 Animate
        animates_in_window = [
            a for a in animate_list
            if rs_recv_ts <= a[0] <= rs_window_end
        ]

        # 6.3 收集 RS 侧信息
        # RenderFrame: 在 rs_recv 之后找，同时获取 callid 映射到 thread.tid
        render = None
        rs_render_tid = None
        gpu_begin_ts = None
        gpu_dur_ns = None
        for r_ts, r_dur, r_name in render_frame_events:
            if rs_recv_ts < r_ts <= rs_recv_ts + period_ns * 2:
                # 通过预查询的 ts → callid 字典获取 callid（消除 N+1 SQL）
                callid = renderframe_ts_to_callid.get(r_ts)
                if callid and callid in callid_to_tid:
                    rs_render_tid = callid_to_tid[callid]
                # 通过 RenderFrame 后的 Acquire Fence 匹配 fence_id，找 GPU 耗时
                for a_ts, a_dur, a_fence_id, a_name in acquire_fence:
                    if r_ts < a_ts <= r_ts + period_ns * 2:
                        if a_fence_id in gpu_dur_by_fence:
                            gpu_begin_ts, gpu_dur_ns = gpu_dur_by_fence[a_fence_id]
                            break
                render = (r_ts, r_dur, 0)
                break

        # 通过预查询的 ts → callid 字典获取 rs_tid（消除 N+1 SQL）
        rs_tid = None
        callid = rs_recv_vsync_ts_to_callid.get(rs_recv_ts)
        if callid and callid in callid_to_tid:
            rs_tid = callid_to_tid[callid]

        # 计算 RS 实际起始时间：max(SendVsync.now, 上一帧 RS recv.ts + recv.dur)
        rs_actual_begin = rs_send_ts
        if prev_rs_recv_end is not None:
            rs_actual_begin = max(rs_send_ts, prev_rs_recv_end)

        # 计算 RS 结束时间（renderFrame.ts + render.dur）
        # 如果找不到 render，则使用 H:ReceiveVsync name:rs 的结束点作为回退
        rs_complete_ts = None
        if render:
            r_ts, r_dur, _ = render
            rs_complete_ts = r_ts + r_dur
        else:
            # 回退方案：使用 H:ReceiveVsync name:rs 的结束点
            rs_complete_ts = rs_recv_ts + rs_dur

        # HwcPresent + WaitPresent: 在 rs_recv 之后找
        hwc_begin, hwc_dur = None, None
        present_id, present_begin, present_dur = None, None, None
        for hwc_ts, hwc_d, fence_id, fence_ts, fence_d in hwc_with_fence:
            if rs_recv_ts < hwc_ts <= rs_recv_ts + period_ns * 4:
                hwc_begin = hwc_ts
                hwc_dur = hwc_d
                present_id = fence_id
                present_begin = fence_ts
                present_dur = fence_d
                break

        display = present_id is not None

        # 6.4 对 ProcCmd 关联的每个 [tid,seq] 找对应 Marsh，输出帧记录
        ui_tids_in_frame: Set[int] = set()
        frame_output_count = 0

        for proc in proc_cmds_in_window:
            p_ts, p_tid, p_seq, p_name = proc

            # 通过 [tid,seq] 找 Marsh
            marsh = _find_marsh_by_tid_seq(p_tid, p_seq, marsh_list)

            # 判断 UI 帧有效性
            ui_vsync_id, ui_begin_ts, ui_recv_complete_ts, ui_dur_ns, ui_tid, ui_thread_name, ui_marsh_end_ts = None, None, None, None, None, None, None
            ui_recv_match = None

            if marsh:
                marsh_ts, m_tid, m_seq, marsh_timestamp, m_name, marsh_dur = marsh

                # 用 Marsh.timestamp 找对应 UI RecvVsync，优先匹配包含 tid 的 conn
                ui_recv_match = _find_ui_recv_vsync(marsh_timestamp, recv_vsync, preferred_tid=m_tid)

                if ui_recv_match:
                    conn, ui_recv = ui_recv_match
                    # 检查 Marsh 是否在 UI RecvVsync 窗口内
                    if _is_marsh_in_recv_window(marsh_ts, ui_recv[0], ui_recv[4]):
                        ui_vsync_id = ui_recv[3]  # vsync_id
                        # ui_begin_ts = max(SendVsync.callstack_ts, prev_ui_recv_end)
                        # SendVsync.callstack_ts = vs_matched 中该 conn 对应 now 的 send_ts
                        ui_send_ts = ui_now_to_send_ts.get((conn, ui_recv[1]), ui_recv[0])
                        ui_begin_ts = max(ui_send_ts, prev_ui_recv_end.get(conn, 0))
                        ui_recv_complete_ts = ui_recv[0] + ui_recv[4]  # ts + dur（handler 实际结束时间）
                        prev_ui_recv_end[conn] = ui_recv_complete_ts
                        ui_dur_ns = ui_recv_complete_ts - ui_begin_ts if ui_recv_complete_ts > ui_begin_ts else None
                        ui_marsh_end_ts = marsh_ts + marsh_dur + 4000000  # +4ms buffer
                        ui_tid = m_tid
                        ui_thread_name = tid_to_name.get(m_tid)
                        ui_tids_in_frame.add(m_tid)

            # 构建帧记录（共享 RS 侧信息）
            frame = _make_frame(
                ui_vsync_id=ui_vsync_id,
                rs_vsync_id=rs_vsync_id,
                present_id=present_id,
                recv_vsync_ts=ui_recv[0] if ui_recv_match else None,
                ui_tid=ui_tid,
                ui_thread_name=ui_thread_name,
                ui_begin_ts=ui_begin_ts,
                ui_recv_complete_ts=ui_recv_complete_ts,
                ui_dur_ns=ui_dur_ns,
                ui_marsh_end_ts=ui_marsh_end_ts,
                rs_tid=rs_tid,
                rs_render_tid=rs_render_tid,
                rs_begin_ts=rs_actual_begin,
                rs_complete_ts=rs_complete_ts,
                render=render,
                hwc_begin=hwc_begin,
                hwc_dur_ns=hwc_dur,
                present_begin=present_begin,
                present_dur_ns=present_dur,
                frame_interval_ns=fence_intervals.get(present_id),
                gpu_begin_ts=gpu_begin_ts,
                gpu_dur_ns=gpu_dur_ns,
                frame_rate=rate_by_vsync_id.get(rs_vsync_id),
                jank=False,
                jank_type=None,
                jank_tag=None,
                skipped_time_ms=None,
                jank_window=None,
                display=display,
                tid_to_name=tid_to_name,
            )
            frames.append(frame)
            frame_output_count += 1

        # 6.5 ProcCmd 无有效 UI Marsh → 仍输出 1 条（UI 字段为空）
        # 只有当 ProcCmd 列表为空时才走这个分支
        if not proc_cmds_in_window:
            # 有 Animate 无 ProcCmd，或无 ProcCmd 无 Animate → 仍输出 1 条
            animate_tids: Set[int] = set()
            for a in animates_in_window:
                animate_tids.update(a[1])  # a[1] = [tid, ...]

            # 如果有 ProcCmd 但都无有效 Marsh，已经在上面输出了
            # 这里只处理完全没有 ProcCmd 的情况
            if animates_in_window or not proc_cmds_in_window:
                # 收集 animate 的 tid 作为 ui_tid（可能为空）
                ui_tid = next(iter(animate_tids)) if animate_tids else None
                ui_thread_name = tid_to_name.get(ui_tid) if ui_tid else None

                frame = _make_frame(
                    ui_vsync_id=None,
                    rs_vsync_id=rs_vsync_id,
                    present_id=present_id,
                    recv_vsync_ts=None,
                    ui_tid=ui_tid,
                    ui_thread_name=ui_thread_name,
                    ui_begin_ts=None,
                    ui_recv_complete_ts=None,
                    ui_dur_ns=None,
                    ui_marsh_end_ts=None,
                    rs_tid=rs_tid,
                    rs_render_tid=rs_render_tid,
                    rs_begin_ts=rs_actual_begin,
                    rs_complete_ts=rs_complete_ts,
                    render=render,
                    hwc_begin=hwc_begin,
                    hwc_dur_ns=hwc_dur,
                    present_begin=present_begin,
                    present_dur_ns=present_dur,
                    frame_interval_ns=fence_intervals.get(present_id),
                    gpu_begin_ts=gpu_begin_ts,
                    gpu_dur_ns=gpu_dur_ns,
                    frame_rate=rate_by_vsync_id.get(rs_vsync_id),
                    jank=False,
                    jank_type=None,
                    jank_tag=None,
                    skipped_time_ms=None,
                    jank_window=None,
                    display=display,
                    tid_to_name=tid_to_name,
                )
                frames.append(frame)

        # 更新 prev_rs_recv_end
        prev_rs_recv_end = rs_recv_ts + rs_dur

    log.info("构建完成: %d 帧", len(frames))

    # ------------------------------------------------------------------
    # Jank 判定：类型一（Trace）+ 类型二（帧率突变）
    # ------------------------------------------------------------------

    # 7.1 构建 jank_frames 匹配：recv_vsync_ts 窗口匹配
    # 每条 JANK_FRAME 打点属于 recv_vsync_ts <= jf_ts < 下一个 recv_vsync_ts 的帧
    jank_frames = events.get("jank_frames", [])
    frames_with_rv = [f for f in frames if f.get("recv_vsync_ts") is not None]
    for jf in jank_frames:
        jf_ts, skipped_ms, window_name, jank_trace = jf
        for i, frame in enumerate(frames_with_rv):
            rv_ts = frame["recv_vsync_ts"]
            next_rv_ts = frames_with_rv[i + 1]["recv_vsync_ts"] if i + 1 < len(frames_with_rv) else float("inf")
            if rv_ts <= jf_ts < next_rv_ts:
                frame["jank"] = True
                if frame["jank_type"] is None:
                    frame["jank_type"] = "trace"
                else:
                    frame["jank_type"] = "both"
                frame["skipped_time_ms"] = skipped_ms
                frame["jank_trace"] = jank_trace
                break

    # 7.2 类型二：帧率突变检测（基于前后4帧窗口）
    # 收集所有帧的 frame_interval_ns 序列（按 present_begin_ts 排序）
    sorted_frames = sorted(
        [f for f in frames if f.get("present_begin_ts") is not None and f.get("frame_interval_ns") is not None],
        key=lambda f: f["present_begin_ts"]
    )
    if sorted_frames:
        interval_arr = [f["frame_interval_ns"] for f in sorted_frames]
        smooth_rates_arr = _smooth_frame_rates(interval_arr, window_size=3)  # 9帧平滑窗口

        for i, frame in enumerate(sorted_frames):
            is_anim = bool(frame.get("rs_vsync_id"))  # TODO: 用动效标记更准确

            # actual_rates: 当前帧及前后各2帧（共5帧）的实际帧率
            actual_rates = []
            for j in range(i - 2, i + 3):
                if 0 <= j < len(sorted_frames):
                    iv = sorted_frames[j]["frame_interval_ns"]
                    actual_rates.append(_compute_actual_rate(iv))
                else:
                    # 越界补 60
                    actual_rates.append(60)
            # smooth_rates: 当前帧前后各4帧（共9帧）的平滑帧率
            smooth_rates = []
            for j in range(i - 4, i + 5):
                if 0 <= j < len(smooth_rates_arr):
                    smooth_rates.append(smooth_rates_arr[j])
                else:
                    smooth_rates.append(60)

            tag = _get_refresh_rate_tag(actual_rates, smooth_rates, is_anim)
            frame["jank_tag"] = tag
            frame["frame_rate_trend"] = _format_frame_rate_trend(actual_rates, cur_index=2)
            if tag in ("帧率突变", "跟手卡顿"):
                if frame["jank_type"] is None:
                    frame["jank_type"] = "interval"
                else:
                    frame["jank_type"] = "both"
                frame["jank"] = True

    ctx.data = frames
    ctx.meta["frame_count"] = len(frames)
    ctx.meta["jank_count"] = sum(1 for f in frames if f.get("jank"))
    return ctx


@register_operator("aggregate_frame_summary")
def aggregate_frame_summary(ctx: PreprocessContext) -> PreprocessContext:
    """聚合帧统计摘要。

    输入 ctx.data：build_render_frames 输出的帧列表
    输出 ctx.data：frame_summary 的聚合结果

    result_schema.type=object（标量摘要），QueryEngine 会自动取首行展开
    """
    frames = ctx.data
    if not isinstance(frames, list):
        raise PreprocessError(f"aggregate_frame_summary: ctx.data 应为 list，实际为 {type(frames)}")

    if not frames:
        ctx.data = {
            "total_frames": 0,
            "jank_count": 0,
            "avg_frame_time": 0.0,
            "max_frame_time": 0.0,
            "p95_frame_time": 0.0,
            "display_count": 0,
            "display_rate": 0.0,
        }
        return ctx

    # 提取有效的 pipeline_dur_ns
    pipeline_durs = [f["pipeline_dur_ns"] for f in frames if f.get("pipeline_dur_ns")]
    total = len(frames)
    jank_count = sum(1 for f in frames if f.get("jank"))
    display_count = sum(1 for f in frames if f.get("display"))

    avg_frame_time = sum(pipeline_durs) / len(pipeline_durs) / 1_000_000 if pipeline_durs else 0.0  # ns → ms
    max_frame_time = max(pipeline_durs) / 1_000_000 if pipeline_durs else 0.0

    # P95
    if pipeline_durs:
        sorted_durs = sorted(pipeline_durs)
        idx = int(len(sorted_durs) * 0.95)
        p95_frame_time = sorted_durs[min(idx, len(sorted_durs) - 1)] / 1_000_000
    else:
        p95_frame_time = 0.0

    ctx.data = {
        "total_frames": total,
        "jank_count": jank_count,
        "avg_frame_time": round(avg_frame_time, 3),
        "max_frame_time": round(max_frame_time, 3),
        "p95_frame_time": round(p95_frame_time, 3),
        "display_count": display_count,
        "display_rate": round(display_count / total, 3) if total > 0 else 0.0,
    }
    ctx.meta["aggregated"] = True
    return ctx
