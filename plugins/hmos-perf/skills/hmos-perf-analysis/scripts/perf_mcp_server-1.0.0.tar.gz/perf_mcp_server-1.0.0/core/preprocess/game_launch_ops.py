"""游戏启动阶段事件解析算子 (UE引擎版).

基于真实trace+perf采样分析，UE游戏启动流程共9个阶段：
    1. 启动起点：首个 H:touchEventDispatch（用户触屏点击，来自 callstack 表）
    2. 启动终点：H:GAS::GameGScene value=3 跳变（来自 process_measure 表，filter_id=214）

UE启动阶段（基于perf_sample + callstack markers识别）：
    - touch_dispatch: 触屏事件分发 (ohos.sceneboard线程55)
    - napi_bridge: NAPI桥接初始化 (游戏主进程线程568) - LoadJSmodule/Napi_workerInit
    - preinit: 引擎预初始化 (WorkerThread_Ue线程1047) - 最大耗时阶段
    - pak_load: Pak文件加载 (PoolThread线程1108)
    - shader_register: Shader类型注册 (WorkerThread_Ue线程1047)
    - rhi_init: 渲染硬件接口初始化 (RenderThread 0线程1219)
    - resource_load: 异步资源加载 (FAsyncLoading线程1279)
    - engine_init: 引擎高层初始化 (WorkerThread_Ue线程1047)
    - game_loop: 游戏主循环 (WorkerThread_Ue线程1047)

线程映射（callstack.dur = thread.id）：
    - 55: ohos.sceneboard (触屏事件)
    - 568: 游戏主进程
    - 1047: WorkerThread_Ue (UE引擎主线程)
    - 1108: PoolThread (Pak文件加载)
    - 1219: RenderThread 0 (RHIInit执行线程)
    - 1279: FAsyncLoading (异步资源加载)
"""
from __future__ import annotations

import re
from typing import Dict, Optional

import pandas as pd

from core.game_engine_detector import detect_game_engine, get_sql_thread_filter, GameEngineInfo
from core.observability import get_observability_logger
from core.preprocess.base import PreprocessContext, PreprocessError, register_operator

_log = get_observability_logger("game_launch_ops")

# ---------------------------------------------------------------------------
# 常量定义
# ---------------------------------------------------------------------------

# TouchEventDispatch 事件标记（hiprofiler 中为 H:touchEventDispatch，大小写不敏感）
TOUCH_EVENT_RE = re.compile(r"touchEventDispatch|TouchEventDispatch", re.IGNORECASE)

# GameGScene 甬道名称
GAME_GSCENE_NAME = "H:GAS::GameGScene"

# UE启动关键函数模式（按启动顺序排列）
UE_STARTUP_PATTERNS = [
    # 阶段1: 触屏事件分发 (callstack marker H:phase:touch_dispatch)
    # 阶段2: NAPI桥接层初始化 (LoadJSmodule/Napi_workerInit)
    #    - LoadJSModule: JS 模块加载
    #    - Napi_workerInit: Native API 桥接初始化
    #    - OpenHarmonyMain: UE 鸿蒙版入口
    (re.compile(r"NapiManager::Napi_workerInit"), "napi_bridge"),
    (re.compile(r"LoadJSmodule", re.IGNORECASE), "napi_bridge"),
    (re.compile(r"OpenHarmonyMain"), "napi_bridge"),
    # 阶段3: 引擎预初始化（最大耗时阶段）
    (re.compile(r"FEngineLoop::PreInit"), "preinit"),
    (re.compile(r"FEngineLoop::PreInitPreStartupScreen"), "preinit"),
    (re.compile(r"FEngineLoop::PreInitPostStartupScreen"), "preinit"),
    (re.compile(r"LaunchCheckForFileOverride"), "preinit"),
    (re.compile(r"FPakPlatformFile::Initialize"), "preinit"),
    (re.compile(r"FPakFile::LoadIndex"), "preinit"),
    (re.compile(r"UClass::CreateDefaultObject"), "preinit"),  # 反射系统初始化
    (re.compile(r"ProcessNewlyLoadedUObjects"), "preinit"),
    # 阶段4: Pak文件加载
    (re.compile(r"FPakFile::CalculatePathTableKeys"), "pak_load"),
    (re.compile(r"FPakFile::ReadFullDirectoryIndex"), "pak_load"),
    (re.compile(r"FPakFile::LoadIndexInternal"), "pak_load"),
    # 阶段5: Shader注册（UE4启动关键瓶颈）
    #    - FGlobalShaderType: 全局Shader类型注册
    #    - FMeshMaterialShaderType: 材质Shader类型注册
    #    - TShaderMap::Serialize*: Shader序列化/反序列化（消耗最多采样）
    #    注意：这些函数发生在 LoadJSModule 内部（时间线上与 napi_bridge 重叠）
    (re.compile(r"FGlobalShaderType::FGlobalShaderType"), "shader_register"),
    (re.compile(r"FMeshMaterialShaderType::FMeshMaterialShaderType"), "shader_register"),
    (re.compile(r"FMaterialShaderType::FMaterialShaderType"), "shader_register"),
    (re.compile(r"TShaderMap.*::RegisterSerializedShaders"), "shader_register"),
    (re.compile(r"TShaderMap.*::Serialize"), "shader_register"),  # 捕获 SerializeInline/SerializeShaderForLoad
    # 阶段6: RHI初始化 (RenderThread 0)
    (re.compile(r"RHIInit"), "rhi_init"),
    (re.compile(r"FVulkanDynamicRHI::Init"), "rhi_init"),
    (re.compile(r"StartRenderingThread"), "rhi_init"),
    # 阶段7: 异步资源加载
    (re.compile(r"FAsyncLoadingThread::TickAsyncThread"), "resource_load"),
    (re.compile(r"LoadPackage"), "resource_load"),
    # 阶段8: 引擎Init
    (re.compile(r"FEngineLoop::Init"), "engine_init"),
    (re.compile(r"UGameEngine::Init"), "engine_init"),
    (re.compile(r"UGameInstance::Init"), "engine_init"),
    # 阶段9: 游戏主循环
    (re.compile(r"FEngineLoop::Tick"), "game_loop"),
]

# UE启动阶段定义（9个阶段）
UE_PHASE_ORDER = [
    "touch_dispatch",
    "napi_bridge",
    "preinit",
    "pak_load",
    "shader_register",
    "rhi_init",
    "resource_load",
    "engine_init",
    "game_loop",
]

# UE阶段中文名
UE_PHASE_NAMES = {
    "touch_dispatch": "触屏事件分发",
    "napi_bridge": "NAPI桥接初始化",
    "preinit": "引擎预初始化",
    "pak_load": "Pak文件加载",
    "shader_register": "Shader注册",
    "rhi_init": "渲染硬件初始化",
    "resource_load": "异步资源加载",
    "engine_init": "引擎初始化",
    "game_loop": "游戏主循环",
}


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def _match_ue_phase(func_name: str) -> Optional[str]:
    """匹配函数到UE启动阶段."""
    for pattern, phase in UE_STARTUP_PATTERNS:
        if pattern.search(str(func_name)):
            return phase
    return None


# ---------------------------------------------------------------------------
# 算子实现
# ---------------------------------------------------------------------------


@register_operator("detect_game_launch_boundary")
def detect_game_launch_boundary(ctx: PreprocessContext) -> PreprocessContext:
    """检测游戏启动的起点和终点时间戳.

    从 callstack 表获取 TouchEventDispatch，从 process_measure 表获取 GameGScene。
    结果写入 ctx.meta["launch_boundary"]。
    """
    conn = ctx.sqlite_conn
    if conn is None:
        raise PreprocessError("detect_game_launch_boundary 需要 sqlite_conn")

    cur = conn.cursor()

    # --- 起点：首个 TouchEventDispatch ---
    start_ts: Optional[int] = None
    touch_end_ts: Optional[int] = None  # touch_dispatch 的实际结束时间
    try:
        cur.execute("""
            SELECT MIN(ts), MAX(ts) FROM callstack
            WHERE name LIKE '%touchEventDispatch%'
              AND ts > 0
        """)
        row = cur.fetchone()
        if row and row[0] is not None:
            start_ts = int(row[0])
            touch_end_ts = int(row[1])
    except Exception as e:
        _log.warn("query_touch_event_failed", error=str(e))

    # --- 终点：GameGScene value=3 ---
    end_ts: Optional[int] = None
    try:
        cur.execute("""
            SELECT id FROM process_measure_filter
            WHERE name = ?
        """, (GAME_GSCENE_NAME,))
        filter_row = cur.fetchone()

        if filter_row:
            filter_id = filter_row[0]
            cur.execute("""
                SELECT ts FROM process_measure
                WHERE filter_id = ? AND value = 3
                ORDER BY ts ASC
                LIMIT 1
            """, (filter_id,))
            end_row = cur.fetchone()
            if end_row and end_row[0] is not None:
                end_ts = int(end_row[0])
    except Exception as e:
        _log.warn("query_game_gscene_failed", error=str(e))

    # --- 降级：如果没有 GameGScene，尝试用 gameStatus ---
    if end_ts is None:
        try:
            cur.execute("""
                SELECT MIN(cs.ts)
                FROM callstack cs
                WHERE cs.name LIKE '%ResSchedClient::ReportData%'
                  AND cs.name LIKE '%gameStatus%'
            """)
            row = cur.fetchone()
            if row and row[0] is not None:
                end_ts = int(row[0])
                _log.info("launch_end_fallback_gamestatus", end_ts=end_ts)
        except Exception:
            pass

    # 获取trace起点时间（从trace_range表或sched_slice推算）
    trace_start_ts: Optional[int] = None
    try:
        cur.execute("SELECT start_ts FROM trace_range LIMIT 1")
        row = cur.fetchone()
        if row and row[0] is not None:
            trace_start_ts = int(row[0])
    except Exception:
        pass
    if trace_start_ts is None:
        try:
            cur.execute("SELECT MIN(ts) FROM sched_slice")
            row = cur.fetchone()
            if row and row[0] is not None:
                trace_start_ts = int(row[0])
        except Exception:
            pass

    boundary = {
        "start_ts": start_ts,
        "end_ts": end_ts,
        "trace_start_ts": trace_start_ts,
        "duration_ms": (end_ts - start_ts) / 1e6 if start_ts and end_ts else None,
        "touch_end_ts": touch_end_ts,  # touch_dispatch 的实际结束时间
    }

    ctx.meta["launch_boundary"] = boundary

    if start_ts is None:
        ctx.meta["warnings"] = ctx.meta.get("warnings", []) + ["未找到 TouchEventDispatch 事件"]
    if end_ts is None:
        ctx.meta["warnings"] = ctx.meta.get("warnings", []) + ["未找到 GameGScene 跳变事件"]

    _log.info("launch_boundary_detected", **boundary)
    return ctx


@register_operator("parse_ue_startup_events")
def parse_ue_startup_events(ctx: PreprocessContext) -> PreprocessContext:
    """解析UE启动期间的关键函数事件.

    从 perf_sample + perf_callchain + data_dict 获取UE启动函数调用栈，
    记录每个阶段的首次出现时间（start_ts）和采样点数。

    结果写入 ctx.data，格式为 DataFrame：
    [phase, start_ts, sample_count, key_functions, tid, thread_name]
    """
    conn = ctx.sqlite_conn
    if conn is None:
        raise PreprocessError("parse_ue_startup_events 需要 sqlite_conn")

    boundary = ctx.meta.get("launch_boundary", {})
    start_ts = boundary.get("start_ts")
    end_ts = boundary.get("end_ts")

    if start_ts is None:
        raise PreprocessError("缺少启动起点，请先运行 detect_game_launch_boundary")

    cur = conn.cursor()

    # 查询UE启动函数（从perf_sample + perf_callchain + data_dict）
    time_filter = "s.timestamp_trace BETWEEN ? AND ?" if end_ts else "s.timestamp_trace >= ?"
    params = [start_ts, end_ts] if end_ts else [start_ts]

    query = f"""
        SELECT
            s.timestamp_trace AS ts,
            s.thread_id,
            pt.thread_name,
            d.data AS func_name,
            s.event_count
        FROM perf_sample s
        JOIN perf_callchain c ON s.callchain_id = c.callchain_id
        JOIN data_dict d ON c.name = d.id
        JOIN perf_thread pt ON s.thread_id = pt.thread_id
        WHERE c.depth BETWEEN 4 AND 100
          AND d.data IS NOT NULL
          AND ({time_filter})
        ORDER BY s.timestamp_trace ASC
    """

    try:
        cur.execute(query, params)
        rows = cur.fetchall()
    except Exception as e:
        _log.warn("query_ue_events_failed", error=str(e))
        ctx.data = pd.DataFrame(columns=[
            "phase", "start_ts", "sample_count", "key_functions", "tid", "thread_name"
        ])
        return ctx

    # 按阶段聚合 - 记录首次和最后一次出现时间、每个tid的样本数
    phase_data = {}
    for phase_name in UE_PHASE_ORDER:
        phase_data[phase_name] = {
            "start_ts": None,
            "start_tid": None,  # 记录提供start_ts的tid
            "end_ts": None,
            "sample_count": 0,
            "key_functions": set(),
            "tid_counts": {},  # {tid: sample_count} 用于找出样本最多的tid
            "tid_first_ts": {},  # {tid: 首次采样时间} 用于计算线程真实的开始时间
        }

    for row in rows:
        ts, tid, thread_name, func_name, event_count = row
        if func_name is None:
            continue

        # 过滤系统库和ArkTS runtime
        func_str = str(func_name)
        if any(skip in func_str for skip in ["panda::", "ark::", "libark_", "libace_", "libhilog"]):
            continue

        phase = _match_ue_phase(func_str)
        if phase is None:
            continue

        pd_item = phase_data[phase]
        ts_int = int(ts)
        # 记录首次和最后一次出现时间（用于计算阶段真实时长）
        if pd_item["start_ts"] is None:
            pd_item["start_ts"] = ts_int
            pd_item["start_tid"] = tid  # 记录提供start_ts的tid
        pd_item["end_ts"] = ts_int  # 每次出现都更新，确保最终是最后一次
        pd_item["sample_count"] += 1
        pd_item["key_functions"].add(func_str[:100])
        # 统计每个tid的样本数和首次采样时间
        if tid is not None:
            pd_item["tid_counts"][tid] = pd_item["tid_counts"].get(tid, 0) + 1
            if tid not in pd_item["tid_first_ts"]:
                pd_item["tid_first_ts"][tid] = ts_int

    # 转换为DataFrame
    events = []
    for phase_name in UE_PHASE_ORDER:
        p = phase_data[phase_name]
        if p["start_ts"] is None:
            continue
        # 选择样本数最多的tid作为主线程
        main_tid = None
        if p["tid_counts"]:
            main_tid = max(p["tid_counts"].items(), key=lambda x: x[1])[0]
        # napi_bridge 是特殊情况：LoadJsModule(主线程)先于Napi_workerInit(WorkerThread_Ue)开始
        # start_ts 来自主线程，但样本数最多的tid是 WorkerThread_Ue
        # 使用提供 start_ts 的那个线程的 tid
        if phase_name == "napi_bridge" and p.get("start_tid"):
            main_tid = p["start_tid"]
        # shader_register 是特殊情况：可能多个线程都有采样，但只有主要工作线程的首次采样时间才是真实的开始时间
        # 例如：主线程1946ms只有42个旁路调用样本，WorkerThread_Ue 6170ms才有4931个真实工作样本
        # 应该使用样本数最多线程的首次采样时间
        if phase_name == "shader_register" and main_tid and p.get("tid_first_ts"):
            main_thread_first_ts = p["tid_first_ts"].get(main_tid)
            if main_thread_first_ts is not None:
                p["start_ts"] = main_thread_first_ts
        events.append({
            "phase": phase_name,
            "phase_cn": UE_PHASE_NAMES.get(phase_name, phase_name),
            "start_ts": p["start_ts"],
            "end_ts": p["end_ts"],
            "sample_count": p["sample_count"],
            "key_functions": list(p["key_functions"])[:10],
            "tid": main_tid,
            "thread_name": "",  # 由format_game_launch_summary从thread_queries补充
        })

    if events:
        # 如果有touchEventDispatch但没有touch_dispatch阶段，添加一个
        boundary = ctx.meta.get("launch_boundary", {})
        launch_start = boundary.get("start_ts")
        has_touch_dispatch = any(e["phase"] == "touch_dispatch" for e in events)

        if not has_touch_dispatch and launch_start:
            # 创建touch_dispatch阶段，覆盖launch_start到touch_end_ts的真实时间段
            touch_end = boundary.get("touch_end_ts")
            events.insert(0, {
                "phase": "touch_dispatch",
                "phase_cn": UE_PHASE_NAMES.get("touch_dispatch", "触屏事件分发"),
                "start_ts": launch_start,
                "end_ts": touch_end,  # 真实的 touchEventDispatch 结束时间
                "sample_count": 0,
                "key_functions": ["H:touchEventDispatch (callstack)"],
                "tid": None,
                "thread_name": "ohos.sceneboard",
            })

        ctx.data = pd.DataFrame(events)
    else:
        ctx.data = pd.DataFrame(columns=[
            "phase", "phase_cn", "start_ts", "sample_count", "key_functions", "tid", "thread_name"
        ])

    ctx.meta["launch_event_count"] = len(events)
    _log.info("ue_launch_events_parsed", event_count=len(events))
    return ctx


@register_operator("compute_ue_launch_phases")
def compute_ue_launch_phases(ctx: PreprocessContext) -> PreprocessContext:
    """将UE启动事件聚合为逻辑阶段.

    基于 parse_ue_startup_events 的输出，按start_ts排序，
    每个阶段的持续时间 = 下一个阶段的start_ts - 当前阶段的start_ts
    （sequential view，即使某些阶段可能并行运行）

    结果写入 ctx.data，格式为：
    [{"phase": str, "phase_cn": str, "start_ms": float, "end_ms": float,
      "duration_ms": float, "sample_count": int, "key_functions": [...], ...}]
    """
    boundary = ctx.meta.get("launch_boundary", {})
    launch_start = boundary.get("start_ts", 0)
    launch_end = boundary.get("end_ts")

    df = ctx.data
    if df.empty:
        ctx.data = []
        return ctx

    # 按start_ts排序
    df = df.sort_values("start_ts").reset_index(drop=True)

    # 计算每个阶段的持续时间
    result = []
    for i, row in df.iterrows():
        start_ts = row["start_ts"]
        start_ms = (start_ts - launch_start) / 1e6 if launch_start else 0
        phase_name = row.get("phase", "")

        # 阶段结束时间的确定策略：
        # 1. touch_dispatch（首阶段）：有 callstack 的真实 touch_end_ts，直接使用
        # 2. napi_bridge：特殊处理，包含 LoadJSModule 和内部的 shader_register，
        #    逻辑上结束于 preinit 开始（3753ms），而不是 shader_register 的 start_ts
        # 3. 其他阶段：串行模型，结束于下一阶段 start_ts
        if i == 0:
            # touch_dispatch：使用 callstack 的真实结束时间
            explicit_end_ts = row.get("end_ts")
            end_ts = explicit_end_ts if explicit_end_ts is not None and not pd.isna(explicit_end_ts) else start_ts
        elif phase_name == "napi_bridge":
            # napi_bridge 特殊处理：延伸到 preinit 开始（第一个真正独立的后续阶段）
            # 找到第一个不是 shader_register 的后续阶段
            next_non_nested = None
            for j in range(i + 1, len(df)):
                if df.iloc[j].get("phase") != "shader_register":
                    next_non_nested = df.iloc[j]["start_ts"]
                    break
            end_ts = next_non_nested if next_non_nested is not None else (launch_end if launch_end else start_ts)
        else:
            # 通用串行模型
            next_start_ts = df.iloc[i + 1]["start_ts"] if i + 1 < len(df) else None
            end_ts = next_start_ts if next_start_ts is not None else (launch_end if launch_end else start_ts)

        end_ms = (end_ts - launch_start) / 1e6 if launch_start else 0
        duration_ms = end_ms - start_ms

        result.append({
            "phase": row.get("phase", ""),
            "phase_cn": row.get("phase_cn", ""),
            "start_ms": round(start_ms, 2),
            "end_ms": round(end_ms, 2),
            "duration_ms": round(duration_ms, 2),
            "sample_count": row.get("sample_count", 0),
            "key_functions": row.get("key_functions", []),
            "tid": row.get("tid"),
            "thread_name": row.get("thread_name", ""),
        })

    # 添加总体信息
    total_ms = None
    if launch_start and launch_end:
        total_ms = (launch_end - launch_start) / 1e6
        result.append({
            "phase": "total_launch",
            "phase_cn": "总启动时长",
            "start_ms": 0.0,
            "end_ms": round(total_ms, 2),
            "duration_ms": round(total_ms, 2),
            "sample_count": sum(r["sample_count"] for r in result if r["phase"] != "total_launch"),
            "key_functions": [],
            "tid": None,
            "thread_name": "",
        })
        ctx.meta["_total_launch_ms"] = total_ms

    ctx.data = result
    _log.info("ue_launch_phases_computed", phase_count=len(result), total_ms=total_ms)
    return ctx


@register_operator("identify_game_launch_bottleneck")
def identify_game_launch_bottleneck(ctx: PreprocessContext) -> PreprocessContext:
    """识别启动瓶颈阶段.

    阈值通过 params["bottleneck_threshold_ms"] 传入（默认 2000ms）。
    注意：engine_tick 阶段代表游戏主循环，不计入瓶颈分析。
    将瓶颈信息写入 ctx.meta["launch_bottleneck"]。
    """
    threshold_ms = ctx.params.get("bottleneck_threshold_ms", 2000)
    phases = ctx.data if isinstance(ctx.data, list) else []

    # 跳过 total_launch 和 game_loop
    bottleneck = None
    max_duration = 0
    for phase in phases:
        phase_name = phase.get("phase", "")
        if phase_name in ("total_launch", "game_loop"):
            continue
        dur = phase.get("duration_ms", 0)
        if dur > max_duration:
            max_duration = dur
            bottleneck = phase

    if bottleneck and max_duration > threshold_ms:
        bottleneck["is_bottleneck"] = True
        bottleneck["bottleneck_threshold_ms"] = threshold_ms
        ctx.meta["launch_bottleneck"] = bottleneck
        _log.info("launch_bottleneck_found", phase=bottleneck["phase"],
                  duration_ms=max_duration, threshold_ms=threshold_ms)
    else:
        ctx.meta["launch_bottleneck"] = None

    return ctx


@register_operator("build_game_launch_thread_queries")
def build_game_launch_thread_queries(ctx: PreprocessContext) -> PreprocessContext:
    """为瓶颈阶段构建线程查询列表，供后续线程调度分析使用.

    通过游戏引擎检测识别关键线程（WorkerThread_Ue/RenderThread/FAsyncLoading 等），
    只保留有角色的游戏线程，过滤掉系统/工具线程。

    输出 ctx.meta["thread_queries"]，格式为：
    [{"tid": int, "thread_name": str, "running_dur_ms": float,
      "start_ms": float, "end_ms": float, "role": str}]
    """
    conn = ctx.sqlite_conn
    thread_queries = []
    seen = set()

    boundary = ctx.meta.get("launch_boundary", {})
    launch_start = boundary.get("start_ts")
    launch_end = boundary.get("end_ts")

    if conn is None:
        ctx.meta["thread_queries"] = thread_queries
        return ctx

    cur = conn.cursor()

    # Step 1: 引擎检测
    engine_info: Optional[GameEngineInfo] = None
    thread_filter = ""
    try:
        cur.execute("SELECT name, tid, itid FROM thread")
        all_threads = cur.fetchall()
        if all_threads:
            thread_df = pd.DataFrame(all_threads, columns=["name", "tid", "itid"])
            engine_info = detect_game_engine(thread_df)
            thread_filter = get_sql_thread_filter(engine_info)
            ctx.meta["engine_type"] = engine_info.engine_type
            _log.info("launch_thread_engine_detected",
                      engine_type=engine_info.engine_type,
                      key_thread_roles=list(engine_info.key_threads.keys()),
                      thread_filter=thread_filter)
    except Exception as e:
        _log.warn("launch_thread_engine_detect_failed", error=str(e))
        ctx.meta["engine_type"] = "UNKNOWN"

    if not launch_start:
        ctx.meta["thread_queries"] = thread_queries
        return ctx

    # Step 2: 查询游戏线程的Running时间
    time_filter = ""
    params_list: list = []
    if launch_end:
        time_filter = "AND ss.ts BETWEEN ? AND ?"
        params_list = [launch_start, launch_end]
    else:
        time_filter = "AND ss.ts >= ?"
        params_list = [launch_start]

    try:
        if thread_filter:
            sql = f"""
                SELECT t.itid, t.tid, t.name,
                       SUM(CASE WHEN ss.end_state IN ('R', 'S+') OR ss.end_state = 'R'
                           THEN ss.dur ELSE 0 END) AS running_dur
                FROM sched_slice ss
                JOIN thread t ON ss.itid = t.itid
                WHERE {thread_filter} {time_filter}
                GROUP BY t.itid
                ORDER BY running_dur DESC
                LIMIT 20
            """
        else:
            sql = f"""
                SELECT t.itid, t.tid, t.name,
                       SUM(CASE WHEN ss.end_state IN ('R', 'S+') OR ss.end_state = 'R'
                           THEN ss.dur ELSE 0 END) AS running_dur
                FROM sched_slice ss
                JOIN thread t ON ss.itid = t.itid
                WHERE 1=1 {time_filter}
                GROUP BY t.itid
                ORDER BY running_dur DESC
                LIMIT 20
            """
        cur.execute(sql, params_list)
        rows = cur.fetchall()

        launch_start_ms = launch_start / 1e6
        launch_end_ms = launch_end / 1e6 if launch_end else 0.0

        # 构建 tid -> role 反查映射
        tid_to_role: Dict[int, str] = {}
        if engine_info:
            for role, tids in engine_info.key_threads.items():
                for tid in tids:
                    tid_to_role[tid] = role

        for row in rows:
            itid = row[0]
            if itid in seen:
                continue
            seen.add(itid)
            tid = row[1]
            thread_name = str(row[2] or "")
            role = tid_to_role.get(tid, "")
            thread_queries.append({
                "tid": tid,
                "thread_name": thread_name,
                "running_dur_ms": round(row[3] / 1e6, 2) if row[3] else 0,
                "start_ms": round(launch_start_ms, 2),
                "end_ms": round(launch_end_ms, 2),
                "role": role,
            })
    except Exception as e:
        _log.warn("build_thread_queries_failed", error=str(e))

    ctx.meta["thread_queries"] = thread_queries
    _log.info("launch_thread_queries_built", count=len(thread_queries))
    return ctx


@register_operator("format_game_launch_summary")
def format_game_launch_summary(ctx: PreprocessContext) -> PreprocessContext:
    """格式化游戏启动分析结果，供 LLM 推理步骤消费.

    输出 ctx.data 为结构化字典：
    {
        "total_duration_ms": float,
        "engine_type": str,
        "boundary": {...},
        "phases": [...],
        "bottleneck": {...} | None,
        "thread_queries": [...],
        "warnings": [...]
    }
    """
    boundary = ctx.meta.get("launch_boundary", {})
    phases = ctx.data if isinstance(ctx.data, list) else []
    bottleneck = ctx.meta.get("launch_bottleneck")
    thread_queries = ctx.meta.get("thread_queries", [])
    warnings = ctx.meta.get("warnings", [])
    engine_type = ctx.meta.get("engine_type", "UNKNOWN")
    conn = ctx.sqlite_conn

    # 计算启动总时长
    total_ms = ctx.meta.get("_total_launch_ms")
    if total_ms is None:
        total_ms = boundary.get("duration_ms")
        if total_ms is None and boundary.get("start_ts") and boundary.get("end_ts"):
            total_ms = (boundary.get("end_ts") - boundary.get("start_ts")) / 1e6

    # 补充 pct_of_total 和 is_bottleneck 标记
    bottleneck_phase_name = bottleneck.get("phase") if bottleneck else None
    # 构建 tid -> thread_name 的映射（从thread_queries + thread表直接查询）
    tid_to_name = {tq["tid"]: tq["thread_name"] for tq in thread_queries if "tid" in tq}
    # 补充查询未在thread_queries中的tid的线程名（如PoolThread等辅助线程）
    if conn is not None:
        cur = conn.cursor()
        all_tids = [ph.get("tid") for ph in phases if ph.get("tid") is not None and pd.notna(ph.get("tid"))]
        missing_tids = [int(tid) for tid in all_tids if int(tid) not in tid_to_name]
        if missing_tids:
            placeholders = ",".join("?" * len(missing_tids))
            cur.execute(f"SELECT tid, name FROM thread WHERE tid IN ({placeholders})", missing_tids)
            for row in cur.fetchall():
                tid_to_name[row[0]] = row[1] or ""
    # 计算trace起点到launch起点的偏移
    trace_start = boundary.get("trace_start_ts", boundary.get("start_ts"))
    launch_start = boundary.get("start_ts")
    offset_ms = (launch_start - trace_start) / 1e6 if launch_start and trace_start else 0.0

    enriched_phases = []
    for ph in phases:
        ph_dur = ph.get("duration_ms", 0)
        pct = round(ph_dur / total_ms * 100, 1) if total_ms and total_ms > 0 else 0.0
        ph_tid = ph.get("tid")
        ph_thread_name = ph.get("thread_name", "") or tid_to_name.get(ph_tid, "")
        ph_start_ms = ph.get("start_ms", 0)
        ph_end_ms = ph.get("end_ms", 0)
        enriched_phases.append({
            "phase": ph.get("phase", ""),
            "phase_cn": ph.get("phase_cn", ""),
            "start_ms": ph_start_ms,
            "end_ms": ph_end_ms,
            "abs_start_ms": round(ph_start_ms + offset_ms, 2),
            "abs_end_ms": round(ph_end_ms + offset_ms, 2),
            "duration_ms": ph_dur,
            "pct_of_total": pct,
            "sample_count": ph.get("sample_count", 0),
            "key_functions": ph.get("key_functions", []),
            "tid": ph_tid,
            "thread_name": ph_thread_name,
            "is_bottleneck": (ph.get("phase") == bottleneck_phase_name),
        })

    ctx.data = {
        "total_duration_ms": round(total_ms, 2) if total_ms else 0.0,
        "engine_type": engine_type,
        "boundary": boundary,
        "phases": enriched_phases,
        "bottleneck": bottleneck,
        "thread_queries": thread_queries,
        "warnings": warnings,
    }

    return ctx
