"""逐步骤进程指令数对比算子。

两个 @register_operator 算子：
- build_perf_step_comparison: 步骤配对 + 全量查询 + 进程对比 + 线程拆解
- format_comparison_csv: CSV 文件生成

辅助函数从 server.py compare_process_instructions 迁移而来。
"""
from __future__ import annotations

import csv
import io
import json
import re
import sqlite3
from collections import defaultdict
from pathlib import Path
from .base import PreprocessContext, register_operator

# ---------------------------------------------------------------------------
# 黑名单配置
# ---------------------------------------------------------------------------

_BLACKLIST_PATH = Path(__file__).resolve().parent.parent.parent / "config" / "perf" / "perf_process_blacklist.json"
_BLACKLIST_CACHE: list | None = None


def _strip_process_path(name: str) -> str:
    """去除进程名中的路径前缀，只保留最后一段。

    "/system/bin/hiview" → "hiview"
    "com.example.app" → "com.example.app"
    """
    if not name:
        return name
    return name.rsplit("/", 1)[-1]


def _load_blacklist() -> list:
    """加载黑名单配置，返回编译后的正则表达式列表。结果缓存。

    JSON 结构：{"android_black_list": [...], "harmony_black_list": [...]}
    两个列表合并后统一匹配。
    """
    global _BLACKLIST_CACHE
    if _BLACKLIST_CACHE is not None:
        return _BLACKLIST_CACHE

    patterns = []
    if _BLACKLIST_PATH.exists():
        with open(_BLACKLIST_PATH, encoding="utf-8") as f:
            data = json.load(f)
        for key in ("android_black_list", "harmony_black_list"):
            for p in data.get(key, []):
                patterns.append(re.compile(p))

    _BLACKLIST_CACHE = patterns
    return patterns


def _is_blacklisted(process_name: str) -> bool:
    """判断进程名是否在黑名单中。先去除路径前缀再匹配。"""
    stripped = _strip_process_path(process_name)
    for p in _load_blacklist():
        if p.match(stripped):
            return True
    return False

# ---------------------------------------------------------------------------
# 辅助函数（从 server.py 迁移，逻辑不变）
# ---------------------------------------------------------------------------

def _normalize_thread_name(name: str) -> str:
    """将线程名映射到线程组名。
    - OS_FFRT_<组编号>_<线程编号> -> OS_FFRT_<组编号>_*
    - OS_IPC_<组编号>_<线程编号> -> OS_IPC_*
    - OS_GC_Thread -> OS_GC_Thread（不变）
    - 其他线程名不变
    """
    if name is None:
        return "unknown_thread"
    if name.startswith("OS_FFRT_"):
        parts = name.split("_")
        # OS_FFRT_2_40 -> ["OS", "FFRT", "2", "40"]
        if len(parts) >= 4:
            return f"OS_FFRT_{parts[2]}_*"
    elif name.startswith("OS_IPC_"):
        # OS_IPC_1_5079 -> OS_IPC_*
        return "OS_IPC_*"
    # OS_GC_Thread 或其他 -> 不变
    return name


def _parse_step_segments(segments: list, trace_end_ms: float) -> dict:
    """从 callstack 标记解析出 {step_name: {start_ms, end_ms}}
    缺 End 标记时，用 trace_end_ms 兜底。
    """
    steps = {}
    for seg in segments:
        name = seg.get("name", "")
        ts_ms = seg.get("ts_ms", 0)
        if name.startswith("TestScenarios_Start_"):
            step_key = name[len("TestScenarios_Start_"):]
            steps.setdefault(step_key, {})["start_ms"] = ts_ms
        elif name.startswith("TestScenarios_End_"):
            step_key = name[len("TestScenarios_End_"):]
            steps.setdefault(step_key, {})["end_ms"] = ts_ms
    # 缺 End 时用 trace 结束时间兜底，缺 Start 的丢弃
    for k, v in steps.items():
        if "start_ms" in v and "end_ms" not in v:
            v["end_ms"] = trace_end_ms
    complete = {k: v for k, v in steps.items() if "start_ms" in v and "end_ms" in v}
    return complete


def _parse_case_id(step_key: str) -> str:
    """从标记名解析用例编号。
    示例输入: PerfLoad#bilibili#0020_yylx.danmaku.bili_0001&视频播放页面-...
    输出: bilibili_0020_step1
    """
    parts = step_key.split("#")
    if len(parts) >= 3:
        app_name = parts[1]
        remainder = parts[2]
        # 提取编号: 0020_yylx.danmaku.bili_0001&... -> 0020
        num_match = re.match(r"(\d+)", remainder)
        app_num = num_match.group(1) if num_match else "0000"
        # 提取步骤编号: 取 & 前最后一段 _ 后的数字 0001 -> 1
        before_amp = remainder.split("&")[0]
        trailing_nums = re.findall(r"_(\d+)$", before_amp)
        step_num = int(trailing_nums[-1]) if trailing_nums else 0
        return f"{app_name}_{app_num}_step{step_num}"
    # 回退：用原始 key 做简化
    return step_key.replace("#", "_").replace("&", "_").replace(" ", "_")


def _parse_thread_detail(detail_str: str) -> dict:
    """解析线程明细字符串 "thread1:count1,thread2:count2" -> {name: count}"""
    result = {}
    if not detail_str or detail_str.strip() == "":
        return result
    for part in detail_str.split(","):
        part = part.strip()
        if ":" in part:
            idx = part.rfind(":")
            name = part[:idx].strip()
            count_str = part[idx + 1:].strip()
            try:
                result[name] = int(count_str)
            except ValueError:
                result[name] = count_str
    return result


def _merge_by_thread_group(threads: list) -> dict:
    """将线程按线程组名合并，汇总 total_instructions 和 sample_count，
    同时保留组内各线程的明细（线程名:指令数）。"""
    merged = defaultdict(lambda: {
        "total_instructions": 0,
        "sample_count": 0,
        "thread_details": [],
    })
    for t in threads:
        tname = t.get("thread_name", "")
        if not tname:
            continue
        group_name = _normalize_thread_name(tname)
        instr = t.get("total_instructions", 0)
        merged[group_name]["total_instructions"] += instr
        merged[group_name]["sample_count"] += t.get("sample_count", 0)
        merged[group_name]["thread_details"].append(f"{tname}:{instr}")
    # 对明细按线程名排序，保证输出稳定
    for g in merged.values():
        g["thread_details"].sort()
    return dict(merged)


def _aggregate_thread_rows(raw_rows: list) -> list:
    """将全量线程采样行聚合为 [{thread_name, total_instructions, sample_count}, ...]。

    raw_rows: [(thread_id, process_id, thread_name, timeStamp_ns, event_count), ...]
    """
    acc = defaultdict(lambda: {"thread_name": "", "total_instructions": 0, "sample_count": 0})
    for thread_id, process_id, thread_name, ts_ns, event_count in raw_rows:
        key = thread_id
        acc[key]["thread_name"] = thread_name
        acc[key]["total_instructions"] += event_count
        acc[key]["sample_count"] += 1
    return list(acc.values())


# ---------------------------------------------------------------------------
# 算子 1: 步骤配对 + 全量查询 + 进程对比 + 线程拆解
# ---------------------------------------------------------------------------

@register_operator("build_perf_step_comparison")
def build_perf_step_comparison(ctx: PreprocessContext) -> PreprocessContext:
    """步骤配对 + 全量查询 + 进程对比 + 线程拆解（计算核心）。

    ctx.params 输入:
        baseline_sqlite_path: str
        current_sqlite_path: str
        baseline_start_ms: float
        baseline_end_ms: float
        current_start_ms: float
        current_end_ms: float
        regression_threshold_pct: float (默认 5.0)
        engine: QueryEngine 实例（server.py 传入）

    ctx.data 输出:
        step_queries: list[dict]    — 步骤对齐信息
        process_rows: list[dict]    — 进程级对比数据
        thread_rows: list[dict]     — 线程级拆解数据
        drill_down_queries: list    — 劣化进程列表
        summary: list[dict]         — 每步骤汇总
    """
    p = ctx.params
    baseline_sqlite_path = p["baseline_sqlite_path"]
    current_sqlite_path = p["current_sqlite_path"]
    baseline_start_ms = p["baseline_start_ms"]
    baseline_end_ms = p["baseline_end_ms"]
    current_start_ms = p["current_start_ms"]
    current_end_ms = p["current_end_ms"]
    regression_threshold_pct = p.get("regression_threshold_pct", 5.0)
    engine = p["engine"]  # QueryEngine 实例，由 server.py 传入

    # ------------------------------------------------------------------
    # 1. 获取步骤边界（复用 perf_step_segments 指标）
    # ------------------------------------------------------------------
    def _query_segments(sqlite_path: str, start_ms: float, end_ms: float) -> list:
        result = engine.execute(
            sqlite_path=sqlite_path,
            indicator_names=["perf_step_segments"],
            base_params={"start_ms": start_ms, "end_ms": end_ms},
        )
        data = result.get("indicators", {}).get("perf_step_segments", {}).get("data", [])
        return data if isinstance(data, list) else []

    baseline_segments = _query_segments(baseline_sqlite_path, baseline_start_ms, baseline_end_ms)
    current_segments = _query_segments(current_sqlite_path, current_start_ms, current_end_ms)

    if not baseline_segments and not current_segments:
        ctx.data = {"error": "两个版本均未找到 TestScenarios 标记，无法配对步骤"}
        return ctx

    # 单侧无标记时也无法配对，提前报错
    if not baseline_segments or not current_segments:
        missing = "当前版本" if not current_segments else "基线版本"
        ctx.data = {"error": f"{missing}未找到 TestScenarios 标记，无法配对步骤"}
        return ctx

    # ------------------------------------------------------------------
    # 2. 配对 Start/End
    # ------------------------------------------------------------------
    baseline_steps = _parse_step_segments(baseline_segments, baseline_end_ms)
    current_steps = _parse_step_segments(current_segments, current_end_ms)

    # ------------------------------------------------------------------
    # 3. 基线/当前步骤对齐
    # ------------------------------------------------------------------
    all_step_keys = sorted(set(list(baseline_steps.keys()) + list(current_steps.keys())))
    step_queries = []
    for idx, sk in enumerate(all_step_keys):
        b = baseline_steps.get(sk)
        c = current_steps.get(sk)
        step_queries.append({
            "step_index": idx,
            "step_key": sk,
            "case_id": _parse_case_id(sk),
            "step_name": sk.split("&")[-1] if "&" in sk else sk,
            "baseline_start_ms": b["start_ms"] if b else None,
            "baseline_end_ms": b["end_ms"] if b else None,
            "current_start_ms": c["start_ms"] if c else None,
            "current_end_ms": c["end_ms"] if c else None,
            "paired": b is not None and c is not None,
        })

    # ------------------------------------------------------------------
    # 4. 全量查询进程级数据（每个 db 只开一次连接，同时取主线程名映射）
    # ------------------------------------------------------------------
    _SAMPLE_SQL = """
        SELECT t.process_id,
               t.thread_name,
               ps.timeStamp,
               ps.event_count
        FROM perf_sample ps
        JOIN perf_thread t ON ps.thread_id = t.thread_id
        WHERE ps.timeStamp > ? AND ps.timeStamp < ?
    """

    _MAIN_THREAD_SQL = """
        SELECT process_id, thread_name
        FROM perf_thread
        WHERE thread_id = process_id
    """

    def _query_process_data(sqlite_path: str, start_ms: float, end_ms: float) -> tuple:
        """一次连接同时查主线程名映射 + 全量采样数据。

        返回 (main_names, sample_rows):
          main_names: {process_id: stripped_process_name}
          sample_rows: [(process_id, thread_name, timeStamp_ns, event_count), ...]
        """
        conn = sqlite3.connect(sqlite_path)
        try:
            main_rows = conn.execute(_MAIN_THREAD_SQL).fetchall()
            main_names = {pid: _strip_process_path(name) for pid, name in main_rows}
            sample_rows = conn.execute(
                _SAMPLE_SQL,
                [start_ms * 1_000_000, end_ms * 1_000_000],
            ).fetchall()
            return main_names, sample_rows
        finally:
            conn.close()

    # ------------------------------------------------------------------
    # 5. Python 按 step 区间聚合
    # ------------------------------------------------------------------
    # 构建步骤时间区间列表（仅 paired 步骤参与聚合）
    paired_steps = [sq for sq in step_queries if sq["paired"]]

    def _aggregate_by_steps(raw_rows: list, steps: list, which: str,
                            main_names: dict) -> dict:
        """将全量行按步骤时间区间聚合，返回 {(step_idx, process_id): total_instructions}。

        which: "baseline" 或 "current"，用于选择 start/end 字段名。
        main_names: 预查的主线程名映射 {process_id: process_name}。
        """
        acc = defaultdict(int)  # (step_index, process_id) → total_instructions
        pid_to_name = {}  # process_id → process_name_hint

        # 预构建步骤区间（避免循环内重复属性访问）
        step_ranges = []
        for sq in steps:
            start_key = f"{which}_start_ms"
            end_key = f"{which}_end_ms"
            step_ranges.append((sq["step_index"], sq[start_key], sq[end_key]))

        for process_id, thread_name, ts_ns, event_count in raw_rows:
            # 进程名从 perf_thread 主线程行映射，查不到则用 PID 字符串
            if process_id not in pid_to_name:
                pid_to_name[process_id] = main_names.get(process_id, str(process_id))
            ts_ms = ts_ns / 1_000_000
            # 找到所属 step（线性扫描，步骤数通常 < 30）
            for step_idx, s_start, s_end in step_ranges:
                if s_start <= ts_ms < s_end:
                    acc[(step_idx, process_id)] += event_count
                    break

        return {"acc": dict(acc), "pid_to_name": pid_to_name}

    # 查询 baseline 和 current 全量数据（每个 db 只开一次连接）
    b_main_names, b_raw = _query_process_data(baseline_sqlite_path, baseline_start_ms, baseline_end_ms)
    c_main_names, c_raw = _query_process_data(current_sqlite_path, current_start_ms, current_end_ms)

    b_agg = _aggregate_by_steps(b_raw, paired_steps, "baseline", b_main_names)
    c_agg = _aggregate_by_steps(c_raw, paired_steps, "current", c_main_names)

    # ------------------------------------------------------------------
    # 6. 计算劣化率
    # ------------------------------------------------------------------
    process_rows = []
    drill_down_queries = []

    for sq in paired_steps:
        si = sq["step_index"]
        # 收集该步骤下所有出现过的 process_id
        b_pids = {pid for (s, pid) in b_agg["acc"] if s == si}
        c_pids = {pid for (s, pid) in c_agg["acc"] if s == si}

        # 分别建立 pid → name 映射（baseline 和 current 可能同一 pid 对应不同进程）
        b_name_map = b_agg["pid_to_name"]
        c_name_map = c_agg["pid_to_name"]

        # 按进程名对齐：同名进程合并，不同名进程各自独立
        # 先按 (name, which) 收集 pid
        b_name_to_pids = defaultdict(list)
        for pid in b_pids:
            b_name_to_pids[b_name_map.get(pid, str(pid))].append(pid)

        c_name_to_pids = defaultdict(list)
        for pid in c_pids:
            c_name_to_pids[c_name_map.get(pid, str(pid))].append(pid)

        all_names = sorted(set(list(b_name_to_pids.keys()) + list(c_name_to_pids.keys())))

        for pname in all_names:
            # 黑名单过滤：匹配的进程不出现在进程级对比和线程拆解中
            if _is_blacklisted(pname):
                continue
            b_pids_for_name = b_name_to_pids.get(pname, [])
            c_pids_for_name = c_name_to_pids.get(pname, [])
            b_val = sum(b_agg["acc"].get((si, pid), 0) for pid in b_pids_for_name)
            c_val = sum(c_agg["acc"].get((si, pid), 0) for pid in c_pids_for_name)
            b_pid = b_pids_for_name[0] if b_pids_for_name else None
            c_pid = c_pids_for_name[0] if c_pids_for_name else None

            if b_val == 0 and c_val == 0:
                rate_str = "0.00"
                rate_val = 0.0
            elif b_val == 0 and c_val > 0:
                rate_str = "NEW"
                rate_val = float("inf")
            else:
                rate_val = (c_val - b_val) / b_val * 100
                rate_str = f"{rate_val:.2f}"

            process_rows.append({
                "case_id": sq["case_id"],
                "step_name": sq["step_name"],
                "process_name": pname,
                "baseline_instructions": b_val,
                "current_instructions": c_val,
                "regression_amount": c_val - b_val,
                "regression_rate_pct": rate_str,
            })

            # 劣化进程 → 需要线程拆解
            if rate_val > regression_threshold_pct or (b_val == 0 and c_val > 0):
                drill_down_queries.append({
                    "case_id": sq["case_id"],
                    "step_name": sq["step_name"],
                    "process_name": pname,
                    "baseline_pid": b_pid,
                    "current_pid": c_pid,
                    "baseline_start_ms": sq["baseline_start_ms"],
                    "baseline_end_ms": sq["baseline_end_ms"],
                    "current_start_ms": sq["current_start_ms"],
                    "current_end_ms": sq["current_end_ms"],
                })

    # ------------------------------------------------------------------
    # 7. 劣化进程线程级拆解（复用连接，每个 db 只开一次）
    # ------------------------------------------------------------------
    _THREAD_SQL = """
        SELECT t.thread_id, t.process_id, t.thread_name,
               ps.timeStamp, ps.event_count
        FROM perf_sample ps
        JOIN perf_thread t ON ps.thread_id = t.thread_id
        WHERE t.process_id = ?
          AND ps.timeStamp > ? AND ps.timeStamp < ?
    """

    thread_rows = []

    # 按 db 分组查询，避免重复开关连接
    b_drilldowns = [dd for dd in drill_down_queries if dd["baseline_pid"] is not None]
    c_drilldowns = [dd for dd in drill_down_queries if dd["current_pid"] is not None]

    b_thread_cache = {}  # (case_id, process_name) -> aggregated threads
    if b_drilldowns:
        conn = sqlite3.connect(baseline_sqlite_path)
        try:
            for dd in b_drilldowns:
                rows = conn.execute(
                    _THREAD_SQL,
                    [dd["baseline_pid"],
                     dd["baseline_start_ms"] * 1_000_000,
                     dd["baseline_end_ms"] * 1_000_000],
                ).fetchall()
                b_thread_cache[(dd["case_id"], dd["process_name"])] = _aggregate_thread_rows(rows)
        finally:
            conn.close()

    c_thread_cache = {}
    if c_drilldowns:
        conn = sqlite3.connect(current_sqlite_path)
        try:
            for dd in c_drilldowns:
                rows = conn.execute(
                    _THREAD_SQL,
                    [dd["current_pid"],
                     dd["current_start_ms"] * 1_000_000,
                     dd["current_end_ms"] * 1_000_000],
                ).fetchall()
                c_thread_cache[(dd["case_id"], dd["process_name"])] = _aggregate_thread_rows(rows)
        finally:
            conn.close()

    for dd in drill_down_queries:
        key = (dd["case_id"], dd["process_name"])
        b_threads_raw = b_thread_cache.get(key, [])
        c_threads_raw = c_thread_cache.get(key, [])

        b_tmap = _merge_by_thread_group(b_threads_raw)
        c_tmap = _merge_by_thread_group(c_threads_raw)
        all_tnames = sorted(set(list(b_tmap.keys()) + list(c_tmap.keys())))

        for tname in all_tnames:
            b_val = b_tmap.get(tname, {}).get("total_instructions", 0)
            c_val = c_tmap.get(tname, {}).get("total_instructions", 0)
            b_detail = ",".join(b_tmap.get(tname, {}).get("thread_details", []))
            c_detail = ",".join(c_tmap.get(tname, {}).get("thread_details", []))

            if b_val == 0 and c_val == 0:
                rate_str = "0.00"
            elif b_val == 0 and c_val > 0:
                rate_str = "NEW"
            else:
                rate_val = (c_val - b_val) / b_val * 100
                rate_str = f"{rate_val:.2f}"

            thread_rows.append({
                "case_id": dd["case_id"],
                "step_name": dd["step_name"],
                "process_name": dd["process_name"],
                "thread_group_name": tname,
                "baseline_instructions": b_val,
                "current_instructions": c_val,
                "regression_amount": c_val - b_val,
                "regression_rate_pct": rate_str,
                "baseline_thread_detail": b_detail,
                "current_thread_detail": c_detail,
            })

    # ------------------------------------------------------------------
    # 8. 生成 summary
    # ------------------------------------------------------------------
    summary = []
    for sq in step_queries:
        if not sq["paired"]:
            continue
        procs = [r for r in process_rows if r["case_id"] == sq["case_id"]]
        regressed = [r for r in procs if r["regression_rate_pct"] == "NEW" or
                     (r["regression_rate_pct"] != "0.00" and
                      r["regression_rate_pct"] != "NEW" and
                      float(r["regression_rate_pct"]) > regression_threshold_pct)]
        summary.append({
            "case_id": sq["case_id"],
            "step_name": sq["step_name"],
            "process_count": len(procs),
            "regressed_count": len(regressed),
        })

    ctx.data = {
        "step_queries": step_queries,
        "process_rows": process_rows,
        "thread_rows": thread_rows,
        "drill_down_queries": drill_down_queries,
        "summary": summary,
    }
    return ctx


# ---------------------------------------------------------------------------
# 算子 2: CSV 文件生成
# ---------------------------------------------------------------------------

@register_operator("format_comparison_csv")
def format_comparison_csv(ctx: PreprocessContext) -> PreprocessContext:
    """CSV 文件生成（I/O 输出）。

    ctx.params 输入:
        process_rows: list[dict]  — 来自 build_perf_step_comparison
        thread_rows: list[dict]   — 来自 build_perf_step_comparison
        output_dir: str           — 输出目录路径

    ctx.data 输出:
        process_csv_path: str
        thread_csv_path: str
    """
    p = ctx.params
    process_rows = p.get("process_rows", [])
    thread_rows = p.get("thread_rows", [])
    output_dir = Path(p["output_dir"])

    # ------------------------------------------------------------------
    # CSV1: 进程级对比
    # ------------------------------------------------------------------
    process_rows.sort(key=lambda r: (r["case_id"], -r["regression_amount"]))

    csv1_buf = io.StringIO()
    csv1_writer = csv.writer(csv1_buf)
    csv1_writer.writerow(["用例编号", "步骤名称", "进程名", "基线指令数", "当前指令数", "劣化量", "劣化率(%)"])
    for row in process_rows:
        csv1_writer.writerow([
            row["case_id"],
            row["step_name"],
            row["process_name"],
            row["baseline_instructions"],
            row["current_instructions"],
            row["regression_amount"],
            row["regression_rate_pct"],
        ])
    csv1_content = csv1_buf.getvalue()

    csv1_path = output_dir / "perf_process_comparison.csv"
    if csv1_content:
        with open(csv1_path, "w", encoding="utf-8-sig", newline="") as f:
            f.write(csv1_content)

    # ------------------------------------------------------------------
    # CSV2: 线程级拆解
    # ------------------------------------------------------------------
    # 构建进程排序索引：(case_id, process_name) → 排序序号，与进程CSV一致
    process_order = {}
    for idx, pr in enumerate(process_rows):
        key = (pr["case_id"], pr["process_name"])
        process_order[key] = idx

    # 排序：按进程CSV顺序，同进程内线程组按劣化量降序
    thread_rows.sort(key=lambda r: (
        process_order.get((r["case_id"], r["process_name"]), 999999),
        -r["regression_amount"],
    ))
    csv2_path = output_dir / "perf_thread_comparison.csv"

    if not thread_rows:
        ctx.data = {
            "process_csv_path": str(csv1_path),
            "thread_csv_path": "",
        }
        return ctx

    csv2_buf = io.StringIO()
    csv2_writer = csv.writer(csv2_buf)
    csv2_writer.writerow(["用例编号", "步骤名称", "进程名", "线程组名", "基线线程组指令数", "当前线程组指令数", "线程组劣化量", "线程组劣化率(%)", "线程名", "基线线程指令数", "当前线程指令数"])
    for row in thread_rows:
        b_threads = _parse_thread_detail(row["baseline_thread_detail"])
        c_threads = _parse_thread_detail(row["current_thread_detail"])
        # 线程组内线程按绝对指令数降序（不看劣化，因为线程名两边对不上）
        all_names = list(b_threads.keys()) + [n for n in c_threads if n not in b_threads]
        all_names.sort(key=lambda tn: -max(b_threads.get(tn, 0), c_threads.get(tn, 0)))
        if not all_names:
            all_names = [""]
        for tn in all_names:
            csv2_writer.writerow([
                row["case_id"], row["step_name"], row["process_name"],
                row["thread_group_name"],
                row["baseline_instructions"], row["current_instructions"],
                row["regression_amount"], row["regression_rate_pct"],
                tn, b_threads.get(tn, 0), c_threads.get(tn, 0),
            ])
    with open(csv2_path, "w", encoding="utf-8-sig", newline="") as f:
        f.write(csv2_buf.getvalue())

    ctx.data = {
        "process_csv_path": str(csv1_path),
        "thread_csv_path": str(csv2_path),
    }
    return ctx
