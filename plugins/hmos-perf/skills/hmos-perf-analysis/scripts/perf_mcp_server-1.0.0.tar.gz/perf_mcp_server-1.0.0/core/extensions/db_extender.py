"""数据库扩展器 - 将 Page Cache 事件写入 SQLite .db 文件"""
import sqlite3
from core.observability import get_module_logger
from .page_cache_parser import parse_page_cache_events

logger = get_module_logger(__name__)

PAGE_CACHE_IO_SCHEMA = """
CREATE TABLE IF NOT EXISTS page_cache_io (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts_ns INTEGER NOT NULL,
    cpu INTEGER NOT NULL,
    itid INTEGER NOT NULL,
    tid INTEGER NOT NULL,
    comm TEXT NOT NULL,
    dev_major INTEGER NOT NULL,
    dev_minor INTEGER NOT NULL,
    i_ino INTEGER NOT NULL,
    pfn INTEGER NOT NULL,
    page_index INTEGER NOT NULL,
    offset INTEGER NOT NULL,
    is_add INTEGER NOT NULL
);
"""


def extend_db_with_page_cache(ftrace_path: str, db_path: str) -> dict:
    """解析 ftrace 文件中的 page cache 事件，添加到现有 .db 文件

    Args:
        ftrace_path: .ftrace 文件路径
        db_path: 已由 trace_streamer 生成的 .db 文件路径

    Returns:
        dict: 包含 page_cache_io_count 等统计信息
    """
    logger.info(f"Parsing page cache events from {ftrace_path}")
    events = parse_page_cache_events(ftrace_path)

    if not events:
        logger.warning("No page cache events found in ftrace")
        return {"page_cache_io_count": 0}

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 创建表
    cursor.execute(PAGE_CACHE_IO_SCHEMA)

    # 批量插入数据
    records = [
        (e.ts_ns, e.cpu, e.itid, e.pid, e.comm, e.dev_major, e.dev_minor,
         e.i_ino, e.pfn, e.index, e.offset, 1 if e.is_add else 0)
        for e in events
    ]

    cursor.executemany(
        "INSERT INTO page_cache_io (ts_ns, cpu, itid, tid, comm, dev_major, dev_minor, "
        "i_ino, pfn, page_index, offset, is_add) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        records
    )

    # 创建索引
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_page_cache_ts ON page_cache_io(ts_ns)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_page_cache_ino ON page_cache_io(i_ino)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_page_cache_dev ON page_cache_io(dev_major, dev_minor)")

    conn.commit()
    conn.close()

    logger.info(f"Inserted {len(events)} page cache events into {db_path}")

    return {
        "page_cache_io_count": len(events),
        "add_count": sum(1 for e in events if e.is_add),
        "delete_count": sum(1 for e in events if not e.is_add),
    }


def get_page_cache_stats(db_path: str) -> dict:
    """获取 page_cache_io 表的统计信息"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM page_cache_io")
    total = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM page_cache_io WHERE is_add = 1")
    add_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM page_cache_io WHERE is_add = 0")
    delete_count = cursor.fetchone()[0]

    cursor.execute("SELECT MIN(ts_ns), MAX(ts_ns), MAX(ts_ns) - MIN(ts_ns) FROM page_cache_io")
    ts_row = cursor.fetchone()
    min_ts, max_ts, duration = ts_row if ts_row else (0, 0, 0)

    cursor.execute("SELECT COUNT(DISTINCT i_ino) FROM page_cache_io")
    unique_inodes = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(DISTINCT comm) FROM page_cache_io")
    unique_procs = cursor.fetchone()[0]

    conn.close()

    return {
        "total_events": total,
        "add_count": add_count,
        "delete_count": delete_count,
        "min_ts_ns": min_ts,
        "max_ts_ns": max_ts,
        "duration_ns": duration,
        "unique_inodes": unique_inodes,
        "unique_processes": unique_procs,
    }
