"""启动流程拆解算子（pipeline 形态）。

冷启动事件序列（来自 callstack 表）：
  1. AppSpawnExecuteSpawningHook      → ProcessCreate
  2. HandleLaunchApplication           → ApplicationInit
  3. HandleLaunchAbility               → AbilityInit
  4. HandleAbilityTransaction          → AbilityLifecycle（结束点: 当前进程内首个ReceiveVsync的ts）
  5. ReceiveVsync(首个) → FirstFrame（ts → ts+dur，单事件区间）

ExtensionAbility 启动事件序列：
  1. HandleExtensionTransaction → ExtensionAbilityLifecycle
  2. ReceiveVsync(首个) → FirstFrame（可选，带 UI 的 Extension）

温启动事件序列：
  1. HandleLaunchAbility               → AbilityInit
  2. HandleAbilityTransaction          → AbilityLifecycle
  3. ReceiveVsync(首个) → FirstFrame（ts → ts+dur）

热启动事件序列：
  1. HandleAbilityTransaction → AbilityLifecycle
  2. ReceiveVsync(首个) → FirstFrame（ts → ts+dur）

AbilityLifecycle 与 ExtensionAbilityLifecycle 互斥：同一启动实例只取第一个出现的。

多次启动支持：
  - 同一 ipid 的每次 AbilityTransaction/ExtensionTransaction 视为一次独立启动
  - 每次启动拥有独立的阶段列表，前置阶段（ProcessCreate/ApplicationInit/AbilityInit）
    在第一个实例中拥有，后续实例标记 missing=true
  - 输出多个 launch_phase_summary 条目，每个包含 launch_instance_index（0-based）

FirstFrame 语义：当前进程内 AbilityLifecycle/ExtensionAbilityLifecycle 开始后的
第一个 ReceiveVsync 事件的 ts 为起点、ts+dur 为结束点。
不再依赖 ReportEventFirstFrame（已从 SQL 中移除）。

单位: ts_ns / dur_ns（纳秒），输出 start_ms / end_ms / duration_ms（毫秒）

多进程支持:
  - 按 ipid 分组独立分析每个进程
  - ipid=null 的数据归入 "unknown" 组
  - 阶段间 gap 被消除（前一阶段 end_ms = 下一阶段 start_ms）
  - 末阶段（FirstFrame）保持自己的 end_ms
"""

from __future__ import annotations

import pandas as pd
from typing import Any
from core.observability import get_module_logger
from .base import PreprocessContext, PreprocessError, register_operator
from .frame_ops import _resolve_app_name
from utils.process_name import get_process_name

log = get_module_logger(__name__)

# 启动阶段顺序（与 callstack 事件名的映射关系）
LAUNCH_PHASES_ORDER = [
    "ProcessCreate",
    "ApplicationInit",
    "AbilityInit",
    "AbilityLifecycle",
    "ExtensionAbilityLifecycle",  # ExtensionAbility 生命周期
    "FirstFrame",
]

# callstack 事件名 → 阶段名 的映射
# ReportEventFirstFrame 保留映射但不在 LAUNCH_PHASES_ORDER 中，SQL 已不查询该事件
EVENT_TO_PHASE = {
    "AppSpawnExecuteSpawningHook": "ProcessCreate",
    "HandleLaunchApplication": "ApplicationInit",
    "HandleLaunchAbility": "AbilityInit",
    "HandleAbilityTransaction": "AbilityLifecycle",
    "HandleExtensionTransaction": "ExtensionAbilityLifecycle",  # ExtensionAbility
    "ReceiveVsync": "FirstFrame",          # FirstFrame: ts → ts+dur（单事件区间）
    "ReportEventFirstFrame": "_FirstFrameEnd",  # 哨兵：SQL 已不查询，保留兼容
}

# 启动锚点阶段：每次出现这些阶段的事件标志着一次新的启动实例
LAUNCH_ANCHOR_PHASES = {"AbilityLifecycle", "ExtensionAbilityLifecycle"}

# 前置阶段：进程级事件，同一 ipid 只出现一次
PRE_PHASES = {"ProcessCreate", "ApplicationInit", "AbilityInit"}

# callstack.ts / callstack.dur 单位是微秒（μs），转换为毫秒需除以 1e6
# 注：字段虽命名为 ts_ns/dur_ns，但实际存的是 μs，这由 sql_schema.md 确认
US_TO_MS = 1e-6


def _raw_name_to_phase(name: str) -> str | None:
    """根据 callstack name 推断阶段名。"""
    for pattern, phase in EVENT_TO_PHASE.items():
        if pattern in name:
            return phase
    return None


def _row_to_anchor(row, ipid: int | None, time_field: str, event_field: str) -> dict[str, Any]:
    """从 DataFrame row 提取锚点 dict。"""
    return {
        "ts_ns": int(row[time_field]) if pd.notna(row[time_field]) else 0,
        "dur_ns": int(row["dur_ns"]) if "dur_ns" in row and pd.notna(row["dur_ns"]) else 0,
        "raw_name": str(row[event_field]),
        "tid": int(row["tid"]) if "tid" in row and pd.notna(row["tid"]) else None,
        "thread_name": str(row["thread_name"]) if "thread_name" in row and pd.notna(row["thread_name"]) else None,
        "ipid": ipid,
    }


# ---------------------------------------------------------------------------
# Layer 1: 配对事件
# ---------------------------------------------------------------------------
@register_operator("pair_lifecycle_events")
def pair_lifecycle_events(ctx: PreprocessContext) -> PreprocessContext:
    """把 SQL 拉出的事件流按 ipid 分组，提取每个阶段的锚点时间。

    输入:
        ctx.data: DataFrame 含列 ts_ns / dur_ns / name / (optional) ipid / tid / thread_name
    输出:
        ctx.data: 新增列 phase（阶段名），筛选出启动相关的行
        ctx.meta["anchors"]: {phase: {"ts_ns": int, "dur_ns": int, "raw_name": str, ...}}
        ctx.meta["ipid_groups"]: {ipid: {"rows": [], "anchors": {}, "df": DataFrame}}
        ctx.meta["paired_processes"]: 进程数量
    """
    df = ctx.data
    time_field = ctx.params.get("time_field", "ts_ns")
    event_field = ctx.params.get("event_field", "name")

    required = {time_field, event_field}
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(
            f"pair_lifecycle_events 输入缺少列: {sorted(missing)}; "
            f"请确认 SQL 输出已包含 {sorted(required)}"
        )

    # 过滤出启动相关事件，提取阶段名
    phase_col = []
    for name in df[event_field]:
        phase = _raw_name_to_phase(str(name))
        phase_col.append(phase)

    df = df.copy()
    df["phase"] = phase_col

    # 保留原始事件名（用于后续 ReceiveVsync 查找）
    df["raw_name"] = df[event_field]

    # 只保留有阶段名的行
    df = df[df["phase"].notna()].copy()
    df = df.sort_values(time_field).reset_index(drop=True)

    # SQLite NULL → pandas NaN；int(NaN) 会崩溃，提前填充
    if "dur_ns" in df.columns:
        df["dur_ns"] = df["dur_ns"].fillna(0)
    if "ts_ns" in df.columns:
        df["ts_ns"] = df["ts_ns"].fillna(0)

    # 提取每个阶段的第一个锚点事件（按时间顺序）
    anchors: dict[str, dict[str, Any]] = {}

    # 按 ipid 分组存储
    # ipid 为 None/null 时归入 None 组（称为 "unknown" 组）
    ipid_groups: dict[int | None, dict[str, Any]] = {}

    for _, row in df.iterrows():
        p = row["phase"]

        # 提取 ipid 字段（pd.notna 兼容 NaN）
        ipid: int | None = None
        if "ipid" in row and pd.notna(row["ipid"]):
            try:
                ipid = int(row["ipid"])
            except (ValueError, TypeError):
                ipid = None

        # 单个全局 anchor（兼容旧逻辑）
        if p not in anchors:
            anchors[p] = _row_to_anchor(row, ipid, time_field, event_field)

        # 按 ipid 分组
        if ipid not in ipid_groups:
            ipid_groups[ipid] = {"rows": [], "anchors": {}}
        ipid_groups[ipid]["rows"].append(row)

    # 每个 ipid 组独立提取 anchors（支持多次启动）
    for ipid, group in ipid_groups.items():
        group_df = pd.DataFrame(group["rows"]).sort_values(time_field).reset_index(drop=True)

        # 先收集所有前置阶段事件（每个只取第一个）
        pre_anchors: dict[str, dict[str, Any]] = {}
        for _, row in group_df.iterrows():
            p = row["phase"]
            if p in PRE_PHASES and p not in pre_anchors:
                pre_anchors[p] = _row_to_anchor(row, ipid, time_field, event_field)

        # 找到所有启动锚点事件（按时间排序）
        anchor_rows = group_df[group_df["phase"].isin(LAUNCH_ANCHOR_PHASES)]

        # 去重：同一 phase 且时间区间重叠的锚点视为同一事务
        # （不同线程处理同一 HandleAbilityTransaction 会产生多行）
        deduped_anchors = []
        for _, arow in anchor_rows.iterrows():
            if deduped_anchors:
                last = deduped_anchors[-1]
                same_phase = last["phase"] == arow["phase"]
                last_end = last[time_field] + last.get("dur_ns", 0)
                overlaps = arow[time_field] < last_end
                if same_phase and overlaps:
                    continue  # 跳过重复事务
            deduped_anchors.append(arow)

        launch_instances: list[dict[str, dict[str, Any]]] = []
        if not deduped_anchors:
            # 无启动锚点：保留旧行为，用 pre_anchors 作为唯一实例
            if pre_anchors:
                launch_instances.append(pre_anchors)
        else:
            pre_phase_assigned = False
            for anchor_row in deduped_anchors:
                instance_anchors: dict[str, dict[str, Any]] = {}
                # 第一个实例拥有前置阶段
                if not pre_phase_assigned:
                    instance_anchors.update(pre_anchors)
                    pre_phase_assigned = True
                # 添加启动锚点
                anchor_phase = anchor_row["phase"]
                instance_anchors[anchor_phase] = _row_to_anchor(anchor_row, ipid, time_field, event_field)
                launch_instances.append(instance_anchors)

        group["launch_instances"] = launch_instances
        # 向后兼容：group["anchors"] 使用 first-instance-wins（旧格式）
        group["anchors"] = launch_instances[0] if launch_instances else {}
        group["df"] = group_df

    ctx.data = df
    ctx.meta["anchors"] = anchors
    ctx.meta["ipid_groups"] = ipid_groups
    ctx.meta["paired_processes"] = len(ipid_groups)
    # launch_instances 已写入 ipid_groups[ipid]["launch_instances"]
    return ctx


def _find_main_ipid(ipid_groups: dict[int | None, dict]) -> int | None:
    """选择主进程 ipid（按锚点优先级：ProcessCreate > AbilityLifecycle/ExtensionAbilityLifecycle > 锚点数最多）。"""
    main_ipid: int | None = None
    main_ipid_priority = -1
    for ipid, group in ipid_groups.items():
        group_anchors = group.get("anchors", {})
        priority = 0
        if "ProcessCreate" in group_anchors:
            priority = 3
        elif "AbilityLifecycle" in group_anchors or "ExtensionAbilityLifecycle" in group_anchors:
            priority = 2
        elif len(group_anchors) > 0:
            priority = 1
        if priority > main_ipid_priority:
            main_ipid_priority = priority
            main_ipid = ipid
    return main_ipid


def pre_anchors_for_ipid(ipid_groups: dict, ipid: int | None) -> int | None:
    """从 ipid_groups 中提取主线程 TID（进程级共享）。

    优先从 ProcessCreate 获取；温/热启动无 ProcessCreate 时，
    从 AbilityLifecycle / AbilityInit / ExtensionAbilityLifecycle 锚点 fallback。
    """
    # Fallback 优先级：AbilityLifecycle > AbilityInit > ExtensionAbilityLifecycle
    _LIFECYCLE_FALLBACK_PHASES = ("AbilityLifecycle", "AbilityInit", "ExtensionAbilityLifecycle")

    group = ipid_groups.get(ipid, {})
    # 优先从 launch_instances[0] 的 pre_anchors 获取
    launch_instances = group.get("launch_instances", [])
    if launch_instances:
        first_instance = launch_instances[0]
        pc = first_instance.get("ProcessCreate", {})
        if pc.get("tid") is not None:
            return pc["tid"]
        # Fallback: 温/热启动无 ProcessCreate，从 lifecycle 锚点获取主线程 tid
        for phase_name in _LIFECYCLE_FALLBACK_PHASES:
            anchor = first_instance.get(phase_name, {})
            if anchor.get("tid") is not None:
                return anchor["tid"]
    # 回退：从 group["anchors"] 获取
    anchors = group.get("anchors", {})
    pc = anchors.get("ProcessCreate", {})
    if pc.get("tid") is not None:
        return pc["tid"]
    # Fallback: 从 anchors 中的 lifecycle 锚点获取
    for phase_name in _LIFECYCLE_FALLBACK_PHASES:
        anchor = anchors.get(phase_name, {})
        if anchor.get("tid") is not None:
            return anchor["tid"]
    return None


# ---------------------------------------------------------------------------
# Layer 2: 计算阶段耗时（按 ipid 分组）
# ---------------------------------------------------------------------------
def _compute_phases_for_group(
    anchors: dict[str, dict[str, Any]],
    group_df: pd.DataFrame,
    app_main_tid: int | None = None,
    first_frame_upper_ns: int | None = None,
) -> tuple[list[dict[str, Any]], list[str]]:
    """为单个 ipid 组计算各阶段耗时。

    特殊处理：
    - AbilityLifecycle/ExtensionAbilityLifecycle: 从前一阶段结束到当前进程内首个 ReceiveVsync 的 ts
    - FirstFrame: 当前进程内首个 ReceiveVsync 事件的 ts → ts+dur（单事件区间）
    - 缺失的阶段标 missing=True
    - 阶段间 gap 被消除（前一阶段 end_ms → 下一阶段 start_ms）
    - 末阶段（FirstFrame）保持自己的 end_ms
    - AbilityLifecycle 与 ExtensionAbilityLifecycle 互斥（只取第一个出现的）

    Args:
        anchors: 该 ipid 组的锚点事件
        group_df: 该 ipid 组的 DataFrame（用于查找同进程内的 ReceiveVsync）
        app_main_tid: 主线程 TID（进程级共享，非首次实例无 ProcessCreate 时需传入）
        first_frame_upper_ns: FirstFrame 搜索上界（非最终实例防止跨实例 VSync 污染）
    """
    if not anchors:
        return [], []

    # 互斥处理：AbilityLifecycle 和 ExtensionAbilityLifecycle 只取第一个出现的
    lifecycle_phase = None
    lifecycle_anchor = None
    for phase_name in ("AbilityLifecycle", "ExtensionAbilityLifecycle"):
        if phase_name in anchors:
            lifecycle_phase = phase_name
            lifecycle_anchor = anchors[phase_name]
            break

    phases: list[dict[str, Any]] = []

    # ProcessCreate → AbilityLifecycle: 用锚点时间直接计算
    prev_end_ns: int | None = None

    for phase in LAUNCH_PHASES_ORDER[:-1]:  # 排除 FirstFrame，单独处理
        if phase not in anchors:
            phases.append({"name": phase, "missing": True})
            prev_end_ns = None
            continue

        anchor = anchors[phase]
        ts_ns = anchor["ts_ns"]
        dur_ns = anchor["dur_ns"]
        start_ms = ts_ns * US_TO_MS
        end_ms = (ts_ns + dur_ns) * US_TO_MS
        duration_ms = dur_ns * US_TO_MS

        if prev_end_ns is not None:
            # 相邻阶段之间有 gap（AbilityInit 结束后到 AbilityLifecycle 开始）
            gap_ms = (ts_ns - prev_end_ns) * US_TO_MS
            if gap_ms > 0:
                # 将 gap 累积到 lifecycle 阶段（AbilityLifecycle 或 ExtensionAbilityLifecycle）
                if phase == lifecycle_phase:
                    # lifecycle 阶段从前一阶段结束点开始
                    start_ms = prev_end_ns * US_TO_MS

        phases.append({
            "name": phase,
            "missing": False,
            "start_ms": start_ms,
            "end_ms": end_ms,
            "duration_ms": round(duration_ms, 2),
        })
        prev_end_ns = ts_ns + dur_ns

    # AbilityLifecycle: 结束点是 gap 后的第一个 ReceiveVsync
    # 已在上面通过 prev_end_ns 传递了起点
    # 现在需要找到 ReceiveVsync 作为终点

    # 找到 AbilityInit 的结束点（作为 lifecycle 阶段起点）
    if "AbilityInit" in anchors:
        app_init_start_ns = anchors["AbilityInit"]["ts_ns"] + anchors["AbilityInit"]["dur_ns"]
    elif lifecycle_anchor is not None:
        app_init_start_ns = lifecycle_anchor["ts_ns"]
    else:
        app_init_start_ns = None

    # 找 lifecycle 开始后的第一个 ReceiveVsync（冷/热启动统一）
    # FirstFrame = 该 ReceiveVsync 的 ts → ts+dur（单事件区间）
    # lifecycle.end_ms = FirstFrame.start_ms
    # 搜索范围：仅当前进程（group_df），找不到则 FirstFrame missing
    first_recv_ts_ns: int | None = None
    first_recv_dur_ns: int | None = None
    if lifecycle_anchor is not None:
        lifecycle_ts_ns = lifecycle_anchor["ts_ns"]
        recv_mask = (
            (group_df["raw_name"].str.contains("ReceiveVsync", na=False)) &
            (group_df["ts_ns"] > lifecycle_ts_ns)
        )
        if first_frame_upper_ns is not None:
            # 非最终实例：只搜索当前实例和下一个实例之间的 ReceiveVsync
            recv_mask = recv_mask & (group_df["ts_ns"] < first_frame_upper_ns)
        if app_main_tid is not None:
            recv_mask = recv_mask & (group_df["tid"] == app_main_tid)
        recv_events = group_df[recv_mask]
        if len(recv_events) > 0:
            first_recv_ts_ns = int(recv_events.iloc[0]["ts_ns"])
            first_recv_dur_ns = int(recv_events.iloc[0]["dur_ns"])

    # 处理 AbilityLifecycle 和 FirstFrame 阶段
    # FirstFrame = 当前进程内 AbilityLifecycle 后首个 ReceiveVsync 的 ts → ts+dur
    # AbilityLifecycle.end_ms = FirstFrame.start_ms
    if first_recv_ts_ns is not None and app_init_start_ns is not None:
        # AbilityLifecycle 结束于首个 ReceiveVsync 的 ts
        for p in phases:
            if p["name"] == lifecycle_phase and not p["missing"]:
                p["start_ms"] = app_init_start_ns * US_TO_MS
                p["end_ms"] = first_recv_ts_ns * US_TO_MS
                p["duration_ms"] = round((first_recv_ts_ns - app_init_start_ns) * US_TO_MS, 2)

        # FirstFrame: ts → ts+dur（同一 ReceiveVsync 事件）
        first_frame_phase = {
            "name": "FirstFrame",
            "missing": False,
            "start_ms": first_recv_ts_ns * US_TO_MS,
            "end_ms": (first_recv_ts_ns + first_recv_dur_ns) * US_TO_MS,
            "duration_ms": round(first_recv_dur_ns * US_TO_MS, 2),
        }
        phases.append(first_frame_phase)

    # 消除阶段间的 gap：非 missing 阶段的前一阶段 end_ms → 下一阶段 start_ms
    # 末阶段（FirstFrame）不参与 gap 消除，保持自己的 end_ms
    # 排除 missing=true 或 start_ms/end_ms 为 None 的阶段
    valid = [
        p for p in phases
        if not p.get("missing")
        and p.get("start_ms") is not None
        and p.get("end_ms") is not None
    ]
    valid_sorted = sorted(valid, key=lambda p: p["start_ms"])
    gap_warnings = []
    for i in range(len(valid_sorted) - 1):
        curr = valid_sorted[i]
        nxt = valid_sorted[i + 1]
        gap = nxt["start_ms"] - curr["end_ms"]
        if gap > 0:
            curr["end_ms"] = nxt["start_ms"]
            curr["duration_ms"] = round(curr["end_ms"] - curr["start_ms"], 2)
            if gap > 50:
                gap_warnings.append(
                    f"{curr['name']} absorbed {round(gap, 2)}ms of unattributed time"
                )

    return phases, gap_warnings


@register_operator("compute_phase_durations")
def compute_phase_durations(ctx: PreprocessContext) -> PreprocessContext:
    """基于锚点事件按 ipid 分组独立计算各阶段耗时。

    特殊处理：
    - AbilityLifecycle: 从前一阶段结束（ts+dur）到当前进程内首个 ReceiveVsync.ts
    - FirstFrame: 当前进程内首个 ReceiveVsync 的 ts → ts+dur（单事件区间）
    - 中间缺失的阶段标 missing=True
    - 阶段间 gap 被消除（前一阶段 end_ms → 下一阶段 start_ms）
    - 末阶段（FirstFrame）保持自己的 end_ms

    输出 ctx.meta["phases"]: [
        {"name": "...", "start_ms": float, "end_ms": float, "duration_ms": float, "missing": bool}, ...
    ]
    """
    ipid_groups = ctx.meta.get("ipid_groups", {})
    # 无 ipid 分组时回退到旧的 anchors 逻辑
    if not ipid_groups:
        anchors = ctx.meta.get("anchors", {})
        if not anchors:
            ctx.meta["phases"] = []
            ctx.meta["warning"] = "未匹配到任何启动阶段事件，请核对事件名常量"
            return ctx
        # 单进程：直接用全局 anchors 和 ctx.data
        phases, gap_warnings = _compute_phases_for_group(anchors, ctx.data)
        ctx.meta["phases"] = phases
        ctx.meta["ipid_gap_warnings"] = {None: gap_warnings} if gap_warnings else {}
        ctx.meta.pop("gap_warnings", None)  # Clean up old key

        # 计算总启动耗时：从首阶段到 FirstFrame.end_ms
        valid_phases = [p for p in phases if not p.get("missing")]
        total_ms = 0.0
        if valid_phases:
            first_phase = valid_phases[0]
            last_phase = valid_phases[-1]
            if first_phase.get("start_ms") is not None and last_phase.get("end_ms") is not None:
                total_ms = round(last_phase["end_ms"] - first_phase["start_ms"], 2)
        ctx.meta["total_launch_ms"] = total_ms
        return ctx

    # 按 ipid 分组独立计算（支持多启动实例）
    ipid_gap_warnings: dict[int | None, list[str]] = {}
    main_ipid = _find_main_ipid(ipid_groups)

    # 对每个 ipid 组独立计算阶段（支持 launch_instances）
    ipid_launch_phases: dict[int | None, list[list[dict[str, Any]]]] = {}
    for ipid, group in ipid_groups.items():
        launch_instances = group.get("launch_instances", [])
        group_df = group.get("df", pd.DataFrame())

        if not launch_instances:
            # 回退：使用旧 anchors 逻辑（单实例）
            group_anchors = group.get("anchors", {})
            if group_anchors:
                phases, gap_warnings = _compute_phases_for_group(
                    group_anchors, group_df,
                    app_main_tid=group_anchors.get("ProcessCreate", {}).get("tid"),
                )
                ipid_launch_phases[ipid] = [phases]
                if gap_warnings:
                    ipid_gap_warnings[ipid] = gap_warnings
            continue

        # 提取 app_main_tid（进程级，所有实例共享）
        app_main_tid = pre_anchors_for_ipid(ipid_groups, ipid)

        instance_phases_list = []
        for inst_idx, instance_anchors in enumerate(launch_instances):
            # 计算 FirstFrame 上界：下一个实例的 lifecycle anchor ts_ns
            first_frame_upper_ns = None
            if inst_idx + 1 < len(launch_instances):
                next_instance = launch_instances[inst_idx + 1]
                for phase_name in ("AbilityLifecycle", "ExtensionAbilityLifecycle"):
                    if phase_name in next_instance:
                        first_frame_upper_ns = next_instance[phase_name]["ts_ns"]
                        break

            phases, gap_warnings = _compute_phases_for_group(
                instance_anchors, group_df,
                app_main_tid=app_main_tid,
                first_frame_upper_ns=first_frame_upper_ns,
            )
            instance_phases_list.append(phases)
            if gap_warnings:
                ipid_gap_warnings.setdefault(ipid, []).extend(
                    [f"[launch#{inst_idx}] {w}" for w in gap_warnings]
                )
        ipid_launch_phases[ipid] = instance_phases_list

    # 向后兼容双写
    # ipid_phases: 每个ipid的首个实例phases（dict[int, list[dict]]，旧格式）
    ipid_phases_compat: dict[int | None, list[dict[str, Any]]] = {}
    for ipid, instances in ipid_launch_phases.items():
        if instances:
            ipid_phases_compat[ipid] = instances[0]

    ctx.meta["ipid_launch_phases"] = ipid_launch_phases
    ctx.meta["ipid_phases"] = ipid_phases_compat  # 向后兼容（旧键）
    main_ipid = _find_main_ipid(ipid_groups)
    ctx.meta["phases"] = ipid_phases_compat.get(main_ipid, [])  # 向后兼容
    ctx.meta["ipid_gap_warnings"] = ipid_gap_warnings
    ctx.meta.pop("gap_warnings", None)  # Clean up old key

    # 计算总启动耗时（从主进程的第一个阶段到最后阶段结束）
    total_ms = 0.0
    main_phases = ctx.meta.get("phases", [])
    if main_phases:
        valid_phases = [p for p in main_phases if not p.get("missing")]
        if valid_phases:
            # 总耗时 = 从第一个阶段的 start_ms 到最后一个阶段的 end_ms
            first_start = valid_phases[0].get("start_ms", 0)
            last_end = valid_phases[-1].get("end_ms", 0)
            total_ms = round(last_end - first_start, 2) if first_start and last_end else 0.0

    ctx.meta["total_launch_ms"] = total_ms
    return ctx
@register_operator("identify_bottleneck_phase")
def identify_bottleneck_phase(ctx: PreprocessContext) -> PreprocessContext:
    """挑出 duration_ms 最大且超过 threshold_ms 的阶段作为瓶颈。"""
    threshold = float(ctx.params.get("threshold_ms", 50.0))
    phases = ctx.meta.get("phases", [])
    candidates = [p for p in phases if not p.get("missing") and p.get("duration_ms", 0) > 0]
    if not candidates:
        ctx.meta["bottleneck"] = None
        return ctx

    bottleneck = max(candidates, key=lambda p: p.get("duration_ms", 0) or 0)
    duration = bottleneck.get("duration_ms", 0) or 0
    if duration < threshold:
        ctx.meta["bottleneck"] = None
        ctx.meta["bottleneck_threshold_ms"] = threshold
        return ctx

    ctx.meta["bottleneck"] = {
        "phase": bottleneck["name"],
        "duration_ms": duration,
        "threshold_ms": threshold,
    }
    return ctx


@register_operator("compute_completion_phase")
def compute_completion_phase(ctx: PreprocessContext) -> PreprocessContext:
    """基于 launch_duration 追加 Completion 阶段。

    Completion 阶段不参与瓶颈计算，仅用于表示启动"完成"的时间点。
    当 launch_duration > 0 且存在有效阶段时追加。
    """
    launch_duration = ctx.params.get("launch_duration")

    # 无 launch_duration 或 <= 0：不追加 Completion 阶段
    if launch_duration is None or launch_duration <= 0:
        return ctx

    ipid_phases = ctx.meta.get("ipid_phases", {})
    ipid_launch_phases = ctx.meta.get("ipid_launch_phases", {})
    ipid_groups = ctx.meta.get("ipid_groups", {})
    phases = ctx.meta.get("phases", [])

    if ipid_launch_phases:
        # 多实例模式：为每个实例追加 Completion
        for ipid, instance_phases_list in ipid_launch_phases.items():
            for instance_phases in instance_phases_list:
                completion = _make_completion_phase(instance_phases, launch_duration)
                if completion:
                    instance_phases.append(completion)
        # 同步旧键 ipid_phases（向后兼容：首个实例）
        for ipid, instances in ipid_launch_phases.items():
            if instances:
                ipid_phases[ipid] = instances[0]
        # 同步 ctx.meta["phases"]
        main_ipid = _find_main_ipid(ipid_groups)
        if main_ipid and main_ipid in ipid_launch_phases and ipid_launch_phases[main_ipid]:
            ctx.meta["phases"] = ipid_launch_phases[main_ipid][0]
    elif ipid_phases:
        # 旧路径（单实例）
        for ipid, ipid_phase_list in ipid_phases.items():
            completion = _make_completion_phase(ipid_phase_list, launch_duration)
            if completion:
                ipid_phase_list.append(completion)
        # 主进程 phases 同步更新
        main_ipid = None
        if phases:
            for ipid, ipid_phase_list in ipid_phases.items():
                if ipid_phase_list == phases:
                    main_ipid = ipid
                    break
            if main_ipid is None and ipid_phases:
                main_ipid = next(iter(ipid_phases.keys()))
        if main_ipid and main_ipid in ipid_phases:
            ctx.meta["phases"] = ipid_phases[main_ipid]
    else:
        # 单进程回退
        completion = _make_completion_phase(phases, launch_duration)
        if completion:
            phases.append(completion)

    return ctx


def _make_completion_phase(
    phases: list[dict[str, Any]],
    launch_duration: float,
) -> dict[str, Any] | None:
    """为给定阶段列表创建 Completion 阶段。

    launch_duration 表示用户报告的总启动时长（如"启动1s"→1000ms）。
    Completion 阶段从最后一个阶段（通常是 FirstFrame）结束开始，
    延伸 (launch_duration - 已有阶段总耗时) 的时间。
    当已有阶段总耗时 >= launch_duration 时不追加 Completion。

    Returns:
        Completion 阶段 dict 或 None（无可计算阶段或已超时时）
    """
    valid = [p for p in phases if not p.get("missing")
             and p.get("start_ms") is not None
             and p.get("end_ms") is not None]
    if not valid:
        return None

    window_start = valid[0]["start_ms"]
    natural_end = valid[-1]["end_ms"]
    existing_duration = natural_end - window_start

    # Completion = 用户报告总时长 - 已有阶段耗时
    remaining_ms = launch_duration - existing_duration
    if remaining_ms <= 0.01:
        # 已有阶段已达到或超过用户报告时长，不追加 Completion
        # （0.01ms 容差避免浮点精度误判）
        # 已有阶段已超过用户报告时长，不追加 Completion
        return None

    completion_end = natural_end + remaining_ms

    return {
        "name": "Completion",
        "missing": False,
        "start_ms": natural_end,
        "end_ms": completion_end,
        "duration_ms": round(remaining_ms, 2),
        "truncated": False,
    }


# ---------------------------------------------------------------------------
# Layer 3.5: 生成 thread_queries（扁平钻取数组）
# ---------------------------------------------------------------------------
# 丢帧分析风格：按 duration 排序，取 Top-N phases 生成 thread_queries
_REASON_TEMPLATES = {
    "ProcessCreate": {
        "culprit": "主进程创建耗时({duration_ms}ms)，占启动总时长{percent}%，通常由 AMS 控制",
        "main_thread": "主进程创建，耗时 {duration_ms}ms，占启动总时长 {percent}%",
    },
    "ApplicationInit": {
        "culprit": "ApplicationInit 耗时({duration_ms}ms)，占{percent}%，疑似 Application.onCreate 回调慢",
        "main_thread": "ApplicationInit 回调 {duration_ms}ms，占 {percent}%",
    },
    "AbilityInit": {
        "culprit": "AbilityInit 耗时({duration_ms}ms)，占{percent}%，瓶颈阶段",
        "main_thread": "AbilityInit 耗时 {duration_ms}ms，占 {percent}%",
    },
    "AbilityLifecycle": {
        "culprit": "AbilityLifecycle 耗时({duration_ms}ms)，占{percent}%，疑似应用初始化回调慢",
        "main_thread": "AbilityLifecycle 耗时 {duration_ms}ms，占 {percent}%",
    },
    "ExtensionAbilityLifecycle": {
        "culprit": "ExtensionAbilityLifecycle 耗时({duration_ms}ms)，占{percent}%，疑似 ExtensionAbility 初始化回调慢",
        "main_thread": "ExtensionAbilityLifecycle 耗时 {duration_ms}ms，占 {percent}%",
    },
    "FirstFrame": {
        "culprit": "FirstFrame 耗时({duration_ms}ms)，占{percent}%，首帧渲染慢",
        "main_thread": "首帧渲染锚点在主线程 ReceiveVsync，耗时 {duration_ms}ms，占 {percent}%",
    },
}

_SUGGESTION_TEMPLATES = {
    "ProcessCreate": "ProcessCreate 通常由 AMS 控制，非优化重点",
    "ApplicationInit": "检查 Application.onCreate 是否有同步 I/O / 大量初始化操作",
    "AbilityInit": "检查 Ability.onInit 回调，是否有过多同步操作或 I/O",
    "AbilityLifecycle": "检查 App.onCreate 或 Ability.onInit 是否有同步 I/O / 阻塞操作",
    "ExtensionAbilityLifecycle": "检查 ExtensionAbility.onCreate/onConnect 是否有同步 I/O / 阻塞操作",
    "FirstFrame": "首帧渲染耗时正常范围，重点关注 AbilityInit 和 AbilityLifecycle",
}


@register_operator("build_launch_thread_queries")
def build_launch_thread_queries(ctx: PreprocessContext) -> PreprocessContext:
    """从 phases 生成 thread_queries 扁平数组，按 duration 严格排序决定 priority。

    生成策略（多进程场景）：
    - 如果 ctx.meta["ipid_phases"] 存在，遍历每个 ipid 组
    - 从 ctx.meta["ipid_results"][ipid] 获取 app_name/tid/thread_name
    - 每个 ipid 组取 Top-3 phases by duration_ms
    - tag = {app_name}_{tid}（进程标识），不是阶段名
    - 合并所有 ipid 组的 thread_queries
    - 按总 duration 降序重排 priority（第1大=1，第2大=2，第3大=3）
    - 同时存储 per_process_thread_queries：每个 ipid 独立的 Top-3，per-process priority

    生成策略（单进程回退）：
    - 使用 ctx.meta["phases"] 和 ctx.meta["anchors"]
    - tag = {app_name}_{tid}
    - tid/thread_name 来自 anchors

    输出格式（6个字段）：
    - tag: 进程标识（{app_name}_{tid}）
    - tid: 主线程 tid
    - thread_name: 主线程名
    - start_ms: 阶段 start_ms
    - end_ms: 阶段 end_ms
    - priority: 1=最慢, 2=次慢, 3=第三慢
    """
    ipid_launch_phases = ctx.meta.get("ipid_launch_phases")
    ipid_launch_results = ctx.meta.get("ipid_launch_results", {})
    ipid_phases = ctx.meta.get("ipid_phases")
    ipid_results = ctx.meta.get("ipid_results", {})

    all_thread_queries = []
    per_process_tqs: dict[int | None, list[dict]] = {}

    if ipid_launch_phases:
        # 多实例场景：遍历每个 ipid 的每个启动实例
        for ipid, instance_phases_list in ipid_launch_phases.items():
            ipid_info_list = ipid_launch_results.get(ipid, [])

            for inst_idx, phases in enumerate(instance_phases_list):
                info = ipid_info_list[inst_idx] if inst_idx < len(ipid_info_list) else {}
                valid_phases = [p for p in phases if not p.get("missing") and p.get("duration_ms", 0) > 0]
                if not valid_phases:
                    continue

                sorted_phases = sorted(valid_phases, key=lambda p: p.get("duration_ms", 0) or 0, reverse=True)
                app_name = info.get("app_name", f"ipid_{ipid}")
                tid = info.get("app_main_tid")
                thread_name = info.get("app_main_thread_name")

                # 二次回退：detect_cold_or_warm 未解析时从 thread 表查询
                if tid is None and ipid is not None and ctx.sqlite_conn is not None:
                    fb_tid, fb_name = _fallback_query_main_thread(int(ipid), ctx.sqlite_conn)
                    if fb_tid is not None:
                        tid = fb_tid
                        thread_name = fb_name
                        if not app_name or app_name.startswith("ipid_"):
                            app_name = _resolve_app_name(thread_name)

                # 多实例时 tag 添加 _L{idx} 后缀避免碰撞
                tag_suffix = f"_L{inst_idx}" if len(instance_phases_list) > 1 else ""
                ipid_entries = []
                for phase in sorted_phases[:3]:
                    entry = {
                        "tag": f"{app_name}_{tid or 'unknown'}{tag_suffix}",
                        "tid": tid,
                        "thread_name": thread_name,
                        "start_ms": phase.get("start_ms"),
                        "end_ms": phase.get("end_ms"),
                        "priority": 0,  # 暂定0，后面统一重排
                        "phase": phase.get("name"),
                        "launch_instance_index": inst_idx,
                    }
                    all_thread_queries.append(entry)
                    ipid_entries.append(entry)

                per_process_tqs.setdefault(ipid, []).extend([{**e} for e in ipid_entries])
    elif ipid_phases:
        # 旧路径：单实例多进程
        for ipid, phases in ipid_phases.items():
            valid_phases = [p for p in phases if not p.get("missing") and p.get("duration_ms", 0) > 0]
            if not valid_phases:
                continue

            sorted_phases = sorted(valid_phases, key=lambda p: p.get("duration_ms", 0) or 0, reverse=True)
            ipid_info = ipid_results.get(ipid, {})
            app_name = ipid_info.get("app_name", f"ipid_{ipid}")
            tid = ipid_info.get("app_main_tid")
            thread_name = ipid_info.get("app_main_thread_name")

            # 二次回退：detect_cold_or_warm 未解析时从 thread 表查询
            if tid is None and ipid is not None and ctx.sqlite_conn is not None:
                fb_tid, fb_name = _fallback_query_main_thread(int(ipid), ctx.sqlite_conn)
                if fb_tid is not None:
                    tid = fb_tid
                    thread_name = fb_name
                    if not app_name or app_name.startswith("ipid_"):
                        app_name = _resolve_app_name(thread_name)

            ipid_entries = []
            for phase in sorted_phases[:3]:
                entry = {
                    "tag": f"{app_name}_{tid or 'unknown'}",
                    "tid": tid,
                    "thread_name": thread_name,
                    "start_ms": phase.get("start_ms"),
                    "end_ms": phase.get("end_ms"),
                    "priority": 0,
                    "phase": phase.get("name"),
                    "launch_instance_index": 0,
                }
                all_thread_queries.append(entry)
                ipid_entries.append(entry)

            per_process_tqs[ipid] = [{**e} for e in ipid_entries]
    else:
        # 单进程回退
        phases = ctx.meta.get("phases", [])
        anchors = ctx.meta.get("anchors", {})
        valid_phases = [p for p in phases if not p.get("missing") and p.get("duration_ms", 0) > 0]
        sorted_phases = sorted(valid_phases, key=lambda p: p.get("duration_ms", 0) or 0, reverse=True)

        # 获取 app_name/tid/thread_name
        app_name = ctx.meta.get("app_name", "unknown")
        app_main_tid = anchors.get("ProcessCreate", {}).get("tid")
        app_main_thread_name = anchors.get("ProcessCreate", {}).get("thread_name") if app_main_tid else None

        # 二次回退：ProcessCreate 缺失时从 thread 表查询
        if app_main_tid is None and ctx.sqlite_conn is not None:
            # 尝试从 meta 获取 ipid
            fallback_ipid = ctx.meta.get("anchors", {}).get("ProcessCreate", {}).get("ipid")
            if fallback_ipid is not None:
                fb_tid, fb_name = _fallback_query_main_thread(int(fallback_ipid), ctx.sqlite_conn)
                if fb_tid is not None:
                    app_main_tid = fb_tid
                    app_main_thread_name = fb_name
                    if not app_name or app_name == "unknown":
                        app_name = _resolve_app_name(app_main_thread_name)

        # Same pattern: collect in local list, deep-copy, per-process priority
        ipid_entries = []
        for phase in sorted_phases[:3]:
            entry = {
                "tag": f"{app_name}_{app_main_tid or 'unknown'}",
                "tid": app_main_tid,
                "thread_name": app_main_thread_name,
                "start_ms": phase.get("start_ms"),
                "end_ms": phase.get("end_ms"),
                "priority": 0,
                "phase": phase.get("name"),
                "launch_instance_index": 0,
            }
            all_thread_queries.append(entry)
            ipid_entries.append(entry)

        # None is an intentional sentinel key for single-process mode (no ipid grouping needed)
        per_process_tqs[None] = [{**e} for e in ipid_entries]

    # Per-process priority assignment: sort by duration within each process
    for ipid_key, entries in per_process_tqs.items():
        entries.sort(
            key=lambda x: (x.get("end_ms", 0) - x.get("start_ms", 0)),
            reverse=True,
        )
        for i, tq in enumerate(entries):
            tq["priority"] = i + 1  # 1=slowest per process, 2=next, 3=third

    # 按 duration_ms 降序统一重排 priority（第1大=1，第2大=2，第3大=3）
    all_thread_queries.sort(
        key=lambda x: (x.get("end_ms", 0) - x.get("start_ms", 0)),
        reverse=True,
    )
    for i, tq in enumerate(all_thread_queries[:3]):
        tq["priority"] = i + 1

    ctx.meta["thread_queries"] = all_thread_queries[:3]  # 最终只保留 Top-3
    ctx.meta["per_process_thread_queries"] = per_process_tqs
    return ctx


# ---------------------------------------------------------------------------
# Layer 4: 冷/热启动判定（支持按 ipid 分组独立判定）
# ---------------------------------------------------------------------------

def _detect_on_foreground_ipids(ctx: PreprocessContext) -> set[int]:
    """查询 callstack 表中包含 OnForeground 事件的 ipid 集合。

    使用 ctx.sqlite_conn 直接查询，绕过 pair_lifecycle_events 的
    EVENT_TO_PHASE 过滤（OnForeground 不在映射表中会被丢弃）。

    Note: SQLite LIKE 对 ASCII 大小写敏感，'%OnForeground%' 仅匹配
    PascalCase 命名（如 UIAbility::OnForeground），不匹配 onForeground。
    HarmonyOS trace 遵循 PascalCase 约定，因此无需 LOWER()。

    Returns:
        有 OnForeground 事件的 ipid 集合；sqlite_conn 不可用时返回空集
    """
    if ctx.sqlite_conn is None:
        log.warning("sqlite_conn unavailable for OnForeground detection, defaulting all to not visible")
        return set()

    start_ms = ctx.meta.get("start_ms", 0) or 0
    end_ms = ctx.meta.get("end_ms", 0) or 0

    try:
        on_fg_rows = pd.read_sql_query(
            "SELECT DISTINCT t.ipid FROM callstack c "
            "LEFT JOIN thread t ON c.callid = t.id "
            "WHERE c.name LIKE '%OnForeground%' "
            "AND c.ts BETWEEN ? * 1000000 AND ? * 1000000",
            ctx.sqlite_conn,
            params=(start_ms, end_ms),
        )
        return set(on_fg_rows["ipid"].dropna().astype(int))
    except Exception as e:
        log.warning("Failed to query OnForeground events, defaulting all to not visible, error=%s", e)
        return set()


def _fallback_query_main_thread(ipid: int, sqlite_conn) -> tuple[int | None, str | None]:
    """分层回退查询主线程 tid 和 name。

    策略：
    1. thread WHERE ipid=? AND is_main_thread=1（TraceStreamer DB 有此列）
    2. process WHERE ipid=? 获取进程名 → thread WHERE ipid=? AND name=?
    3. thread WHERE ipid=? ORDER BY id LIMIT 1（不可靠，仅最后手段）

    Returns: (tid, thread_name) 或 (None, None)
    """
    # Layer 1: is_main_thread 列
    try:
        row = pd.read_sql_query(
            "SELECT tid, name FROM thread WHERE ipid = ? AND is_main_thread = 1 LIMIT 1",
            sqlite_conn, params=(ipid,),
        )
        if not row.empty:
            return int(row["tid"].iloc[0]), str(row["name"].iloc[0])
    except Exception:
        pass  # is_main_thread 列可能不存在（旧版 DB / 测试 fixture）

    # Layer 2: process name → thread name 匹配
    try:
        proc_row = pd.read_sql_query(
            "SELECT name FROM process WHERE ipid = ? LIMIT 1",
            sqlite_conn, params=(ipid,),
        )
        if not proc_row.empty:
            proc_name = str(proc_row["name"].iloc[0]).strip()
            thread_row = pd.read_sql_query(
                "SELECT tid, name FROM thread WHERE ipid = ? AND name = ? LIMIT 1",
                sqlite_conn, params=(ipid, proc_name),
            )
            if not thread_row.empty:
                return int(thread_row["tid"].iloc[0]), str(thread_row["name"].iloc[0])
    except Exception as e:
        log.warning("fallback_query_main_thread layer2 failed for ipid=%s: %s", ipid, e)

    # Layer 3: ORDER BY id LIMIT 1（不可靠，最后手段）
    try:
        row = pd.read_sql_query(
            "SELECT tid, name FROM thread WHERE ipid = ? ORDER BY id LIMIT 1",
            sqlite_conn, params=(ipid,),
        )
        if not row.empty:
            tid = int(row["tid"].iloc[0])
            name = str(row["name"].iloc[0])
            log.warning("fallback_query_main_thread: using first-thread heuristic for ipid=%s (tid=%s, name=%s)", ipid, tid, name)
            return tid, name
    except Exception as e:
        log.warning("fallback_query_main_thread layer3 failed for ipid=%s: %s", ipid, e)

    return None, None


@register_operator("detect_cold_or_warm")
def detect_cold_or_warm(ctx: PreprocessContext) -> PreprocessContext:
    """判断启动类型（cold/warm/hot/unknown）:
    - cold: 有 AppSpawnExecuteSpawningHook 事件
    - warm: 无 AppSpawnExecuteSpawningHook，有 HandleLaunchAbility 事件
    - hot: 无 AppSpawnExecuteSpawningHook 且无 HandleLaunchAbility，有 HandleAbilityTransaction 事件
    - unknown: 无以上所有
    并设置 app_name / app_main_tid / app_main_thread_name

    支持 ipid 分组：
    - 优先从 ctx.meta["ipid_groups"] 获取数据（如果存在）
    - 每个 ipid 组独立判定启动类型
    - 存储每个 ipid 的分析结果到 ctx.meta["ipid_results"]
    - 回退逻辑：如果 ctx.meta["ipid_groups"] 为空，使用 ctx.meta["anchors"] 的旧逻辑
    """
    ipid_groups = ctx.meta.get("ipid_groups", {})
    ipid_results: dict[int | None, dict[str, Any]] = {}

    # 检测 OnForeground 事件（用于 is_user_visible 判定）
    on_foreground_ipids = _detect_on_foreground_ipids(ctx)

    # 如果有 ipid_groups，按每个 ipid 独立判定
    if ipid_groups:
        ipid_launch_results: dict[int | None, list[dict[str, Any]]] = {}
        for ipid, group in ipid_groups.items():
            launch_instances = group.get("launch_instances", [])

            # app 基础信息从 group["anchors"]["ProcessCreate"] 提取（所有实例共享）
            pc_anchor = group.get("anchors", {}).get("ProcessCreate", {})
            app_main_tid = pc_anchor.get("tid")
            app_main_thread_name = pc_anchor.get("thread_name")

            # 温/热启动时 ProcessCreate missing，回退查询 thread 表
            if app_main_tid is None and ipid is not None and ctx.sqlite_conn is not None:
                fb_tid, fb_name = _fallback_query_main_thread(int(ipid), ctx.sqlite_conn)
                if fb_tid is not None:
                    app_main_tid = fb_tid
                    app_main_thread_name = fb_name

            app_name = _resolve_app_name(app_main_thread_name)

            if not launch_instances:
                # 回退旧逻辑
                anchors = group.get("anchors", {})
                raw_names = [a["raw_name"] for a in anchors.values()]
                has_spawning_hook = any("AppSpawnExecuteSpawningHook" in n for n in raw_names)
                has_launch_ability = any("HandleLaunchAbility" in n for n in raw_names)
                has_ability_transaction = any("HandleAbilityTransaction" in n for n in raw_names)
                has_ext_transaction = any("HandleExtensionTransaction" in n for n in raw_names)

                launch_type = "cold" if has_spawning_hook else \
                              "warm" if has_launch_ability else \
                              "hot" if (has_ability_transaction or has_ext_transaction) else "unknown"

                ipid_launch_results[ipid] = [{
                    "launch_type": launch_type,
                    "app_name": app_name,
                    "app_main_tid": app_main_tid,
                    "app_main_thread_name": app_main_thread_name,
                    "is_user_visible": ipid in on_foreground_ipids,
                }]
                continue

            ipid_info_list = []
            for instance_anchors in launch_instances:
                raw_names = [a["raw_name"] for a in instance_anchors.values()]
                has_spawning_hook = any("AppSpawnExecuteSpawningHook" in n for n in raw_names)
                has_launch_ability = any("HandleLaunchAbility" in n for n in raw_names)
                has_ability_transaction = any("HandleAbilityTransaction" in n for n in raw_names)
                has_ext_transaction = any("HandleExtensionTransaction" in n for n in raw_names)

                launch_type = "cold" if has_spawning_hook else \
                              "warm" if has_launch_ability else \
                              "hot" if (has_ability_transaction or has_ext_transaction) else "unknown"

                ipid_info_list.append({
                    "launch_type": launch_type,
                    "app_name": app_name,
                    "app_main_tid": app_main_tid,
                    "app_main_thread_name": app_main_thread_name,
                    "is_user_visible": ipid in on_foreground_ipids,
                })

            ipid_launch_results[ipid] = ipid_info_list

        ctx.meta["ipid_launch_results"] = ipid_launch_results
        # 向后兼容：ipid_results 写入首个实例
        ipid_results_compat: dict[int | None, dict[str, Any]] = {}
        for ipid, info_list in ipid_launch_results.items():
            if info_list:
                ipid_results_compat[ipid] = info_list[0]
        ctx.meta["ipid_results"] = ipid_results_compat

        # 设置向后兼容的全局 meta（使用第一个 ipid 的结果）
        if ipid_results:
            first_result = next(iter(ipid_results.values()))
            ctx.meta["launch_type"] = first_result["launch_type"]
            ctx.meta["app_name"] = first_result["app_name"]
            ctx.meta["app_main_tid"] = first_result["app_main_tid"]
            ctx.meta["app_main_thread_name"] = first_result["app_main_thread_name"]
    else:
        # 回退逻辑：使用全局 anchors（旧逻辑）
        anchors = ctx.meta.get("anchors", {})
        raw_names = [a["raw_name"] for a in anchors.values()]

        has_spawning_hook = any("AppSpawnExecuteSpawningHook" in n for n in raw_names)
        has_launch_ability = any("HandleLaunchAbility" in n for n in raw_names)
        has_ability_transaction = any("HandleAbilityTransaction" in n for n in raw_names)
        has_ext_transaction = any("HandleExtensionTransaction" in n for n in raw_names)

        if has_spawning_hook:
            ctx.meta["launch_type"] = "cold"
        elif has_launch_ability:
            ctx.meta["launch_type"] = "warm"
        elif has_ability_transaction or has_ext_transaction:
            ctx.meta["launch_type"] = "hot"
        else:
            ctx.meta["launch_type"] = "unknown"

        # 从 ProcessCreate 锚点提取 app 基础信息
        pc_anchor = anchors.get("ProcessCreate", {})
        ctx.meta["app_main_tid"] = pc_anchor.get("tid")
        ctx.meta["app_main_thread_name"] = pc_anchor.get("thread_name")

        # 温/热启动时 ProcessCreate missing，回退查询 thread 表
        if ctx.meta["app_main_tid"] is None:
            anchor_ipid = pc_anchor.get("ipid")
            if anchor_ipid is not None and ctx.sqlite_conn is not None:
                fb_tid, fb_name = _fallback_query_main_thread(int(anchor_ipid), ctx.sqlite_conn)
                if fb_tid is not None:
                    ctx.meta["app_main_tid"] = fb_tid
                    ctx.meta["app_main_thread_name"] = fb_name

        ctx.meta["app_name"] = _resolve_app_name(ctx.meta["app_main_thread_name"])

        # 单进程回退：ipid 级 OnForeground 判定
        # 优先从 anchors 获取 ipid（pair_lifecycle_events 已写入），避免额外 SQL 查询
        anchor_ipid = pc_anchor.get("ipid")
        if anchor_ipid is not None:
            is_user_visible = int(anchor_ipid) in on_foreground_ipids
        else:
            # 回退：从 thread 表查询 ipid
            is_user_visible = False
            tid = pc_anchor.get("tid")
            if tid is not None and ctx.sqlite_conn is not None:
                try:
                    ipid_row = pd.read_sql_query(
                        "SELECT ipid FROM thread WHERE tid = ?",
                        ctx.sqlite_conn,
                        params=(tid,),
                    )
                    if not ipid_row.empty:
                        is_user_visible = int(ipid_row["ipid"].iloc[0]) in on_foreground_ipids
                except Exception as e:
                    log.warning("Failed to resolve ipid for OnForeground check, error=%s", e)
        ctx.meta["is_user_visible"] = is_user_visible

        # 兼容：设置 ipid_results 为空
        ctx.meta["ipid_results"] = {}

    return ctx


# ---------------------------------------------------------------------------
# Layer 5: 收敛输出
# ---------------------------------------------------------------------------
@register_operator("format_phase_summary")
def format_phase_summary(ctx: PreprocessContext) -> PreprocessContext:
    """收敛为 LLM 友好的 launch_process[] 数组结构（与丢帧分析对齐）。

    多进程模式：遍历 ipid_groups，每个 ipid 独立构建进程条目。
    单进程回退：构建单个元素的数组。
    最终输出 ctx.data = {"launch_process": [...]}
    """
    threshold_ms = float(ctx.meta.get("bottleneck_threshold_ms")
                          or ctx.params.get("threshold_ms", 50.0))
    ipid_groups = ctx.meta.get("ipid_groups", {})
    ipid_launch_phases = ctx.meta.get("ipid_launch_phases", {})
    ipid_launch_results = ctx.meta.get("ipid_launch_results", {})
    ipid_results = ctx.meta.get("ipid_results", {})
    ipid_phases = ctx.meta.get("ipid_phases", {})
    per_process_tqs = ctx.meta.get("per_process_thread_queries", {})

    # 预加载 ipid → process_name 映射（用于 proc_entry 的 process_name/package_name 字段）
    ipid_process_map: dict[int | None, str] = {}
    if ctx.sqlite_conn:
        try:
            rows = ctx.sqlite_conn.execute("""
                SELECT ipid, name FROM process
            """).fetchall()
            for ipid_val, proc_name in rows:
                if ipid_val is not None and proc_name is not None:
                    ipid_process_map[ipid_val] = proc_name.strip()
        except Exception as e:
            log.warning("format_phase_summary: ipid→process_name 查询失败: %s", e)

    launch_process = []

    if ipid_groups and (ipid_launch_results or ipid_results):
        # ---- 多进程模式（支持多实例） ----
        for ipid in ipid_groups:
            instance_phases_list = ipid_launch_phases.get(ipid, [])
            ipid_info_list = ipid_launch_results.get(ipid, [])

            # 如果没有 launch_phases（旧路径），回退到 ipid_phases
            if not instance_phases_list:
                phases_raw_single = ipid_phases.get(ipid, [])
                if phases_raw_single:
                    instance_phases_list = [phases_raw_single]
                ipid_info_single = ipid_results.get(ipid, {})
                if ipid_info_single:
                    ipid_info_list = [ipid_info_single]

            for inst_idx, phases_raw in enumerate(instance_phases_list):
                info = ipid_info_list[inst_idx] if inst_idx < len(ipid_info_list) else {}

                # 构建 phases 列表
                phases_out = []
                for p in phases_raw:
                    phase_entry = {
                        "name": p["name"],
                        "start_ms": p.get("start_ms"),
                        "end_ms": p.get("end_ms"),
                        "duration_ms": p.get("duration_ms"),
                        "missing": p.get("missing", False),
                    }
                    # Completion 阶段额外透传 truncated 字段
                    if p["name"] == "Completion" and "truncated" in p:
                        phase_entry["truncated"] = p["truncated"]
                    phases_out.append(phase_entry)

                # Filter out all-missing instances
                if all(p.get("missing", True) for p in phases_out):
                    log.debug("format_phase_summary: skipping ipid=%s launch#%s — all phases missing", ipid, inst_idx)
                    continue

                # total_launch_ms
                valid_phases = [p for p in phases_out if not p.get("missing")]
                total_launch_ms = 0.0
                if valid_phases:
                    first_start = valid_phases[0].get("start_ms") or 0
                    last_end = valid_phases[-1].get("end_ms") or 0
                    if first_start and last_end and last_end > first_start:
                        total_launch_ms = round(last_end - first_start, 2)

                # bottleneck
                candidates = [p for p in phases_out if not p.get("missing")
                              and (p.get("duration_ms") or 0) > 0]
                bottleneck = None
                if candidates:
                    worst = max(candidates, key=lambda p: p.get("duration_ms") or 0)
                    dur = worst.get("duration_ms") or 0
                    if dur >= threshold_ms:
                        bottleneck = {
                            "phase": worst["name"],
                            "duration_ms": dur,
                            "threshold_ms": threshold_ms,
                        }

                # thread_queries for this instance
                proc_tqs = per_process_tqs.get(ipid, [])
                if any("launch_instance_index" in tq for tq in proc_tqs):
                    # 新格式：按 launch_instance_index 过滤
                    proc_queries = _simplify_thread_queries(
                        [tq for tq in proc_tqs
                         if tq.get("launch_instance_index") == inst_idx]
                    )
                else:
                    # 旧格式：无 launch_instance_index，全部属于首个实例
                    if inst_idx == 0:
                        proc_queries = _simplify_thread_queries(proc_tqs)
                    else:
                        proc_queries = []

                _proc_name = ipid_process_map.get(ipid, "")
                proc_entry = {
                    "type": "launch_phase_summary",
                    "launch_type": info.get("launch_type", "unknown"),
                    "total_launch_ms": total_launch_ms,
                    "app_name": info.get("app_name"),
                    "app_main_tid": info.get("app_main_tid"),
                    "app_main_thread_name": info.get("app_main_thread_name"),
                    "ipid": ipid,
                    "is_user_visible": info.get("is_user_visible", False),
                    "launch_instance_index": inst_idx,
                    "phases": phases_out,
                    "bottleneck": bottleneck,
                    "thread_queries": proc_queries,
                    "process_name": _proc_name,
                    "package_name": get_process_name(_proc_name) if _proc_name else "",
                }
                # gap_warnings: 按 launch instance 索引过滤
                ipid_gap_warnings = ctx.meta.get("ipid_gap_warnings", {})
                if len(instance_phases_list) == 1:
                    # 单实例：gap_warnings 无前缀（旧格式）
                    proc_gap_warnings = ipid_gap_warnings.get(ipid, [])
                else:
                    # 多实例：按 [launch#idx] 前缀过滤
                    proc_gap_warnings = [
                        w.replace(f"[launch#{inst_idx}] ", "")
                        for w in ipid_gap_warnings.get(ipid, [])
                        if f"[launch#{inst_idx}]" in w
                    ]
                if proc_gap_warnings:
                    proc_entry["gap_warnings"] = proc_gap_warnings
                launch_process.append(proc_entry)
    else:
        # ---- 单进程回退 ----
        phases_raw = ctx.meta.get("phases", [])
        phases_out = []
        for p in phases_raw:
            phase_entry = {
                "name": p["name"],
                "start_ms": p.get("start_ms"),
                "end_ms": p.get("end_ms"),
                "duration_ms": p.get("duration_ms"),
                "missing": p.get("missing", False),
            }
            # Completion 阶段额外透传 truncated 字段
            if p["name"] == "Completion" and "truncated" in p:
                phase_entry["truncated"] = p["truncated"]
            phases_out.append(phase_entry)

        if all(p.get("missing", True) for p in phases_out):
            log.debug("format_phase_summary: skipping single process — all phases missing")
            ctx.data = {"launch_process": []}
            ctx.meta["visible_process_count"] = 0
            return ctx

        # total_launch_ms
        valid_phases = [p for p in phases_out if not p.get("missing")]
        total_launch_ms = ctx.meta.get("total_launch_ms", 0.0) or 0.0
        if not total_launch_ms and valid_phases:
            first_start = valid_phases[0].get("start_ms") or 0
            last_end = valid_phases[-1].get("end_ms") or 0
            if first_start and last_end and last_end > first_start:
                total_launch_ms = round(last_end - first_start, 2)

        # bottleneck
        bottleneck = None
        bn = ctx.meta.get("bottleneck")
        if bn and isinstance(bn, dict):
            bottleneck = bn
        else:
            candidates = [p for p in phases_out if not p.get("missing")
                          and (p.get("duration_ms") or 0) > 0]
            if candidates:
                worst = max(candidates, key=lambda p: p.get("duration_ms") or 0)
                dur = worst.get("duration_ms") or 0
                if dur >= threshold_ms:
                    bottleneck = {
                        "phase": worst["name"],
                        "duration_ms": dur,
                        "threshold_ms": threshold_ms,
                    }

        # thread_queries: per_process_tqs is always populated (single-process branch sets None key)
        first_ipid = next(iter(per_process_tqs), None)
        proc_queries = _simplify_thread_queries(per_process_tqs.get(first_ipid, []))

        _single_ipid = ctx.meta.get("anchors", {}).get("AbilityLifecycle", {}).get("ipid")
        _proc_name = ipid_process_map.get(_single_ipid, "") if _single_ipid is not None else ""
        proc_entry = {
            "type": "launch_phase_summary",
            "launch_type": ctx.meta.get("launch_type", "unknown"),
            "total_launch_ms": total_launch_ms,
            "app_name": ctx.meta.get("app_name"),
            "app_main_tid": ctx.meta.get("app_main_tid"),
            "app_main_thread_name": ctx.meta.get("app_main_thread_name"),
            "ipid": _single_ipid,
            "is_user_visible": ctx.meta.get("is_user_visible", False),
            "launch_instance_index": 0,
            "phases": phases_out,
            "bottleneck": bottleneck,
            "thread_queries": proc_queries,
            "process_name": _proc_name,
            "package_name": get_process_name(_proc_name) if _proc_name else "",
        }
        ipid_gap_warnings = ctx.meta.get("ipid_gap_warnings", {})
        proc_gap_warnings = ipid_gap_warnings.get(None, [])
        if proc_gap_warnings:
            proc_entry["gap_warnings"] = proc_gap_warnings
        launch_process.append(proc_entry)

    ctx.data = {"launch_process": launch_process}
    ctx.meta["visible_process_count"] = sum(1 for p in launch_process if p.get("is_user_visible"))
    return ctx


def _simplify_thread_queries(queries: list[dict]) -> list[dict]:
    """将 thread_queries 精简为 7 字段格式（含 phase）。"""
    return [_extract_6field_query(q) for q in queries]


def _extract_6field_query(q: dict) -> dict:
    """提取 thread_queries 的 8 字段：tag/tid/thread_name/start_ms/end_ms/priority/phase/launch_instance_index。"""
    result = {
        "tag": q.get("tag"),
        "tid": q.get("tid"),
        "thread_name": q.get("thread_name"),
        "start_ms": q.get("start_ms"),
        "end_ms": q.get("end_ms"),
        "priority": q.get("priority"),
        "phase": q.get("phase"),
    }
    if "launch_instance_index" in q:
        result["launch_instance_index"] = q["launch_instance_index"]
    return result
