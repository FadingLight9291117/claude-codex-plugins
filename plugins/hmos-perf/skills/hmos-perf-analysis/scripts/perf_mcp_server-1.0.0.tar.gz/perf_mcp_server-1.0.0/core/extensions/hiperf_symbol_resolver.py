"""Symbol resolver for hiperf .data files.

Builds an MMAP interval tree and per-file symbol tables directly from the
single .data binary using the hiperf_files_symbol feature section.
"""
from __future__ import annotations

import bisect
import logging
from dataclasses import dataclass, field
from typing import Optional

from core.extensions.hiperf_binary_parser import HiperfBinaryParser

log = logging.getLogger(__name__)

# Kernel address threshold: vaddr >= this is treated as kernel
KERNEL_ADDR_THRESHOLD = 0xFFFFFF0000000000

# The hiperf_files_symbol feature stores symbol offsets as raw file offsets.
# In the captured binaries the first executable segment is loaded at virtual
# address 0x1000 (minExecAddr == minExecAddrFileOffset + 0x1000), so an IP in
# a mapping with pgoff=0 must have 0x1000 added to (vaddr - start) before it
# can be looked up in the symbol table.  The MMAP pgoff values in this data
# set are byte offsets, not page counts, so they are added directly.
PAGE_OFFSET_ADJUSTMENT = 0x1000


@dataclass
class FilesInfo:
    """One mapped binary with its symbol table.

    Mirrors oss_pmutools FilesInfo: file_symbols is sorted [(offset, name)].
    """

    file_id: int
    path: str
    symbols: list[tuple[int, str]] = field(default_factory=list)
    _offsets: list[int] = field(init=False, repr=False, default_factory=list)

    def __post_init__(self) -> None:
        self._offsets = [s[0] for s in self.symbols]

    def lookup_symbol(self, offset: int) -> Optional[str]:
        """Binary search for the symbol containing the given offset.

        Returns the symbol whose start offset is the greatest <= offset.
        Returns None if offset is before the first symbol.
        """
        entry_offset = self.lookup_symbol_entry_offset(offset)
        if entry_offset is None:
            return None
        return self._symbol_at(entry_offset)

    def lookup_symbol_entry_offset(self, offset: int) -> Optional[int]:
        """Return the function-entry offset that contains `offset`.

        Uses bisect_right on the sorted symbol table to find the greatest
        start offset <= `offset`.  This is the start of the containing
        function and is the value that should be stored in `dim_symbol`.
        """
        if not self.symbols:
            return None
        idx = bisect.bisect_right(self._offsets, offset) - 1
        if idx < 0:
            return None
        return self.symbols[idx][0]

    def _symbol_at(self, entry_offset: int) -> Optional[str]:
        """Return the symbol name whose start offset equals entry_offset."""
        idx = bisect.bisect_left(self._offsets, entry_offset)
        if idx < len(self.symbols) and self.symbols[idx][0] == entry_offset:
            return self.symbols[idx][1]
        return None


@dataclass
class MmapEntry:
    """One MMAP interval entry.

    Attributes:
        start: virtual address start (inclusive)
        end: virtual address end (exclusive)
        pid: process id
        pgoff: file page offset (pgoff=-1 for synthetic kernel MMAP)
        file_info: resolved FilesInfo for this mapping
    """

    start: int
    end: int
    pid: int
    pgoff: int
    file_info: FilesInfo


class MmapIntervalTree:
    """Interval tree for MMAP records with per-pid sorted index.

    Entries are grouped by pid, each group sorted by start address.
    Lookup uses binary search within the pid group, plus a max-end prefix
    array so a backward scan can stop as soon as no earlier entry can
    contain the address (O(log n + overlaps) instead of O(n) on miss).

    Pid filtering: exact pid match takes priority over pid=0 wildcard.
    pid=0 is treated as wildcard (matches any pid, used for kernel mappings).
    """

    def __init__(self) -> None:
        self._pid_entries: dict[int, list[MmapEntry]] = {}
        self._pid_starts: dict[int, list[int]] = {}
        self._pid_max_end: dict[int, list[int]] = {}
        self._total: int = 0

    def add(
        self,
        start: int,
        end: int,
        pid: int,
        pgoff: int,
        file_info: FilesInfo,
    ) -> None:
        entry = MmapEntry(
            start=start, end=end, pid=pid, pgoff=pgoff, file_info=file_info
        )
        if pid not in self._pid_entries:
            self._pid_entries[pid] = []
            self._pid_starts[pid] = []
        self._pid_entries[pid].append(entry)
        self._pid_starts[pid].append(start)
        self._total += 1

    def _finalize(self) -> None:
        """Sort each pid group by start address and build max-end prefix."""
        for pid, entries in self._pid_entries.items():
            entries.sort(key=lambda e: e.start)
            self._pid_starts[pid] = [e.start for e in entries]
            max_end: list[int] = []
            cur = 0
            for e in entries:
                if e.end > cur:
                    cur = e.end
                max_end.append(cur)
            self._pid_max_end[pid] = max_end

    def lookup(self, addr: int, pid: int) -> Optional[MmapEntry]:
        """Find the MmapEntry containing addr for the given pid.

        Priority: exact pid match first, then pid=0 (kernel wildcard).
        """
        if pid != 0 and pid in self._pid_entries:
            result = self._lookup_in_pid(addr, pid)
            if result is not None:
                return result

        if pid != 0 and 0 in self._pid_entries:
            return self._lookup_in_pid(addr, 0)

        if pid == 0 and 0 in self._pid_entries:
            return self._lookup_in_pid(addr, 0)

        return None

    def _lookup_in_pid(self, addr: int, pid: int) -> Optional[MmapEntry]:
        """Binary search within a single pid group.

        Scans backward from the bisect position over entries that may
        overlap `addr`.  The max-end prefix lets the scan stop as soon as
        no earlier entry can contain `addr`, which turns a miss from
        O(pid mappings) into O(overlaps).
        """
        starts = self._pid_starts.get(pid)
        entries = self._pid_entries.get(pid)
        max_end = self._pid_max_end.get(pid)
        if not starts or not entries or not max_end:
            return None

        idx = bisect.bisect_right(starts, addr) - 1
        if idx < 0:
            return None

        i = idx
        while i >= 0 and max_end[i] > addr:
            entry = entries[i]
            # entry.start <= addr is guaranteed for i <= idx (sorted starts).
            if entry.end > addr:
                return entry
            i -= 1
        return None

    def __len__(self) -> int:
        return self._total


class SymbolResolver:
    """Resolves virtual addresses to (symbol, binary_path, file_offset).

    Built once from .data binary; used by hiperf_extender to populate
    brbe_sample binary / offset / symbol columns.

    Results are memoized per (pid, addr) — branch-heavy workloads hit
    the same addresses many times, and unresolved results are cached
    too since misses dominate lookup cost on sparse-MMAP data.

    Usage:
        parser = HiperfBinaryParser(data_path)
        resolver = SymbolResolver(parser)
        resolver.build()
        symbol, binary, file_offset = resolver.resolve(vaddr, pid)
    """

    def __init__(self, binary_parser: HiperfBinaryParser) -> None:
        self.parser = binary_parser
        self._mmap_tree = MmapIntervalTree()
        self._files_map: dict[str, FilesInfo] = {}
        self._built = False
        self._kernel_mmap_injected = False
        self._resolve_cache: dict[
            tuple[int, int],
            tuple[Optional[str], Optional[str], Optional[int], Optional[int]],
        ] = {}
        self.cache_hits = 0
        self.cache_misses = 0

    def build(self) -> None:
        """Build the resolver from MMAP records and symbol tables.

        Steps:
        1. Parse symbol tables from the binary feature section
           (hiperf_files_symbol, feature 192).
        2. Parse MMAP records from .data binary.
        3. Build files_map: file_path -> FilesInfo (with symbols).
        4. Build IntervalTree: vaddr range -> (pgoff, FilesInfo).
        5. When sysmgr.elf MMAP is found, inject synthetic kernel MMAP.
        """
        log.info("symbol_resolver_build_start")

        # 1. Parse symbol tables from binary.
        symbol_tables = self.parser.parse_files_symbol_from_binary()
        log.info(
            "symbol_tables_parsed_from_binary",
            extra={"file_count": len(symbol_tables)},
        )

        # 2. Parse MMAP records from binary
        mmap_records = self.parser.parse_mmap_records()
        log.info("mmap_records_parsed", extra={"count": len(mmap_records)})

        # 3. Build files_map: file_path -> FilesInfo
        next_file_id = 1
        for file_path, sym_table in symbol_tables.items():
            self._files_map[file_path] = FilesInfo(
                file_id=next_file_id,
                path=file_path,
                symbols=sym_table.symbols,
            )
            next_file_id += 1

        for rec in mmap_records:
            if rec.filename and rec.filename not in self._files_map:
                self._files_map[rec.filename] = FilesInfo(
                    file_id=next_file_id,
                    path=rec.filename,
                    symbols=[],
                )
                next_file_id += 1

        # 4. Build IntervalTree from MMAP records
        sysmgr_max_end = 0
        for rec in mmap_records:
            if (
                rec.filename == "[kernel.kallsyms]"
                and rec.pid == 0
                and rec.start == 0
                and rec.end == 0xFFFFFFFFFFFFFFFF
            ):
                continue

            fi = self._files_map.get(rec.filename)
            if fi is None:
                fi = FilesInfo(
                    file_id=next_file_id, path=rec.filename, symbols=[]
                )
                self._files_map[rec.filename] = fi
                next_file_id += 1

            self._mmap_tree.add(
                start=rec.start,
                end=rec.end,
                pid=rec.pid,
                pgoff=rec.pgoff,
                file_info=fi,
            )

            if "sysmgr.elf" in rec.filename:
                if rec.end > sysmgr_max_end:
                    sysmgr_max_end = rec.end

        # 5. Inject synthetic kernel MMAP when sysmgr.elf is found
        if sysmgr_max_end > 0:
            kernel_path = "[kernel.kallsyms]"
            if kernel_path not in self._files_map:
                self._files_map[kernel_path] = FilesInfo(
                    file_id=next_file_id,
                    path=kernel_path,
                    symbols=[],
                )
            kernel_fi = self._files_map[kernel_path]
            self._mmap_tree.add(
                start=sysmgr_max_end + 1,
                end=0xFFFFFFFFFFFFFFFF,
                pid=0,
                pgoff=-1,
                file_info=kernel_fi,
            )
            self._kernel_mmap_injected = True
            log.info(
                "kernel_mmap_injected",
                extra={
                    "start": hex(sysmgr_max_end + 1),
                    "end": hex(0xFFFFFFFFFFFFFFFF),
                },
            )

        self._mmap_tree._finalize()
        self._built = True
        log.info(
            "symbol_resolver_build_complete",
            extra={
                "mmap_count": len(self._mmap_tree),
                "file_count": len(self._files_map),
                "kernel_mmap_injected": self._kernel_mmap_injected,
            },
        )

    def known_binaries(self) -> list[str]:
        """Return all binary paths seen in MMAP and symbol tables."""
        return list(self._files_map.keys())

    def resolve(
        self, addr: int, pid: int
    ) -> tuple[Optional[str], Optional[str], Optional[int]]:
        """Resolve a virtual address to (symbol, binary_path, file_offset).

        Returns:
            (symbol_name, binary_path, file_offset) or (None, None, None)
            if unresolved. symbol_name may be None even when binary_path
            is known (no symbol table loaded for that file).
        """
        symbol, binary, file_offset, _ = self.resolve_symbol_entry(addr, pid)
        return symbol, binary, file_offset

    def resolve_symbol_entry(
        self, addr: int, pid: int
    ) -> tuple[Optional[str], Optional[str], Optional[int], Optional[int]]:
        """Resolve a virtual address including the symbol entry offset.

        Results are memoized per (pid, addr) — branch-heavy workloads hit
        the same addresses many times, and unresolved results are cached
        too since misses dominate lookup cost on sparse-MMAP data.

        Returns:
            (symbol_name, binary_path, file_offset, symbol_entry_offset) or
            (None, None, None, None) if unresolved.  symbol_entry_offset is
            the function-entry offset (bisect result) and is what callers
            should use as `dim_symbol.offset`.
        """
        if not self._built:
            return None, None, None, None

        vaddr = addr & 0xFFFFFFFFFFFFFFFF
        key = (pid, vaddr)
        cached = self._resolve_cache.get(key)
        if cached is not None:
            self.cache_hits += 1
            return cached
        self.cache_misses += 1

        def _file_offset_and_entry(
            entry: MmapEntry,
        ) -> tuple[Optional[int], Optional[int]]:
            if entry.pgoff < 0:
                file_offset = vaddr
            else:
                file_offset = (
                    vaddr - entry.start + entry.pgoff + PAGE_OFFSET_ADJUSTMENT
                )
            entry_offset = entry.file_info.lookup_symbol_entry_offset(file_offset)
            return file_offset, entry_offset

        result: tuple[Optional[str], Optional[str], Optional[int], Optional[int]]
        entry = self._mmap_tree.lookup(vaddr, pid)
        if entry is None:
            result = (None, None, None, None)
        else:
            file_offset, entry_offset = _file_offset_and_entry(entry)
            symbol = entry.file_info.lookup_symbol(file_offset)
            result = (symbol, entry.file_info.path, file_offset, entry_offset)

        self._resolve_cache[key] = result
        return result

    def cache_stats(self) -> dict[str, int]:
        """Return resolution-cache counters for diagnostics."""
        return {
            "size": len(self._resolve_cache),
            "hits": self.cache_hits,
            "misses": self.cache_misses,
        }

    def resolve_simple(
        self, addr: int, pid: int
    ) -> tuple[Optional[str], Optional[str]]:
        """Backward-compatible resolve returning (symbol, binary_path)."""
        symbol, binary, _ = self.resolve(addr, pid)
        return symbol, binary
