<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-06-11 -->

# core/rendering — Rendering Pipeline Data Models

## Purpose
Pure data classes (Pydantic-style) that define the rendering pipeline detection type system. These models mirror SmartPerfetto's TypeScript types and are consumed by core/rendering_pipeline.py. Defines pipeline threads, key slices, detection signals, scoring rules, filter configurations, pin instructions, and educational content structures.

## Key Files

| File | Description |
|------|-------------|
| `models.py` | All data classes: PipelineThreadRole, PipelineKeySlice, SmartFilterConfig, PinInstruction, TeachingContent, PipelineMeta (id, display_name, family, four_features), CommonIssue, DetectionSignal, ScoringSignal, DetectionRules, PipelineDefinition, PipelineIndex. |

## For AI Agents

### Working In This Directory
- These are pure data models — no logic, no SQL, no side effects.
- When adding new fields, ensure they match the YAML structure in config/pipelines/.
- Field names should be consistent with SmartPerfetto's TypeScript naming conventions.
- Update config/pipelines/ YAML files if adding required fields to PipelineDefinition.

### Testing Requirements
- Models should serialize/deserialize cleanly from YAML.
- Verify with: `python -c "from core.rendering.models import PipelineDefinition; ..."`

### Common Patterns
- Use `@dataclass` with type hints for all fields.
- Optional fields use `Optional[Type]` with `None` defaults.
- List fields use `field(default_factory=list)`.

## Dependencies

### Internal
- `core/rendering_pipeline.py` — The engine that consumes these models
- `config/pipelines/` — YAML definitions that deserialize into these models

### External
- `dataclasses` (stdlib) — Data class definitions
- `typing` (stdlib) — Type hints
