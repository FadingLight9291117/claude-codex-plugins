"""CPU 频点 × idle state 二维分布预处理算子。

包含算子（通过 ``@register_operator`` 注册）：

- ``cpu_state_freq_residency``：按 cpuid 分组扫描线，求 freq 区间 ∩ idle state
  区间的二维分布，按 (cluster, freq, state) 聚合，服务 ``cpu_state_freq`` 指标。

输入 ``ctx.data`` 为 pandas DataFrame，列要求：
- ``cpuid`` (int)：逻辑 CPU ID
- ``ts_start`` (int, ns)：区间起点
- ``ts_end``   (int, ns)：区间终点（SQL 层已用 trace_range.end_ts 填充 NULL dur）
- ``state`` (int, NULL for freq rows)：idle state id（0=Running, 1/2/3=C1/C2/C3）
- ``freq`` (int, NULL for idle rows)：频点值（MHz，SQL 层已从 kHz /1000 转换）
- ``data_type`` (str)：'idle' 或 'freq'

输出：``ctx.data = {"summary": {"cluster_stats": {...}}, "data": [...]}``。

设计依据：``docs/superpowers/specs/2026-07-13-cpu-state-freq-design.md``。
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import pandas as pd

from core.observability import get_module_logger

from .base import PreprocessContext, PreprocessError, register_operator

__all__ = ["cpu_state_freq_residency"]

log = get_module_logger(__name__)


# ---------------------------------------------------------------------------
# 单核扫描线
# ---------------------------------------------------------------------------

def _scan_one_core(
    cpuid: int,
    df_freq: pd.DataFrame,
    df_idle: pd.DataFrame,
) -> List[Dict[str, Any]]:
    """O((n+m) log(n+m)) 扫描线，输出 (cpuid, freq, state, ts_start, ts_end) 段。

    事件类型：
    - 'F' / 'E'：频点区间进入 / 退出（携带 freq 值）
    - 'I' / 'EI'：idle state 区间进入 / 退出（携带 state 值）

    排序规则：同 ts 时退出事件(E/EI)优先于进入事件(F/I)，避免零宽重叠段。

    状态维护：
    - ``current_freq``：None 表示当前无频点覆盖（两段 freq 间空隙，不计入输出）
    - ``current_state``：默认 0 (Running)；进入 idle 时更新为 1/2/3；退出 idle 时回到 0

    设计决策：
    - idle 期间保留进入 idle 前的 ``current_freq``，输出 (freq, state=1/2/3) 段。
      诊断价值：识别"高频点下进入浅 idle"等调度策略。
    - 两段 freq 区间之间的空隙（current_freq=None）不计入输出，避免 freq=null 虚假记录。
    """
    events: List[tuple] = []

    if not df_freq.empty:
        freq_vals = df_freq[["ts_start", "ts_end", "freq"]].values
        for ts_start, ts_end, freq in freq_vals:
            if ts_end > ts_start:
                events.append((int(ts_start), "F", int(freq)))
                events.append((int(ts_end), "E", int(freq)))

    if not df_idle.empty:
        idle_vals = df_idle[["ts_start", "ts_end", "state"]].values
        for ts_start, ts_end, state in idle_vals:
            if ts_end > ts_start:
                events.append((int(ts_start), "I", int(state)))
                events.append((int(ts_end), "EI", int(state)))

    if not events:
        return []

    def event_key(x: tuple) -> tuple:
        ts, typ = x[0], x[1]
        order = {"E": 0, "EI": 0, "F": 1, "I": 1}
        return (ts, order.get(typ, 2))

    events.sort(key=event_key)

    current_freq: Optional[int] = None
    current_state: int = 0
    last_ts: Optional[int] = None
    intervals: List[Dict[str, Any]] = []

    for ts, typ, val in events:
        if last_ts is not None and current_freq is not None:
            dur = ts - last_ts
            if dur > 0:
                intervals.append({
                    "cpuid": cpuid,
                    "freq": int(current_freq),
                    "state": int(current_state),
                    "ts_start": int(last_ts),
                    "ts_end": int(ts),
                })

        if typ == "F":
            current_freq = val
        elif typ == "E":
            current_freq = None
        elif typ == "I":
            current_state = val
        elif typ == "EI":
            current_state = 0

        last_ts = ts

    return intervals


# ---------------------------------------------------------------------------
# 聚合
# ---------------------------------------------------------------------------

def _aggregate_data(intervals: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """按 (cluster, freq, state) 聚合 duration_ms，按 (cluster, freq, state) 排序。"""
    agg: Dict[tuple, Dict[str, Any]] = {}
    for iv in intervals:
        key = (iv["cluster"], iv["freq"], iv["state"])
        if key not in agg:
            agg[key] = {
                "cluster": iv["cluster"],
                "freq": iv["freq"],
                "state": iv["state"],
                "duration_ms": 0.0,
            }
        agg[key]["duration_ms"] += (iv["ts_end"] - iv["ts_start"]) / 1_000_000.0

    # 四舍五入到 3 位小数（与 smt_ops 风格一致）
    for v in agg.values():
        v["duration_ms"] = round(v["duration_ms"], 3)

    return sorted(agg.values(), key=lambda x: (x["cluster"], x["freq"], x["state"]))


def _aggregate_cluster_stats(
    intervals: List[Dict[str, Any]],
) -> Dict[str, Dict[str, Any]]:
    """按 cluster 聚合：total_duration_ms / avg_freq_mhz / duration_ratio / state 分布。"""
    per_cluster: Dict[str, Dict[str, Any]] = {}
    for iv in intervals:
        cl = iv["cluster"]
        if cl not in per_cluster:
            per_cluster[cl] = {
                "total_duration_ms": 0.0,
                "weighted_freq_sum": 0.0,
                "state_duration_ms": {},
            }
        dur_ms = (iv["ts_end"] - iv["ts_start"]) / 1_000_000.0
        per_cluster[cl]["total_duration_ms"] += dur_ms
        per_cluster[cl]["weighted_freq_sum"] += dur_ms * iv["freq"]
        state_key = str(iv["state"])
        per_cluster[cl]["state_duration_ms"][state_key] = (
            per_cluster[cl]["state_duration_ms"].get(state_key, 0.0) + dur_ms
        )

    total_all = sum(s["total_duration_ms"] for s in per_cluster.values())
    result: Dict[str, Dict[str, Any]] = {}
    for cl, s in per_cluster.items():
        total = s["total_duration_ms"]
        avg_freq = s["weighted_freq_sum"] / total if total > 0 else 0
        state_dur = {k: round(v, 3) for k, v in sorted(s["state_duration_ms"].items())}
        state_ratio = {
            k: round(v / total * 100, 1) if total > 0 else 0
            for k, v in sorted(s["state_duration_ms"].items())
        }
        result[cl] = {
            "total_duration_ms": round(total, 3),
            "avg_freq_mhz": round(avg_freq, 1),
            "duration_ratio": round(total / total_all * 100, 1) if total_all > 0 else 0,
            "state_duration_ms": state_dur,
            "state_ratio": state_ratio,
        }

    return dict(sorted(result.items()))


# ---------------------------------------------------------------------------
# 主算子
# ---------------------------------------------------------------------------

@register_operator("cpu_state_freq_residency")
def cpu_state_freq_residency(ctx: PreprocessContext) -> PreprocessContext:
    """计算 (cluster, freq, state) 二维分布。

    流程：
    1. 通过 chip_config 匹配芯片，构建 cpuid → cluster 映射
    2. 按 cpuid 分组，每核独立扫描线
    3. 按 (cluster, freq, state) 聚合 → data
    4. 按 cluster 聚合 → summary.cluster_stats
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame):
        raise PreprocessError("cpu_state_freq_residency: ctx.data 期望为 DataFrame")

    required_cols = {"cpuid", "ts_start", "ts_end", "state", "freq", "data_type"}
    missing = required_cols - set(df.columns)
    if missing:
        raise PreprocessError(
            f"cpu_state_freq_residency: 缺少必要列: {sorted(missing)}"
        )

    # 空输入处理
    if df.empty:
        ctx.data = {"summary": {"cluster_stats": {}}, "data": []}
        return ctx

    cluster_filter = ctx.params.get("cluster")

    cache = ctx.trace_cache
    if cache is None:
        raise PreprocessError("cpu_state_freq_residency: trace_cache 不可用")
    chip_config = cache.chip_config()
    if not chip_config:
        raise PreprocessError("无法获取芯片配置")
    actual_chip_model = chip_config.get("chip_model")
    log.info(
        "cpu_state_freq_residency: chip=%s, cluster=%s",
        actual_chip_model, cluster_filter,
    )

    # 1. cpuid → cluster 映射
    cpuid_cluster_map: Dict[int, Optional[str]] = {}
    for cpuid in sorted(df["cpuid"].unique()):
        cpuid_cluster_map[cpuid] = cache.cluster_of(int(cpuid))

    if cluster_filter:
        filtered_cpuid_list = [
            c for c, cl in cpuid_cluster_map.items() if cl == cluster_filter
        ]
    else:
        filtered_cpuid_list = sorted(cpuid_cluster_map.keys())

    # 2. 预分离 freq / idle 数据，按 cpuid 索引
    df = df.copy()
    df["ts_start"] = df["ts_start"].astype("int64")
    df["ts_end"] = df["ts_end"].astype("int64")
    df = df[df["ts_end"] > df["ts_start"]]

    df_freq = df[df["data_type"] == "freq"]
    df_idle = df[df["data_type"] == "idle"]

    # 3. 每 cpuid 独立扫描线
    all_intervals: List[Dict[str, Any]] = []
    for cpuid in filtered_cpuid_list:
        df_freq_core = df_freq[df_freq["cpuid"] == cpuid]
        df_idle_core = df_idle[df_idle["cpuid"] == cpuid]
        if df_freq_core.empty:
            continue  # 无频点数据则跳过（与 smt_ops 行为一致）

        intervals = _scan_one_core(int(cpuid), df_freq_core, df_idle_core)
        cluster = cpuid_cluster_map.get(cpuid, "unknown")
        for iv in intervals:
            iv["cluster"] = cluster
        all_intervals.extend(intervals)

    # 4. 聚合输出
    data = _aggregate_data(all_intervals)
    cluster_stats = _aggregate_cluster_stats(all_intervals)

    ctx.data = {"summary": {"cluster_stats": cluster_stats}, "data": data}
    ctx.meta["chip_model"] = actual_chip_model
    log.debug("cpu_state_freq_residency 完成: %d 条 data 记录", len(data))
    return ctx
