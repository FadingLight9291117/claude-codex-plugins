"""丢帧分析算子：从渲染帧链路提取丢帧区间和线程查询信息。

设计参考 docs/frame_drop_analysis_design.md v3.0

两个核心算子：
- build_drop_ranges: jank 帧 → drop_ranges[]（每帧独立，含 culprit）
- build_thread_queries: drop_ranges[] → thread_queries[]（扁平数组，供 step5 精确查询）
"""
from __future__ import annotations

from core.observability import get_module_logger
from typing import Any, Dict, List, Optional

from .base import PreprocessContext, register_operator

log = get_module_logger(__name__)


# ---------------------------------------------------------------------------
# 工具函数
# ---------------------------------------------------------------------------

def _compute_severity(skipped_ms: int) -> str:
    """根据跳帧时长计算严重等级。"""
    if skipped_ms < 50:
        return "light"
    elif skipped_ms < 200:
        return "medium"
    return "severe"


def _find_culprit(
    frame: Dict[str, Any],
    prev_frame: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """从帧数据中找出耗时增量最大的阶段作为 culprit。

    - 有前一帧：比较当前帧各阶段相对前一帧的增量，取增量最大者
    - 无前一帧：直接看各阶段总量，取绝对值最大者
    阶段: ui_dur_ns, rs_dur_ns, rs_render_dur_ns, hwc_dur_ns, present_dur_ns
    """
    stage_keys = ["ui", "rs", "rs_render", "hwc", "present"]

    # 当前帧各阶段耗时
    curr_dur = {k: frame.get(f"{k}_dur_ns") or 0 for k in stage_keys}

    if prev_frame:
        prev_dur = {k: prev_frame.get(f"{k}_dur_ns") or 0 for k in stage_keys}
        # 有前一帧 → 看增量
        delta_dur = {k: curr_dur[k] - prev_dur[k] for k in stage_keys}
        max_stage = max(delta_dur, key=delta_dur.get)
        max_delta = delta_dur[max_stage]
        max_delta_ms = max_delta / 1_000_000
        reason_prefix = "相对前一帧增量"
        pct_base = max_delta
    else:
        # 无前一帧 → 看总量
        max_stage = max(curr_dur, key=curr_dur.get)
        max_delta = curr_dur[max_stage]
        max_delta_ms = max_delta / 1_000_000
        reason_prefix = "累计耗时"
        pct_base = max_delta

    pipeline_dur_ns = frame.get("pipeline_dur_ns") or 1
    pct = (pct_base / pipeline_dur_ns * 100) if pipeline_dur_ns else 0

    # 阶段 → 线程名映射
    stage_to_name = {
        "ui": frame.get("ui_thread_name") or "UIThread",
        "rs": frame.get("rs_thread_name") or "RSMainThread",
        "rs_render": frame.get("rs_render_thread_name") or "RenderThread",
        "hwc": "HWCThread",
        "present": "PresentFence",
    }

    # 阶段 → tid 映射
    stage_to_tid = {
        "ui": frame.get("ui_tid"),
        "rs": frame.get("rs_tid"),
        "rs_render": frame.get("rs_render_tid"),
        "hwc": None,
        "present": None,
    }

    # 阶段 → 建议映射
    stage_to_suggestion = {
        "ui": "检查UI线程调度延迟",
        "rs": "检查RSMainThread负载",
        "rs_render": "检查RenderThread负载",
        "hwc": "检查HWC处理耗时",
        "present": "检查PresentFence等待耗时",
    }

    culprit_name = stage_to_name.get(max_stage, "Unknown")
    culprit_tid = stage_to_tid.get(max_stage)

    return {
        "thread_name": culprit_name,
        "tid": culprit_tid,
        "reason": f"{culprit_name}{reason_prefix}(+{max_delta_ms:.1f}ms)，占本帧{pct:.1f}%",
        "suggestion": stage_to_suggestion.get(max_stage, "检查该线程负载"),
    }


# ---------------------------------------------------------------------------
# 算子实现
# ---------------------------------------------------------------------------

@register_operator("build_drop_ranges")
def build_drop_ranges(ctx: PreprocessContext) -> PreprocessContext:
    """将 jank 帧转换为 drop_ranges 列表（每帧独立）。

    输入 ctx.data: build_render_frames 输出的帧列表（list[dict]），已按 present_id 排序
    输出 ctx.data: {
        drop_ranges: [...],
        summary: {total_frames, jank_frames, jank_rate, drop_range_count, thread_query_count}
    }
    """
    frames: List[Dict[str, Any]] = ctx.data
    if not isinstance(frames, list):
        log.warning("build_drop_ranges: ctx.data 不是 list，实际为 %s", type(frames))
        ctx.data = {"drop_ranges": [], "summary": {}}
        return ctx

    if not frames:
        ctx.data = {"drop_ranges": [], "summary": {"total_frames": 0, "jank_frames": 0}}
        return ctx

    # 建立 present_id → frame 的映射，用于查找前一帧
    frame_by_id: Dict[int, Dict[str, Any]] = {}
    for f in frames:
        pid = f.get("present_id")
        if pid is not None:
            frame_by_id[pid] = f

    # 筛选 jank 帧（保持原有顺序）
    jank_frames = [f for f in frames if f.get("jank")]
    log.info("build_drop_ranges: 总帧数=%d, jank帧数=%d", len(frames), len(jank_frames))

    drop_ranges: List[Dict[str, Any]] = []

    for frame in jank_frames:
        present_id = frame.get("present_id")
        present_begin_ts = frame.get("present_begin_ts") or 0
        pipeline_dur_ns = frame.get("pipeline_dur_ns") or 0

        # 时间计算（ns → ms）
        start_ms = present_begin_ts / 1_000_000
        end_ms = start_ms + pipeline_dur_ns / 1_000_000

        # 实际帧间隔（来自 frame_ops 已计算的 present fence 间隔）
        frame_rate = frame.get("frame_rate") or 60
        frame_interval_ns = frame.get("frame_interval_ns") or (1_000_000_000 // frame_rate)
        # 理论帧间隔（用于过滤阈值）
        theoretical_interval_ns = 1_000_000_000 // frame_rate

        # 过滤误报：所有 stage 都小于帧率对应时长，则非真 jank
        stage_keys = ["ui_dur_ns", "rs_dur_ns", "hwc_dur_ns", "present_dur_ns"]
        # present_dur 允许 1ms 波动（即 <= theoretical_interval + 1ms 不算超限）
        def _under_threshold(frame: dict, key: str) -> bool:
            val = frame.get(key) or 0
            if key == "present_dur_ns":
                return val <= theoretical_interval_ns + 1000000  # +1ms buffer
            return val < theoretical_interval_ns

        all_stages_under_threshold = all(_under_threshold(frame, k) for k in stage_keys)
        if all_stages_under_threshold:
            continue  # 跳过此帧，不是真 jank

        # 严重等级
        skipped_ms = frame.get("skipped_time_ms") or 0
        severity = _compute_severity(skipped_ms)

        # 查找前一帧（present_id - 1）
        prev_frame = frame_by_id.get(present_id - 1) if present_id else None

        # culprit：基于增量计算
        culprit = _find_culprit(frame, prev_frame)

        def _dur_ms(val_ns: Optional[int]) -> Optional[float]:
            """ns → ms，保留两位小数。"""
            if val_ns is None:
                return None
            return round(val_ns / 1_000_000, 2)

        drop_range: Dict[str, Any] = {
            "present_fence_id": present_id,
            "app_name": frame.get("app_name"),
            "ui_tid": frame.get("ui_tid"),
            "ui_thread_name": frame.get("ui_thread_name"),
            "start_ms": round(start_ms, 3),
            "end_ms": round(end_ms, 3),
            "severity": severity,
            "jank_trace": frame.get("jank_trace"),
            "frame_rate": frame_rate,
            "frame_interval_ms": round(frame_interval_ns / 1_000_000, 2),
            "jank_type": frame.get("jank_type"),
            "ui_dur_ms": _dur_ms(frame.get("ui_dur_ns")),
            "ui_begin_ms": _dur_ms(frame.get("ui_begin_ts")),
            "ui_end_ms": _dur_ms(frame.get("ui_recv_complete_ts")),
            "rs_dur_ms": _dur_ms(frame.get("rs_dur_ns")),
            "hwc_dur_ms": _dur_ms(frame.get("hwc_dur_ns")),
            "present_dur_ms": _dur_ms(frame.get("present_dur_ns")),
            "culprit": culprit,
        }
        drop_ranges.append(drop_range)

    summary = {
        "total_frames": len(frames),
        "jank_frames": len(jank_frames),
        "jank_rate": round(len(jank_frames) / len(frames), 3) if frames else 0,
        "drop_range_count": len(drop_ranges),
        "thread_query_count": len(drop_ranges) * 2,  # culprit + main_thread 各一个
    }

    ctx.data = {
        "drop_ranges": drop_ranges,
        "summary": summary,
    }
    return ctx


@register_operator("build_thread_queries")
def build_thread_queries(ctx: PreprocessContext) -> PreprocessContext:
    """从 drop_ranges 生成 thread_queries 扁平数组。

    生成逻辑：
    - P1 culprit（必含）: 从 drop_range.culprit 获取 tid 和 thread_name
    - P2 main_thread（必含）: 从 frames 数据中匹配 UI Thread 的 tid

    输入 ctx.data: {drop_ranges: [...], summary: {...}}
    输出 ctx.data: 添加 thread_queries[]
    """
    data: Dict[str, Any] = ctx.data
    drop_ranges: List[Dict[str, Any]] = data.get("drop_ranges", [])
    thread_queries: List[Dict[str, Any]] = []

    for dr in drop_ranges:
        present_fence_id = dr.get("present_fence_id")
        start_ms = dr.get("start_ms")
        end_ms = dr.get("end_ms")
        culprit = dr.get("culprit") or {}

        # P1: culprit（必含）
        thread_queries.append({
            "tag": present_fence_id,
            "start_ms": start_ms,
            "end_ms": end_ms,
            "tid": culprit.get("tid"),
            "thread_name": culprit.get("thread_name"),
            "query_reason": "culprit",
            "priority": 1,
        })

        # P2: main_thread（必含）
        # UI 主线程独立查询，用于判断 UI 线程整体调度情况
        # 若与 culprit 相同则跳过，避免重复查询
        ui_tid = dr.get("ui_tid")
        ui_thread_name = dr.get("ui_thread_name")
        if ui_tid is not None and ui_tid != culprit.get("tid"):
            thread_queries.append({
                "tag": present_fence_id,
                "start_ms": start_ms,
                "end_ms": end_ms,
                "tid": ui_tid,
                "thread_name": ui_thread_name,
                "query_reason": "main_thread",
                "priority": 2,
            })

    data["thread_queries"] = thread_queries
    ctx.data = data
    return ctx


def subtract_intervals(
    parent: tuple[float, float],
    subs: list[tuple[float, float]],
) -> list[tuple[float, float]]:
    """parent - subs → 剩余子区间列表。

    Args:
        parent: (begin, end) 父区间
        subs: [(s1, e1), (s2, e2), ...] 子区间列表，可未排序、可重叠

    Returns:
        剩余子区间列表，已按时间升序排列。
        若 subs 完全覆盖 parent，返回空列表。
    """
    result: list[tuple[float, float]] = []
    cursor = parent[0]
    for s, e in sorted(subs):
        # Clamp sub-interval to parent range
        s = max(s, parent[0])
        e = min(e, parent[1])
        if s >= parent[1] or e <= parent[0]:
            continue  # sub is entirely outside parent
        if s > cursor:
            result.append((cursor, s))
        cursor = max(cursor, e)
    if cursor < parent[1]:
        result.append((cursor, parent[1]))
    return result
