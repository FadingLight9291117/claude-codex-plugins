"""动效区间预处理算子。"""

from __future__ import annotations

import bisect
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .trace_data_cache import TraceDataCache

import pandas as pd

from core.observability import get_module_logger

from .base import PreprocessContext, register_operator

log = get_module_logger(__name__)

# 动效注册表（allow-list）
# 清洗规则：去重（保留最后一条）、去除尾部引号、空描述用名称填充、排除方括号前缀条目
# 仅注册表中的动效类型会出现在输出中；不在注册表中的 H: 异步事件被过滤
ANIMATION_REGISTRY: dict[str, str] = {
    "ABILITY_OR_PAGE_SWITCH": "应用内界面切换",
    "ABILITY_OR_PAGE_SWITCH_INTERACTIVE": "应用内跟手界面转场",
    "ADJUST_SPLIT_RATIO": "分屏比例调节",
    "ANIMATE_TO_POSITION": "图库大图进入/退出编辑",
    "Animator": "通用动效",
    "AOD_TO_LAUNCHER": "AOD到桌面",
    "AOD_TO_LOCKSCREEN": "AOD到锁屏",
    "APP_EXIT_FROM_WINDOW_TITLE_BAR_CLOSED": "窗口标题栏关闭",
    "APP_LIST_FLING": "应用内列表滑动",
    "APP_SWIPER_FLING": "Swiper组件滑动（抛滑）",
    "APP_SWIPER_SCROLL": "Swiper组件滑动（拖滑）",
    "APP_TABS_FLING": "tab栏滑动",
    "APP_TAB_SWITCH": "TAB页切换",
    "APP_TRANSITION_FROM_OTHER_APP": "跨应用转场",
    "APP_TRANSITION_FROM_OTHER_SERVICE": "半屏小艺语音打开其他应用、下拉搜索打开其他应用等",
    "APP_TRANSITION_TO_OTHER_APP": "跨应用转场",
    "AUTO_APP_SWIPER_FLING": "Swiper组件滑动（autoPlay动画）",
    "BROWSER_SWIPE": "图库大图左右滑动",
    "CAMERA_UE_BACK_FRONT": "前后置切换",
    "CAMERA_UE_CHANGE_MODE": "模式切换",
    "CAMERA_UE_GO_GALLERY": "大图展开",
    "CAMERA_UE_PHOTO_SHOOT": "拍照动效（快速缩略图刷新）",
    "CAMERA_UE_VIDEO_START": "录像开始",
    "CAMERA_UE_VIDEO_STOP": "录像结束",
    "CLEAR_1_RECENT_ANI": "删除单个多任务",
    "CLEAR_All_RECENT_ANI": "一键删除多任务",
    "CLEAR_NT_ANI": "清理单个通知消息",
    "CLOSE_BROWSER": "大图侧滑/下拉返回",
    "CLOSE_FOLDER_ANI": "关闭大小文件夹",
    "CONTACTS_DIALER_BUTTON_PRESS": "拨号盘按键",
    "CONTACTS_DIALER_HIDE": "拨号盘收回动效",
    "CONTACTS_DIALER_SHOW": "拨号盘弹出动效",
    "CORE_METHOD_DESKTOP_SHOW": "桌面元素入场",
    "CUSTOM_ANIMATOR": "自定义动效",
    "DRAG_FLOAT": "拖动悬浮窗",
    "DRAG_ITEM_ANI": "桌面图标拖拽挤位",
    "DROPDOWNPANEL_CONTROL_CENTER_EXPAND": "状态栏下拉到控制中心",
    "EDITMODE_ENTER": "桌面捏合进入桌面管理",
    "EDITMODE_EXIT": "退出桌面管理",
    "ENTER_MIDSCENE": "分屏待中景进三窗中景",
    "ENTER_ONE_STEP_FLOAT": "一步悬浮窗",
    "ENTER_ONE_STEP_MIDSCENE": "一步手势进待中景",
    "ENTER_ONE_STEP_SPLIT": "一步分屏-待分屏",
    "ENTER_SPLIT": "形成分屏",
    "EXIT_AA_ANI": "退出负一屏",
    "EXIT_CC_ANI": "退出控制中心",
    "EXIT_CC_MEDIA_ANI": "退出播控中心二级页面",
    "EXIT_CC_SUB_BLUETOOTH_ANI": "退出蓝牙二级页面",
    "EXIT_CC_SUB_WIFI_ANI": "退出wifi二级页面",
    "EXIT_FLOAT_BY_CLICK": "悬浮窗点击关闭按钮",
    "EXIT_LV_ANIM": "退出实况窗",
    "EXIT_NC_ANI": "退出通知中心",
    "EXIT_RECENT_2_HOME_ANI": "退出多任务",
    "EXIT_SEARCH_ANI": "退出智慧搜索",
    "EXPAND_SCREEN_ROTATION_ANI": "折叠屏展开态横竖屏旋转",
    "EXPAND_TO_FOLD_AA": "负一屏折叠",
    "EXPAND_TO_FOLD_INDICATOR": "桌面折叠",
    "EXPAND_TO_FOLD_WINDOWS": "窗口折叠",
    "FACIAL_FLING_UNLOCK_ANI": "人脸滑动解锁",
    "FACIAL_UNLOCK_ANI": "人脸直接解锁",
    "FINGERPRINT_UNLOCK_ANI": "指纹解锁",
    "FLOAT_START_FROM_DOCK": "侧边dock点击图标打开悬浮窗",
    "FLOAT_START_FROM_SIDEBAR": "侧边条打开单个悬浮窗",
    "FLOAT_TO_FULL": "悬浮窗点击最大化按钮",
    "FOLD_EXPAND_SPLIT_VIEW": "分屏状态下折叠/分屏状态下展开",
    "FOLD_TO_EXPAND_AA": "负一屏展开",
    "FOLD_TO_EXPAND_DOCK_BACKGROUND_SCALE_TWO": "桌面展开",
    "FOLD_TO_EXPAND_WINDOWS": "窗口展开",
    "FORM_MANAGER_CREATE_FORM": "添加服务卡片",
    "FORMSTACK_SLIDE_BACK": "堆叠卡片滑动还原",
    "FORMSTACK_SLIDE_DOWN": "堆叠卡片下滑翻页",
    "FORMSTACK_SLIDE_UP": "堆叠卡片上滑翻页",
    "FORMSTACK_SWITCH_CARD": "堆叠卡片上下切换",
    "GESTURE_TO_RECENTS": "手势进入多任务(桌面/应用上滑)，离手后动效",
    "HIDE_INPUT_METHOD_ANIMATION": "输入法面板收回",
    "INTO_AA_ANI": "进入负一屏（跟手+离手）",
    "INTO_CC_ANI": "进入控制中心",
    "INTO_CC_FROM_NC": "通知中心切换到控制中心",
    "INTO_CC_MEDIA_ANI": "点击播控中心进入二级页面",
    "INTO_CC_SUB_BLUETOOTH_ANI": "点击蓝牙图标进入二级页面",
    "INTO_CC_SUB_WIFI_ANI": "点击wifi图标进入二级页面",
    "INTO_HOME_ANI": "桌面入场（无密码上滑解锁）",
    "INTO_LV_ANIM": "进入实况窗",
    "INTO_NC_ANI": "进入通知中心",
    "INTO_NC_FROM_CC": "控制中心切换到通知中心",
    "INTO_SEARCH_ANI": "进入智慧搜索",
    "LAUNCHER_APP_BACK_TO_HOME": "侧滑退出",
    "LAUNCHER_APP_LAUNCH_FROM_APPCENTER": "应用中心点击应用",
    "LAUNCHER_APP_LAUNCH_FROM_CARD": "FA卡片启动",
    "LAUNCHER_APP_LAUNCH_FROM_DOCK": "Dock栏应用图标启动",
    "LAUNCHER_APP_LAUNCH_FROM_ICON": "桌面应用图标启动",
    "LAUNCHER_APP_LAUNCH_FROM_MENU": "长按桌面应用图标，点击菜单启动",
    "LAUNCHER_APP_LAUNCH_FROM_MISSON": "Dock栏图标右键菜单打开",
    "LAUNCHER_APP_LAUNCH_FROM_NOTIFICATIONBAR": "通知栏通知消息启动",
    "LAUNCHER_APP_LAUNCH_FROM_NOTIFICATIONBAR_IN_LOCKSCREEN": "锁屏通知启动",
    "LAUNCHER_APP_LAUNCH_FROM_RECENT": "多任务启动",
    "LAUNCHER_APP_LAUNCH_FROM_STATUSBAR": "状态栏点击应用启动",
    "LAUNCHER_APP_SWIPE_TO_HOME": "上滑退出",
    "LAUNCHER_BIGFLODER_CLOSE_CLICK": "LAUNCHER_BIGFLODER_CLOSE_CLICK",
    "LAUNCHER_BIGFLODER_OPEN": "打开文件/大文件夹",
    "LAUNCHER_BIGFOLDER_OPEN": "打开大文件夹",
    "LAUNCHER_CARD_TEMP_SHOW": "暂态卡片呼出",
    "LAUNCHER_FOLDER_OPEN": "打开文件夹（不区分大小文件夹）",
    "LAUNCHER_OVER_SCROLL": "桌面滑动翻页",
    "LAUNCHER_SCROLL": "桌面主屏滑动屏幕",
    "LAUNCHER_SMALLFOLDER_OPEN": "打开小文件夹（6.0日落）",
    "LAUNCHER_SPRINGBACK_SCROLL": "桌面滑动回弹",
    "LAUNCHER_TO_AOD": "一镜到底（桌面-锁屏-AOD）",
    "LOCKSCREEN_TO_AOD": "锁屏到AOD",
    "LOCKSCREEN_TO_LAUNCHER": "锁屏到桌面",
    "LV_INTO_APP_ANIM": "实况窗进入应用",
    "META_BALLS_TURBO_CHARGING_ANIMATION": "充电动效",
    "MIDSCENE_FOCUS_TRANSFER": "两窗中景切换侧身",
    "MIDSCENE_REPLACE": "替换窗口：三窗点击侧边条替换",
    "MIDSCENE_ROTATION": "三窗中景旋转",
    "MIDSCENE_TO_FULL": "关闭窗口：两窗关闭窗口退出到全屏",
    "MIDSCENE_TO_RECENT": "三窗中景回桌面",
    "MIDSCENE_TO_SPLIT": "关闭窗口：三窗关闭窗口退到两窗分屏",
    "MINI_FLOAT_TO_DEFAULT": "点击min小窗切换至默认悬浮窗",
    "MINIMIZE_FLOAT_BY_CLICK": "悬浮窗点击最小化按钮",
    "MUTIPLE_DESKTOPS_CLICK_SWITCH": "MUTIPLE_DESKTOPS_CLICK_SWITCH",
    "OPEN_ALBUM": "相册页打开相册",
    "OPEN_BROWSER": "图库大图打开",
    "PASSWORD_UNLOCK_ANI": "密码解锁",
    "RECENT_REALIGN_ANI": "卡片补位",
    "SAVE_COMBINATION": "保存AB分屏/中景组合",
    "SCENE_CAP_TO_CARD_ANIM": "沉浸胶囊展开到沉浸卡片动效",
    "SCENE_CAP_TO_LIST_ANIM": "锁屏界面通知信息展开动效",
    "SCENE_CARD_TO_CAP_ANIM": "沉浸卡片收起到沉浸胶囊动效",
    "SCENE_LIST_SWIPE_ANIM": "锁屏界面通知信息上下滑动",
    "SCENE_LIST_TO_CAP_ANIM": "锁屏界面通知列表过渡到胶囊",
    "SCROLLER_ANIMATION": "Scroller组件滑动",
    "SCREEN_OFF_TO_SCREENLOCK_END": "黑屏到锁屏",
    "SCREEN_ROTATION_ANI": "直板机横竖屏旋转",
    "SCREENLOCK_EXIT_EDITOR_ANIM": "退出锁屏编辑",
    "SCREENLOCK_INTO_EDITOR_ANIM": "锁屏界面捏合进入锁屏编辑",
    "SCREENLOCK_SCREEN_OFF_ANIM": "灭屏一镜到底",
    "SCREENLOCK_SCREEN_INTO_PIN": "锁屏界面到密码界面",
    "SCREENRECORD_ANIMATION": "录屏缩略图由大变小",
    "SCREENRECORD_DISMISS_ANIMATION": "录屏缩略图自动退场动效",
    "SCREENRECORD_DISMISS_ANIMATION_BY_USER": "录屏缩略图手动左滑/右滑退场动效",
    "SCREENSHOT_DISMISS_ANIMATION": "截屏缩略图自动退场动效",
    "SCREENSHOT_DISMISS_ANIMATION_BY_USER": "截屏缩略图手动左滑/右滑退场动效",
    "SCREENSHOT_SCALE_ANIMATION": "截屏缩略图由大变小",
    "SCROLL_2_AA": "进入负一屏（离手）",
    "SCROLL_NC_LIST_ANI": "通知列表滑动",
    "SHOW_INPUT_METHOD_ANIMATION": "输入法面板弹出",
    "SNAP_RECENT_ANI": "多任务列表滑动",
    "SPLIT_BACK_SEC": "侧滑退出下or右分屏",
    "SPLIT_DRAG_EXIT": "拖动分屏线退出分屏",
    "SPLIT_STYLE_EXCHANGE": "上下和左右分屏互换",
    "SPLIT_SWAP_ANIMATION": "分屏点击互换",
    "SPLIT_TO_FLOAT": "分屏点击菜单按钮切悬浮窗",
    "START_APP_ANI_AG": "应用中心启动（PC）",
    "START_APP_ANI_FORM": "FA卡片启动",
    "START_APP_ANI_MENU": "应用启动(从Dock栏右键菜单 PC)",
    "START_COMBINATION": "启动AB分屏/中景组合",
    "VOLUME_BAR_CHANGE_ON": "VOLUME_BAR_CHANGE_ON",
    "VOLUME_BAR_COLLAPSE": "音量面板收起",
    "VOLUME_BAR_EXPAND": "音量面板展开",
    "VOLUME_BAR_SHOW": "音量条呼出",
    "VOLUME_BAR_SLIDE": "音量条滑动",
    "VOLUME_BAR_TOUCHED": "音量条点击",
    "WEB_LIST_FLING": "web抛滑",
}


# 场景关键词 → 动画类型分组映射
# 将 164 个动画类型按用户可感知的场景分组，支持通过场景关键词（如"滑动"）
# 查询一组相关动画类型。用户也可直接传入具体动画类型名。
SCENE_TO_ANIMATION_TYPES: dict[str, list[str]] = {
    "滑动": [
        "APP_LIST_FLING", "APP_SWIPER_FLING", "APP_SWIPER_SCROLL",
        "AUTO_APP_SWIPER_FLING",
        "APP_TABS_FLING", "LAUNCHER_SCROLL", "LAUNCHER_OVER_SCROLL",
        "LAUNCHER_SPRINGBACK_SCROLL", "SCROLLER_ANIMATION",
        "SNAP_RECENT_ANI", "SCROLL_NC_LIST_ANI", "SCROLL_2_AA",
        "BROWSER_SWIPE", "WEB_LIST_FLING", "FORMSTACK_SLIDE_UP",
        "FORMSTACK_SLIDE_DOWN", "FORMSTACK_SLIDE_BACK",
        "SCENE_LIST_SWIPE_ANIM",
    ],
    "转场": [
        "ABILITY_OR_PAGE_SWITCH", "ABILITY_OR_PAGE_SWITCH_INTERACTIVE",
        "APP_TRANSITION_FROM_OTHER_APP", "APP_TRANSITION_FROM_OTHER_SERVICE",
        "APP_TRANSITION_TO_OTHER_APP", "APP_TAB_SWITCH",
        "LAUNCHER_APP_BACK_TO_HOME", "LAUNCHER_APP_SWIPE_TO_HOME",
    ],
    "启动": [
        "LAUNCHER_APP_LAUNCH_FROM_ICON", "LAUNCHER_APP_LAUNCH_FROM_DOCK",
        "LAUNCHER_APP_LAUNCH_FROM_MENU", "LAUNCHER_APP_LAUNCH_FROM_RECENT",
        "LAUNCHER_APP_LAUNCH_FROM_CARD", "LAUNCHER_APP_LAUNCH_FROM_APPCENTER",
        "LAUNCHER_APP_LAUNCH_FROM_NOTIFICATIONBAR",
        "LAUNCHER_APP_LAUNCH_FROM_STATUSBAR",
        "LAUNCHER_APP_LAUNCH_FROM_MISSON",
        "LAUNCHER_APP_LAUNCH_FROM_NOTIFICATIONBAR_IN_LOCKSCREEN",
        "START_APP_ANI_AG", "START_APP_ANI_FORM", "START_APP_ANI_MENU",
    ],
    "解锁": [
        "FACIAL_FLING_UNLOCK_ANI", "FACIAL_UNLOCK_ANI",
        "FINGERPRINT_UNLOCK_ANI", "PASSWORD_UNLOCK_ANI",
        "LOCKSCREEN_TO_LAUNCHER", "INTO_HOME_ANI",
    ],
    "桌面": [
        "CORE_METHOD_DESKTOP_SHOW", "LAUNCHER_BIGFLODER_OPEN",
        "LAUNCHER_BIGFLODER_CLOSE_CLICK",
        "LAUNCHER_BIGFOLDER_OPEN", "LAUNCHER_FOLDER_OPEN",
        "CLOSE_FOLDER_ANI",
        "LAUNCHER_SMALLFOLDER_OPEN", "LAUNCHER_CARD_TEMP_SHOW",
        "EDITMODE_ENTER", "EDITMODE_EXIT", "DRAG_ITEM_ANI",
        "MUTIPLE_DESKTOPS_CLICK_SWITCH",
    ],
    "分屏": [
        "ADJUST_SPLIT_RATIO", "ENTER_SPLIT", "ENTER_ONE_STEP_SPLIT",
        "ENTER_ONE_STEP_MIDSCENE", "ENTER_ONE_STEP_FLOAT",
        "ENTER_MIDSCENE", "MIDSCENE_FOCUS_TRANSFER", "MIDSCENE_REPLACE",
        "MIDSCENE_ROTATION", "MIDSCENE_TO_FULL", "MIDSCENE_TO_RECENT",
        "MIDSCENE_TO_SPLIT", "SPLIT_BACK_SEC", "SPLIT_DRAG_EXIT",
        "SPLIT_STYLE_EXCHANGE", "SPLIT_SWAP_ANIMATION", "SPLIT_TO_FLOAT",
        "FLOAT_START_FROM_DOCK", "FLOAT_START_FROM_SIDEBAR",
        "FLOAT_TO_FULL", "DRAG_FLOAT", "MINI_FLOAT_TO_DEFAULT",
        "MINIMIZE_FLOAT_BY_CLICK", "EXIT_FLOAT_BY_CLICK",
        "FOLD_EXPAND_SPLIT_VIEW", "SAVE_COMBINATION", "START_COMBINATION",
    ],
    "通知": [
        "INTO_NC_ANI", "EXIT_NC_ANI", "INTO_CC_ANI", "EXIT_CC_ANI",
        "INTO_CC_FROM_NC", "INTO_NC_FROM_CC", "INTO_CC_MEDIA_ANI",
        "EXIT_CC_MEDIA_ANI", "INTO_CC_SUB_BLUETOOTH_ANI",
        "EXIT_CC_SUB_BLUETOOTH_ANI", "INTO_CC_SUB_WIFI_ANI",
        "EXIT_CC_SUB_WIFI_ANI", "DROPDOWNPANEL_CONTROL_CENTER_EXPAND",
        "CLEAR_NT_ANI", "SCENE_CAP_TO_CARD_ANIM", "SCENE_CAP_TO_LIST_ANIM",
        "SCENE_CARD_TO_CAP_ANIM", "SCENE_LIST_TO_CAP_ANIM",
    ],
    "输入法": [
        "SHOW_INPUT_METHOD_ANIMATION", "HIDE_INPUT_METHOD_ANIMATION",
    ],
    "截屏录屏": [
        "SCREENSHOT_SCALE_ANIMATION", "SCREENSHOT_DISMISS_ANIMATION",
        "SCREENSHOT_DISMISS_ANIMATION_BY_USER", "SCREENRECORD_ANIMATION",
        "SCREENRECORD_DISMISS_ANIMATION", "SCREENRECORD_DISMISS_ANIMATION_BY_USER",
    ],
    "相机": [
        "CAMERA_UE_BACK_FRONT", "CAMERA_UE_CHANGE_MODE",
        "CAMERA_UE_GO_GALLERY", "CAMERA_UE_PHOTO_SHOOT",
        "CAMERA_UE_VIDEO_START", "CAMERA_UE_VIDEO_STOP",
    ],
    "旋转": [
        "SCREEN_ROTATION_ANI", "EXPAND_SCREEN_ROTATION_ANI",
    ],
    "折叠": [
        "EXPAND_TO_FOLD_AA", "EXPAND_TO_FOLD_INDICATOR",
        "EXPAND_TO_FOLD_WINDOWS", "FOLD_TO_EXPAND_AA",
        "FOLD_TO_EXPAND_DOCK_BACKGROUND_SCALE_TWO", "FOLD_TO_EXPAND_WINDOWS",
    ],
    "多任务": [
        "GESTURE_TO_RECENTS", "CLEAR_1_RECENT_ANI",
        "CLEAR_All_RECENT_ANI", "EXIT_RECENT_2_HOME_ANI",
        "RECENT_REALIGN_ANI",
    ],
    "锁屏": [
        "AOD_TO_LAUNCHER", "AOD_TO_LOCKSCREEN", "LOCKSCREEN_TO_AOD",
        "SCREEN_OFF_TO_SCREENLOCK_END", "SCREENLOCK_SCREEN_OFF_ANIM",
        "SCREENLOCK_INTO_EDITOR_ANIM", "SCREENLOCK_EXIT_EDITOR_ANIM",
        "SCREENLOCK_SCREEN_INTO_PIN", "LAUNCHER_TO_AOD",
    ],
    "负一屏": [
        "INTO_AA_ANI", "EXIT_AA_ANI", "SCROLL_2_AA",
    ],
    "搜索": [
        "INTO_SEARCH_ANI", "EXIT_SEARCH_ANI",
    ],
    "实况窗": [
        "INTO_LV_ANIM", "EXIT_LV_ANIM", "LV_INTO_APP_ANIM",
    ],
    "窗口": [
        "APP_EXIT_FROM_WINDOW_TITLE_BAR_CLOSED",
        "LAUNCHER_APP_LAUNCH_FROM_STATUSBAR",
    ],
    "音量": [
        "VOLUME_BAR_SHOW", "VOLUME_BAR_SLIDE", "VOLUME_BAR_TOUCHED",
        "VOLUME_BAR_EXPAND", "VOLUME_BAR_COLLAPSE", "VOLUME_BAR_CHANGE_ON",
    ],
    "充电": [
        "META_BALLS_TURBO_CHARGING_ANIMATION",
    ],
    "拨号": [
        "CONTACTS_DIALER_BUTTON_PRESS", "CONTACTS_DIALER_HIDE",
        "CONTACTS_DIALER_SHOW",
    ],
    "图库": [
        "ANIMATE_TO_POSITION", "OPEN_ALBUM", "OPEN_BROWSER", "CLOSE_BROWSER",
    ],
    "卡片": [
        "FORM_MANAGER_CREATE_FORM", "FORMSTACK_SWITCH_CARD",
    ],
    "通用": [
        "Animator", "CUSTOM_ANIMATOR",
    ],
}


def resolve_animation_types(animation_type: str | None) -> list[str]:
    """将场景关键词或具体动画类型解析为动画类型列表。

    防护：SkillExecutor 将未提供的 input.xxx 解析为字符串 "None"，
    需排除 "None" 和空字符串。
    """
    if not animation_type or animation_type in ("None", ""):
        return []
    # 场景关键词
    if animation_type in SCENE_TO_ANIMATION_TYPES:
        return SCENE_TO_ANIMATION_TYPES[animation_type]
    # 具体动画类型
    if animation_type in ANIMATION_REGISTRY:
        return [animation_type]
    return []


def _build_animation_df_from_cache(
    cache: "TraceDataCache",
    start_ns: int,
    end_ns: int,
    tid: Optional[int],
    filter_process_name: Optional[str],
) -> pd.DataFrame:
    """从 TraceDataCache 构建等效于 animation_interval SQL 的 DataFrame。

    替代 Path A：YAML sql 已改为空 stub，数据由本函数从 cache 拉取，
    避免每帧全表扫描 SQLite（15.7s → ~0s）。

    SQL 映射：
      - callstack (cookie IS NOT NULL, name LIKE 'H:%') → cache.callstack_all() 逐 itid 过滤
      - thread (tid, name) → cache.thread_meta_all()
      - process (pid, name) → cache.process_name_all() + thread_meta ipid
      - tid 过滤 → cache.tid_to_itid() 找同 ipid 的所有 itid
      - filter_process_name 过滤 → cache.process_name_all() 模糊匹配
    """
    # 使用预过滤的 animation_callstack_view（仅 H: 事件，~数千行 vs 全量 793K）
    anim_cache, anim_ts_only = cache.animation_callstack_view()
    meta_dict = cache.thread_meta_all()  # {itid: (name, tid, ipid)}
    pid_to_pname = cache.process_name_all()  # {ipid: name}
    ipid_to_pid = cache.ipid_to_pid_all()  # {ipid: pid}
    tid_to_itid_map = cache.tid_to_itid_all()  # {tid: itid}

    # 确定需要过滤的 ipid 集合
    target_ipids: set | None = None
    if tid is not None:
        # tid → itid → ipid → 同 ipid 所有 itid
        # tid 不存在或 ipid 不在 process 表 → 空集合（无结果）
        target_itid = tid_to_itid_map.get(int(tid))
        if target_itid is not None:
            meta = meta_dict.get(target_itid)
            if meta is not None and meta[2] in pid_to_pname:
                target_ipid = meta[2]
                target_ipids = {target_ipid}
        if target_ipids is None:
            # tid 找不到或 ipid 无对应 process → 返回空
            log.warning(f"tid={tid} 找不到对应 itid/ipid，将返回空结果")
            target_ipids = set()
    elif filter_process_name is not None:
        # 按 process_name 模糊匹配 ipid 集合
        # pname 可能为 None（真实 trace 中 process 表存在 name 为 NULL 的行）
        target_ipids = {
            ipid for ipid, pname in pid_to_pname.items()
            if pname and filter_process_name in pname
        }

    rows: list = []
    for itid, anim_list in anim_cache.items():
        # ipid 过滤
        if target_ipids is not None:
            meta = meta_dict.get(itid)
            if meta is None or meta[2] not in target_ipids:
                continue

        # bisect + 区间相交过滤（同 cache.callstack 的 _filter_intersection 逻辑）
        ts_arr = anim_ts_only.get(itid)
        if ts_arr is None or len(anim_list) == 0:
            continue
        idx_hi = bisect.bisect_left(ts_arr, end_ns)
        if idx_hi == 0:
            continue
        for i in range(idx_hi):
            r = anim_list[i]
            ts, dur = r[0], r[1]
            if ts + dur <= start_ns:
                continue

            # r: (ts, dur, name, cookie, id)
            name = r[2]
            cookie = r[3]
            rid = r[4]

            meta = meta_dict.get(itid)
            tname = meta[0] if meta else "unknown"
            ttid = meta[1] if meta else None
            ipid = meta[2] if meta else None
            pid_val = None
            pname = "unknown"
            if ipid is not None:
                pid_val = ipid_to_pid.get(ipid)
                pname = pid_to_pname.get(ipid) or "unknown"  # name 为 NULL 时归一为 unknown

            rows.append((rid, name, ts, dur, cookie, ttid, tname, pid_val, pname))

    if not rows:
        return pd.DataFrame(columns=["id", "name", "ts", "dur", "cookie", "tid", "thread_name", "pid", "process_name"])

    return pd.DataFrame(rows, columns=["id", "name", "ts", "dur", "cookie", "tid", "thread_name", "pid", "process_name"])


@register_operator("match_animation_events")
def match_animation_events(ctx: PreprocessContext) -> PreprocessContext:
    """从 SQL 宽过滤结果中提取动效类型，匹配注册表，过滤非动效行，构建输出。"""
    df = ctx.data
    cache = ctx.trace_cache

    start_ms = ctx.meta.get("start_ms")
    end_ms = ctx.meta.get("end_ms")
    tid = ctx.params.get("tid")
    filter_process_name = ctx.params.get("filter_process_name")

    # Path A: SQL stub → 从 TraceDataCache 构建 DataFrame
    if not isinstance(df, pd.DataFrame) or len(df) == 0 or "name" not in (df.columns if isinstance(df, pd.DataFrame) else []):
        if cache is None:
            ctx.data = {
                "summary": {"animation_count": 0, "dropped_non_animation_count": 0,
                            "total_dur_ms": 0.0, "longest_animation": "", "longest_dur_ms": 0.0,
                            "process_name": "all", "tid": None},
                "animation_list": [],
            }
            return ctx
        start_ns = int(start_ms * 1_000_000) if start_ms else 0
        end_ns = int(end_ms * 1_000_000) if end_ms else 0
        df = _build_animation_df_from_cache(cache, start_ns, end_ns, tid, filter_process_name)

    if not isinstance(df, pd.DataFrame) or df.empty:
        ctx.data = {
            "summary": {
                "animation_count": 0,
                "dropped_non_animation_count": 0,
                "total_dur_ms": 0.0,
                "longest_animation": "",
                "longest_dur_ms": 0.0,
                "process_name": "all",
                "tid": None,
            },
            "animation_list": [],
        }
        return ctx

    # 1. 提取动效类型名：从 "H:NAME,metadata..." 中提取 NAME
    names = df["name"].astype(str)
    without_prefix = names.str[2:]  # 去掉 H: 前缀
    anim_types = without_prefix.str.split(",").str[0].str.strip()
    df["animation_type"] = anim_types

    # 2. 匹配注册表（allow-list）
    df["is_known"] = df["animation_type"].isin(ANIMATION_REGISTRY)

    # 3. 过滤非动效行（不在注册表中的 H: 异步事件）
    dropped_count = int((~df["is_known"]).sum())
    df = df[df["is_known"]].copy()

    if df.empty:
        ctx.data = {
            "summary": {
                "animation_count": 0,
                "dropped_non_animation_count": dropped_count,
                "total_dur_ms": 0.0,
                "longest_animation": "",
                "longest_dur_ms": 0.0,
                "process_name": "all",
                "tid": None,
            },
            "animation_list": [],
        }
        return ctx

    # 4. 添加中文描述
    df["description"] = df["animation_type"].map(ANIMATION_REGISTRY)

    # 5. 时间转换 ns→ms + pd.notna() 保护 int() 转换
    df["start_ms"] = df["ts"] / 1_000_000.0
    df["end_ms"] = (df["ts"] + df["dur"]) / 1_000_000.0
    df["dur_ms"] = df["dur"] / 1_000_000.0
    df["pid"] = pd.array([int(v) if pd.notna(v) else None for v in df["pid"]], dtype=object)
    df["tid"] = pd.array([int(v) if pd.notna(v) else None for v in df["tid"]], dtype=object)

    # 6. 构建 summary
    summary = {
        "animation_count": len(df),
        "dropped_non_animation_count": dropped_count,
        "total_dur_ms": round(df["dur_ms"].sum(), 3),
        "longest_animation": df.loc[df["dur_ms"].idxmax(), "animation_type"],
        "longest_dur_ms": round(df["dur_ms"].max(), 3),
        "process_name": (
            "all" if df["process_name"].nunique() > 1 else df["process_name"].iloc[0]
        ),
        "tid": (
            None if df["tid"].nunique() > 1
            else (int(df["tid"].iloc[0]) if pd.notna(df["tid"].iloc[0]) else None)
        ),
    }

    # 7. 构建 animation_list
    df = df.rename(columns={"name": "animation_name"})
    cols = [
        "process_name", "pid", "tid", "thread_name",
        "animation_name", "animation_type",
        "start_ms", "end_ms", "dur_ms", "description",
    ]
    animation_list = df[cols].to_dict("records")

    ctx.data = {"summary": summary, "animation_list": animation_list}
    return ctx
