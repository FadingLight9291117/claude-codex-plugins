"""并行度算子：扫描线计算时间加权平均并行度。

基于参考算法 D:\\Code\\oss-zlc\\oss_tracetools\\concurrent_analysis\\
os_metric_parser\\concurrent_metric_parser.py 的 calculate_concur_time。

核心概念：
- state='Running' → 在 CPU 上运行
- state='R' / 'R+' → 进入就绪队列等待调度（Runnable）
- running_parallelism  = running_cpu_time / running_active_time
- demand_parallelism   = demand_cpu_time / demand_active_time
- runnable_ratio       = (demand_cpu_time - running_cpu_time) / demand_cpu_time
"""
from __future__ import annotations

from core.observability import get_module_logger
from typing import Optional

import pandas as pd

from .base import PreprocessContext, PreprocessError, register_operator

log = get_module_logger(__name__)


# ---------------------------------------------------------------------------
# 扫描线核心
# ---------------------------------------------------------------------------

def _sweep_line(slices_ms: list[tuple[float, float]]) -> tuple[float, float, dict[int, float]]:
    """对一组 (begin_ms, end_ms) 切片执行扫描线，返回
    (active_time_ms, cpu_time_ms, buckets)。

    active_time = sum(buckets[N>=1])  # 任意线程在状态的时长
    cpu_time    = sum(N * buckets[N])  # 总时长(含并发叠加)
    buckets    = {N: ms}  # N 个线程同时处于该状态的时长
    """
    if not slices_ms:
        return 0.0, 0.0, {}

    events: list[tuple[float, int]] = []  # (ts, order): order=0 开始(+1), order=1 结束(-1)
    for begin, end in slices_ms:
        if end <= begin:
            continue
        events.append((begin, 0))
        events.append((end, 1))

    events.sort(key=lambda e: (e[0], e[1]))

    current_count = 0
    last_ts: Optional[float] = None
    buckets: dict[int, float] = {}

    for ts, order in events:
        if last_ts is not None and current_count > 0:
            delta = ts - last_ts
            if delta > 0:
                buckets[current_count] = buckets.get(current_count, 0.0) + delta
        if order == 0:
            current_count += 1
        else:
            current_count -= 1
        last_ts = ts

    active_time = sum(v for n, v in buckets.items() if n >= 1)
    cpu_time = sum(n * v for n, v in buckets.items())
    return active_time, cpu_time, buckets


def _clip_slices(
    df: pd.DataFrame,
    start_ns: float,
    end_ns: float,
) -> list[tuple[float, float, int, str]]:
    """裁剪 DataFrame 切片到时间窗，返回
    [(begin_ms, end_ms, pid, state), ...]。
    跳过 dur 为 NaN 或完全在窗外的切片。
    """
    if not len(df):
        return []

    out: list[tuple[float, float, int, str]] = []
    for _, row in df.iterrows():
        ts = float(row["ts"])
        dur = row["dur"]
        if pd.isna(dur):
            continue
        dur = float(dur)
        slice_end = ts + dur
        # 裁剪到窗口
        clip_begin = max(ts, start_ns)
        clip_end = min(slice_end, end_ns)
        if clip_end <= clip_begin:
            continue
        pid = int(row["pid"]) if not pd.isna(row["pid"]) else 0
        state = str(row["state"])
        out.append((clip_begin / 1_000_000.0, clip_end / 1_000_000.0, pid, state))
    return out


# ---------------------------------------------------------------------------
# 算子 1：compute_concurrent_parallelism
# ---------------------------------------------------------------------------

@register_operator("compute_concurrent_parallelism")
def compute_concurrent_parallelism(ctx: PreprocessContext) -> PreprocessContext:
    """扫描线计算 running/demand 并行度。

    输入:
        ctx.data: DataFrame 含列 ts / dur / pid / state
                  ts, dur 单位为 ns
        ctx.params:
            start_ms (number): 时间窗起点(ms)
            end_ms (number): 时间窗终点(ms)
            pid (int|None): 进程号；None 输出整机并行度

    输出:
        ctx.meta:
            running_active_time_ms, running_cpu_time_ms, running_parallelism
            demand_active_time_ms, demand_cpu_time_ms, demand_parallelism
            runnable_ratio
            scope ("system" | "process"), pid, process_name
        ctx.data: 裁剪后的 DataFrame（保留供调试）
    """
    df = ctx.data
    required = {"ts", "dur", "pid", "state"}
    if not isinstance(df, pd.DataFrame):
        raise PreprocessError("compute_concurrent_parallelism: ctx.data 期望为 DataFrame")
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(
            f"compute_concurrent_parallelism 输入缺少列: {sorted(missing)}"
        )

    start_ms = float(ctx.params.get("start_ms", 0))
    end_ms = float(ctx.params.get("end_ms", 0))
    pid = ctx.params.get("pid")

    # 进程级查询：按 pid 过滤切片（SQL 层通常已过滤，此处兜底确保正确性）
    if pid is not None:
        df = df[df["pid"] == int(pid)]

    start_ns = start_ms * 1_000_000.0
    end_ns = end_ms * 1_000_000.0

    clipped = _clip_slices(df, start_ns, end_ns)

    running_slices = [(b, e) for b, e, _, s in clipped if s == "Running"]
    demand_slices = [(b, e) for b, e, _, s in clipped if s in ("Running", "R", "R+")]

    running_active, running_cpu, _ = _sweep_line(running_slices)
    demand_active, demand_cpu, _ = _sweep_line(demand_slices)

    running_parallelism = running_cpu / running_active if running_active > 0 else 0.0
    demand_parallelism = demand_cpu / demand_active if demand_active > 0 else 0.0
    runnable = demand_cpu - running_cpu
    runnable_ratio = runnable / demand_cpu if demand_cpu > 0 else 0.0

    scope = "process" if pid is not None else "system"
    process_name: Optional[str] = None

    if scope == "process":
        if ctx.sqlite_conn is not None:
            try:
                row = ctx.sqlite_conn.execute(
                    "SELECT name FROM process WHERE pid = ?", [int(pid)]
                ).fetchone()
                process_name = row[0] if row else f"Process[{pid}]"
            except Exception:
                log.debug("无法从 process 表获取进程名, pid=%s", pid)
                process_name = f"Process[{pid}]"
        else:
            process_name = f"Process[{pid}]"

    # 写入 start_ms/end_ms 到 meta，供 format_concurrent_summary 回显 time_range
    # (query_engine._run_pipeline 也会注入，这里做兜底，使算子可独立测试)
    ctx.meta["start_ms"] = start_ms
    ctx.meta["end_ms"] = end_ms

    ctx.meta["running_active_time_ms"] = round(running_active, 3)
    ctx.meta["running_cpu_time_ms"] = round(running_cpu, 3)
    ctx.meta["running_parallelism"] = round(running_parallelism, 3)
    ctx.meta["demand_active_time_ms"] = round(demand_active, 3)
    ctx.meta["demand_cpu_time_ms"] = round(demand_cpu, 3)
    ctx.meta["demand_parallelism"] = round(demand_parallelism, 3)
    ctx.meta["runnable_ratio"] = round(runnable_ratio, 3)
    ctx.meta["scope"] = scope
    ctx.meta["pid"] = int(pid) if pid is not None else None
    ctx.meta["process_name"] = process_name

    # 保留裁剪后的切片供调试
    if clipped:
        ctx.data = pd.DataFrame(
            clipped,
            columns=["begin_ms", "end_ms", "pid", "state"],
        )
    else:
        ctx.data = pd.DataFrame(
            columns=["begin_ms", "end_ms", "pid", "state"]
        )
    return ctx


# ---------------------------------------------------------------------------
# 算子 2：format_concurrent_summary
# ---------------------------------------------------------------------------

@register_operator("format_concurrent_summary")
def format_concurrent_summary(ctx: PreprocessContext) -> PreprocessContext:
    """收敛并行度计算结果为 LLM 友好 summary dict。

    输入:
        ctx.meta: compute_concurrent_parallelism 写入的所有字段
                  (query_engine 也会在 pipeline 启动时注入 start_ms/end_ms)
    输出:
        ctx.data: dict 结构见 spec §5
    """
    # 从 ctx.meta 读取，兼容两种来源：
    # 1. compute_concurrent_parallelism 显式写入
    # 2. query_engine._run_pipeline 在 pipeline 启动时注入
    start_ms = float(ctx.meta.get("start_ms", 0))
    end_ms = float(ctx.meta.get("end_ms", 0))
    pid = ctx.meta.get("pid")

    summary = {
        "meta": {
            "type": "concurrent_parallelism_summary",
            "scope": ctx.meta.get("scope", "system"),
            "pid": pid,
            "process_name": ctx.meta.get("process_name"),
            "time_range": {
                "start_ms": start_ms,
                "end_ms": end_ms,
                "duration_ms": end_ms - start_ms,
            },
            "running_active_time_ms": ctx.meta.get("running_active_time_ms", 0.0),
            "demand_active_time_ms": ctx.meta.get("demand_active_time_ms", 0.0),
        },
        "running_parallelism": ctx.meta.get("running_parallelism", 0.0),
        "demand_parallelism": ctx.meta.get("demand_parallelism", 0.0),
        "runnable_ratio": ctx.meta.get("runnable_ratio", 0.0),
    }
    ctx.data = summary
    return ctx
