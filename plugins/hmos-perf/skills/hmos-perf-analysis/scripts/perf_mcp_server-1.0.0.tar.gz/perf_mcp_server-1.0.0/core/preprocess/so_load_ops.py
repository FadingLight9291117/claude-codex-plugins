"""SO 加载统计预处理算子。"""

import pandas as pd
from .base import PreprocessContext, register_operator


@register_operator("format_so_load_summary")
def format_so_load_summary(ctx: PreprocessContext) -> PreprocessContext:
    """将 SQL 扁平行转为 {summary, so_list} 嵌套结构。

    输入:
        ctx.data: DataFrame with columns [so_path, total_dur_ms, call_count,
                  max_dur_ms, avg_dur_ms, tid, thread_name, event_type]
    输出:
        ctx.data: dict with summary + so_list
    """
    df = ctx.data
    top_n = int(ctx.params.get("top_n", 50))

    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "summary": {
                "total_so_dur_ms": 0.0,
                "total_load_count": 0,
                "so_count": 0,
                "slowest_so_path": "",
                "slowest_so_dur_ms": 0.0,
                "tid": None,
                "thread_name": "all",
            },
            "so_list": [],
        }
        return ctx

    # Summary: aggregate across all rows (across all event_types)
    total_so_dur_ms = round(float(df["total_dur_ms"].sum()), 3)
    total_load_count = int(df["call_count"].sum())
    so_count = int(df["so_path"].nunique())

    # Slowest SO: re-aggregate across event_type to find true slowest
    so_totals = df.groupby("so_path")["total_dur_ms"].sum()
    slowest_so_path = str(so_totals.idxmax())
    slowest_so_dur_ms = round(float(so_totals.max()), 3)

    # Determine tid/thread_name for summary
    unique_tids = df["tid"].unique()
    if len(unique_tids) == 1:
        summary_tid = int(unique_tids[0])
        summary_thread_name = str(df["thread_name"].iloc[0])
    else:
        summary_tid = None
        summary_thread_name = "all"

    # so_list: top_n by total_dur_ms (already sorted by SQL ORDER BY)
    # top_n=0 means unlimited (return all rows)
    top_df = df.head(top_n) if top_n > 0 else df
    so_list = [
        {
            "so_path": str(r["so_path"]),
            "total_dur_ms": round(float(r["total_dur_ms"]), 3),
            "call_count": int(r["call_count"]),
            "max_dur_ms": round(float(r["max_dur_ms"]), 3),
            "avg_dur_ms": round(float(r["avg_dur_ms"]), 3),
            "tid": int(r["tid"]),
            "thread_name": str(r["thread_name"]),
            "event_type": str(r["event_type"]),
        }
        for _, r in top_df.iterrows()
    ]

    ctx.data = {
        "summary": {
            "total_so_dur_ms": total_so_dur_ms,
            "total_load_count": total_load_count,
            "so_count": so_count,
            "slowest_so_path": slowest_so_path,
            "slowest_so_dur_ms": slowest_so_dur_ms,
            "tid": summary_tid,
            "thread_name": summary_thread_name,
        },
        "so_list": so_list,
    }
    return ctx
