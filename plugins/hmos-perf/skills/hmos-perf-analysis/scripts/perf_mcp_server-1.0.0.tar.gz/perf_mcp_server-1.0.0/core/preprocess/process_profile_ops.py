# -*- coding: utf-8 -*-
"""进程画像预处理算子。

给定 tid + 时间窗口，返回该进程全量线程的三维画像：
1. callstack_hotspots: H: trace_marker 热点函数 TopN
2. thread_running_top: 线程 running 时间 TopN
3. thread_sched_top: 线程调度状态分布 TopN（按 contention_score 排序）
"""
from __future__ import annotations

import pandas as pd

from core.observability import get_module_logger

from .base import PreprocessContext, PreprocessError, register_operator

log = get_module_logger(__name__)


# ---------------------------------------------------------------------------
# State classification helpers (subset of sched_ops.py; X/Z excluded as rare)
# ---------------------------------------------------------------------------

_RUNNING_STATES = {"Running"}
_RUNNABLE_STATES = {"R", "R+"}
_SLEEPING_STATES = {"S", "I"}
_DSTATE_STATES = {"D", "D-NIO", "D|W"}
_IOWAIT_STATES = {"D-IO"}

# Single-pass state→category mapping (replaces 5 boolean columns + 5 groupby)
_STATE_CATEGORY_MAP: dict[str, str] = {}
for _s in _RUNNING_STATES:
    _STATE_CATEGORY_MAP[_s] = "running"
for _s in _RUNNABLE_STATES:
    _STATE_CATEGORY_MAP[_s] = "runnable"
for _s in _SLEEPING_STATES:
    _STATE_CATEGORY_MAP[_s] = "sleeping"
for _s in _DSTATE_STATES:
    _STATE_CATEGORY_MAP[_s] = "d_state"
for _s in _IOWAIT_STATES:
    _STATE_CATEGORY_MAP[_s] = "iowait"


@register_operator("compute_process_callstack_hotpath")
def compute_process_callstack_hotpath(ctx: PreprocessContext) -> PreprocessContext:
    """查询该进程所有线程的 H: trace_marker，按函数名聚合 TopN。

    从 ctx.sqlite_conn 执行 callstack_markers SQL，
    结果存入 ctx.meta["callstack_hotspots"]。
    """
    start_ms = ctx.meta.get("start_ms")
    end_ms = ctx.meta.get("end_ms")
    tid = ctx.meta.get("tid")
    top_n = ctx.params.get("top_n", 5)

    if not ctx.sqlite_conn:
        ctx.meta["callstack_hotspots"] = []
        return ctx

    if top_n == 0:
        ctx.meta["callstack_hotspots"] = []
        return ctx

    # Temporal overlap: callstack visible if it overlaps the time window
    # Clause order preserves params=(tid, start_ms, end_ms) binding
    sql = """
        SELECT c.name, c.ts, c.dur, c.depth, t.tid, t.name as thread_name
        FROM callstack c
        JOIN thread t ON c.callid = t.itid
        WHERE t.ipid IN (SELECT ipid FROM thread WHERE tid = ?)
          AND c.name LIKE 'H:%'
          AND (c.ts + COALESCE(c.dur, 0)) > ? * 1000000
          AND c.ts < ? * 1000000
        ORDER BY c.ts
    """
    df = pd.read_sql_query(sql, ctx.sqlite_conn, params=(tid, start_ms, end_ms))

    if df.empty:
        ctx.meta["callstack_hotspots"] = []
        return ctx

    # Dur-clipping: clip callstack duration to window bounds
    # Precedent: game_render_ops.py:797-802 (dur-clipping concept)
    window_start_ns = start_ms * 1_000_000
    window_end_ns = end_ms * 1_000_000
    df["effective_dur"] = (
        (df["ts"] + df["dur"]).clip(upper=window_end_ns)
        - df["ts"].clip(lower=window_start_ns)
    )
    df["effective_dur"] = df["effective_dur"].clip(lower=0)  # guard negative

    # Aggregate by function name using effective_dur
    agg = df.groupby("name").agg(
        total_time_ns=("effective_dur", "sum"),
        count=("name", "size"),
        representative_tid=("tid", "first"),
    ).reset_index()

    # Get thread_name for each function's representative tid
    tid_name_map = df.drop_duplicates(subset=["tid", "thread_name"]).set_index("tid")["thread_name"]
    agg["thread_name"] = agg["representative_tid"].map(tid_name_map)
    agg["total_time_ms"] = agg["total_time_ns"] / 1e6
    agg["avg_duration_ms"] = agg["total_time_ms"] / agg["count"]
    agg = agg.sort_values("total_time_ms", ascending=False).head(top_n)

    hotspots = []
    for _, row in agg.iterrows():
        hotspots.append({
            "function_name": row["name"],
            "total_time_ms": round(row["total_time_ms"], 3),
            "count": int(row["count"]),
            "avg_duration_ms": round(row["avg_duration_ms"], 3),
            "tid": int(row["representative_tid"]),
            "thread_name": str(row["thread_name"]) if pd.notna(row["thread_name"]) else "unknown",
        })

    ctx.meta["callstack_hotspots"] = hotspots
    return ctx


@register_operator("compute_process_thread_profile")
def compute_process_thread_profile(ctx: PreprocessContext) -> PreprocessContext:
    """从 thread_states DataFrame 计算线程 running TopN + 调度状态分布 TopN。

    输入: ctx.data = thread_states DataFrame (from YAML sql)
    输出: ctx.meta["thread_running_top"], ctx.meta["thread_sched_top"]
    """
    df = ctx.data
    top_n = ctx.params.get("top_n", 5)

    # Validate required input columns
    required = {"tid", "thread_name", "state", "ts", "dur"}
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(
            f"compute_process_thread_profile input missing columns: {sorted(missing)}; "
            f"required: {sorted(required)}"
        )

    start_ms = ctx.meta.get("start_ms", 0)
    end_ms = ctx.meta.get("end_ms", 0)
    total_window_ms = end_ms - start_ms if start_ms is not None and end_ms is not None else 0

    if top_n == 0:
        ctx.meta["thread_running_top"] = []
        ctx.meta["thread_sched_top"] = []
        ctx.meta["total_thread_count"] = 0
        return ctx

    if df.empty:
        ctx.meta["thread_running_top"] = []
        ctx.meta["thread_sched_top"] = []
        ctx.meta["total_thread_count"] = 0
        return ctx

    # Classify each row's state and compute duration in ms
    df = df.copy()

    # Dur-clipping: clip thread_state duration to window bounds
    # Precedent: compute_process_callstack_hotpath dur-clipping (line 73-77)
    start_ms_val = ctx.meta.get("start_ms", 0)
    end_ms_val = ctx.meta.get("end_ms", 0)
    if start_ms_val is not None and end_ms_val is not None:
        window_start_ns = start_ms_val * 1_000_000
        window_end_ns = end_ms_val * 1_000_000
        effective_dur = (
            (df["ts"] + df["dur"]).clip(upper=window_end_ns)
            - df["ts"].clip(lower=window_start_ns)
        )
        df["dur"] = effective_dur.clip(lower=0)

    df["dur_ms"] = df["dur"] / 1e6
    df["state_category"] = df["state"].map(_STATE_CATEGORY_MAP)

    # Single-pass pivot: one groupby instead of 5
    pivot = df.pivot_table(
        index=["tid", "thread_name"],
        columns="state_category",
        values="dur_ms",
        aggfunc="sum",
        fill_value=0,
    )

    # Ensure all expected columns exist (threads may lack some states)
    for col in ("running", "runnable", "sleeping", "d_state", "iowait"):
        if col not in pivot.columns:
            pivot[col] = 0

    thread_stats = pivot.reset_index()
    thread_stats = thread_stats.rename(columns={
        "running": "running_ms",
        "runnable": "runnable_ms",
        "sleeping": "sleeping_ms",
        "d_state": "d_state_ms",
        "iowait": "iowait_ms",
    })

    # Compute contention_score
    thread_stats["total_ms"] = (
        thread_stats["running_ms"]
        + thread_stats["runnable_ms"]
        + thread_stats["sleeping_ms"]
        + thread_stats["d_state_ms"]
        + thread_stats["iowait_ms"]
    )
    # Guard against division by zero
    thread_stats["contention_score"] = 0.0
    nonzero = thread_stats["total_ms"] > 0
    thread_stats.loc[nonzero, "contention_score"] = (
        (thread_stats.loc[nonzero, "runnable_ms"]
         + thread_stats.loc[nonzero, "d_state_ms"]
         + thread_stats.loc[nonzero, "iowait_ms"])
        / thread_stats.loc[nonzero, "total_ms"]
    )

    # thread_running_top: by running_ms DESC
    running_sorted = thread_stats.sort_values("running_ms", ascending=False).head(top_n)
    running_top = []
    for _, row in running_sorted.iterrows():
        running_pct = (row["running_ms"] / total_window_ms * 100) if total_window_ms > 0 else 0
        running_top.append({
            "tid": int(row["tid"]),
            "thread_name": str(row["thread_name"]) if pd.notna(row["thread_name"]) else "unknown",
            "running_ms": round(float(row["running_ms"]), 3),
            "total_ms": round(float(total_window_ms), 3),
            "running_pct": round(float(running_pct), 1),
        })

    # thread_sched_top: by contention_score DESC
    sched_sorted = thread_stats.sort_values("contention_score", ascending=False).head(top_n)
    sched_top = []
    for _, row in sched_sorted.iterrows():
        sched_top.append({
            "tid": int(row["tid"]),
            "thread_name": str(row["thread_name"]) if pd.notna(row["thread_name"]) else "unknown",
            "running_ms": round(float(row["running_ms"]), 3),
            "runnable_ms": round(float(row["runnable_ms"]), 3),
            "sleeping_ms": round(float(row["sleeping_ms"]), 3),
            "d_state_ms": round(float(row["d_state_ms"]), 3),
            "iowait_ms": round(float(row["iowait_ms"]), 3),
            "contention_score": round(float(row["contention_score"]), 4),
        })

    ctx.meta["thread_running_top"] = running_top
    ctx.meta["thread_sched_top"] = sched_top
    ctx.meta["total_thread_count"] = len(thread_stats)
    return ctx


@register_operator("format_process_profile")
def format_process_profile(ctx: PreprocessContext) -> PreprocessContext:
    """组装 process_profile 最终输出。

    从 ctx.meta 读取三个 TopN 数组，查询 meta 信息（process_name, ipid），
    输出最终结构到 ctx.data。
    """
    tid = ctx.meta.get("tid")
    start_ms = ctx.meta.get("start_ms", 0)
    end_ms = ctx.meta.get("end_ms", 0)
    duration_ms = end_ms - start_ms if start_ms is not None and end_ms is not None else 0

    # Query meta info: process_name and ipid
    process_name = "unknown"
    ipid = None
    if ctx.sqlite_conn and tid is not None:
        try:
            row = ctx.sqlite_conn.execute(
                "SELECT t.ipid, p.name as process_name "
                "FROM thread t JOIN process p ON t.ipid = p.ipid "
                "WHERE t.tid = ? LIMIT 1",
                (tid,),
            ).fetchone()
            if row:
                ipid = row[0]
                process_name = row[1]
        except Exception:
            log.warning("format_process_profile: failed to query process_name for tid=%s", tid)

    # Total thread count from upstream operator (not top-N limited)
    thread_count = ctx.meta.get("total_thread_count")
    if thread_count is None:
        log.warning("format_process_profile: total_thread_count not set by upstream operator")
        thread_count = len(ctx.meta.get("thread_sched_top", []))

    result = {
        "meta": {
            "process_name": process_name,
            "ipid": ipid,
            "source_tid": tid,
            "time_range": {
                "start_ms": start_ms,
                "end_ms": end_ms,
                "duration_ms": duration_ms,
            },
            "thread_count": thread_count,
        },
        "callstack_hotspots": ctx.meta.get("callstack_hotspots", []),
        "thread_running_top": ctx.meta.get("thread_running_top", []),
        "thread_sched_top": ctx.meta.get("thread_sched_top", []),
    }

    ctx.data = result
    return ctx
