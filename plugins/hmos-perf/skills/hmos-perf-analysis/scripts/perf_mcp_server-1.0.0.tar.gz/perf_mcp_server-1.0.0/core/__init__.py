"""perf-mcp-server core engine package.

包含:
- registry: YAML 加载 + Indicator/Skill 注册中心
- query_engine: SQL 渲染、动态参数合并、大数据采样
- skill_router: get_skill / list_skills 响应组装
- validators: YAML Schema 校验、循环依赖检测、sql_params 一致性检查
- sampling: 时序采样、分桶聚合、直方图生成
- flamegraph_collapse: 火焰图同类归一化合并 + 四层折叠
"""

__version__ = "2.2.0"
