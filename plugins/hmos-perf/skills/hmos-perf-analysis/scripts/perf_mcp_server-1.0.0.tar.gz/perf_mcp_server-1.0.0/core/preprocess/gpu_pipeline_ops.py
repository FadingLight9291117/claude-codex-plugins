"""GPU 管线瓶颈分析预处理算子。

包含算子（通过 ``@register_operator`` 注册）：

- ``gpu_pipeline_aggregate``：双管线 GPU 瓶颈分析
  - 游戏管线: eglSwapBuffers 调用栈树 + 同进程 GPU 线程 waiting 关联
  - ArkUI 管线: H:RenderFrame 调用栈 + H:Waiting for Acquire Fence GPU 等待
  服务 ``gpu_pipeline_analysis`` 指标。

输入 ``ctx.data`` 为 pandas DataFrame，列要求：
- ``ts`` (int, ns)
- ``dur`` (int, ns, 可为 NULL，已在 SQL 层用 trace_range.end_ts 填充)
- ``name`` (str, 采样类行可为 NULL)
- ``depth`` (int)
- ``parent_id`` (int)
- ``callid`` (int)
- ``value`` (float/NULL)：gpufreq 行是 MHz，gpuload 行是 %，gpu_state 行是 1，callstack/gpu_waiting 行是 NULL
- ``data_type`` (str)：
    - 游戏管线: 'callstack' / 'gpu_waiting' / 'gpufreq' / 'gpu_state' / 'gpuload'
    - ArkUI 管线: 'arkui_callstack' / 'arkui_gpu_waiting' / 'gpufreq' / 'gpu_state' / 'gpuload'

输出：``ctx.data = {"summary": {...}}``。

设计依据：``docs/superpowers/specs/2026-07-08-arkui-gpu-pipeline-design.md``
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .trace_data_cache import TraceDataCache

import pandas as pd

from .base import PreprocessContext, PreprocessError, register_operator

__all__ = ["gpu_pipeline_aggregate"]


# 关键阶段白名单 - 游戏管线（精确匹配裸 name）
_STAGE_WHITELIST = (
    "PresentPredictedFrame",
    "HMS_XEG_GLDrawNeuralFrame",
    "dequeueBuffer",
    "waiting for free buffer",
    "queueBuffer",
)

# ArkUI 管线关键阶段白名单（LIKE 模糊匹配，H: 前缀）
_ARKUI_STAGE_WHITELIST = (
    "H:RenderStart skip",
    "H:vkQueueSubmit",
    "H:GrDrawingManager::Flush",
    "H:Render surface flush and submit",
    "H:NativeWindowFlushBuffer",
)


@register_operator("gpu_pipeline_aggregate")
def gpu_pipeline_aggregate(ctx: PreprocessContext) -> PreprocessContext:
    """双管线 GPU 瓶颈分析（游戏 + ArkUI）。

    流程：
    1. 分流：arkui_gpu_waiting 非空 → ArkUI 管线; gpu_waiting 非空 → 游戏管线; 否则空
    2. 游戏管线（不变）:
       a. tid → pid → 同进程 GPU 线程；无 GPU 线程或无 waiting → has_gpu_wait=false
       b. 一次性拉取的 callstack 按 parent_id 构树，定位 eglSwapBuffers 根节点
       c. 遍历 eglSwapBuffers 子树，按白名单精确匹配裸 name 提取关键阶段
       d. GPU 线程 waiting for GPU completion 累计耗时
    3. ArkUI 管线（新增）:
       a. arkui_gpu_waiting（H:Waiting for Acquire Fence）累计耗时 → GPU 等待
       b. arkui_callstack 中定位 H:RenderFrame 根节点，遍历子树提取 ArkUI 阶段
    4. gpufreq ∩ gpu_state 扫描线交集（共用），输出加权平均频点
    5. gpuload overlap 加权平均（共用）
    """
    df = ctx.data
    cache = ctx.trace_cache

    # 从 meta 读取窗口（QueryEngine 注入）
    start_ms = ctx.meta.get("start_ms")
    end_ms = ctx.meta.get("end_ms")
    if start_ms is None or end_ms is None:
        raise PreprocessError("gpu_pipeline_aggregate: meta 缺少 start_ms/end_ms")

    start_ns = int(start_ms * 1_000_000)
    end_ns = int(end_ms * 1_000_000)
    tid = ctx.meta.get("tid")
    gpu_freq_rated_max_mhz = (
        ctx.trace_cache.chip_config().get('gpu', {}).get('rated_max_mhz')
        if ctx.trace_cache is not None else None
    )

    # Path A: SQL stub → 从 TraceDataCache 构建 DataFrame
    if not isinstance(df, pd.DataFrame) or len(df) == 0 or "data_type" not in df.columns:
        if cache is None:
            ctx.data = {"summary": _empty_summary(gpu_freq_rated_max_mhz)}
            return ctx
        df = _build_df_from_cache(cache, start_ns, end_ns, tid)

    # 空输入
    if df.empty:
        summary = _empty_summary(gpu_freq_rated_max_mhz)
        ctx.data = {"summary": summary}
        return ctx

    df = df.copy()
    df["ts"] = df["ts"].astype("int64")
    df["dur"] = df["dur"].astype("int64")

    # 分流 - 游戏管线
    df_callstack = df[df["data_type"] == "callstack"].copy()
    df_gpu_waiting = df[df["data_type"] == "gpu_waiting"].copy()
    # 分流 - ArkUI 管线
    df_arkui_callstack = df[df["data_type"] == "arkui_callstack"].copy()
    df_arkui_gpu_waiting = df[df["data_type"] == "arkui_gpu_waiting"].copy()
    # 共用 GPU 计数器
    df_gpufreq = df[df["data_type"] == "gpufreq"].copy()
    df_gpu_state = df[df["data_type"] == "gpu_state"].copy()
    df_gpuload = df[df["data_type"] == "gpuload"].copy()

    # GPU 频点 + Load（两条管线共用）
    gpu_freq_avg = _weighted_avg_freq(df_gpufreq, df_gpu_state, start_ns, end_ns)
    gpu_load_avg = _weighted_avg_load(df_gpuload, start_ns, end_ns)

    # --- 管线分派 ---
    # ArkUI 管线：arkui_callstack 或 arkui_gpu_waiting 任一非空（用 RenderFrame/Acquire Fence 信号识别 ArkUI）
    if not df_arkui_callstack.empty or not df_arkui_gpu_waiting.empty:
        return _aggregate_arkui(
            ctx, df_arkui_callstack, df_arkui_gpu_waiting,
            start_ns, end_ns, tid, gpu_freq_avg, gpu_load_avg, gpu_freq_rated_max_mhz,
        )

    # 游戏管线：检查 callstack 中是否含 eglSwapBuffers（避免误判 ArkUI 线程为游戏管线）
    has_eglswap = (not df_callstack.empty
                   and df_callstack["name"].str.contains("eglSwapBuffers", na=False).any())
    if not df_gpu_waiting.empty or has_eglswap:
        return _aggregate_game(
            ctx, df_callstack, df_gpu_waiting,
            start_ns, end_ns, tid, gpu_freq_avg, gpu_load_avg, gpu_freq_rated_max_mhz,
        )

    # 两条管线均无 GPU waiting → 空汇总
    ctx.data = {
        "summary": {
            "has_gpu_wait": False,
            "pipeline_type": None,
            "pid": _fetch_pid_for_tid(ctx.sqlite_conn, int(tid)) if tid is not None and ctx.sqlite_conn else None,
            "gpu_thread_tid": None,
            "gpu_wait_count": 0,
            "gpu_wait_total_ms": 0.0,
            "gpu_wait_max_ms": 0.0,
            "eglswap_count": 0,
            "eglswap_total_ms": 0.0,
            "render_frame_count": 0,
            "render_frame_total_ms": 0.0,
            "stages_total_ms": {},
            "gpu_freq_avg_mhz": gpu_freq_avg,
            "gpu_load_avg": gpu_load_avg,
            "gpu_freq_rated_max_mhz": gpu_freq_rated_max_mhz,
        }
    }
    return ctx


def _aggregate_game(
    ctx: PreprocessContext,
    df_callstack: pd.DataFrame,
    df_gpu_waiting: pd.DataFrame,
    start_ns: int,
    end_ns: int,
    tid: Optional[int],
    gpu_freq_avg: Optional[float],
    gpu_load_avg: Optional[float],
    gpu_freq_rated_max_mhz: Optional[int],
) -> PreprocessContext:
    """游戏管线分支：eglSwapBuffers 调用栈拆解 + 同进程 GPU 线程 waiting 关联。"""
    # --- 1. 定位同进程 GPU 线程 ---
    pid: Optional[int] = None
    gpu_thread_tid: Optional[int] = None
    if tid is not None:
        pid = _fetch_pid_for_tid(ctx.sqlite_conn, int(tid)) if ctx.sqlite_conn else None
        # 优先从 cache 获取（Path A），回退到 SQL
        cache = ctx.trace_cache
        if cache is not None:
            gpu_itid = _find_gpu_thread_itid_from_cache(cache, int(tid))
            if gpu_itid is not None:
                meta = cache.thread_meta(gpu_itid)
                gpu_thread_tid = meta[1] if meta else None
        elif ctx.sqlite_conn is not None:
            gpu_thread_tid = _fetch_gpu_thread_tid(ctx.sqlite_conn, int(tid))

    has_gpu_wait = not df_gpu_waiting.empty
    gpu_wait_count = len(df_gpu_waiting)
    gpu_wait_total_ms = float(df_gpu_waiting["dur"].sum()) / 1_000_000.0 if has_gpu_wait else 0.0
    gpu_wait_max_ms = float(df_gpu_waiting["dur"].max()) / 1_000_000.0 if has_gpu_wait else 0.0

    # 无 GPU waiting → 提前返回
    if not has_gpu_wait:
        ctx.data = {
            "summary": {
                "has_gpu_wait": False,
                "pipeline_type": "game",
                "pid": pid,
                "gpu_thread_tid": None,
                "gpu_wait_count": 0,
                "gpu_wait_total_ms": 0.0,
                "gpu_wait_max_ms": 0.0,
                "eglswap_count": 0,
                "eglswap_total_ms": 0.0,
                "render_frame_count": 0,
                "render_frame_total_ms": 0.0,
                "stages_total_ms": {},
                "gpu_freq_avg_mhz": gpu_freq_avg,
                "gpu_load_avg": gpu_load_avg,
                "gpu_freq_rated_max_mhz": gpu_freq_rated_max_mhz,
            }
        }
        return ctx

    # --- 2. 定位 eglSwapBuffers 根节点（事件类：end_ts 落在窗口内）---
    df_callstack = df_callstack.copy()
    df_callstack["end_ts"] = df_callstack["ts"] + df_callstack["dur"]
    eglswap_mask = df_callstack["name"].str.contains("eglSwapBuffers", na=False)
    df_eglswap_roots = df_callstack[eglswap_mask].copy()
    df_eglswap_roots = df_eglswap_roots[
        (df_eglswap_roots["end_ts"] > start_ns) & (df_eglswap_roots["end_ts"] <= end_ns)
    ]

    eglswap_count = len(df_eglswap_roots)
    eglswap_total_ms = float(df_eglswap_roots["dur"].sum()) / 1_000_000.0 if eglswap_count > 0 else 0.0

    # --- 3. 遍历 eglSwapBuffers 子树，提取关键阶段 ---
    stages_total_ms: Dict[str, float] = {stage: 0.0 for stage in _STAGE_WHITELIST}

    if eglswap_count > 0:
        for _, root in df_eglswap_roots.iterrows():
            root_ts = int(root["ts"])
            root_end = int(root["end_ts"])
            callid = int(root["callid"])
            # 同 callid 在 [root_ts, root_end] 内的所有节点
            subtree = df_callstack[
                (df_callstack["callid"] == callid)
                & (df_callstack["ts"] >= root_ts)
                & (df_callstack["ts"] < root_end)
            ]
            # 精确匹配裸 name
            for stage in _STAGE_WHITELIST:
                stage_mask = subtree["name"] == stage
                stage_dur = subtree.loc[stage_mask, "dur"].sum()
                stages_total_ms[stage] += float(stage_dur) / 1_000_000.0

    stages_total_ms = {k: round(v, 3) for k, v in stages_total_ms.items()}

    ctx.data = {
        "summary": {
            "has_gpu_wait": True,
            "pipeline_type": "game",
            "pid": pid,
            "gpu_thread_tid": gpu_thread_tid,
            "gpu_wait_count": gpu_wait_count,
            "gpu_wait_total_ms": round(gpu_wait_total_ms, 3),
            "gpu_wait_max_ms": round(gpu_wait_max_ms, 3),
            "eglswap_count": eglswap_count,
            "eglswap_total_ms": round(eglswap_total_ms, 3),
            # 通用字段（游戏管线时与 eglswap_* 相同）
            "render_frame_count": eglswap_count,
            "render_frame_total_ms": round(eglswap_total_ms, 3),
            "stages_total_ms": stages_total_ms,
            "gpu_freq_avg_mhz": gpu_freq_avg,
            "gpu_load_avg": gpu_load_avg,
            "gpu_freq_rated_max_mhz": gpu_freq_rated_max_mhz,
        }
    }
    return ctx


def _aggregate_arkui(
    ctx: PreprocessContext,
    df_arkui_callstack: pd.DataFrame,
    df_arkui_gpu_waiting: pd.DataFrame,
    start_ns: int,
    end_ns: int,
    tid: Optional[int],
    gpu_freq_avg: Optional[float],
    gpu_load_avg: Optional[float],
    gpu_freq_rated_max_mhz: Optional[int],
) -> PreprocessContext:
    """ArkUI 管线分支：H:RenderFrame 调用栈 + H:Waiting for Acquire Fence GPU 等待。"""
    # GPU 等待统计（H:Waiting for Acquire Fence 累计耗时）
    has_gpu_wait = not df_arkui_gpu_waiting.empty
    gpu_wait_count = len(df_arkui_gpu_waiting) if has_gpu_wait else 0
    gpu_wait_total_ms = float(df_arkui_gpu_waiting["dur"].sum()) / 1_000_000.0 if has_gpu_wait else 0.0
    gpu_wait_max_ms = float(df_arkui_gpu_waiting["dur"].max()) / 1_000_000.0 if has_gpu_wait else 0.0

    # --- 定位 H:RenderFrame 根节点（区间相交）---
    render_frame_count = 0
    render_frame_total_ms = 0.0
    stages_total_ms: Dict[str, float] = {stage: 0.0 for stage in _ARKUI_STAGE_WHITELIST}

    if not df_arkui_callstack.empty:
        df_arkui_callstack = df_arkui_callstack.copy()
        df_arkui_callstack["end_ts"] = df_arkui_callstack["ts"] + df_arkui_callstack["dur"]
        # RenderFrame 根节点：name 以 H:RenderFrame 开头
        rf_mask = df_arkui_callstack["name"].str.contains("RenderFrame", na=False)
        # 排除 H:Render vsyncId: (单独事件，不应该是 RenderFrame)
        rf_mask &= ~df_arkui_callstack["name"].str.contains("vsyncId:", na=False)
        df_rf_roots = df_arkui_callstack[rf_mask].copy()
        # 区间相交
        df_rf_roots = df_rf_roots[
            (df_rf_roots["end_ts"] > start_ns) & (df_rf_roots["ts"] < end_ns)
        ]

        render_frame_count = len(df_rf_roots)
        render_frame_total_ms = float(df_rf_roots["dur"].sum()) / 1_000_000.0 if render_frame_count > 0 else 0.0

        # 遍历 RenderFrame 子树，提取 ArkUI 阶段（LIKE 模糊匹配）
        if render_frame_count > 0:
            for _, root in df_rf_roots.iterrows():
                root_ts = int(root["ts"])
                root_end = int(root["end_ts"])
                callid = int(root["callid"])
                subtree = df_arkui_callstack[
                    (df_arkui_callstack["callid"] == callid)
                    & (df_arkui_callstack["ts"] >= root_ts)
                    & (df_arkui_callstack["ts"] < root_end)
                ]
                for stage_pattern in _ARKUI_STAGE_WHITELIST:
                    # 用 contains 模糊匹配（stage_pattern 是 H:xxx 格式）
                    stage_mask = subtree["name"].str.contains(stage_pattern, na=False, regex=False)
                    stage_dur = subtree.loc[stage_mask, "dur"].sum()
                    stages_total_ms[stage_pattern] += float(stage_dur) / 1_000_000.0

    stages_total_ms = {k: round(v, 3) for k, v in stages_total_ms.items()}

    ctx.data = {
        "summary": {
            "has_gpu_wait": has_gpu_wait,
            "pipeline_type": "arkui",
            "pid": None,  # ArkUI 管线不需要 pid
            "gpu_thread_tid": tid if has_gpu_wait else None,  # Acquire Fence 线程的 tid
            "gpu_wait_count": gpu_wait_count,
            "gpu_wait_total_ms": round(gpu_wait_total_ms, 3),
            "gpu_wait_max_ms": round(gpu_wait_max_ms, 3),
            # 别名字段（ArkUI 时指向 render_frame_*）
            "eglswap_count": render_frame_count,
            "eglswap_total_ms": round(render_frame_total_ms, 3),
            # 通用字段
            "render_frame_count": render_frame_count,
            "render_frame_total_ms": round(render_frame_total_ms, 3),
            "stages_total_ms": stages_total_ms,
            "gpu_freq_avg_mhz": gpu_freq_avg,
            "gpu_load_avg": gpu_load_avg,
            "gpu_freq_rated_max_mhz": gpu_freq_rated_max_mhz,
        }
    }
    return ctx


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------


def _build_df_from_cache(
    cache: "TraceDataCache",
    start_ns: int,
    end_ns: int,
    tid: Optional[int],
) -> pd.DataFrame:
    """从 TraceDataCache 构建等效于 6 段 UNION ALL SQL 的 DataFrame。

    替代 Path A：YAML sql 已改为空 stub，数据由本函数从 cache 拉取，
    避免每帧 6 段 UNION ALL 重复扫 SQLite（59.8s → ~0s）。

    6 个分支映射：
      - SQL1 (callstack) → cache.callstack(itid) 按 tid 过滤
      - SQL2 (gpu_waiting) → cache.callstack(gpu_itid) 同进程 GPU 线程 + name 过滤
      - SQL3a (gpufreq) → cache.measure_no_cpu('gpufreq')
      - SQL3b (gpu_state) → cache.measure_no_cpu('gpu_state') value=1
      - SQL4 (gpuload) → cache.measure_no_cpu('gpuload')
      - SQL5 (arkui_callstack) → cache.callstack(itid) name LIKE 'H%RenderFrame%'
      - SQL6 (arkui_gpu_waiting) → cache.callstack(itid) name LIKE 'H%Waiting%for%Acquire%Fence%'

    callstack 只拉一次，按 name 分流为 4 个 data_type。
    """
    _, trace_end_ns = cache.trace_range()
    rows: list = []

    # --- SQL1 + SQL2 + SQL5 + SQL6: callstack（按 itid 交集过滤）---
    if tid is not None:
        itid = cache.tid_to_itid(tid)
        if itid:
            raw = cache.callstack(itid, start_ns, end_ns)
            # cache.callstack tuple: (callid, ts, dur, name, depth, parent_id, id, cookie, argsetid)
            for r in raw:
                name = r[3] or ""
                # SQL5/SQL6: ArkUI 管线分流（优先判断，因为含 RenderFrame/Acquire Fence 的是 ArkUI）
                if "RenderFrame" in name and "vsyncId:" not in name:
                    data_type = "arkui_callstack"
                elif "Waiting" in name and "Acquire" in name and "Fence" in name:
                    data_type = "arkui_gpu_waiting"
                # SQL2: 游戏管线 GPU waiting（同进程 GPU 线程的 callstack，但此处分流到 callstack
                #       因为 GPU 线程的 itid 不同于 tid 的 itid，见下方单独拉取）
                else:
                    data_type = "callstack"
                rows.append((r[1], r[2], name, r[4], r[5], r[0], None, data_type))

        # SQL2: 同进程 GPU 线程的 waiting for GPU completion
        gpu_itid = _find_gpu_thread_itid_from_cache(cache, tid)
        if gpu_itid and gpu_itid != itid:
            raw = cache.callstack(gpu_itid, start_ns, end_ns)
            for r in raw:
                name = r[3] or ""
                if "waiting for GPU completion" in name:
                    rows.append((r[1], r[2], name, r[4], r[5], r[0], None, "gpu_waiting"))

    # --- SQL3a/3b/4: measure (gpufreq, gpu_state, gpuload) ---
    for filter_name, data_type in [("gpufreq", "gpufreq"), ("gpu_state", "gpu_state"), ("gpuload", "gpuload")]:
        raw = cache.measure_no_cpu(filter_name, start_ns, end_ns)
        for r in raw:
            ts, dur, value = r[0], r[1], r[2]
            # SQL 对 dur 的 COALESCE 逻辑：NULL → trace_range.end_ts - ts
            dur_eff = dur if dur is not None else (trace_end_ns - ts) if trace_end_ns > ts else 0
            if data_type == "gpufreq":
                val = value / 1_000_000.0 if value is not None else None
            elif data_type == "gpu_state":
                # SQL3b: WHERE value = 1
                if value != 1:
                    continue
                val = 1
            else:
                val = value
            rows.append((ts, dur_eff, None, 0, 0, 0, val, data_type))

    if not rows:
        return pd.DataFrame(columns=["ts", "dur", "name", "depth", "parent_id", "callid", "value", "data_type"])

    df = pd.DataFrame(rows, columns=["ts", "dur", "name", "depth", "parent_id", "callid", "value", "data_type"])
    df["ts"] = df["ts"].astype("int64")
    df["dur"] = df["dur"].astype("int64")
    df.sort_values("ts", inplace=True)
    return df


def _find_gpu_thread_itid_from_cache(cache: "TraceDataCache", tid: int) -> Optional[int]:
    """同进程 GPU 线程的 itid（从 cache 替代 _fetch_gpu_thread_tid 的 SQL）。

    逻辑：找与 tid 同 ipid 且 name='GPU' 的线程 itid。
    """
    meta_dict = cache.thread_meta_all()
    # 找 tid 对应的 ipid
    target_itid = cache.tid_to_itid(tid)
    target_meta = meta_dict.get(target_itid)
    if not target_meta:
        return None
    target_ipid = target_meta[2]
    # 找同 ipid 且 name='GPU' 的线程
    for itid, meta in meta_dict.items():
        if meta[2] == target_ipid and meta[0] == "GPU":
            return itid
    return None


def _empty_summary(gpu_freq_rated_max_mhz: Optional[int] = None) -> Dict[str, Any]:
    return {
        "has_gpu_wait": False,
        "pipeline_type": None,
        "pid": None,
        "gpu_thread_tid": None,
        "gpu_wait_count": 0,
        "gpu_wait_total_ms": 0.0,
        "gpu_wait_max_ms": 0.0,
        "eglswap_count": 0,
        "eglswap_total_ms": 0.0,
        "render_frame_count": 0,
        "render_frame_total_ms": 0.0,
        "stages_total_ms": {},
        "gpu_freq_avg_mhz": None,
        "gpu_load_avg": None,
        "gpu_freq_rated_max_mhz": gpu_freq_rated_max_mhz,
    }


def _fetch_pid_for_tid(sqlite_conn, tid: int) -> Optional[int]:
    """tid → pid（通过 thread + process 表）。"""
    if sqlite_conn is None:
        return None
    try:
        row = sqlite_conn.execute(
            "SELECT p.pid FROM thread t JOIN process p ON t.ipid = p.ipid WHERE t.tid = ? LIMIT 1",
            (tid,),
        ).fetchone()
        return int(row[0]) if row and row[0] is not None else None
    except Exception:
        return None


def _fetch_gpu_thread_tid(sqlite_conn, tid: int) -> Optional[int]:
    """同进程 GPU 线程的 tid。"""
    if sqlite_conn is None:
        return None
    try:
        row = sqlite_conn.execute(
            """
            SELECT t2.tid FROM thread t1
            JOIN thread t2 ON t1.ipid = t2.ipid
            WHERE t1.tid = ? AND t2.name = 'GPU' LIMIT 1
            """,
            (tid,),
        ).fetchone()
        return int(row[0]) if row and row[0] is not None else None
    except Exception:
        return None


def _weighted_avg_freq(
    df_freq: pd.DataFrame, df_state: pd.DataFrame, start_ns: int, end_ns: int
) -> Optional[float]:
    """freq ∩ running 加权平均频点。

    扫描线求 gpufreq 和 gpu_state=1 的交集，按 overlap 时长加权。
    """
    if df_freq.empty or df_state.empty:
        return None

    events: List[tuple] = []
    for _, row in df_freq.iterrows():
        ts_s = int(row["ts"])
        ts_e = ts_s + int(row["dur"])
        freq = row.get("value")
        if freq is None or pd.isna(freq):
            continue
        if ts_e > ts_s:
            events.append((ts_s, "F", int(freq)))
            events.append((ts_e, "E", int(freq)))
    for _, row in df_state.iterrows():
        ts_s = int(row["ts"])
        ts_e = ts_s + int(row["dur"])
        if ts_e > ts_s:
            events.append((ts_s, "R", None))
            events.append((ts_e, "X", None))

    if not events:
        return None

    # 排序：同 ts 时，结束事件优先于开始事件（避免零长重叠）
    order_map = {"E": 0, "X": 0, "F": 1, "R": 1}
    events.sort(key=lambda e: (e[0], order_map.get(e[1], 2)))

    current_freq: Optional[int] = None
    is_running = False
    last_ts: Optional[int] = None
    weighted_sum = 0
    total_ns = 0

    for ts, typ, payload in events:
        if last_ts is not None and current_freq is not None and is_running:
            dur = ts - last_ts
            if dur > 0:
                weighted_sum += current_freq * dur
                total_ns += dur
        if typ == "F":
            current_freq = payload
        elif typ == "E":
            if current_freq == payload:
                current_freq = None
        elif typ == "R":
            is_running = True
        elif typ == "X":
            is_running = False
        last_ts = ts

    if total_ns == 0:
        return None
    return round(weighted_sum / total_ns, 2)


def _weighted_avg_load(df_load: pd.DataFrame, start_ns: int, end_ns: int) -> Optional[float]:
    """gpuload overlap 加权平均。

    按 (gpuload 区间 ∩ 查询窗口) 的 overlap 时长加权。
    """
    if df_load.empty:
        return None

    weighted_sum = 0.0
    total_overlap_ns = 0
    for _, row in df_load.iterrows():
        ts_s = int(row["ts"])
        ts_e = ts_s + int(row["dur"])
        val = row.get("value")
        if val is None or pd.isna(val):
            continue
        overlap_start = max(ts_s, start_ns)
        overlap_end = min(ts_e, end_ns)
        if overlap_end > overlap_start:
            overlap_ns = overlap_end - overlap_start
            weighted_sum += float(val) * overlap_ns
            total_overlap_ns += overlap_ns

    if total_overlap_ns == 0:
        return None
    return round(weighted_sum / total_overlap_ns, 2)
