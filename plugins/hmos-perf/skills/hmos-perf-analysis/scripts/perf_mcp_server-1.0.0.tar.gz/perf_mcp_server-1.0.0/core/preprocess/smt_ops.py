"""SMT residency 算子：计算各 CPU 核心的 MT/ST 时长。

SMT/Cluster 配置从 config/chips/chip_database.json 动态加载（通过 chip_config 模块）。
"""
from __future__ import annotations

from core.observability import get_module_logger
from typing import Any, Dict, List, Optional

import pandas as pd

from .base import PreprocessContext, PreprocessError, register_operator

log = get_module_logger(__name__)


# ---------------------------------------------------------------------------
# 扫描线算法
# ---------------------------------------------------------------------------

def _merge_intervals(intervals: List[Dict[str, int]]) -> List[Dict[str, int]]:
    """扫描线合并区间，返回互不重叠的区间集合。"""
    if not intervals:
        return []
    sorted_intervals = sorted(intervals, key=lambda x: x["start"])
    merged = [sorted_intervals[0]]
    for cur in sorted_intervals[1:]:
        last = merged[-1]
        if cur["start"] <= last["end"]:
            last["end"] = max(last["end"], cur["end"])
        else:
            merged.append(cur)
    return merged


def _smt_residency_one_core(
    cpuid: int,
    sibling_cpuid: Optional[int],
    df_freq: pd.DataFrame,
    df_run_cpuid: pd.DataFrame,
    df_run_sib: pd.DataFrame,
    is_smt: bool,
) -> List[Dict[str, Any]]:
    """为单个物理核心计算 MT/ST 时长（O(n) 扫描线算法），返回每段区间详情。"""
    events: List[tuple] = []

    if not df_freq.empty:
        freq_vals = df_freq[["ts_start", "ts_end", "freq"]].values
        for ts_start, ts_end, freq in freq_vals:
            if ts_end > ts_start:
                events.append((int(ts_start), "F", int(freq), int(ts_end)))
                events.append((int(ts_end), "E", int(freq), None))

    if not df_run_cpuid.empty:
        run_vals = df_run_cpuid[["ts_start", "ts_end", "tid", "pid"]].values
        for ts_start, ts_end, tid, pid in run_vals:
            if ts_end > ts_start:
                events.append((int(ts_start), "S", int(ts_end), (tid, pid)))
                events.append((int(ts_end), "X", None, (None, None)))

    if not df_run_sib.empty:
        sib_vals = df_run_sib[["ts_start", "ts_end"]].values
        for ts_start, ts_end in sib_vals:
            if ts_end > ts_start:
                events.append((int(ts_start), "RS", int(ts_end), None))
                events.append((int(ts_end), "RX", None, None))

    if not events:
        return []

    def event_key(x):
        ts, typ = x[0], x[1]
        order = {"E": 0, "X": 0, "RX": 0, "F": 1, "S": 1, "RS": 1}
        return (ts, order.get(typ, 2))

    events.sort(key=event_key)

    current_freq: Optional[int] = None
    cpu_run_end: Optional[int] = None
    cpu_run_tid: Optional[int] = None
    cpu_run_pid: Optional[int] = None
    sib_run_end: Optional[int] = None
    last_ts: Optional[int] = None

    intervals: List[Dict[str, Any]] = []

    for event in events:
        ts, typ = event[0], event[1]

        if last_ts is not None and current_freq is not None:
            dur = ts - last_ts
            if dur > 0:
                cpu_running = (cpu_run_end is not None and cpu_run_end > last_ts)
                sib_running = (sib_run_end is not None and sib_run_end > last_ts)
                if cpu_running:
                    is_mt = is_smt and sib_running

                    def _to_int_or_none(v):
                        if v is None or (isinstance(v, float) and v != v):
                            return None
                        return int(v)

                    intervals.append({
                        "ts_start": int(last_ts),
                        "ts_end": int(ts),
                        "freq": int(current_freq),
                        "tid": _to_int_or_none(cpu_run_tid),
                        "pid": _to_int_or_none(cpu_run_pid),
                        "is_mt": is_mt,
                    })

        if typ == "F":
            current_freq = event[2]
        elif typ == "E":
            if current_freq == event[2]:
                current_freq = None
        elif typ == "S":
            cpu_run_end = event[2]
            cpu_run_tid = event[3][0] if event[3] else None
            cpu_run_pid = event[3][1] if event[3] else None
        elif typ == "X":
            if cpu_run_end == ts:
                cpu_run_end = None
                cpu_run_tid = None
                cpu_run_pid = None
        elif typ == "RS":
            sib_run_end = event[2]
        elif typ == "RX":
            if sib_run_end == ts:
                sib_run_end = None

        last_ts = ts

    return intervals


@register_operator("smt_residency")
def smt_residency(ctx: PreprocessContext) -> PreprocessContext:
    """计算 SMT MT/ST residency。

    从 chip_config 模块获取芯片配置，自动检测或使用显式传入的 chip_model。

    每段 Running 区间标记 is_mt 后，按用户需求聚合：
    - 未指定 tid/pid：系统级，group by cpuid, freq
    - 指定 tid/pid：线程级，group by tid/pid, cpuid, freq
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame):
        raise PreprocessError("smt_residency: ctx.data 期望为 DataFrame")

    df = df.dropna(subset=["ts_end"])

    cluster_filter = ctx.params.get("cluster")
    tid_filter = ctx.params.get("tid")
    pid_filter = ctx.params.get("pid")

    # 从连接级缓存获取芯片配置(若 cache 不可用,降级到空 dict)
    cache = ctx.trace_cache
    if cache is None:
        raise PreprocessError("smt_residency: trace_cache 不可用")
    chip_config = cache.chip_config()
    if not chip_config:
        raise PreprocessError("无法获取芯片配置")

    actual_chip_model = chip_config.get("chip_model")
    log.info("smt_residency: chip=%s, cluster=%s, tid=%s, pid=%s",
             actual_chip_model, cluster_filter, tid_filter, pid_filter)

    # 构建 cpuid -> cluster 映射
    cpuid_cluster_map: Dict[int, Optional[str]] = {}
    for cpuid in sorted(df["cpuid"].unique()):
        cpuid_cluster_map[cpuid] = cache.cluster_of(int(cpuid))

    if cluster_filter:
        filtered_cpuid_list = [c for c, cl in cpuid_cluster_map.items() if cl == cluster_filter]
    else:
        filtered_cpuid_list = sorted(cpuid_cluster_map.keys())

    # 预分离 running/freq
    df_running = df[df["data_type"] == "running"]
    df_freq = df[df["data_type"] == "freq"]

    # tid/pid 过滤仅影响线程级聚合阶段，不影响扫描线的 MT/ST 判定
    # MT/ST 判定需要所有线程的 running 事件才能正确计算同胞核重叠

    # 预构建索引
    freq_by_cpuid: Dict[int, pd.DataFrame] = {}
    for cpuid in filtered_cpuid_list:
        freq_by_cpuid[cpuid] = df_freq[df_freq["cpuid"] == cpuid]

    running_by_cpuid: Dict[int, pd.DataFrame] = {}
    for cpuid in filtered_cpuid_list:
        running_by_cpuid[cpuid] = df_running[df_running["cpuid"] == cpuid]

    # 收集 sibling 对需要的 CPU 数据
    sibling_pairs = set()
    for cpuid in filtered_cpuid_list:
        sib = cache.sibling_of(int(cpuid))
        if sib is not None:
            sibling_pairs.add((min(cpuid, sib), max(cpuid, sib)))

    for cpuid, sib in sibling_pairs:
        if sib not in running_by_cpuid:
            running_by_cpuid[sib] = df_running[df_running["cpuid"] == sib]

    # 计算每段区间的 MT/ST
    all_intervals: List[Dict[str, Any]] = []

    for cpuid in filtered_cpuid_list:
        sibling_cpuid = cache.sibling_of(int(cpuid))
        cluster = cpuid_cluster_map.get(cpuid, "unknown")
        smt_on = cache.sibling_of(int(cpuid)) is not None

        df_freq_core = freq_by_cpuid.get(cpuid)
        if df_freq_core is None or df_freq_core.empty:
            continue

        df_run_cpuid = running_by_cpuid.get(cpuid, pd.DataFrame())
        df_run_sib = running_by_cpuid.get(sibling_cpuid, pd.DataFrame()) if sibling_cpuid else pd.DataFrame()

        intervals = _smt_residency_one_core(
            cpuid, sibling_cpuid, df_freq_core, df_run_cpuid, df_run_sib, smt_on
        )
        for iv in intervals:
            iv["cpuid"] = int(cpuid)
            iv["cluster"] = cluster
        all_intervals.extend(intervals)

    # 聚合输出
    if tid_filter is not None or pid_filter is not None:
        results = _aggregate_thread_level(all_intervals, tid_filter, pid_filter)
    else:
        results = _aggregate_system_level(all_intervals)

    # 构建 cluster summary: 每个 cluster 的总时长、平均频点
    # tid 过滤只在线程级分析时生效（只统计目标线程在各 cluster 的贡献）
    stats_intervals = all_intervals
    if tid_filter is not None or pid_filter is not None:
        stats_intervals = [
            iv for iv in all_intervals
            if (tid_filter is None or iv.get("tid") == tid_filter)
            and (pid_filter is None or iv.get("pid") == pid_filter)
        ]

    cluster_stats: Dict[str, Dict[str, Any]] = {}
    for iv in stats_intervals:
        cl = iv.get("cluster", "unknown")
        if cl not in cluster_stats:
            cluster_stats[cl] = {"total_duration_ms": 0.0, "weighted_freq_sum": 0.0, "st_duration_ms": 0.0, "mt_duration_ms": 0.0}
        dur = (iv["ts_end"] - iv["ts_start"]) / 1e6
        cluster_stats[cl]["total_duration_ms"] += dur
        cluster_stats[cl]["weighted_freq_sum"] += dur * iv["freq"]
        if iv.get("is_mt"):
            cluster_stats[cl]["mt_duration_ms"] += dur
        else:
            cluster_stats[cl]["st_duration_ms"] += dur

    total_all = sum(s["total_duration_ms"] for s in cluster_stats.values())
    for cl, stats in cluster_stats.items():
        total = stats["total_duration_ms"]
        avg_freq = stats["weighted_freq_sum"] / total if total > 0 else 0
        st_ratio = stats["st_duration_ms"] / total if total > 0 else 0
        mt_ratio = stats["mt_duration_ms"] / total if total > 0 else 0
        cluster_stats[cl] = {
            "total_duration_ms": round(total, 3),
            "avg_freq_mhz": round(avg_freq, 1),
            "duration_ratio": round(total / total_all * 100, 1) if total_all > 0 else 0,
            "st_duration_ms": round(stats["st_duration_ms"], 3),
            "mt_duration_ms": round(stats["mt_duration_ms"], 3),
            "st_ratio": round(st_ratio * 100, 1),
            "mt_ratio": round(mt_ratio * 100, 1),
        }

    # 计算系统级算力供给
    total_system_compute = 0.0
    for cl, stats in cluster_stats.items():
        # 获取集群的 freq_max 和 compute_scale
        cluster_cfg = None
        for c in chip_config.get("clusters", []):
            if c.get("cluster_name") == cl:
                cluster_cfg = c
                break
        if not cluster_cfg:
            continue
        freq_max = cluster_cfg.get("freq_max_mhz", 1)
        compute_scale = cluster_cfg.get("compute_scale", 1.0)

        # ST效率=100%, MT效率=60%
        st_eff = 1.0
        mt_eff = 0.6
        cluster_eff = stats["st_ratio"] / 100 * st_eff + stats["mt_ratio"] / 100 * mt_eff

        # 频率占比
        freq_ratio = stats["avg_freq_mhz"] / freq_max if freq_max > 0 else 0

        # 该集群的算力供给贡献（加权时长比例）
        cluster_compute = cluster_eff * freq_ratio * compute_scale * stats["duration_ratio"] / 100
        total_system_compute += cluster_compute

    summary = {
        "tid": tid_filter,
        "pid": pid_filter,
        "cluster_stats": dict(sorted(cluster_stats.items())),
        "compute_supply": f"{round(total_system_compute * 100, 1)}%",
    }

    ctx.data = {"summary": summary, "data": results}
    ctx.meta["chip_model"] = actual_chip_model
    ctx.meta["cpu_count"] = len(results)
    log.debug("smt_residency 完成: %d 条记录", len(results))
    return ctx


def _aggregate_system_level(intervals: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """系统级聚合: group by cpuid, freq → ST/MT 时长."""
    agg: Dict[tuple, Dict[str, Any]] = {}
    for iv in intervals:
        key = (iv["cpuid"], iv["freq"])
        if key not in agg:
            agg[key] = {
                "cpuid": iv["cpuid"],
                "freq": iv["freq"],
                "cluster": iv["cluster"],
                "mt_duration_ms": 0,
                "st_duration_ms": 0,
            }
        dur = iv["ts_end"] - iv["ts_start"]
        if iv["is_mt"]:
            agg[key]["mt_duration_ms"] += round(dur / 1e6, 3)
        else:
            agg[key]["st_duration_ms"] += round(dur / 1e6, 3)
    return sorted(agg.values(), key=lambda x: (x["cpuid"], x["freq"]))


def _aggregate_thread_level(
    intervals: List[Dict[str, Any]],
    tid_filter: Optional[int],
    pid_filter: Optional[int],
) -> List[Dict[str, Any]]:
    """线程级聚合: group by cpuid, freq → ST/MT 时长（不含 tid/pid）。"""
    agg: Dict[tuple, Dict[str, Any]] = {}
    for iv in intervals:
        iv_tid = iv.get("tid")
        iv_pid = iv.get("pid")
        if tid_filter is not None and iv_tid != tid_filter:
            continue
        if pid_filter is not None and iv_pid != pid_filter:
            continue

        key = (iv["cpuid"], iv["freq"])
        if key not in agg:
            agg[key] = {
                "cpuid": iv["cpuid"],
                "freq": iv["freq"],
                "cluster": iv["cluster"],
                "mt_duration_ms": 0,
                "st_duration_ms": 0,
            }
        dur = iv["ts_end"] - iv["ts_start"]
        if iv["is_mt"]:
            agg[key]["mt_duration_ms"] += round(dur / 1e6, 3)
        else:
            agg[key]["st_duration_ms"] += round(dur / 1e6, 3)
    return sorted(agg.values(), key=lambda x: (x["cpuid"], x["freq"]))
