"""Skill 路由层。

把 SkillDef / SkillStep 数据类组装为 MCP `get_skill` / `list_skills`
返回的 JSON 结构。

职责:
- get_skill: 完整工作流定义（含 steps、rules、default_indicator_params、reasoning_hints）
- list_skills: 供 Agent 做意图路由的最小元数据列表
- routing_table: 将 high_priority / low_priority_fallback 路由表暴露给 Agent
- indicator_set 简写展开: Skill 中写 `indicator_set: jank_essentials`，
  路由层自动展开为 `indicators: [...]` 数组（Todo: 详细实现）
"""
from __future__ import annotations


from core.registry import ConfigRegistry


class SkillRouter:
    """组装 Skill 元数据响应。"""

    def __init__(self, registry: ConfigRegistry):
        self.registry = registry

    # ---------- list_skills ----------

    def list_skills_payload(self) -> list[dict]:
        """返回所有 Skill 的简略列表（含 input_params 摘要），用于 Agent 做意图匹配。"""
        return [
            {
                "skill_id": s.skill_id,
                "name": s.name,
                "triggers": s.triggers,
                "priority": s.priority,
                "description": s.description,
                "input_params": self._serialize_input_params_summary(s.input_params),
            }
            for s in self.registry.skills.values()
        ]

    def _serialize_input_params_summary(self, params: list) -> list[dict]:
        """序列化 input_params 摘要，供路由表使用。

        - 跳过 trace_path_or_dir（已是 run_skill 顶层参数）
        - 始终包含: name, type, required
        - required=false 时额外包含 description（引导 AI 何时该传）
        """
        result = []
        for p in params:
            if p.name == "trace_path_or_dir":
                continue
            d: dict = {"name": p.name, "type": p.type, "required": p.required}
            if not p.required:
                d["description"] = p.description
            result.append(d)
        return result

    def routing_table_payload(self) -> dict:
        """优先级路由表，由 Agent 决定先匹配 high 再 fallback low。"""
        high = []
        low = []
        for s in self.registry.skills.values():
            entry = {"skill_id": s.skill_id, "triggers": s.triggers}
            if s.priority == "low":
                low.append(entry)
            else:
                high.append(entry)

        return {
            "high_priority": high,
            "low_priority_fallback": low,
            "routing_rules": [
                "先匹配 high_priority，一旦匹配立即执行对应 Skill",
                "如果完全不匹配 high_priority，执行 priority=low 的 fallback Skill",
                "如果同时匹配 high 和 low（如『卡顿且看看温度』），只执行 high",
                "如果连 fallback Skill 也匹配不上，反问用户具体想查什么",
            ],
        }

    # ---------- get_skill ----------

    def get_skill_payload(self, skill_id: str) -> dict:
        """返回 get_skill 的完整 JSON。"""
        skill = self.registry.get_skill(skill_id)
        if skill is None:
            return {"error": f"Skill '{skill_id}' not found. Call list_skills() first."}

        return {
            "skill_id": skill.skill_id,
            "name": skill.name,
            "description": skill.description,
            "trigger_condition": f"用户提到: {', '.join(skill.triggers)}",
            "priority": skill.priority,
            "input_params": [self._serialize_input_param(p) for p in skill.input_params],
            "steps": [self._serialize_step(s) for s in skill.steps],
            "rules": skill.rules,
        }

    def _serialize_input_param(self, p) -> dict:
        """将 InputParam 序列化为 dict，仅包含非空的可选字段。"""
        d: dict = {
            "name": p.name,
            "type": p.type,
            "required": p.required,
            "description": p.description,
        }
        if p.default is not None:
            d["default"] = p.default
        if p.example is not None:
            d["example"] = p.example
        if p.enum:
            d["enum"] = p.enum
        return d

    def _serialize_step(self, step) -> dict:
        return {
            "step": step.step,
            "tool": step.tool,
            "action": step.action,
            "args": self._expand_indicator_set(step.args),
            "output": step.output,
            "iterate": step.iterate,
            "instruction": step.instruction,
            "default_indicator_params": step.default_indicator_params,
        }

    # ---------- indicator_set 简写展开 ----------

    def _expand_indicator_set(self, args: dict) -> dict:
        """如果 Skill step.args 写了 `indicator_set: <group_name>`，
        展开为 `indicators: [<atomic1>, <atomic2>, ...]`。
        同时将 group 的 override_params 合并到 default_indicator_params。
        """
        indicator_set = args.get("indicator_set")
        if not indicator_set:
            return dict(args)

        group_meta = self.registry.indicators.get(indicator_set)
        if not group_meta or group_meta.type != "group":
            # 非 group 或不存在，保持原样
            return dict(args)

        # 展开为原子指标列表
        atomic_names = [child["name"] for child in group_meta.expands_to]
        result = dict(args)
        result["indicators"] = atomic_names
        del result["indicator_set"]

        # 将 group 的 override_params 合并到 default_indicator_params
        if group_meta.expands_to:
            for child in group_meta.expands_to:
                override_params = child.get("override_params") or {}
                if override_params:
                    if "default_indicator_params" not in result:
                        result["default_indicator_params"] = {}
                    indicator_name = child["name"]
                    if indicator_name not in result["default_indicator_params"]:
                        result["default_indicator_params"][indicator_name] = {}
                    result["default_indicator_params"][indicator_name].update(override_params)

        return result


# ---------------------------------------------------------------------------
# 模块级便捷函数（被 server.py 直接调用）
# ---------------------------------------------------------------------------

def list_skills(registry: ConfigRegistry) -> list[dict]:
    return SkillRouter(registry).list_skills_payload()


def get_skill(registry: ConfigRegistry, skill_id: str) -> dict:
    return SkillRouter(registry).get_skill_payload(skill_id)


def routing_table(registry: ConfigRegistry) -> dict:
    return SkillRouter(registry).routing_table_payload()
