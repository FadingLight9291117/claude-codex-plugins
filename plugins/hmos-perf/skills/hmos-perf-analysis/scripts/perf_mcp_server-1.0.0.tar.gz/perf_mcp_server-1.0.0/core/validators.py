"""YAML 校验工具。

被 ConfigRegistry 在加载阶段调用，也可由 scripts/validate_yaml.py
作为 CI 前置校验脚本独立运行。

校验项:
- YAML 文件语法
- atomic 必须含 `sql`
- group 必须含 `expands_to` 且无循环依赖
- atomic 的 sql_params 必须覆盖 SQL 中所有 :xxx 占位符（除 template_vars）
- result_schema.type ∈ {array, object, scalar}
- 指标名必须是合法标识符
- enum 值类型必须与 type 一致
- Skill 步骤引用的 tool 必须真实存在
- result_schema 时序指标必须含 ts/value 列
- preprocess.pipeline 算子必须在注册表中
- atomic 指标必须含 start_ms/end_ms
- group expands_to 必须引用已注册的指标
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Set

import yaml


VALID_INDICATOR_NAME = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")
VALID_INPUT_PARAM_NAME = re.compile(r"^[a-z][a-z0-9_]*$")
VALID_SCHEMA_TYPES = {"array", "object", "scalar"}
VALID_INPUT_PARAM_TYPES = {"string", "number", "integer", "boolean"}

# 文档章节引用（用于 Fix: 提示）
DOC_REF = "docs/YAML_GUIDE.md"
SQL_PARAMS_REF = f"{DOC_REF} §2.3"
PREPROCESS_REF = f"{DOC_REF} §6.2"
ATOMIC_PARAM_REF = f"{DOC_REF} §2.1"
EXPANDS_TO_REF = f"{DOC_REF} §4.2"

# 导入预处理算子注册表（副作用：填充 OPERATORS）
from core.preprocess import OPERATORS  # noqa: E402


# ---------------------------------------------------------------------------
# 错误聚合容器
# ---------------------------------------------------------------------------

class ValidationError(Exception):
    """单条校验失败异常。"""


class ValidationReport:
    """聚合多条校验结果，校验完成后由调用方决定是否抛出。"""

    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def add_error(self, msg: str) -> None:
        self.errors.append(msg)

    def add_warning(self, msg: str) -> None:
        self.warnings.append(msg)

    @property
    def ok(self) -> bool:
        return not self.errors

    def raise_if_failed(self) -> None:
        if self.errors:
            joined = "\n".join(f"  - {e}" for e in self.errors)
            raise ValidationError(f"YAML 校验失败:\n{joined}")


# ---------------------------------------------------------------------------
# 顶层入口
# ---------------------------------------------------------------------------

def validate_config_dir(config_dir: str | Path) -> ValidationReport:
    """递归扫描 config_dir 下所有 YAML 文件并执行校验。"""
    report = ValidationReport()
    root = Path(config_dir)

    indicators = _load_all_indicators(root, report)
    skills = _load_all_skills(root, report)

    _validate_indicator_schema(indicators, report)
    _validate_sql_placeholder_coverage(indicators, report)
    _validate_preprocess_pipeline_operators(indicators, report)
    _validate_atomic_required_params(indicators, report)
    _validate_group_expands_to(indicators, report)
    _validate_skills(skills, indicators, report)
    _validate_input_params(skills, report)

    return report


# ---------------------------------------------------------------------------
# 加载阶段（容错读取，记录语法错误）
# ---------------------------------------------------------------------------

def _load_all_indicators(root: Path, report: ValidationReport) -> dict[str, dict]:
    indicators: dict[str, dict] = {}
    ind_root = root / "indicators"
    if not ind_root.exists():
        return indicators

    for yaml_file in sorted(ind_root.rglob("*.yaml")):
        try:
            data = yaml.safe_load(yaml_file.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError as e:
            report.add_error(f"{yaml_file}: YAML 语法错误 -> {e}")
            continue

        for item in data.get("indicators", []):
            name = item.get("name")
            if not name:
                report.add_error(f"{yaml_file}: 指标缺少 name 字段")
                continue
            if name in indicators:
                report.add_error(
                    f"{yaml_file}: 指标 {name} 重复定义"
                )
                continue
            indicators[name] = item

    return indicators


def _load_all_skills(root: Path, report: ValidationReport) -> dict[str, dict]:
    skills: dict[str, dict] = {}
    sk_root = root / "skills"
    if not sk_root.exists():
        return skills

    for yaml_file in sorted(sk_root.glob("*.yaml")):
        try:
            data = yaml.safe_load(yaml_file.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError as e:
            report.add_error(f"{yaml_file}: YAML 语法错误 -> {e}")
            continue

        skill_id = data.get("skill_id")
        if not skill_id:
            report.add_error(f"{yaml_file}: Skill 缺少 skill_id 字段")
            continue
        if skill_id in skills:
            report.add_error(f"{yaml_file}: skill_id={skill_id} 重复定义")
            continue
        skills[skill_id] = data

    return skills


# ---------------------------------------------------------------------------
# 单项校验
# ---------------------------------------------------------------------------

def _validate_indicator_schema(indicators: dict[str, dict], report: ValidationReport) -> None:
    for name, item in indicators.items():
        if not VALID_INDICATOR_NAME.match(name):
            report.add_error(f"指标 {name} 名称非法（仅允许字母/数字/下划线，且不以数字开头）")

        kind = item.get("type")
        if kind not in ("atomic", "group"):
            report.add_error(f"指标 {name} 的 type 必须是 atomic 或 group, 实际: {kind}")
            continue

        if kind == "atomic":
            if not item.get("sql"):
                report.add_error(f"原子指标 {name} 缺少 sql 字段")
            schema = item.get("result_schema") or {}
            schema_type = schema.get("type")
            if schema_type and schema_type not in VALID_SCHEMA_TYPES:
                report.add_error(
                    f"指标 {name} 的 result_schema.type={schema_type} 非法，"
                    f"仅允许 {VALID_SCHEMA_TYPES}"
                )
        else:  # group
            if not item.get("expands_to"):
                report.add_error(f"组合指标 {name} 缺少 expands_to 字段")


def _validate_sql_placeholder_coverage(
    indicators: dict[str, dict],
    report: ValidationReport,
) -> None:
    """校验 SQL 占位符是否在 sql_params/template_vars 中声明。

    增强错误信息：包含文件路径、行号、Fix: 指引和文档引用。
    """
    for name, item in indicators.items():
        if item.get("type") != "atomic":
            continue
        sql = item.get("sql") or ""
        declared = {p["name"] for p in item.get("sql_params", [])}
        declared |= set((item.get("template_vars") or {}).keys())
        placeholders = set(re.findall(r":(\w+)", sql))
        missing = placeholders - declared
        if missing:
            file_path = item.get("_src_file", "config/indicators")
            line_num = item.get("_src_line", "?")
            missing_list = sorted(missing)
            if len(missing_list) == 1:
                placeholder = missing_list[0]
                report.add_error(
                    f"Error: {file_path} line {line_num} uses :{placeholder} "
                    f"but sql_params lacks it. "
                    f"Fix: Add {placeholder} to sql_params with default: null, "
                    f"or remove :{placeholder} from SQL. See {SQL_PARAMS_REF}"
                )
            else:
                report.add_error(
                    f"Error: {file_path} line {line_num} uses {missing_list} "
                    f"but sql_params lacks them. "
                    f"Fix: Add each to sql_params with default: null, "
                    f"or remove them from SQL. See {SQL_PARAMS_REF}"
                )


def _validate_preprocess_pipeline_operators(
    indicators: dict[str, dict],
    report: ValidationReport,
) -> None:
    """校验 preprocess.pipeline 中引用的算子是否在注册表中。"""
    for name, item in indicators.items():
        preprocess = item.get("preprocess")
        if not preprocess:
            continue
        pipeline = preprocess.get("pipeline")
        if not pipeline:
            continue

        for step in pipeline:
            op_name = step.get("op")
            if not op_name:
                continue
            if op_name not in OPERATORS:
                file_path = item.get("_src_file", "config/indicators/<name>.yaml")
                report.add_error(
                    f"Error: {file_path} references op '{op_name}' not found in registry. "
                    f"Fix: Register it in core/preprocess/<module>.py with "
                    f"@register_operator('{op_name}'), or check spelling. "
                    f"See {PREPROCESS_REF}"
                )


def _validate_atomic_required_params(
    indicators: dict[str, dict],
    report: ValidationReport,
) -> None:
    """校验 atomic 指标是否包含必需的 start_ms/end_ms 参数。"""
    REQUIRED_ATOMIC_PARAMS = {"start_ms", "end_ms"}

    for name, item in indicators.items():
        if item.get("type") != "atomic":
            continue

        sql_params = item.get("sql_params", [])
        param_names = {p["name"] for p in sql_params}

        for required_param in REQUIRED_ATOMIC_PARAMS:
            if required_param not in param_names:
                report.add_error(
                    f"Error: config/indicators/{name}.yaml is atomic but missing required "
                    f"param '{required_param}'. "
                    f"Fix: Add {required_param} to sql_params: {{name: {required_param}, "
                    f"type: float, required: true, description: '...'}}. "
                    f"See {ATOMIC_PARAM_REF}"
                )


def _validate_group_expands_to(
    indicators: dict[str, dict],
    report: ValidationReport,
) -> None:
    """校验 group 指标的 expands_to 是否引用已注册的指标。"""
    # 构建所有已注册的指标名集合
    registered_indicators: Set[str] = set(indicators.keys())

    for name, item in indicators.items():
        if item.get("type") != "group":
            continue

        expands_to = item.get("expands_to", [])
        if not expands_to:
            continue

        for entry in expands_to:
            # expands_to 可以是字符串或 {name: ..., override_params: ...}
            if isinstance(entry, dict):
                ref_name = entry.get("name")
            else:
                ref_name = entry

            if ref_name and ref_name not in registered_indicators:
                file_path = item.get("_src_file", f"config/indicators/<category>/{name}.yaml")
                report.add_error(
                    f"Error: {file_path} expands_to references "
                    f"'{ref_name}' which is not registered. "
                    f"Fix: Check that all names in expands_to match actual indicator names "
                    f"in config/indicators/. See {EXPANDS_TO_REF}"
                )


def _validate_skills(
    skills: dict[str, dict],
    indicators: dict[str, dict],
    report: ValidationReport,
) -> None:
    # 收集所有已知的原子指标名（用于校验 default_indicator_params）
    atomic_indicator_names = {
        name for name, meta in indicators.items() if meta.get("type") == "atomic"
    }

    for skill_id, skill in skills.items():
        if not skill.get("steps"):
            report.add_warning(f"Skill {skill_id} 没有 steps")
        if not skill.get("triggers"):
            report.add_warning(f"Skill {skill_id} 没有 triggers")

        # 校验 step 中的 default_indicator_params
        for step in skill.get("steps", []):
            default_params = step.get("default_indicator_params")
            if not default_params:
                continue
            if not isinstance(default_params, dict):
                report.add_error(
                    f"Skill {skill_id} step {step.get('step')} 的 "
                    f"default_indicator_params 必须为 dict，实际为 {type(default_params).__name__}"
                )
                continue

            for indicator_name, param_dict in default_params.items():
                if not isinstance(param_dict, dict):
                    report.add_error(
                        f"Skill {skill_id} step {step.get('step')} 的 "
                        f"default_indicator_params['{indicator_name}'] 必须为 dict，"
                        f"实际为 {type(param_dict).__name__}"
                    )
                    continue
                # 检查引用的指标是否为已注册的原子指标
                if indicator_name not in atomic_indicator_names:
                    report.add_warning(
                        f"Skill {skill_id} step {step.get('step')} 的 "
                        f"default_indicator_params 引用了未知指标 '{indicator_name}'"
                    )


def _validate_input_params(
    skills: dict[str, dict],
    report: ValidationReport,
) -> None:
    """校验 Skill input_params 的结构合法性。"""
    for skill_id, skill in skills.items():
        raw_params = skill.get("input_params", [])
        for i, item in enumerate(raw_params):
            # 字符串形式（向后兼容）— 仅检查 name 合法性
            if isinstance(item, str):
                if not VALID_INPUT_PARAM_NAME.match(item):
                    report.add_error(
                        f"Skill {skill_id} input_params[{i}] name='{item}' 非法，"
                        f"仅允许小写字母开头+[a-z0-9_]"
                    )
                continue

            # 结构化形式
            if not isinstance(item, dict):
                report.add_error(
                    f"Skill {skill_id} input_params[{i}] 必须为 string 或 dict，"
                    f"实际为 {type(item).__name__}"
                )
                continue

            name = item.get("name")
            if not name:
                report.add_error(
                    f"Skill {skill_id} input_params[{i}] 缺少 name 字段"
                )
                continue

            if not VALID_INPUT_PARAM_NAME.match(name):
                report.add_error(
                    f"Skill {skill_id} input_params[{i}] name='{name}' 非法，"
                    f"仅允许小写字母开头+[a-z0-9_]"
                )

            param_type = item.get("type", "string")
            if param_type not in VALID_INPUT_PARAM_TYPES:
                report.add_error(
                    f"Skill {skill_id} input_params[{i}] type='{param_type}' 非法，"
                    f"仅允许 {VALID_INPUT_PARAM_TYPES}"
                )

            required = item.get("required", True)
            default = item.get("default")
            if required and default is not None:
                report.add_warning(
                    f"Skill {skill_id} input_params[{i}] name='{name}' "
                    f"required=true 但设置了 default，语义矛盾"
                )

            enum_values = item.get("enum")
            if enum_values is not None:
                if not isinstance(enum_values, list):
                    report.add_error(
                        f"Skill {skill_id} input_params[{i}] enum 必须为 list"
                    )
                elif len(enum_values) == 0:
                    report.add_error(
                        f"Skill {skill_id} input_params[{i}] enum 不能为空列表"
                    )
                else:
                    type_check = {
                        "string": lambda v: isinstance(v, str),
                        "number": lambda v: isinstance(v, (int, float)),
                        "integer": lambda v: isinstance(v, int) and not isinstance(v, bool),
                        "boolean": lambda v: isinstance(v, bool),
                    }.get(param_type, lambda v: True)
                    for v in enum_values:
                        if not type_check(v):
                            report.add_error(
                                f"Skill {skill_id} input_params[{i}] enum 值 {v!r} "
                                f"类型与 type='{param_type}' 不一致"
                            )
