"""结构化日志基础设施。

职责：
- 提供模块级 logger，复用 Python logging
- 输出 JSON Lines 格式到 logs/observability/{date}/observability.jsonl
- session_id 自动注入到每条日志
- 同步写本地 SSD（关键事件量小，延迟可忽略）
- 按日期懒切换文件 handler

两种 logger 使用方式：
1. ObservabilityLogger（推荐新代码）：log.info("event_name", session_id=sid, key=value)
2. get_module_logger（兼容旧代码）：log = get_module_logger(__name__)
   原有 log.info("msg %s", arg) 调用不用改，自动写入 observability 文件
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

# 日志输出根目录
_LOG_BASE_DIR = Path(__file__).parent.parent / "logs" / "observability"

# 已加载的 logger 缓存: module_name -> ObservabilityLogger
_LOGGERS: dict[str, "ObservabilityLogger"] = {}

# 全局 session_id：用于跨调用链透传（skill_executor → query_engine → preprocess）
_OBS_SESSION_ID: str = ""


def set_observability_session_id(sid: str) -> None:
    """设置当前 observability session_id，供 skill_executor 入口调用。"""
    global _OBS_SESSION_ID
    _OBS_SESSION_ID = sid


def get_observability_session_id() -> str:
    """获取当前 observability session_id，供 query_engine / preprocess 读取。"""
    return _OBS_SESSION_ID


class JSONFormatter(logging.Formatter):
    """将 log record 转为 JSON string，每行一条。

    兼容两种调用方式：
    - ObservabilityLogger: event 来自 extra["event"]
    - 标准 logging: event 用 record.getMessage()（兼容旧代码 log.info("msg %s", arg)）
    """

    def format(self, record: logging.LogRecord) -> str:
        fields = {
            "ts": getattr(record, "ts", datetime.utcnow().isoformat() + "Z"),
            "level": record.levelname,
            "module": getattr(record, "_obs_module", record.module),
            "event": getattr(record, "event", None) or record.getMessage(),
            "session_id": getattr(record, "_obs_session_id", ""),
            "data": getattr(record, "data", {}),
        }
        return json.dumps(fields, ensure_ascii=False)


class _LazyFileHandler(logging.Handler):
    """每天一个文件，按日期懒切换，避免每分钟创建新文件。"""

    def __init__(self, module: str, base_dir: Path):
        super().__init__(logging.DEBUG)
        self.module = module
        self.base_dir = base_dir
        self._current_date: str | None = None
        self._handler: logging.FileHandler | None = None

    def _get_path(self, date_str: str) -> Path:
        day_dir = self.base_dir / date_str
        day_dir.mkdir(parents=True, exist_ok=True)
        return day_dir / "observability.jsonl"

    def _ensure_handler(self) -> logging.FileHandler:
        today = datetime.utcnow().strftime("%Y-%m-%d")
        if today != self._current_date or self._handler is None:
            if self._handler is not None:
                self._handler.close()
                self._handler = None
            self._handler = logging.FileHandler(
                self._get_path(today),
                encoding="utf-8",
            )
            self._handler.setFormatter(JSONFormatter())
            self._current_date = today
        return self._handler

    def emit(self, record: logging.LogRecord) -> None:
        handler = self._ensure_handler()
        handler.emit(record)

    def flush(self) -> None:
        if self._handler is not None:
            self._handler.flush()

    def close(self) -> None:
        if self._handler is not None:
            self._handler.close()
        super().close()


class ObservabilityLogger:
    """模块级结构化 logger，输出 JSON Lines。

    用法：
        log = get_observability_logger("skill_executor")
        log.info("skill_started", session_id="a7c20955", data={"skill_id": "launch_perf"})
    """

    def __init__(self, module: str):
        self.module = module
        self._logger = logging.getLogger(f"obs.{module}")
        self._logger.setLevel(logging.DEBUG)
        self._logger.propagate = False
        self._lazy_handler = _LazyFileHandler(module, _LOG_BASE_DIR)
        # 添加 lazy handler（只添加一次）
        if not self._logger.handlers:
            self._logger.addHandler(self._lazy_handler)

    def _log(
        self,
        level: int,
        event: str,
        session_id: str = "",
        data: dict | None = None,
    ) -> None:
        extra = {
            "event": event,
            "_obs_module": self.module,
            "_obs_session_id": session_id,
            "data": data or {},
        }
        self._logger.log(level, event, extra=extra)

    def debug(self, event: str, session_id: str = "", **kwargs: Any) -> None:
        self._log(logging.DEBUG, event, session_id, kwargs or None)

    def info(self, event: str, session_id: str = "", **kwargs: Any) -> None:
        self._log(logging.INFO, event, session_id, kwargs or None)

    def warn(self, event: str, session_id: str = "", **kwargs: Any) -> None:
        self._log(logging.WARNING, event, session_id, kwargs or None)

    def error(self, event: str, session_id: str = "", **kwargs: Any) -> None:
        self._log(logging.ERROR, event, session_id, kwargs or None)


def get_observability_logger(module: str) -> ObservabilityLogger:
    """按模块名获取 ObservabilityLogger 实例（缓存复用）。"""
    if module not in _LOGGERS:
        _LOGGERS[module] = ObservabilityLogger(module)
    return _LOGGERS[module]


def get_module_logger(name: str) -> logging.Logger:
    """获取标准 logging.Logger，同时输出到 stderr 和 observability 文件。

    兼容旧代码：原有 log.info("msg %s", arg) / log.warning("msg") 调用不用改，
    自动写入 logs/observability/{date}/observability.jsonl。

    用于将旧式 `log = logging.getLogger(__name__)` 迁移到 observability 体系，
    无需修改任何调用点。

    Args:
        name: 模块名（通常传 __name__）

    Returns:
        标准 logging.Logger 实例，已附加 observability FileHandler
    """
    logger = logging.getLogger(name)
    # 避免重复添加 handler
    if not any(isinstance(h, _LazyFileHandler) for h in logger.handlers):
        handler = _LazyFileHandler(name, _LOG_BASE_DIR)
        logger.addHandler(handler)
    return logger
