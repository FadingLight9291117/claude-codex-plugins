"""H: 标记（鸿蒙 hitrace）预处理算子。

负责把 SQL 拉出的扁平区间记录构建成树、计算自耗时、按路径聚合。
"""
from __future__ import annotations

import re
from collections import defaultdict
from typing import Any, Optional

from .base import (
    PreprocessContext,
    PreprocessError,
    register_operator,
    shorten_func_name,
)

# legend 常量（spec §4.3）— marker 算子自有的图例片段
LEGEND_TAG_PCT = "tag_summary.pct = 该 tag self_dur 占总 self_dur 比例"
LEGEND_TIME_OFFSET = "所有时间均为相对帧窗口起点偏移(ms)"


# 根节点 sentinel（trace_streamer 用 UINT32_MAX 表示无父节点）
_NO_PARENT = 4294967295

# ---------------------------------------------------------------------------
# 函数 → 中文标签 映射表（来自专家经验的 ui_trace_parser + rs_trace_parser）
# ---------------------------------------------------------------------------
FUNCTION_TAG_MAP: list[tuple[str, str, list[str]]] = [
    # (中文tag, 英文key, [匹配模式...])
    ("JS执行",     "JSExecute",    ["H:ExecuteJS", "H:JSView: ExecuteRerender"]),
    ("生命周期",   "Lifecycle",    ["H:HandleLaunchAbility", "H:HandleAttachApplication",
                                    "H:HandleLaunchApplication"]),
    ("组件回调",   "ComponentCallback", ["H:aboutToAppear", "H:aboutToDisappear", "H:aboutToBeDeleted",
                                         "H:CustomNode:OnAppear", "H:CustomNode:OnDisappear"]),
    ("组件构建",   "BuildItem",    ["H:CustomNode:BuildItem", "H:CustomNode:BuildRecycle", "H:BuildLazyItem"]),
    ("布局测量",   "Measure",      ["H:CreateTaskMeasure", "H:TextLayoutAlgorithm::MeasureContent",
                                    "H:ListLayoutAlgorithm::MeasureListItem", "H:LazyForEach"]),
    ("布局计算",   "Layout",       ["H:CreateTaskLayout", "H:FlushLayoutTask"]),
    ("渲染提交",   "RenderCommit", ["H:FlushRenderTask", "H:RSModifierManager Draw"]),
    ("脏区更新",   "DirtyNodeUpdate", ["H:FlushDirtyNodeUpdate", "H:CustomNodeUpdate"]),
    ("可见区变化", "AreaChange",   ["H:HandleVisibleAreaChangeEvent", "H:HandleOnAreaChangeEvent",
                                    "H:HandleOnSizeChangeEvent"]),
    ("GC",         "GC",           ["H:PartialGC", "H:FullGC", "H:ConcurrentMarker",
                                    "H:InvokeNativeFinalizeCallbacks", "H:SharedGC"]),
    ("Native回调", "Napi",         ["H:napi::", "H:Native async work complete callback",
                                    "H:OnNativeCallBack"]),
    ("消息刷新",   "FlushMessages",["H:FlushMessages", "SendCommands"]),
    ("动效",       "Animation",    ["H:~AnimationCallback", "H:RunningCustomAnimation"]),
    ("数据删除",   "DataDelete",   ["H:OnDataDeleted"]),
    ("着色器编译", "Shader",       ["OHOS_CompileSpriV", "vkCreateGraphicsPipelines",
                                    "H:CreateGraphicsPipeline", "cmpbe_v2_compile_multiple_shaders",
                                    "bisheng_graphic_pipeline_compilation"]),
    ("RS渲染",     "RSRender",     ["H:RSUniRender::Process", "H:RSSurfaceRenderNodeDrawable::OnDraw:",
                                    "H:RSUniRender:FlushFrame"]),
    ("RS合成",     "RSComposition",["H:RSMainThread::DoComposition"]),
    ("纹理创建",   "Texture",      ["H:onCreateTexture"]),
    ("页面故障",   "PageFault",    ["anon_fault", "faultin_pte_swap", "iomm_fault",
                                    "shmm_fault", "file_fault"]),
    ("内存回收",   "MemoryRecycle",["direct-reclaim", "sysmgr-async-reclaim", "lru-anon-reclaim"]),
    ("WEB",        "WebCreate",    ["CreateNWeb", "H:PAGE_LOAD_TIME", "H:ArkUIWebInitWebViewWithSurface"]),
    ("WEB销毁",    "WebDestroy",   ["H:Compositor::destructor", "H:FrameSinkManager::DestroyCompositorFrameSink",
                                    "H:WebContentsImpl::~WebContentsImpl"]),
]

# 构建快速匹配表：pattern → (中文tag, 英文key)
_TAG_PATTERNS: list[tuple[re.Pattern, str, str]] = []
for zh_tag, en_key, patterns in FUNCTION_TAG_MAP:
    for p in patterns:
        _TAG_PATTERNS.append((re.compile(p, re.IGNORECASE), zh_tag, en_key))

# 兜底未知
_DEFAULT_TAG = ("未分类标记", "NonUiUnknown")

# 混淆名（≥16 位 hex/base64）截断模式（spec §6.2）
_OBFUSCATED_PATTERN = re.compile(r"[0-9a-fA-F]{16,}")


def _truncate_obfuscated(name: str) -> tuple[str, str | None]:
    """截断 ≥16 位 hex/base64 混淆段，返回 (截断后名, raw_name or None)。

    raw_name 仅在确实发生截断时返回原始名（供 call_paths[i].raw_name），
    未截断时返回 None。
    """
    if not _OBFUSCATED_PATTERN.search(name):
        return name, None
    truncated = _OBFUSCATED_PATTERN.sub("...", name)
    return truncated, name if truncated != name else None


def _clean_name(name: str) -> str:
    """
    清理鸿蒙 Trace Segment 名称，提取可读的核心信息。

    处理规则：
    1. -> / :: / (...) 路径段 → 提取最末段纯函数名
    2. 带 vsyncId 的事件 → 保留核心名称 + [vsyncId:值]
    3. 带 name 属性的事件 → 保留描述 + [name:值] 或 [值]
    4. 其他事件/任务 → 去掉参数、ID、timestamp 等噪音，保留核心名称
    """
    original = name.strip()
    s = re.sub(r'\|[A-Z]\d+$', '', original)
    s = re.sub(r'##[^|]+$', '', s)

    has_arrow = '->' in s
    has_namespace = '::' in s
    has_params = re.search(r'\([^)]*\)', s) is not None

    # -> / :: / (...) 均视为结构化路径段，提取最后一段
    if has_arrow or has_namespace or has_params:
        temp = re.sub(r'<[^>]+>', '', s)
        if has_arrow:
            # 取 -> 分隔的最后一段（如 kmp_export->libkmp_export.so → libkmp_export.so）
            last = s.split('->')[-1].strip()
            m = re.match(r'([A-Za-z_][A-Za-z0-9_]*)\s*\(', last)
            if m:
                return m.group(1)
            return last
        if '::' in temp:
            after_colons = temp.split('::')[-1]
            m = re.match(r'([A-Za-z_][A-Za-z0-9_]*)\s*(?:\(|$)', after_colons)
            if m:
                return m.group(1)
        # 只有 params、无 namespace/arrow
        m = re.search(r'([A-Za-z_][A-Za-z0-9_]*)\s*\(', temp)
        if m:
            return m.group(1)
        return s.split('(')[0].split('::')[-1].strip()

    # vsyncId 事件
    vsync_match = re.search(r'vsyncId:\s*(\d+)', s)
    if vsync_match:
        vsync_id = vsync_match.group(1)
        main_part = s[:vsync_match.start()].strip()
        main_part = re.sub(r'^H:', '', main_part)
        main_part = re.sub(r'\b[a-zA-Z_][a-zA-Z0-9_]*:[^,]+\s*,?\s*', '', main_part)
        main_part = main_part.rstrip('[').strip()
        main_part = main_part.strip().rstrip(',').strip()
        main_part = re.sub(r'\s+', ' ', main_part)
        return f"{main_part}[vsyncId:{vsync_id}]"

    # name 属性事件
    name_match = re.search(r'name\s*[:=]\s*([^,|#\]]+)', s)
    if name_match:
        name_value = name_match.group(1).strip()
        name_value = re.sub(r'^default/', '', name_value)
        name_value = re.sub(r'#\d+$', '', name_value)
        main_part = s[:name_match.start()].strip().rstrip(',').strip()
        main_part = main_part.rstrip('[').strip()
        main_part = re.sub(r'^H:', '', main_part)
        snippet = s[name_match.start():name_match.end()]
        if 'name:' in snippet or 'name :' in snippet:
            return f"{main_part}[name:{name_value}]"
        else:
            return f"{main_part}[{name_value}]"

    # 一般情况
    s = re.sub(r'^H:', '', s)
    s = re.sub(r'callback:handleId:\d+', '', s)
    s = re.sub(r'traceid:[^,]+', '', s)
    if '[' in s:
        s = s.split('[')[0]
    s = s.strip().rstrip(',').strip()
    s = re.sub(r'\s+', ' ', s)
    return s


def _match_tag(name: str) -> tuple[str, str]:
    """根据函数名匹配中文 tag 和英文 key。"""
    for pattern, zh_tag, en_key in _TAG_PATTERNS:
        if pattern.search(name):
            return zh_tag, en_key
    return _DEFAULT_TAG


@register_operator("build_marker_tree")
def build_marker_tree(ctx: PreprocessContext) -> PreprocessContext:
    """从扁平 DataFrame 构建标记树。

    输入:
        ctx.data: DataFrame 含列 id, ts, dur, name, depth, parent_id, callid, thread_name
    输出:
        ctx.data: dict {roots: [...], node_map: {id: Node}}
        ctx.meta["marker_total_count"]: 标记总数

    cache 路径（ctx.trace_cache 非空时）:
        用 cache.callstack(itid, start_ns, end_ns) 替代 YAML SQL（N+1 → O(1) 查找）。
        YAML SQL（WHERE cookie IS NULL AND ts BETWEEN ? AND ?）在无索引时全表扫描 93ms ×
        204 = 21.2s；cache 一次性全量拉取后按 itid 分组 + bisect 区间过滤。
    """
    # Task 11: cache 由 query_engine.py 始终注入（Task 6 后），不再判 None。
    cache = ctx.trace_cache
    import pandas as pd
    df = _build_marker_df_from_cache(ctx, cache)
    if df is not None:
        ctx.data = df
        ctx.meta["marker_data_source"] = "trace_cache"
    else:
        # cache 未命中（YAML SQL 是空 stub 或无 callstack 数据）→ 生成空结构化 DataFrame
        if not isinstance(ctx.data, pd.DataFrame) or len(ctx.data) == 0 or "id" not in getattr(ctx.data, "columns", []):
            ctx.data = pd.DataFrame(columns=[
                "id", "ts", "dur", "name", "depth", "parent_id", "callid", "tid", "thread_name"
            ])

    # 空 DataFrame 提前返回结构化空结果（避免后续算子在 None 值上报错）
    if isinstance(ctx.data, pd.DataFrame) and len(ctx.data) == 0:
        start_ms = (ctx.meta or {}).get("start_ms") or 0
        end_ms = (ctx.meta or {}).get("end_ms") or 0
        tid = (ctx.meta or {}).get("tid")
        result = {
            "begin_ts": int(start_ms * 1e6) if start_ms else 0,
            "end_ts": int(end_ms * 1e6) if end_ms else 0,
            "dur_ms": (end_ms - start_ms) if end_ms > start_ms else 0,
            "marker_count": 0,
            "frame_count": 0,
            "function_hotspots": [],
            "tag_summary": {},
            "call_path_hotspots": [],
            "thread_name": "unknown",
        }
        if tid is not None:
            result["tid"] = tid
        ctx.data = result
        ctx.meta["marker_total_count"] = 0
        ctx.meta["marker_root_count"] = 0
        # 显式设置空树状态，供后续算子（compute_self_time 等）识别
        ctx.meta["node_map"] = {}
        ctx.meta["roots"] = []
        return ctx

    return _build_marker_tree_legacy(ctx)


def _build_marker_df_from_cache(
    ctx: PreprocessContext, cache
) -> Optional[Any]:
    """用 cache.callstack 重建 DataFrame，等价于 YAML SQL 的输出。

    YAML SQL:
        SELECT c.id, c.ts, c.dur, c.name, c.depth, c.parent_id, c.callid,
               t.tid, COALESCE(t.name, 'unknown') as thread_name
        FROM callstack c LEFT JOIN thread t ON c.callid = t.id
        WHERE c.cookie IS NULL
          AND c.ts BETWEEN :start_ms * 1e6 AND :end_ms * 1e6
          AND (:tid IS NULL OR t.tid = :tid)
        ORDER BY c.ts

    cache.callstack tuple: (callid, ts, dur, name, depth, parent_id, id, cookie)
    - callid 等价于 itid（per Rule 20），直接对应 thread.itid
    - 通过 cache.thread_meta(itid) 获取 (name, tid, ipid)
    """
    if cache is None:
        return None

    import pandas as pd

    meta = ctx.meta or {}
    start_ms = meta.get("start_ms") or 0
    end_ms = meta.get("end_ms") or 0
    if end_ms <= start_ms:
        return None
    start_ns = int(start_ms * 1_000_000)
    end_ns = int(end_ms * 1_000_000)

    tid_filter = meta.get("tid")
    # 若指定 tid，先转 itid；tid 为 None 时遍历所有 itid
    if tid_filter is not None:
        try:
            tid_int = int(tid_filter)
        except (TypeError, ValueError):
            return None
        itid = cache.tid_to_itid(tid_int)
        if not itid:
            # tid 不在 thread 表，返回空 DataFrame（与 SQL 行为一致）
            return pd.DataFrame(
                columns=["id", "ts", "dur", "name", "depth",
                         "parent_id", "callid", "tid", "thread_name"]
            )
        itids = [itid]
    else:
        # 无 tid 过滤：遍历 cache 中所有 itid（全量 callstack）
        if cache._callstack is None:
            cache._build_callstack()
        itids = list((cache._callstack or {}).keys())

    records = []
    for itid in itids:
        rows = cache.callstack(itid, start_ns, end_ns)
        if not rows:
            continue
        # 取 thread 元数据（tid, name）；callid=itid，LEFT JOIN 等价
        thread_meta = cache.thread_meta(itid)
        tid_val = thread_meta[1] if thread_meta else None
        thread_name = thread_meta[0] if thread_meta and thread_meta[0] else "unknown"

        for r in rows:
            # r = (callid, ts, dur, name, depth, parent_id, id, cookie)
            callid = r[0]
            ts = r[1]
            dur = r[2]
            name = r[3]
            depth = r[4]
            parent_id = r[5]
            row_id = r[6]
            cookie = r[7]
            # 过滤 cookie IS NULL（与 YAML SQL 语义一致）
            if cookie is not None:
                continue
            # cache.callstack(itid, start_ns, end_ns) 已做区间交集过滤
            # (ts+dur) > start_ns AND ts < end_ns（规则 30），无需额外后过滤
            records.append({
                "id": row_id,
                "ts": ts,
                "dur": dur,
                "name": name,
                "depth": depth,
                "parent_id": parent_id,
                "callid": callid,
                "tid": tid_val,
                "thread_name": thread_name,
            })

    # ORDER BY c.ts（与 YAML SQL 一致）
    records.sort(key=lambda x: x["ts"])
    return pd.DataFrame(records, columns=[
        "id", "ts", "dur", "name", "depth",
        "parent_id", "callid", "tid", "thread_name",
    ])


def _build_marker_tree_legacy(ctx: PreprocessContext) -> PreprocessContext:
    """legacy: 用 YAML SQL 拉取的 DataFrame 构建标记树。

    cache 路径未命中时回退到此函数（ctx.data 已是 pd.read_sql_query 的结果）。
    """
    df = ctx.data
    required = {"id", "ts", "dur", "name", "depth", "parent_id", "callid", "thread_name"}
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(f"build_marker_tree 输入缺少列: {sorted(missing)}")

    records = df.to_dict("records")
    node_map: dict[int, dict[str, Any]] = {}
    roots: list[dict[str, Any]] = []

    for rec in records:
        nid = int(rec["id"])
        dur_raw = rec.get("dur")
        dur = int(dur_raw) if dur_raw is not None and dur_raw == dur_raw else 0
        node = {
            "id": nid,
            "ts": int(rec["ts"]),
            "dur": dur,
            "name": _clean_name(str(rec["name"])),
            "raw_name": str(rec["name"]),
            "depth": int(rec["depth"]),
            "parent_id": int(rec["parent_id"]),
            "callid": int(rec["callid"]),
            "thread_name": str(rec["thread_name"]),
            "children": [],
            "self_dur": None,
            "path": None,
            "tags": [],
        }
        node_map[nid] = node

    for node in node_map.values():
        pid = node["parent_id"]
        if pid == _NO_PARENT or pid not in node_map:
            roots.append(node)
        else:
            parent = node_map.get(pid)
            if parent is not None:
                parent["children"].append(node)

    ctx.data = {"roots": roots, "node_map": node_map}
    ctx.meta["marker_total_count"] = len(records)
    ctx.meta["marker_root_count"] = len(roots)
    ctx.meta["node_map"] = node_map  # 供后续算子共享，避免 data 被中间步骤覆盖时丢失
    ctx.meta["roots"] = roots
    return ctx


@register_operator("compute_self_time")
def compute_self_time(ctx: PreprocessContext) -> PreprocessContext:
    """后序遍历树，计算每个节点的自耗时并构建路径字符串。

    自耗时 = 节点 dur - 所有直接子节点 dur 之和
    路径分隔符使用 "->"
    """
    node_map = ctx.meta.get("node_map", {})
    roots = ctx.meta.get("roots", [])
    tree = ctx.data

    def dfs(node: dict[str, Any], parent_path: str) -> int:
        if parent_path:
            path = f"{parent_path}->{node['name']}"
        else:
            path = node["name"]
        node["path"] = path

        children = node.get("children", [])
        for child in children:
            dfs(child, path)

        children_dur_total = sum(c["dur"] for c in children)
        self_dur = max(0, node["dur"] - children_dur_total)
        node["self_dur"] = self_dur
        return self_dur

    for root in roots:
        dfs(root, "")

    ctx.data = tree
    ctx.meta["marker_node_count"] = len(node_map)
    return ctx


@register_operator("map_functions_to_tags")
def map_functions_to_tags(ctx: PreprocessContext) -> PreprocessContext:
    """给每个节点打中文标签。

    遍历 node_map，用 FUNCTION_TAG_MAP 匹配 name，给节点增加 tags 字段。
    一个节点可能匹配多个 tag（按顺序返回第一个匹配的）。
    """
    node_map = ctx.meta.get("node_map", {})

    tag_counts: dict[str, int] = defaultdict(int)
    for node in node_map.values():
        # 用 raw_name（H:前缀完整）匹配 FUNCTION_TAG_MAP，name 已被清理过
        raw = node.get("raw_name", "")
        zh_tag, en_key = _match_tag(raw)
        node["tag"] = zh_tag
        node["tag_key"] = en_key
        tag_counts[zh_tag] += 1

    ctx.meta["tag_counts"] = dict(tag_counts)
    return ctx


@register_operator("aggregate_by_function_tag")
def aggregate_by_function_tag(ctx: PreprocessContext) -> PreprocessContext:
    """按 tag 和 func_name 分组聚合，生成 function_hotspots + tag_summary。

    输出:
        ctx.data: {
            "function_hotspots": [...],
            "tag_summary": {...}
        }
    """
    node_map = ctx.meta.get("node_map", {})

    # 按 (tag, func_name, thread_name) 分组
    func_agg: dict[tuple[str, str, str], dict[str, Any]] = defaultdict(
        lambda: {"self_dur_ns": 0, "call_count": 0, "max_dur_ns": 0}
    )
    tag_agg: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"self_dur_ns": 0, "call_count": 0}
    )

    for node in node_map.values():
        tag = node.get("tag", "未分类标记")
        func = node.get("name", "unknown")
        thread = node.get("thread_name", "unknown")
        self_dur = node.get("self_dur", 0) or 0

        key = (tag, func, thread)
        entry = func_agg[key]
        entry["self_dur_ns"] += self_dur
        entry["call_count"] += 1
        entry["max_dur_ns"] = max(entry["max_dur_ns"], node.get("dur", 0) or 0)

        tag_entry = tag_agg[tag]
        tag_entry["self_dur_ns"] += self_dur
        tag_entry["call_count"] += 1

    # 计算 frame 总 self_dur（用于计算占比）
    total_self_dur_ns = sum(e["self_dur_ns"] for e in tag_agg.values())

    function_hotspots = []
    for (tag, func, thread), entry in func_agg.items():
        sdur = entry["self_dur_ns"]
        function_hotspots.append({
            "func": func,
            "tag": tag,
            "thread_name": thread,
            "self_dur_ms": round(sdur / 1e6, 3),
            "call_count": entry["call_count"],
            "max_dur_ms": round(entry["max_dur_ns"] / 1e6, 3),
        })

    function_hotspots.sort(key=lambda x: x["self_dur_ms"], reverse=True)

    tag_summary = {}
    for tag, entry in tag_agg.items():
        sdur = entry["self_dur_ns"]
        pct = round(sdur / total_self_dur_ns * 100, 1) if total_self_dur_ns else 0
        tag_summary[tag] = {
            "self_dur_ms": round(sdur / 1e6, 3),
            "call_count": entry["call_count"],
            "pct": pct,
        }

    ctx.data = {
        "function_hotspots": function_hotspots,
        "tag_summary": tag_summary,
    }
    # 保留到 meta，避免被后续算子覆盖时丢失
    ctx.meta["function_data"] = ctx.data
    return ctx


@register_operator("aggregate_by_hotpath")
def aggregate_by_hotpath(ctx: PreprocessContext) -> PreprocessContext:
    """按路径聚合，生成 call_path_hotspots。

    输入:
        ctx.data: {roots, node_map}（compute_self_time 后的树）
        ctx.meta["function_data"]: 前序算子输出的 function_hotspots + tag_summary
    输出:
        ctx.data: call_path_hotspots list
        ctx.meta["function_data"]: 保留不动
    """
    node_map = ctx.meta.get("node_map", {})

    agg: dict[tuple[str, str], dict[str, Any]] = defaultdict(
        lambda: {"total_dur_ns": 0, "self_dur_ns": 0, "call_count": 0, "max_dur_ns": 0, "depth": 0}
    )

    for node in node_map.values():
        path = node.get("path")
        if not path:
            continue
        key = (path, node["thread_name"])
        entry = agg[key]
        entry["total_dur_ns"] += node["dur"]
        entry["self_dur_ns"] += node.get("self_dur", 0) or 0
        entry["call_count"] += 1
        entry["max_dur_ns"] = max(entry["max_dur_ns"], node["dur"])
        entry["depth"] = node["depth"]

    result = []
    for (path, thread_name), entry in agg.items():
        call_count = entry["call_count"]
        result.append({
            "path": path,
            "total_dur_ms": round(entry["total_dur_ns"] / 1e6, 3),
            "self_dur_ms": round(entry["self_dur_ns"] / 1e6, 3),
            "call_count": call_count,
            "max_dur_ms": round(entry["max_dur_ns"] / 1e6, 3),
            "avg_dur_ms": round(entry["total_dur_ns"] / call_count / 1e6, 3) if call_count else 0,
            "depth": entry["depth"],
            "thread_name": thread_name,
        })

    result.sort(key=lambda x: x["self_dur_ms"], reverse=True)

    min_self_dur_ms = float(ctx.params.get("min_self_dur_ms", 0) or 0)
    if min_self_dur_ms > 0:
        before_prune = len(result)
        result = [r for r in result if r["self_dur_ms"] >= min_self_dur_ms]
        ctx.meta["hotpath_pruned_count"] = before_prune - len(result)

    top_n = int(ctx.params.get("top_n") or 0)
    if top_n > 0:
        result = result[:top_n]
        ctx.meta["hotpath_top_n"] = top_n

    ctx.data = result
    ctx.meta["hotpath_count"] = len(result)
    ctx.meta["call_path_data"] = result
    return ctx


@register_operator("format_hotpath_summary")
def format_hotpath_summary(ctx: PreprocessContext) -> PreprocessContext:
    """整合 function_hotspots + tag_summary + call_paths，输出 Agent 友好结构（spec §6）。

    三个算子的数据通过 ctx.meta 传递：
    - function_data: 来自 aggregate_by_function_tag（function_hotspots + tag_summary）
    - call_path_data: 来自 aggregate_by_hotpath（call_path list）

    输出:
        ctx.data: {raw_begin_ns, raw_end_ns, offset_from_frame_start_ms, dur_ms,
                   marker_count, frame_count, tag_summary, call_paths,
                   headline, text, _legend_fragments, [tid], thread_name}
    """
    meta = ctx.meta
    func_data = meta.get("function_data", {})
    call_paths_raw = meta.get("call_path_data", [])

    func_hotspots = func_data.get("function_hotspots", [])
    tag_summary = func_data.get("tag_summary", {})

    # 从 function_hotspots 实际数据中提取线程名，避免 meta 未传递时返回 unknown
    thread_name = meta.get("app_main_thread_name") or meta.get("thread_name")
    if not thread_name:
        for fh in func_hotspots:
            tn = fh.get("thread_name")
            if tn and tn != "unknown":
                thread_name = tn
                break
        if not thread_name:
            thread_name = "unknown"
    total_count = meta.get("marker_total_count", 0)
    root_count = meta.get("marker_root_count", 0)

    # 计算 3% 阈值：基于实际分析区间时长 (end_ms - start_ms)
    start_ms = meta.get("start_ms") or 0
    end_ms = meta.get("end_ms") or 0
    total_dur_ms = end_ms - start_ms if end_ms > start_ms else 1
    min_abs_ms = total_dur_ms * 0.03

    # 截断路径（保留前 max_segments 段，不加 ... 保证叶子节点可读），
    # 再按 3% 阈值过滤，构造 call_paths 精简版（含 raw_name）
    max_segments = ctx.params.get("max_path_segments", 6)
    filtered_paths = []
    for cp in call_paths_raw:
        path = cp["path"]
        segments = path.split("->")
        if len(segments) > max_segments:
            trunk_segments = [s[:100] for s in segments[:max_segments]]
        else:
            trunk_segments = [s[:100] for s in segments]
        trunk_path = "->".join(trunk_segments)
        if cp["self_dur_ms"] < min_abs_ms:
            continue
        # 混淆名截断（spec §6.2）
        display_path, raw_name = _truncate_obfuscated(trunk_path)
        filtered_paths.append({
            "path": display_path,
            "total_dur_ms": cp["total_dur_ms"],
            "self_dur_ms": cp["self_dur_ms"],
            "call_count": cp["call_count"],
            "max_dur_ms": cp["max_dur_ms"],
            "depth": len(trunk_segments),
            "raw_name": raw_name,
        })

    # headline（spec §6.1）
    headline = _build_marker_headline(tag_summary, func_hotspots)

    # text（spec §6.2）
    text = _build_marker_text(tag_summary, func_hotspots, filtered_paths)

    result = {
        "headline": headline,
        "text": text,
        "marker_count": total_count,
        "frame_count": root_count,
        "_legend_fragments": {
            "tag_pct": LEGEND_TAG_PCT,
            "time_offset": LEGEND_TIME_OFFSET,
        },
    }

    ctx.data = result
    return ctx


def _build_marker_headline(tag_summary: dict, func_hotspots: list) -> str:
    """spec §6.1：top tag X Yms(Z%)；top 函数 ... 总...ms/自身...ms

    注：func_hotspots 无 total_dur_ms 字段，单次调用时 max==total，
    用 max_dur_ms 作为总耗时近似。
    """
    if not tag_summary:
        return ""
    top_tag_name, top_tag_info = max(
        tag_summary.items(), key=lambda x: x[1].get("self_dur_ms", 0)
    )
    top_tag_dur = top_tag_info.get("self_dur_ms", 0.0)
    top_tag_pct = top_tag_info.get("pct", 0.0)
    parts = [f"top tag {top_tag_name} {top_tag_dur}ms({top_tag_pct}%)"]
    if func_hotspots:
        top_func = max(func_hotspots, key=lambda x: x.get("self_dur_ms", 0))
        func_name = shorten_func_name(top_func.get("func", ""))
        # func_hotspots 无 total_dur_ms；单次调用 max==total
        total_ms = top_func.get("max_dur_ms", 0.0)
        self_ms = top_func.get("self_dur_ms", 0.0)
        parts.append(f"top 函数 {func_name} 总{total_ms}ms/自身{self_ms}ms")
    return "；".join(parts)


def _build_marker_text(tag_summary: dict, func_hotspots: list, call_paths: list) -> str:
    """spec §6.2：Part A (tag_summary) + 空行 + Part B (call_paths 树形)。

    Part B 行前缀：[总{total}ms{call_suffix} | 自身{self_dur}ms{max_suffix}]
      call_suffix = /N次 (call_count>1)
      max_suffix  =  | 单次max{max}ms (call_count>1 and max>0)
    depth → indent: depth=1 无缩进, depth=2 一个 4-space, ...
    """
    lines_a = ["[标记热点]"]
    sorted_tags = sorted(
        [t for t in tag_summary.items() if t[1].get("self_dur_ms", 0) > 0],
        key=lambda x: -x[1].get("self_dur_ms", 0),
    )
    for tag_name, info in sorted_tags:
        dur = info.get("self_dur_ms", 0.0)
        cnt = info.get("call_count", 0)
        pct = info.get("pct", 0.0)
        # 找该 tag 下 top 2 函数
        funcs_in_tag = sorted(
            [f for f in func_hotspots if f.get("tag") == tag_name],
            key=lambda x: -x.get("self_dur_ms", 0),
        )[:2]
        top_suffix = ""
        if funcs_in_tag:
            parts = [
                f"{shorten_func_name(f.get('func', ''))} {f.get('self_dur_ms', 0.0)}ms"
                for f in funcs_in_tag
            ]
            top_suffix = "  # top: " + ", ".join(parts)
        lines_a.append(f"{tag_name}: {dur}ms / {cnt}次 ({pct}%){top_suffix}")

    lines_b = ["[调用路径树]"]
    for cp in call_paths:
        total = cp.get("total_dur_ms", 0.0)
        self_dur = cp.get("self_dur_ms", 0.0)
        cnt = cp.get("call_count", 1)
        max_dur = cp.get("max_dur_ms", 0.0)
        depth = cp.get("depth", 1)
        call_suffix = f"/{cnt}次" if cnt > 1 else ""
        max_suffix = f" | 单次max{max_dur}ms" if cnt > 1 and max_dur > 0 else ""
        prefix = f"[总{total}ms{call_suffix} | 自身{self_dur}ms{max_suffix}]"
        indent = "    " * (depth - 1)
        lines_b.append(f"{indent}{prefix} {cp.get('path', '')}")

    return "\n".join(lines_a) + "\n\n" + "\n".join(lines_b)
