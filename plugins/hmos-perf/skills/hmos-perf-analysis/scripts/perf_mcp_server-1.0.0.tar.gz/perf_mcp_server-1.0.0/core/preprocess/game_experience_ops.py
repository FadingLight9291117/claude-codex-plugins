"""游戏体验指标算子。

计算游戏用户感知流畅度指标：FPS、抖动率、体验卡顿分类和卡顿时长。
本模块分析的是用户感知层面的流畅度体验，与渲染层面的丢帧分析（game_frame_ts）不同：
- 本模块：基于 24fps 电影帧间隔（41.67ms），帧间隔>=83.33ms 判定为"体验卡顿"
- game_frame_ts：基于 P10×1.5 动态阈值，检测渲染层面的帧率异常（更灵敏）
- 丢帧不一定造成体验卡顿（25ms~83ms 之间的帧间隔异常用户不可感知）
- 但体验卡顿一定意味着丢帧

帧定义遵循 AgentOSS 已有 game_render_ops.py 中的 RS 侧帧解析逻辑
（SendVsyncTo → FlushBuffer → AcquireBuffer → CommitLayers → PresentFence）。
"""
from __future__ import annotations

import math
from collections import defaultdict
from typing import Any, Dict, List, Optional

import pandas as pd

from core.observability import get_observability_logger
from core.preprocess.base import PreprocessContext, register_operator

_log = get_observability_logger("game_experience_ops")

# ---------------------------------------------------------------------------
# 卡顿阈值定义
# 基于 24fps 电影帧间隔（41.67ms）的用户感知标准，与显示刷新率无关
# 一般卡顿: 帧间隔 >= 83.33ms（2×电影帧间隔，2~3帧掉帧）
# 严重卡顿: 帧间隔 >= 125ms（3×电影帧间隔，3~4帧掉帧）
# 致命卡顿: 帧间隔 >= 166.67ms（4×电影帧间隔，4帧以上掉帧）
# 基于 24fps 电影帧率（41.67ms/帧）的用户感知标准，与显示刷新率无关
# ---------------------------------------------------------------------------

# 游戏帧体验卡顿分类默认阈值（基于 24fps 电影帧间隔 41.67ms）
# 此标准基于人眼感知的流畅度底线，与游戏实际 FPS 无关
# 适用于 60fps / 90fps / 120fps 等所有刷新率场景
DEFAULT_JANK_THRESHOLDS = {
    "normal": 83.33,      # 83.33ms（2×41.67）— 一般卡顿
    "severe": 125.0,      # 125.00ms（3×41.67）— 严重卡顿
    "fatal": 166.67,      # 166.67ms（4×41.67）— 致命卡顿
}

# 中文标签
JANK_LABELS = {
    "normal": "一般卡顿",
    "severe": "严重卡顿",
    "fatal": "致命卡顿",
}


def _classify_jank(interval_ms: float, thresholds: Dict[str, float]) -> Optional[str]:
    """根据帧间隔分类卡顿等级。"""
    if interval_ms >= thresholds["fatal"]:
        return "fatal"
    elif interval_ms >= thresholds["severe"]:
        return "severe"
    elif interval_ms >= thresholds["normal"]:
        return "normal"
    return None


@register_operator("compute_game_fps")
def compute_game_fps(ctx: PreprocessContext) -> PreprocessContext:
    """计算游戏 FPS。

    自包含实现：直接从 SQLite 查询 RS 侧 "Waiting for Present Fence" 事件，
    以帧结束时间(ts+dur)计算帧间隔和 FPS。

    输出写入 ctx.meta["fps_result"]。
    """
    conn = ctx.sqlite_conn
    start_ms = ctx.params.get("start_ms")
    end_ms = ctx.params.get("end_ms")
    ipid = ctx.params.get("ipid")
    process_name = ctx.params.get("process_name")
    tid = ctx.params.get("tid")
    filter_thread_name = ctx.params.get("filter_thread_name")

    # 从 SQLite 直接查询 PresentFence 帧时间
    frame_ts_ns: List[int] = []
    if conn:
        # 构建时间过滤
        time_filter = ""
        params_list: List = []
        if start_ms is not None and end_ms is not None:
            start_ns = int(start_ms * 1e6)
            end_ns = int(end_ms * 1e6)
            time_filter = "AND cs.ts >= ? AND cs.ts < ?"
            params_list = [start_ns, end_ns]

        # 构建进程/线程过滤
        join_clause = ""
        where_extra: List[str] = []
        extra_params: List = []

        if ipid is not None:
            join_clause = "INNER JOIN thread t ON cs.callid = t.id"
            where_extra.append("t.ipid = ?")
            extra_params.append(ipid)
        elif process_name:
            join_clause = "INNER JOIN thread t ON cs.callid = t.id"
            where_extra.append("t.name LIKE '%' || ? || '%'")
            extra_params.append(process_name)

        if tid is not None:
            if not join_clause:
                join_clause = "INNER JOIN thread t ON cs.callid = t.id"
            where_extra.append("t.tid = ?")
            extra_params.append(tid)
        elif filter_thread_name:
            if not join_clause:
                join_clause = "INNER JOIN thread t ON cs.callid = t.id"
            where_extra.append("t.name LIKE '%' || ? || '%'")
            extra_params.append(filter_thread_name)

        extra_where = (" AND " + " AND ".join(where_extra)) if where_extra else ""

        try:
            cur = conn.cursor()
            cur.execute(f"""
                SELECT cs.ts, cs.dur FROM callstack cs
                {join_clause}
                WHERE (cs.name LIKE '%Waiting for Present Fence%' OR cs.name LIKE '%Waiting for PresentFence%')
                {time_filter}
                {extra_where}
                ORDER BY cs.ts ASC
            """, params_list + extra_params)
            rows = cur.fetchall()
            for row in rows:
                ts = row[0]
                dur = row[1] if row[1] else 0
                frame_ts_ns.append(int(ts) + int(dur))  # 帧结束时间 = ts + dur
        except Exception as e:
            _log.warning("fps_query_failed", error=str(e))
    else:
        # 回退：从 ctx.data 中读取帧时间（如果上游传递了帧数据）
        df = ctx.data
        if df is not None and isinstance(df, pd.DataFrame) and not df.empty:
            if "end_ts" in df.columns:
                frame_ts_ns = [int(x) for x in df["end_ts"].dropna().tolist()]
            elif "present_fence_end_ms" in df.columns:
                frame_ts_ns = [int(x * 1e6) for x in df["present_fence_end_ms"].dropna().tolist()]

    if len(frame_ts_ns) < 2:
        ctx.meta["fps_result"] = {"avg_fps": 0, "fps_per_second": [],
                                   "frame_count": len(frame_ts_ns),
                                   "warning": "帧数不足" if frame_ts_ns else "无帧数据"}
        ctx.meta["frame_intervals_ms"] = []
        return ctx

    frame_ts_ns = sorted(frame_ts_ns)
    total_duration_ns = frame_ts_ns[-1] - frame_ts_ns[0]
    total_duration_ms = total_duration_ns / 1e6

    # 计算帧间隔
    intervals_ms: List[float] = []
    for i in range(1, len(frame_ts_ns)):
        interval_ns = frame_ts_ns[i] - frame_ts_ns[i - 1]
        intervals_ms.append(interval_ns / 1e6)

    # 平均 FPS
    if total_duration_ms > 0:
        avg_fps = (len(frame_ts_ns) - 1) / (total_duration_ms / 1000)
    else:
        avg_fps = 0

    # 逐秒 FPS
    fps_per_second: List[Dict[str, Any]] = []
    if total_duration_ns > 0:
        bucket_size_ns = 1_000_000_000
        start_ns = frame_ts_ns[0]
        bucket_start = start_ns
        bucket_count = 0

        for i in range(1, len(frame_ts_ns)):
            if frame_ts_ns[i] >= bucket_start + bucket_size_ns:
                fps_per_second.append({
                    "second": int((bucket_start - start_ns) / 1e9),
                    "fps": bucket_count,
                })
                bucket_start += bucket_size_ns
                bucket_count = 0
                while frame_ts_ns[i] >= bucket_start + bucket_size_ns:
                    fps_per_second.append({
                        "second": int((bucket_start - start_ns) / 1e9),
                        "fps": 0,
                    })
                    bucket_start += bucket_size_ns
            bucket_count += 1

        if bucket_count > 0:
            fps_per_second.append({
                "second": int((bucket_start - start_ns) / 1e9),
                "fps": bucket_count,
            })

    ctx.meta["fps_result"] = {
        "avg_fps": round(avg_fps, 1),
        "total_frames": len(frame_ts_ns),
        "total_duration_ms": round(total_duration_ms, 2),
        "fps_per_second": fps_per_second,
    }

    # 同时把帧间隔保存到 meta 中供后续算子使用
    ctx.meta["frame_intervals_ms"] = intervals_ms

    _log.info("game_fps_computed", avg_fps=round(avg_fps, 1), total_frames=len(frame_ts_ns))
    return ctx


@register_operator("compute_game_jitter")
def compute_game_jitter(ctx: PreprocessContext) -> PreprocessContext:
    """计算游戏帧间隔抖动率。

    抖动率 = 帧间隔标准差 / 平均帧间隔 * 100%
    同时计算 P50/P90/P95/P99 帧间隔。

    结果写入 ctx.meta["jitter_result"]。
    """
    intervals_ms = ctx.meta.get("frame_intervals_ms", [])

    if not intervals_ms:
        ctx.meta["jitter_result"] = {"jitter_rate": 0, "warning": "无帧间隔数据"}
        return ctx

    n = len(intervals_ms)
    mean_interval = sum(intervals_ms) / n

    # 标准差
    if n > 1:
        variance = sum((x - mean_interval) ** 2 for x in intervals_ms) / (n - 1)
        std_dev = math.sqrt(variance)
    else:
        std_dev = 0

    # 抖动率
    jitter_rate = (std_dev / mean_interval * 100) if mean_interval > 0 else 0

    # 百分位数
    sorted_intervals = sorted(intervals_ms)
    p50 = sorted_intervals[int(n * 0.50)] if n > 0 else 0
    p90 = sorted_intervals[int(n * 0.90)] if n > 0 else 0
    p95 = sorted_intervals[int(n * 0.95)] if n > 0 else 0
    p99 = sorted_intervals[min(int(n * 0.99), n - 1)] if n > 0 else 0

    ctx.meta["jitter_result"] = {
        "jitter_rate": round(jitter_rate, 2),
        "mean_interval_ms": round(mean_interval, 2),
        "std_dev_ms": round(std_dev, 2),
        "p50_ms": round(p50, 2),
        "p90_ms": round(p90, 2),
        "p95_ms": round(p95, 2),
        "p99_ms": round(p99, 2),
    }

    _log.info("game_jitter_computed", jitter_rate=round(jitter_rate, 2),
              mean_interval_ms=round(mean_interval, 2))
    return ctx


@register_operator("compute_game_jank_stats")
def compute_game_jank_stats(ctx: PreprocessContext) -> PreprocessContext:
    """计算游戏卡顿统计。

    卡顿分类（基于 24fps 电影帧间隔 41.67ms 的用户感知标准）：
    - 一般卡顿: 帧间隔 >= 83.33ms（2×电影帧间隔）
    - 严重卡顿: 帧间隔 >= 125ms（3×电影帧间隔）
    - 致命卡顿: 帧间隔 >= 166.67ms（4×电影帧间隔）

    此标准基于人眼感知流畅度底线，与游戏实际 FPS 无关。

    输出：
    - 各类卡顿次数
    - 总卡顿时长
    - 最大连续卡顿帧数
    - 卡顿占比

    结果写入 ctx.meta["jank_stats"]。
    """
    intervals_ms = ctx.meta.get("frame_intervals_ms", [])

    if not intervals_ms:
        ctx.meta["jank_stats"] = {"total_jank_count": 0, "warning": "无帧间隔数据"}
        return ctx

    # 从 ctx.params 读取阈值（YAML 声明的参数优先，否则使用默认值）
    jank_thresholds = {
        "normal": ctx.params.get("jank_normal_threshold_ms", DEFAULT_JANK_THRESHOLDS["normal"]),
        "severe": ctx.params.get("jank_severe_threshold_ms", DEFAULT_JANK_THRESHOLDS["severe"]),
        "fatal": ctx.params.get("jank_fatal_threshold_ms", DEFAULT_JANK_THRESHOLDS["fatal"]),
    }

    # 分类统计
    jank_by_type = defaultdict(int)
    jank_durations = defaultdict(float)
    max_consecutive_jank = 0
    current_consecutive = 0
    total_jank_duration_ms = 0

    for interval in intervals_ms:
        jank_type = _classify_jank(interval, jank_thresholds)
        if jank_type:
            jank_by_type[jank_type] += 1
            jank_durations[jank_type] += interval
            total_jank_duration_ms += interval
            current_consecutive += 1
            max_consecutive_jank = max(max_consecutive_jank, current_consecutive)
        else:
            current_consecutive = 0

    # 卡顿占比
    total_jank_count = sum(jank_by_type.values())
    jank_rate = total_jank_count / len(intervals_ms) * 100 if intervals_ms else 0

    # 构建卡顿列表（用于详情展示）
    jank_details = []
    for jank_type in ["normal", "severe", "fatal"]:
        count = jank_by_type.get(jank_type, 0)
        if count > 0:
            jank_details.append({
                "type": jank_type,
                "label": JANK_LABELS[jank_type],
                "count": count,
                "total_duration_ms": round(jank_durations.get(jank_type, 0), 2),
                "threshold_ms": round(jank_thresholds[jank_type], 2),
            })

    ctx.meta["jank_stats"] = {
        "total_jank_count": total_jank_count,
        "total_jank_duration_ms": round(total_jank_duration_ms, 2),
        "jank_rate": round(jank_rate, 2),
        "max_consecutive_jank_frames": max_consecutive_jank,
        "jank_details": jank_details,
        "thresholds": {k: round(v, 2) for k, v in jank_thresholds.items()},
    }

    _log.info("game_jank_stats_computed", total_jank_count=total_jank_count,
              jank_rate=round(jank_rate, 2), max_consecutive=max_consecutive_jank)
    return ctx


@register_operator("format_game_experience_summary")
def format_game_experience_summary(ctx: PreprocessContext) -> PreprocessContext:
    """格式化游戏体验分析结果。

    输出 ctx.data 为结构化字典：
    {
        "fps": {...},
        "jitter": {...},
        "jank_stats": {...}
    }
    """
    fps_result = ctx.meta.get("fps_result", {})
    jitter_result = ctx.meta.get("jitter_result", {})
    jank_stats = ctx.meta.get("jank_stats", {})

    ctx.data = {
        "fps": fps_result,
        "jitter": jitter_result,
        "jank_stats": jank_stats,
    }

    return ctx
