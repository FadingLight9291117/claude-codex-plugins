"""游戏引擎类型检测。

支持三种主流游戏引擎：
- Unreal Engine (UE): WorkerThread_Ue, RenderThread, AuxiliaryRHI, FAsyncLoading*
- Unity: UnityMain*, UnityGfxDeviceW*, WorkerThread*
- 未知/通用

检测结果会被注入到 Skill 执行上下文中，供后续指标查询和线程角色映射使用。
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import pandas as pd

from core.observability import get_observability_logger

_log = get_observability_logger("game_engine_detector")

# ---------------------------------------------------------------------------
# 正则模式（引擎特有）
# ---------------------------------------------------------------------------

# Unreal Engine 线程模式（HarmonyOS UE 游戏特征）
UE_PATTERNS = [
    re.compile(r"WorkerThread_Ue"),     # UE 游戏逻辑/渲染主线程
    re.compile(r"RenderThread"),        # UE 渲染线程
    re.compile(r"AuxiliaryRHI"),        # UE 辅助 RHI
    re.compile(r"FAsyncLoading"),       # UE 异步加载
    re.compile(r"SlateLoading"),        # UE Slate UI 资源加载
]

# Unity 线程模式
UNITY_PATTERNS = [
    re.compile(r"UnityMain"),
    re.compile(r"UnityGfxDeviceW"),
    re.compile(r"UnityWorker"),
]

# 通用游戏线程模式（降级兜底）
GENERIC_GAME_PATTERNS = [
    re.compile(r"GameThread"),
    re.compile(r"RenderThread"),
    re.compile(r"WorkerThread"),
    re.compile(r"GfxDevice"),
]


@dataclass
class GameEngineInfo:
    """游戏引擎检测结果。"""
    engine_type: str           # "UNREAL" | "UNITY" | "GENERIC" | "UNKNOWN"
    confidence: float          # 0.0-1.0，匹配可信度
    key_threads: Dict[str, List[int]]  # role -> [tid列表]
    matched_patterns: List[str]        # 匹配到的线程名（调试用）
    main_tid: Optional[int] = None     # 主线程 tid（最早创建的 WorkerThread_Ue）
    render_tid: Optional[int] = None   # 渲染线程 tid
    main_thread_pattern: str = ""      # 主线程名称匹配模式

    @property
    def is_unreal(self) -> bool:
        return self.engine_type == "UNREAL"

    @property
    def is_unity(self) -> bool:
        return self.engine_type == "UNITY"

    @property
    def is_game(self) -> bool:
        return self.engine_type in ("UNREAL", "UNITY", "GENERIC")


def _classify_thread(thread_name: str, engine_type: str = "UNKNOWN") -> Optional[str]:
    """根据线程名分类游戏引擎线程角色。

    Args:
        engine_type: 引擎类型，影响 RenderThread 等通用名的分类

    Returns:
        UE 角色: "ue_main" | "ue_render" | "ue_rhi" | "ue_async_loading" | "ue_slate"
        Unity 角色: "unity_main" | "unity_render" | "unity_worker"
        通用角色: "game_main" | "render" | "worker"
        None 表示非游戏线程
    """
    name = thread_name.strip()

    # === Unreal Engine 特有线程 ===
    if re.search(r"WorkerThread_Ue", name):
        return "ue_main"
    if re.search(r"AuxiliaryRHI", name):
        return "ue_rhi"
    if re.search(r"FAsyncLoading", name):
        return "ue_async_loading"
    if re.search(r"SlateLoading", name):
        return "ue_slate"

    # === Unity 特有线程 ===
    if re.search(r"UnityMain", name):
        return "unity_main"
    if re.search(r"UnityGfxDeviceW", name):
        return "unity_render"
    if re.search(r"UnityWorker", name):
        return "unity_worker"

    # === 通用游戏线程（按引擎上下文分类） ===
    if re.search(r"RenderThread", name):
        return "ue_render" if engine_type == "UNREAL" else "render"
    if re.search(r"GameThread", name):
        return "game_main"
    if re.search(r"WorkerThread", name):
        return "worker"

    return None


def _score_engine(threads: List[str]) -> Tuple[str, float, List[str]]:
    """根据线程名集合评分，返回最可能的引擎类型和置信度。"""
    ue_score = 0
    unity_score = 0
    generic_score = 0
    matched: List[str] = []

    for name in threads:
        for pat in UE_PATTERNS:
            if pat.search(name):
                ue_score += 1
                matched.append(name)
                break
        for pat in UNITY_PATTERNS:
            if pat.search(name):
                unity_score += 1
                matched.append(name)
                break
        for pat in GENERIC_GAME_PATTERNS:
            if pat.search(name):
                generic_score += 1
                break

    total = ue_score + unity_score + generic_score
    if total == 0:
        return "UNKNOWN", 0.0, []

    if ue_score >= unity_score and ue_score >= generic_score:
        confidence = min(1.0, ue_score / max(1, total) * 2)
        return "UNREAL", confidence, matched
    elif unity_score >= generic_score:
        confidence = min(1.0, unity_score / max(1, total) * 2)
        return "UNITY", confidence, matched
    else:
        confidence = min(1.0, generic_score / max(1, total) * 0.8)
        return "GENERIC", confidence, matched


def detect_game_engine(thread_df: pd.DataFrame, process_name: Optional[str] = None) -> GameEngineInfo:
    """从线程列表中检测游戏引擎类型。

    Args:
        thread_df: 包含 'name' 和 'tid' 列的 DataFrame
        process_name: 进程名（可选，用于辅助判断）

    Returns:
        GameEngineInfo 检测结果
    """
    if thread_df.empty:
        return GameEngineInfo(engine_type="UNKNOWN", confidence=0.0, key_threads={}, matched_patterns=[])

    # 只分析有名字的线程
    named_threads = thread_df[thread_df["name"].notna() & (thread_df["name"] != "")]
    thread_names = named_threads["name"].dropna().tolist()
    thread_name_to_tid: Dict[str, List[int]] = {}
    for _, row in named_threads.iterrows():
        name = str(row["name"]).strip()
        tid = int(row["tid"])
        thread_name_to_tid.setdefault(name, []).append(tid)

    engine_type, confidence, matched_names = _score_engine(thread_names)

    # 构建角色 -> tid 映射
    key_threads: Dict[str, List[int]] = {}
    main_pattern = ""
    main_tid: Optional[int] = None
    render_tid: Optional[int] = None

    for name, tids in thread_name_to_tid.items():
        role = _classify_thread(name, engine_type)
        if role:
            key_threads[role] = sorted(tids)
            # 记录主线程（最早创建的 WorkerThread_Ue，取最小 tid）
            if role == "ue_main" and main_tid is None:
                main_tid = min(tids)
                main_pattern = name
            elif role == "unity_main" and main_tid is None:
                main_tid = min(tids)
                main_pattern = name
            elif role == "game_main" and main_tid is None:
                main_tid = min(tids)
                main_pattern = name
            # 记录渲染线程
            if role in ("ue_render", "unity_render", "render"):
                render_tid = min(tids)

    result = GameEngineInfo(
        engine_type=engine_type,
        confidence=confidence,
        key_threads=key_threads,
        matched_patterns=matched_names,
        main_tid=main_tid,
        render_tid=render_tid,
        main_thread_pattern=main_pattern,
    )

    _log.info("game_engine_detected",
              engine_type=engine_type, confidence=confidence,
              main_tid=main_tid, render_tid=render_tid,
              key_thread_roles=list(key_threads.keys()))

    return result


def build_thread_role_filter(engine_info: GameEngineInfo) -> Dict[str, str]:
    """根据引擎检测结果生成线程名过滤条件（用于 SQL WHERE 子句）。

    Returns:
        role -> SQL LIKE pattern 映射，例如：
        {
            "ue_main": "WorkerThread_Ue%",
            "ue_render": "RenderThread%",
            ...
        }
    """
    filters: Dict[str, str] = {}

    if engine_info.is_unreal:
        filters = {
            "ue_main": "WorkerThread_Ue%",
            "ue_render": "RenderThread%",
            "ue_rhi": "AuxiliaryRHI%",
            "ue_async_loading": "FAsyncLoading%",
            "ue_slate": "SlateLoading%",
        }
    elif engine_info.is_unity:
        filters = {
            "unity_main": "UnityMain%",
            "unity_render": "UnityGfxDeviceW%",
            "unity_worker": "UnityWorker%",
        }
    elif engine_info.engine_type == "GENERIC":
        filters = {
            "game_main": "GameThread%",
            "render": "RenderThread%",
            "worker": "WorkerThread%",
        }

    return filters


def get_sql_thread_filter(engine_info: GameEngineInfo) -> str:
    """生成 SQL WHERE 子句，用于过滤游戏关键线程。

    Returns:
        SQL LIKE 表达式，例如："(name LIKE 'WorkerThread_Ue%' OR name LIKE 'RenderThread%')"
        若无匹配则返回空字符串
    """
    role_filters = build_thread_role_filter(engine_info)
    if not role_filters:
        return ""

    patterns = [f"name LIKE '{pattern}'" for pattern in role_filters.values()]
    return f"({' OR '.join(patterns)})"
