"""HiPerf 线程热点调用链分析算子。

设计参考 docs/hiperf_thread_hotpath_design_v1_1.md

数据流:
  SQL(扁平) → build_hiperf_callchains → normalize_hiperf_functions
    → collapse_hiperf_system_libs → filter_by_threshold
    → aggregate_hiperf_functions → aggregate_hiperf_paths
    → aggregate_hiperf_binaries → finalize_hiperf

压缩规则:
  P0: 去除函数参数 (在 normalize_hiperf_functions 阶段)
  P1: [ArkTs Stub](N) 折叠 BCStub/BuiltinStub/RTStub/NativeFunction 序列
  P2: libfoo(×N) 同 .so 连续 3+ 节点折叠
  P3: foo(×N) 普通节点连续重复折叠
  P4: 公共前缀提取 (在 finalize_hiperf 阶段)
"""
from __future__ import annotations

from core.observability import get_module_logger
import re
from dataclasses import dataclass, field
from typing import Any

import pandas as pd
from core.flamegraph_collapse import (
    normalize_func_name,
)
from core.preprocess.base import PreprocessContext, register_operator

log = get_module_logger(__name__)

PATH_SEP = " → "
ARKTS_STUB_PREFIXES = (
    "BCStub_", "BuiltinStub_", "RTStub_", "COStub_", "NativeFunction", "panda::JSValueRef", "panda::ecmascript",
    "stateMgmt.abc", "panda::FunctionRef")


@dataclass
class _HotpathNode:
    """调用树节点，用于树式热点路径聚合。

    - self_event: 以当前节点为终点的 callchain 的 self_cycles 总和
    - total_event: self_event + sum(child.total_event)，后序遍历计算
    - binary: binary_name，用于 P1.5（kernel 判断）和 P2（同 .so 判断）
    """
    name: str
    children: dict[str, _HotpathNode] = field(default_factory=dict)
    binary: str = ""
    self_event: int = 0
    total_event: int = 0
    sample_count: int = 0
    total_sample_count: int = 0
    vm_stub_folded: int = 0


# 尾部噪音函数：这些函数的调用不参与路径合并
# 例如 pthread_mutex_lock 等锁函数，多一层锁不应该把同一个热点的路径拆散
TAIL_NOISE_FUNCTIONS: set[str] = {
    "pthread_mutex_lock",
    "pthread_mutex_unlock",
    "pthread_rwlock_rdlock",
    "pthread_rwlock_wrlock",
    "pthread_rwlock_unlock",
    "operator new",
    "malloc",
    "memset",
    "open64",
    "close",
    "mremap",
    "read",
    "mmap64",
    "strcmp",
    "write",
    "std::__h::mutex::lock",
    "std::__h::mutex::unlock",
    "std::__h::recursive_mutex::lock",
    "std::__h::recursive_mutex::unlock",
    "syscall_entry",
    "syscall_exit",
    "el0_sync",
    "el1_sync",
    "lsyscall_centry",
    "mprotect",
    "map_dso_to_cfi_shadow",
}
TAIL_NOISE_BINARY: set[str] = {
    "ld-musl-aarch64.so",
}

# 输出时去除的长命名空间前缀（按长度倒序，避免短前缀先匹配）
NAMESPACE_PREFIXES: list[str] = sorted([
    "OHOS::AppExecFwk::",
    "OHOS::AbilityRuntime::",
    "NativeModuleManager::",
    "OHOS::Rosen::",
    "OHOS::Ace::NG::",
    "panda::",
], key=len, reverse=True)


# ---------------------------------------------------------------------------
# 辅助函数：路径压缩
# ---------------------------------------------------------------------------

def _get_so_name(binary_name: str) -> str:
    """从 binary path 提取简短的 .so 名称."""
    if not binary_name:
        return ""
    # e.g. "/system/lib64/libace_compatible.z.so" → "libace_compatible.z.so"
    name = binary_name.split("/")[-1]
    return name


def _strip_prefix(name: str) -> str:
    """去掉输出时的长命名空间前缀."""
    for prefix in NAMESPACE_PREFIXES:
        if name.startswith(prefix):
            return name[len(prefix):]
    return name


def _clean_symbol(name: str) -> str:
    """简化 ArkTS/HarmonyOS 符号名，保留函数名、文件名、行号、包名。

    示例：
        init:[url:kwai|kwai|1.0.0|src/main/ets/startup/AutoStartupSchedulerTask.ts:29:1]
        → init:AutoStartupSchedulerTask.ts:29@kwai
    """
    if ":[" not in name:
        return name

    func_name, rest = name.split(":[", 1)
    idx = rest.find("]")
    if idx == -1:
        return name
    inner = rest[:idx]

    if inner.startswith("url:"):
        inner = inner[4:]

    parts = inner.split("|")
    if len(parts) < 2:
        return f"{func_name}:{inner}"

    bundle = parts[0]
    path_with_loc = parts[-1]
    file_part = path_with_loc.split("/")[-1]

    segments = file_part.split(":")
    if len(segments) >= 3 and segments[-1].isdigit() and segments[-2].isdigit():
        file_clean = ":".join(segments[:-1])
    else:
        file_clean = file_part

    return f"{func_name}:{file_clean}@{bundle}"


def _is_arkts_stub(func_name: str) -> bool:
    """判断函数名是否为 ArkTS/JS 虚拟机内部 Stub."""
    if not func_name:
        return False
    return func_name.startswith(ARKTS_STUB_PREFIXES)


def _is_arkts_vm_addr(func_name: str) -> bool:
    """判断函数名是否为 JS 运行时原始地址（libark_jsruntime.so+0x...）。"""
    if not func_name:
        return False
    return func_name.startswith("libark_jsruntime.so+")


def _has_offset(func_name: str) -> bool:
    """判断函数名是否含地址偏移量（+0x...），即可以参与同 .so 合并的地址节点。"""
    return "+0x" in func_name


def _is_kernel_binary(binary_name: str | None) -> bool:
    """判断 binary 是否来自内核（用于 P1.5 核态剔除）。"""
    if not binary_name:
        return False
    return "kernel" in binary_name.lower()


def _build_raw_tree(callchains: list[dict[str, Any]]) -> _HotpathNode:
    """用原始归一化 callchain 建树（不做压缩）。每个节点记录 binary_name。"""
    root = _HotpathNode(name="")

    for cc in callchains:
        nodes = cc["nodes"]
        bins = cc["bins"]
        self_cycles = cc["self_cycles"]
        sample_count = cc["sample_count"]

        if not nodes:
            continue

        assert len(nodes) == len(bins), (
            f"nodes and bins length mismatch: {len(nodes)} vs {len(bins)}"
        )

        cur = root
        for node_name, bin_name in zip(nodes, bins):
            if node_name not in cur.children:
                cur.children[node_name] = _HotpathNode(name=node_name, binary=bin_name)
            cur = cur.children[node_name]

        # 终点节点累加
        cur.self_event += self_cycles
        cur.sample_count += sample_count

    # 后序遍历：计算 total_event / total_sample_count
    _compute_total_event(root)

    return root


def _compute_total_event(node: _HotpathNode) -> int:
    """递归后序遍历：total_event = self_event + sum(child.total_event)。"""
    child_total = 0
    child_samples = 0
    for c in node.children.values():
        child_total += _compute_total_event(c)
        child_samples += c.total_sample_count
        node.vm_stub_folded = max(node.vm_stub_folded, c.vm_stub_folded)
    node.total_event = node.self_event + child_total
    node.total_sample_count = node.sample_count + child_samples
    return node.total_event


# ---------------------------------------------------------------------------
# 树上操作： P1 / P1.5 / P2 / P3 / strip_tail_noise
# ---------------------------------------------------------------------------


def _tree_strip_tail_noise(node: _HotpathNode, key: str | None = None, parent: _HotpathNode | None = None) -> None:
    """从叶子往上删除 TAIL_NOISE_FUNCTIONS 节点。

    递归处理 children 后，如果当前节点是叶子且 name 在 noise 中，
    则从 parent.children 中删除自身。
    """
    # 先递归处理子节点
    for child_key in list(node.children.keys()):
        _tree_strip_tail_noise(node.children[child_key], child_key, node)

    # 当前节点是叶子且在 noise 中 → 删除
    if parent is not None and not node.children and _is_noise(node.name):
        del parent.children[key]


def _tree_merge_vm_stubs(node: _HotpathNode) -> None:
    """P1: 把 VM stub/addr 节点原地改名为 [ArkTs VM]，后续 P2/P3 会自然合并。

    递归处理子节点后，遍历当前节点的 children：
      如果 child 满足 _is_arkts_stub 或 _is_arkts_vm_addr，改名为 [ArkTs VM]。
      改名后 children key 变了，需要重建 children dict。
      新 key 使用 hash 格式，同名不合并。
    """
    for child in list(node.children.values()):
        _tree_merge_vm_stubs(child)

    new_children: dict[str, _HotpathNode] = {}
    for child in list(node.children.values()):
        if _is_arkts_stub(child.name) or _is_arkts_vm_addr(child.name):
            child.name = "[ArkTs VM]"
            child.vm_stub_folded = 1
            key = f"[ArkTs VM]#{id(child):x}"
        else:
            key = child.name
        new_children[key] = child
    node.children = new_children


def _tree_strip_kernel(node: _HotpathNode, has_vm: bool = False) -> bool:
    """P1.5: 含 [ArkTs VM] 的子树中删除所有 binary 含 kernel 的节点。

    返回当前子树是否含 [ArkTs VM]（供父节点判断）。
    """
    vm_here = "[ArkTs VM]" in node.name
    has_vm = has_vm or vm_here

    # 递归检查子节点
    removed_keys: list[str] = []
    for child_name, child in list(node.children.items()):
        child_has_vm = _tree_strip_kernel(child, has_vm)
        if child_has_vm and not vm_here:
            has_vm = True
        # P1.5: subtree 含 VM 且当前 child 的 binary 含 kernel → 删除
        if child_has_vm and _is_kernel_binary(child.binary):
            removed_keys.append(child_name)

    for key in removed_keys:
        del node.children[key]

    return has_vm


def _tree_merge_same_so(node: _HotpathNode) -> None:
    """P2: 父子同 .so 地址节点合并（向上吸收）。

    遍历所有子节点：如果父子双方都满足 _has_offset 且同 .so，
    把子节点的 children 挂到父节点上，删除子节点。
    使用 while 迭代处理吸收后剩余的子节点。
    """
    children = list(node.children.items())
    for key, child in children:
        _tree_merge_same_so(child)
        node_has_offset = _has_offset(node.name)
        child_name = child.name
        same_so = (
                node_has_offset
                and _has_offset(child_name)
                and _get_so_name(node.binary) == _get_so_name(child.binary)
        )
        same_name = (node.name == child_name)
        if same_so or same_name:
            _absorb_child(node, child)
            del node.children[key]


def _absorb_child(parent: _HotpathNode, child: _HotpathNode) -> None:
    """子节点被父节点吸收：直接转移 children，用 hash key 避免同名冲突。

    不合并：被吸收节点的直接子节点各自以 name#hash 为 key 挂到 parent 下，
    parent 下原有的同名节点不受影响。
    """
    for gc in list(child.children.values()):
        new_key = f"{gc.name}#{id(gc):x}"
        parent.children[new_key] = gc


def _collect_hotspot_paths(
        root: _HotpathNode,
        grand_total: int,
        threshold_ratio: float = 0.01,
        total_samples: int | None = None,
) -> list[dict[str, Any]]:
    """树遍历：收集热点路径。

    - 阈值 = total_samples × threshold_ratio（基于采样点数量）
    - 当前节点 total_sample_count ≥ 阈值 且 所有子节点 < 阈值 → 输出该节点
    - 当前节点 total_sample_count ≥ 阈值 且 有子节点 ≥ 阈值 → 继续下钻
    - 当前节点 total_sample_count < 阈值 → 跳过
    - self_event / sample_count 从子树所有叶子节点汇总
    """
    if total_samples is None:
        total_samples = int(grand_total)  # 兼容：grand_total 当作 samples（旧的 cycles 逻辑）
    threshold = total_samples * threshold_ratio
    results: list[dict[str, Any]] = []

    def _sum_subtree(node: _HotpathNode) -> tuple[int, int]:
        """递归收集子树中所有节点的 self_event、sample_count 汇总。"""
        total_self = node.self_event
        total_samples = node.sample_count
        for child in node.children.values():
            child_self, child_samples = _sum_subtree(child)
            total_self += child_self
            total_samples += child_samples
        return total_self, total_samples

    def _traverse(node: _HotpathNode, path_nodes: list[str], path_samples: list[int]) -> None:
        if node.total_sample_count < threshold:
            return

        hot_children = [c for c in node.children.values() if c.total_sample_count >= threshold]

        if not hot_children:
            if node.name != "":
                effective_leaf = path_nodes[-1]
                if "[ArkTs VM]" in effective_leaf:
                    for n in reversed(path_nodes[:-1]):
                        if "[ArkTs VM]" not in n:
                            effective_leaf = n
                            break
                subtree_self, subtree_samples = _sum_subtree(node)
                results.append({
                    "path_compressed": PATH_SEP.join(path_nodes),
                    "path_nodes": list(path_nodes),
                    "path_samples": list(path_samples),
                    "self_event": node.self_event,
                    "subtree_self_event": subtree_self,
                    "total_event": node.total_event,
                    "self_sample_count": node.sample_count,
                    "total_sample_count": node.total_sample_count,
                    "leaf_function": effective_leaf,
                })
            return

        for child in hot_children:
            _traverse(child, path_nodes + [child.name], path_samples + [child.total_sample_count])

    # Root 需要特殊处理：root 下钻到所有超阈值子节点
    if root.total_sample_count >= threshold:
        for child in root.children.values():
            _traverse(child, [child.name], [child.total_sample_count])

    # 按 total_event 降序排列
    results.sort(key=lambda x: x["total_event"], reverse=True)
    return results


# ---------------------------------------------------------------------------
# 调试：树可视化
# ---------------------------------------------------------------------------


def _dump_hotpath_tree(
        root: _HotpathNode,
        grand_total: int,
        threshold_ratio: float = 0.01,
        max_depth: int = -1,
        top_children: int = 8,
        total_samples: int | None = None,
) -> str:
    """生成调用树的 ASCII 可视化，供调试用。

    返回一个多行字符串，格式类似 tree 命令输出。

    Args:
        root: 树根节点
        grand_total: 全局 self_cycles 总和
        threshold_ratio: 阈值比例（用于 sample-based 阈值）
        max_depth: 最大递归深度，-1 不限制
        top_children: 每个节点最多显示前 N 个子节点（按 total_event 降序）
        total_samples: 全局采样点总数（默认用 grand_total）
    """
    if total_samples is None:
        total_samples = int(grand_total)
    threshold = total_samples * threshold_ratio
    lines: list[str] = []

    def _dump(
            node: _HotpathNode,
            indent: str,
            is_last: bool,
            depth: int,
    ) -> None:
        if max_depth >= 0 and depth > max_depth:
            return

        if node.name == "":  # root
            total = sum(c.total_event for c in node.children.values())
            root_samples = sum(c.total_sample_count for c in node.children.values())
            lines.append(f"root (total={_fmt(total)}, samples={root_samples}, threshold={threshold:.0f} samples)")
        else:
            branch = "└── " if is_last else "├── "
            hot = " ★ HOT" if node.total_sample_count >= threshold else ""
            lines.append(
                f"{indent}{branch}{node.name[:80]}"
                f"  total={_fmt(node.total_event)}, samples={node.total_sample_count}{hot}"
            )

        children_sorted = sorted(
            node.children.items(), key=lambda x: -x[1].total_event
        )
        if node.name == "":
            # root children: show all top_children
            shown = children_sorted[:top_children]
            hidden = len(children_sorted) - len(shown)
        else:
            # internal nodes: show only HOT children + top few cold ones
            hot = [(n, c) for n, c in children_sorted if c.total_event >= threshold]
            cold = [(n, c) for n, c in children_sorted if c.total_event < threshold]
            if len(hot) > top_children:
                shown = hot[:top_children]
                hidden = len(children_sorted) - len(shown)
            else:
                remaining = top_children - len(hot)
                shown = hot + cold[:remaining]
                hidden = len(children_sorted) - len(shown)

        for i, (name, child) in enumerate(shown):
            last = (i == len(shown) - 1) and (hidden == 0)
            prefix = indent + ("    " if is_last else "│   ")
            _dump(child, prefix, last, depth + 1)

        if hidden > 0:
            prefix = indent + ("    " if is_last else "│   ")
            branch = "└── " if hidden == len(children_sorted) - len(shown) else "├── "
            lines.append(f"{prefix}{branch}... and {hidden} more children")

    _dump(root, "", True, 0)
    return "\n".join(lines)


def _fmt(n: int) -> str:
    """人类可读的数字格式化。"""
    if n >= 1_000_000_000:
        return f"{n / 1_000_000_000:.1f}B"
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)




# ---------------------------------------------------------------------------
# 算子 1: build_hiperf_callchains
# ---------------------------------------------------------------------------

@register_operator("build_hiperf_callchains")
def build_hiperf_callchains(ctx: PreprocessContext) -> PreprocessContext:
    """按 callchain_id 分组，depth 0→N 拼接为 path，叶子节点标记 self_cycles。

    输入 DataFrame 扁平结构（每行一个栈帧）:
      callchain_id, thread_id, thread_name, event_count, depth, func_name,
      binary_name, event_type, ts_ms

    输出 DataFrame 每行一个完整调用链:
      callchain_id, thread_id, thread_name, event_count, depth,
      func_name, binary_name, event_type, ts_ms,
      callchain_path, binary_names(list), max_depth, leaf_func_name, self_cycles, sample_count
    """
    df = ctx.data
    if df is None or df.empty:
        ctx.data = pd.DataFrame()
        return ctx

    df = df.copy()
    df = df.sort_values(["callchain_id", "depth"])

    records: list[dict[str, Any]] = []

    for callchain_id, group in df.groupby("callchain_id", sort=False):
        group = group.sort_values("depth")
        depths = group["depth"].tolist()
        funcs = group["func_name"].tolist()
        bins = group["binary_name"].tolist()

        if not depths:
            continue

        max_depth = max(depths)
        leaf_depth = max_depth
        leaf_idx = depths.index(leaf_depth)

        callchain_path = PATH_SEP.join(funcs)

        first = group.iloc[0]

        records.append({
            "callchain_id": callchain_id,
            "thread_id": first["thread_id"],
            "thread_name": first["thread_name"],
            "event_count": first["event_count"],
            "depth": max_depth,
            "func_name": funcs[0] if funcs else None,
            "binary_name": bins[0] if bins else None,
            "event_type": first["event_type"],
            "ts_ms": first["ts_ms"],
            "callchain_path": callchain_path,
            "binary_names": bins,  # list of binary_name per depth
            "max_depth": max_depth,
            "leaf_func_name": funcs[-1] if funcs else None,
            "leaf_binary_name": bins[leaf_idx] if bins else None,
            "self_cycles": group.iloc[leaf_idx]["event_count"],
            "sample_count": int(first.get("sample_count", 1)) if "sample_count" in first.index else 1,
        })

    result = pd.DataFrame(records)
    ctx.data = result
    ctx.meta["callchains_built"] = len(result)
    return ctx


# ---------------------------------------------------------------------------
# 算子 2: normalize_hiperf_functions
# ---------------------------------------------------------------------------

@register_operator("normalize_hiperf_functions")
def normalize_hiperf_functions(ctx: PreprocessContext) -> PreprocessContext:
    """复用 flamegraph_collapse.normalize_func_name 归一化函数名。

    P0: 去掉函数参数 (第一个 ( 及其后的内容)
    规则: allocate-1932 → allocate, FlushVsync(...) → FlushVsync 等。
    同时更新 callchain_path（按节点归一化拼接）。
    """
    df = ctx.data
    if df is None or df.empty:
        return ctx

    df = df.copy()

    if "func_name" in df.columns:
        df["normalized_name"] = df["func_name"].apply(normalize_func_name)

    if "leaf_func_name" in df.columns:
        df["normalized_leaf"] = df["leaf_func_name"].apply(normalize_func_name)

    if "callchain_path" in df.columns:
        # 按节点归一化 callchain_path
        normalized_paths = []
        for path_str in df["callchain_path"]:
            nodes = path_str.split(PATH_SEP)
            norm_nodes = [normalize_func_name(n) for n in nodes]
            normalized_paths.append(PATH_SEP.join(norm_nodes))
        df["callchain_path"] = normalized_paths

    ctx.data = df
    return ctx


# ---------------------------------------------------------------------------
# 算子 3: collapse_hiperf_system_libs
# ---------------------------------------------------------------------------

@register_operator("collapse_hiperf_system_libs")
def collapse_hiperf_system_libs(ctx: PreprocessContext) -> PreprocessContext:
    """把系统库函数和路径中的系统库段替换为 __system__。

    系统库模式: libc.*, libbinder, android.os.*, skia::, gfx::, jni:: 等。
    同时折叠 binary_name 列。
    """
    df = ctx.data
    if df is None or df.empty:
        return ctx

    df = df.copy()

    if "binary_name" in df.columns:
        df["is_system_lib"] = df["binary_name"].apply(_is_system_lib)
        system_mask = df["is_system_lib"]
        df.loc[system_mask, "binary_name"] = "__system__"
        df = df.drop(columns=["is_system_lib"])

    ctx.data = df
    return ctx


def _is_system_lib(name: str | None) -> bool:
    """判断 binary_name 是否为系统库。"""
    if not name:
        return False
    patterns = [
        r"libc\.",
        r"libbinder",
        r"android\.os\.",
        r"android\.view\.",
        r"ld-musl",
        r"gfx::",
        r"jni::",
        r"Java_android",
        r"__kernel",
    ]
    return any(re.search(p, name) for p in patterns)


# ---------------------------------------------------------------------------
# 算子 4: filter_by_threshold
# ---------------------------------------------------------------------------

@register_operator("filter_by_threshold")
def filter_by_threshold(ctx: PreprocessContext) -> PreprocessContext:
    """1% 阈值过滤: self_cycles < total * 0.01 的调用链被剪枝."""
    df = ctx.data
    if df is None or df.empty:
        return ctx

    df = df.copy()
    threshold_ratio = ctx.params.get("threshold_ratio", 0.01)

    total_self = df["self_cycles"].sum()
    if total_self == 0:
        return ctx

    threshold_value = total_self * threshold_ratio
    before = len(df)
    df = df[df["self_cycles"] >= threshold_value]
    after = len(df)

    ctx.meta["filter_threshold_ratio"] = threshold_ratio
    ctx.meta["filter_threshold_value"] = threshold_value
    ctx.meta["filter_before"] = before
    ctx.meta["filter_after"] = after

    ctx.data = df
    return ctx


# ---------------------------------------------------------------------------
# 算子 4.5: strip_shared_prefix（P4 提前执行，在 aggregation 之前）
# ---------------------------------------------------------------------------

@register_operator("strip_shared_prefix")
def strip_shared_prefix(ctx: PreprocessContext) -> PreprocessContext:
    """Pass-through：LCP 裁剪在新的树优先架构下由 finalize_hiperf 处理。

    保留算子注册以维持管道兼容。
    """
    return ctx


# ---------------------------------------------------------------------------
# 算子 5: aggregate_hiperf_functions
# ---------------------------------------------------------------------------

@register_operator("aggregate_hiperf_functions")
def aggregate_hiperf_functions(ctx: PreprocessContext) -> PreprocessContext:
    """按叶子节点归一化函数名聚合 self/total cycles.

    - self_cycles: 叶子节点的 event_count 总和
    - total_cycles: 该叶子函数所在调用链的 event_count 总和
    - 输出列: name, cycles, sample_count
    """
    df = ctx.data
    if df is None or df.empty:
        ctx.data = pd.DataFrame()
        return ctx

    if "normalized_leaf" not in df.columns:
        if "leaf_func_name" in df.columns:
            df = df.copy()
            df["normalized_leaf"] = df["leaf_func_name"].apply(normalize_func_name)
        else:
            df = df.copy()
            df["normalized_leaf"] = "unknown"

    agg = df.groupby("normalized_leaf", dropna=False).agg(
        cycles=("self_cycles", "sum"),
        sample_count=("sample_count", "sum"),
    ).reset_index()

    agg = agg.rename(columns={"normalized_leaf": "name"})
    agg = agg.sort_values("cycles", ascending=False).reset_index(drop=True)

    ctx.meta["_functions_df"] = agg
    return ctx


def _is_noise(func_name: str) -> bool:
    """判断函数名是否为尾部噪音（不影响合并）。"""
    if not func_name:
        return False
    # 完全匹配
    if func_name in TAIL_NOISE_FUNCTIONS:
        return True
    # 前缀匹配（如 "ld-musl-aarch64.so.1+0x1de1a8" 匹配 "ld-musl-aarch64.so.1"）
    for noise in TAIL_NOISE_BINARY:
        if func_name.startswith(noise):
            return True
    return False


# ---------------------------------------------------------------------------
# 算子 6: aggregate_hiperf_paths
# ---------------------------------------------------------------------------

@register_operator("aggregate_hiperf_paths")
def aggregate_hiperf_paths(ctx: PreprocessContext) -> PreprocessContext:
    """树优先架构：先建原始树 → 树上折叠/剪枝 → 阈值遍历收集热点路径。

    操作顺序:
      1. 用原始归一化 callchain 建树
      2. 后序计算 total_event / total_sample_count
      3. strip_tail_noise: 叶子往上删 noise
      4. P1: 合并连续 VM stub/addr → [ArkTs VM]
      5. P1.5: 含 VM 子树删除 kernel 节点
      6. P2: 父子同 .so 地址合并（向上吸收）
      7. P3: 父子同名合并（向上吸收）
      8. 阈值遍历收集热点
    """
    df = ctx.data
    if df is None or df.empty:
        ctx.data = pd.DataFrame()
        return ctx

    threshold_ratio = ctx.params.get("threshold_ratio", 0.05)

    # 收集原始 callchain 数据
    callchains: list[dict[str, Any]] = []
    grand_total = 0
    for _, row in df.iterrows():
        nodes = row["callchain_path"].split(PATH_SEP)
        bins = row.get("binary_names", [])
        if isinstance(bins, float):
            bins = []
        self_cycles = int(row["self_cycles"])
        sample_count = int(row["sample_count"]) if "sample_count" in row else 1
        callchains.append({
            "nodes": nodes,
            "bins": bins,
            "self_cycles": self_cycles,
            "sample_count": sample_count,
        })
        grand_total += self_cycles

    if not callchains:
        ctx.data = pd.DataFrame()
        return ctx

    # 1. 建原始树
    root = _build_raw_tree(callchains)

    # 2. P1: 合并 VM stub
    _tree_merge_vm_stubs(root)

    # 3. P1.5: 剔除 kernel
    _tree_strip_kernel(root)

    # 4. P2+P3: 同 .so不同地址或者同名合并
    _tree_merge_same_so(root)

    # 5. 叶子往上删 noise
    _tree_strip_tail_noise(root)

    # 7. 阈值遍历 + 覆盖率贪心兜底
    total_samples_sum = sum(c["sample_count"] for c in callchains)
    threshold_ratio_explicit = bool(ctx.params.get("threshold_ratio_explicit", False))
    initial_threshold = threshold_ratio
    used_threshold = threshold_ratio

    if not threshold_ratio_explicit and total_samples_sum > 0:
        # 覆盖率贪心兜底:覆盖率 <85% 时逐档降档
        degradation_steps = [0.05, 0.02, 0.01, 0.005, 0.002, 0.001, 0.0005]
        current_threshold = threshold_ratio
        for try_threshold in degradation_steps:
            if try_threshold > current_threshold:
                continue
            trial_hotspots = _collect_hotspot_paths(
                root, grand_total, try_threshold, total_samples=total_samples_sum
            )
            trial_coverage = sum(h["total_sample_count"] for h in trial_hotspots) / total_samples_sum
            if trial_coverage >= 0.85:
                # 覆盖率达标,用当前阈值
                hotspots = trial_hotspots
                used_threshold = try_threshold
                break
            else:
                # 覆盖率不够,但若实质提升 >5pp 且路径 ≤100,接受降档
                baseline_hotspots = _collect_hotspot_paths(
                    root, grand_total, current_threshold, total_samples=total_samples_sum
                )
                baseline_coverage = sum(h["total_sample_count"] for h in baseline_hotspots) / total_samples_sum
                if (trial_coverage - baseline_coverage) > 0.05 and len(trial_hotspots) <= 100:
                    hotspots = trial_hotspots
                    used_threshold = try_threshold
                    current_threshold = try_threshold  # 继续尝试更低阈值
                # 否则继续降档
        else:
            # 所有降档都未达 85%,用最后一次接受的阈值(或初始阈值)
            if used_threshold == threshold_ratio:
                hotspots = _collect_hotspot_paths(
                    root, grand_total, threshold_ratio, total_samples=total_samples_sum
                )
    else:
        hotspots = _collect_hotspot_paths(root, grand_total, threshold_ratio, total_samples=total_samples_sum)

    ctx.meta["_paths_threshold_ratio_used"] = used_threshold
    ctx.meta["_paths_threshold_ratio_initial"] = initial_threshold

    # 构建 _paths_df
    records = []
    for h in hotspots:
        records.append({
            "path_compressed": h["path_compressed"],
            "path_nodes": h["path_nodes"],
            "path_samples": h["path_samples"],
            "self_cycles": h["self_event"],
            "total_cycles": h["total_event"],
            "self_sample_count": h["self_sample_count"],
            "total_sample_count": h["total_sample_count"],
            "depth": len(h["path_nodes"]),
            "leaf_function": h["leaf_function"],
            "normalized_leaf": normalize_func_name(h["leaf_function"]),
        })

    agg = pd.DataFrame(records)
    if not agg.empty:
        agg = agg.sort_values("total_cycles", ascending=False).reset_index(drop=True)

    ctx.meta["_paths_df"] = agg
    ctx.meta["_paths_raw_total_samples"] = sum(c["sample_count"] for c in callchains)
    ctx.meta["_paths_raw_total_cycles"] = grand_total

    # Debug: 生成树的可视化 dump 并写入文件
    if ctx.params.get("debug_dump_tree"):
        from pathlib import Path
        dump_str = _dump_hotpath_tree(root, grand_total, threshold_ratio, total_samples=total_samples_sum)
        ctx.meta["_tree_dump"] = dump_str
        dump_dir = Path(".")
        if ctx.sqlite_conn:
            try:
                cur = ctx.sqlite_conn.execute("PRAGMA database_list")
                for row in cur.fetchall():
                    if row[1] == "main":
                        dump_dir = Path(row[2]).parent
                        break
            except Exception:
                pass
        dump_file = dump_dir / "hotpath_tree_dump.txt"
        dump_file.write_text(dump_str, encoding="utf-8")
        log.info("tree dump written to %s (%d chars)", dump_file, len(dump_str))

    return ctx


# ---------------------------------------------------------------------------
# 算子 6.5: filter_hiperf_paths（阈值过滤，在聚合之后执行）
# ---------------------------------------------------------------------------

@register_operator("filter_hiperf_paths")
def filter_hiperf_paths(ctx: PreprocessContext) -> PreprocessContext:
    """Pass-through：树式聚合（aggregate_hiperf_paths）已在建树遍历时完成阈值剪枝。

    保留算子注册以维持向后兼容（test_all_eight_ops_registered）。
    """
    return ctx


# ---------------------------------------------------------------------------
# 算子 7: aggregate_hiperf_binaries
# ---------------------------------------------------------------------------

@register_operator("aggregate_hiperf_binaries")
def aggregate_hiperf_binaries(ctx: PreprocessContext) -> PreprocessContext:
    """按叶子节点所在二进制/库名称聚合 self_cycles.

    - 权重为 self_cycles（叶子节点的 event_count）
    - binary 取自 leaf_binary_name（叶子栈帧所在的二进制）
    - 输出列: name, total_cycles, sample_count
    """
    df = ctx.data
    if df is None or df.empty:
        ctx.data = pd.DataFrame()
        return ctx

    if "leaf_binary_name" not in df.columns:
        ctx.data = pd.DataFrame()
        return ctx

    agg = df.groupby("leaf_binary_name", dropna=False).agg(
        total_cycles=("self_cycles", "sum"),
        sample_count=("sample_count", "sum"),
    ).reset_index()

    agg = agg.rename(columns={"leaf_binary_name": "name"})
    agg = agg.sort_values("total_cycles", ascending=False).reset_index(drop=True)

    ctx.meta["_binaries_df"] = agg
    return ctx


# ---------------------------------------------------------------------------
# 算子 8: finalize_hiperf
# ---------------------------------------------------------------------------

@register_operator("finalize_hiperf")
def finalize_hiperf(ctx: PreprocessContext) -> PreprocessContext:
    """收敛为 summary 结构。

    Top 热点函数/库、调用栈树均由下游算子(render_hiperf_agent_report)
    组装到 agent_report 字符串字段;本算子只产出 summary 元数据。
    P4: 公共前缀(LCD)提取由 strip_shared_prefix 算子执行,写入 meta._lcp_*。
    """
    top_n = ctx.params.get("top_n", 10)
    show_original = ctx.params.get("show_original_names", False)

    paths_meta = ctx.meta.get("_paths_df")
    if paths_meta is None:
        paths_meta = pd.DataFrame()

    raw_df = ctx.data if hasattr(ctx.data, "iloc") else None

    if raw_df is not None and not raw_df.empty:
        event_type = str(raw_df["event_type"].iloc[0]) if "event_type" in raw_df.columns else "unknown"
        ts_ms = raw_df["ts_ms"] if "ts_ms" in raw_df.columns else None
        if ts_ms is not None and not ts_ms.empty:
            start_ts = float(ts_ms.min())
            end_ts = float(ts_ms.max())
            time_range_ms = {
                "start": round(start_ts, 2),
                "end": round(end_ts, 2),
                "duration": round(end_ts - start_ts, 2),
            }
        else:
            time_range_ms = {}
    else:
        event_type = "unknown"
        time_range_ms = {}

    filtered_tid = ctx.params.get("tid")

    # 构建 summary
    if paths_meta is not None and not paths_meta.empty:
        total_samples = int(ctx.meta.get("_paths_raw_total_samples", 0))
        total_callchains = len(paths_meta)
        total_cycles = int(ctx.meta.get("_paths_raw_total_cycles", 0))
    else:
        total_samples = 0
        total_callchains = 0
        total_cycles = 0

    summary: dict[str, Any] = {
        "type": "hiperf_thread_hotpath",
        "event_type": event_type,
        "time_range_ms": time_range_ms,
        "total_samples": total_samples,
        "total_callchains": total_callchains,
        "total_cycles": total_cycles,
        "filtered_tid": filtered_tid,
        "top_n": top_n,
        "show_original_names": show_original,
    }

    result: dict[str, Any] = {"summary": summary}

    # Debug: 树可视化 dump
    tree_dump = ctx.meta.get("_tree_dump")
    if tree_dump:
        result["tree_dump"] = tree_dump

    ctx.data = result
    return ctx


# ---------------------------------------------------------------------------
# folded_to_tree 引擎(内联,来自 ZIP 包 folded_to_tree.py,140 行 stdlib-only)
# ---------------------------------------------------------------------------

@dataclass
class _FoldedTreeNode:
    """折叠栈聚合树节点(与 _HotpathNode 区分:前者是折叠栈聚合,后者是 callchain 聚合)。

    - count: 以该节点为根的子树累计样本数(含全部子孙)
    - children: 子节点字典,按 name 索引
    """
    name: str
    count: int = 0
    children: dict[str, "_FoldedTreeNode"] = field(default_factory=dict)


def _strip_common_prefix(stacks: list[tuple[list[str], int]]) -> tuple[list[str], list[tuple[list[str], int]]]:
    """剥离所有栈共享的根前缀。

    Args:
        stacks: [(frames_list, count), ...],frames_list 为根→叶顺序

    Returns:
        (prefix, stripped_stacks): prefix 是所有栈共享的根前缀;
        stripped_stacks 是去除前缀后的栈列表(空栈保留为 ([], count))
    """
    if not stacks:
        return [], stacks
    prefix: list[str] = []
    for col in zip(*(s[0] for s in stacks)):
        if all(f == col[0] for f in col):
            prefix.append(col[0])
        else:
            break
    if not prefix:
        return [], stacks
    prefix_len = len(prefix)
    return prefix, [(s[0][prefix_len:], s[1]) for s in stacks]


def _build_folded_trie(stacks: list[tuple[list[str], int]]) -> _FoldedTreeNode:
    """从折叠栈列表构建 Trie 树。

    每个 node.count = 以该节点为根的子树累计样本数(含全部子孙)。

    Args:
        stacks: [(frames_list, count), ...],frames_list 为根→叶顺序(已剥离公共前缀)

    Returns:
        root _FoldedTreeNode,count = 全部样本总和
    """
    root = _FoldedTreeNode(name="<root>")
    for frames, c in stacks:
        node = root
        node.count += c
        for f in frames:
            node = node.children.setdefault(f, _FoldedTreeNode(name=f))
            node.count += c
    return root


def _render_folded_tree(
    node: _FoldedTreeNode,
    total: int,
    min_count: int,
    max_depth: int,
    prefix: str = "",
    depth: int = 0,
    is_last: bool = True,
    is_root: bool = True,
) -> list[str]:
    """渲染折叠栈 Trie 为累计样本标注树。

    节点标注格式: `[N | P%]` = 累计样本数(含子孙) | 占已知栈比例
    特性:
    - 独子链压缩:a→b→c 合并为一行(计数相同时)
    - 小分支剪枝:< min_count 的分支合并为 "… (N samples)"
    - 深度上限:超过 max_depth 折叠为 "⋯ (deeper N samples)"

    Args:
        node: 当前节点
        total: 已知栈样本总数(用于计算百分比)
        min_count: 剪枝阈值,< 此值的分支合并
        max_depth: 最大渲染深度
        prefix: 当前行前缀(缩进 + 连接线)
        depth: 当前深度
        is_last: 当前节点是否为父节点的最后一个可见子节点
        is_root: 是否为根节点(根节点不打印自身)

    Returns:
        树各行字符串列表
    """
    lines: list[str] = []

    if is_root:
        # 根节点:不打印自身,只打印可见子节点
        children = sorted(node.children.values(), key=lambda n: -n.count)
        visible = [c for c in children if c.count >= min_count]
        hidden = sum(c.count for c in children if c.count < min_count)
        for i, child in enumerate(visible):
            last = (i == len(visible) - 1) and hidden == 0
            lines.extend(_render_folded_tree(child, total, min_count, max_depth, "", 0, last, False))
        if hidden:
            lines.append(f"└── … ({hidden} samples, <{min_count} 阈值分支已剪枝)")
        return lines

    pct = node.count / total * 100 if total else 0
    connector = "└── " if is_last else "├── "

    if depth >= max_depth:
        lines.append(f"{prefix}{connector}⋯ (deeper {node.count} samples)")
        return lines

    # 独子链压缩:a → b → c 合并为一行(计数相同)
    chain: list[str] = [node.name]
    cur = node
    while len(cur.children) == 1:
        child = next(iter(cur.children.values()))
        if child.count != cur.count:
            break
        chain.append(child.name)
        cur = child
    lines.append(f"{prefix}{connector}{' → '.join(chain)}  [{node.count} | {pct:.1f}%]")
    node = cur

    ext = "    " if is_last else "│   "
    children = sorted(node.children.values(), key=lambda n: -n.count)
    visible = [c for c in children if c.count >= min_count]
    hidden = sum(c.count for c in children if c.count < min_count)
    for i, child in enumerate(visible):
        last = (i == len(visible) - 1) and hidden == 0
        lines.extend(_render_folded_tree(child, total, min_count, max_depth, prefix + ext, depth + 1, last, False))
    if hidden:
        lines.append(f"{prefix}{ext}└── … ({hidden} samples, 阈值以下分支已剪枝)")
    return lines


# ---------------------------------------------------------------------------
# 算子 6.5: render_hiperf_folded_tree(把 _paths_df 渲染为标注调用栈树)
# ---------------------------------------------------------------------------

@register_operator("render_hiperf_folded_tree")
def render_hiperf_folded_tree(ctx: PreprocessContext) -> PreprocessContext:
    """把 _paths_df 渲染为累计样本标注调用栈树(复用 folded_to_tree 引擎)。

    产物写入 ctx.meta:
      _folded_tree_lines         树各行(含公共根前缀行)
      _folded_tree_known_stacks  已知栈条数
      _folded_tree_known_samples 已知栈样本总数
      _folded_tree_min_pct       实际使用的剪枝阈值

    参数:
      tree_min_pct(默认 2.0): 剪枝阈值百分比
      tree_max_depth(默认 40): 最大渲染深度
    """
    agg = ctx.meta.get("_paths_df")
    if agg is None or agg.empty:
        ctx.meta["_folded_tree_lines"] = []
        ctx.meta["_folded_tree_known_stacks"] = 0
        ctx.meta["_folded_tree_known_samples"] = 0
        return ctx

    min_pct = float(ctx.params.get("tree_min_pct", 2.0))
    max_depth = int(ctx.params.get("tree_max_depth", 40))

    # 从 _paths_df 提取 (frames_list, count) 列表
    stacks = [
        ([str(n) for n in row["path_nodes"]], int(row["total_sample_count"]))
        for _, row in agg.iterrows()
    ]
    total = sum(c for _, c in stacks)
    prefix, stacks = _strip_common_prefix(stacks)
    min_count = max(1, round(total * min_pct / 100))

    lines: list[str] = []
    if prefix:
        lines.append(f"[公共根前缀,所有栈共享] {' → '.join(prefix)}  [{total} | 100.0%]")
    root = _build_folded_trie(stacks)
    lines.extend(_render_folded_tree(root, total, min_count, max_depth))

    ctx.meta["_folded_tree_lines"] = lines
    ctx.meta["_folded_tree_known_stacks"] = len(stacks)
    ctx.meta["_folded_tree_known_samples"] = total
    ctx.meta["_folded_tree_min_pct"] = min_pct
    return ctx


# ---------------------------------------------------------------------------
# 算子 9: render_hiperf_agent_report(组装 Agent 友好 markdown 报告)
# ---------------------------------------------------------------------------

@register_operator("render_hiperf_agent_report")
def render_hiperf_agent_report(ctx: PreprocessContext) -> PreprocessContext:
    """组装 Agent 友好 markdown 报告,写入 ctx.data["agent_report"]。

    结构:基本信息 → Top 热点函数/库(从 meta._functions_df/_binaries_df 即时计算)
    → 调用栈树(取 meta._folded_tree_lines,由 render_hiperf_folded_tree 生成)。
    """
    result = ctx.data
    if not isinstance(result, dict) or "summary" not in result:
        return ctx

    m = ctx.meta
    s = result["summary"]
    tr = s.get("time_range_ms") or {}
    lines = [
        "# HiPerf 线程热点分析 (调用栈树格式)",
        "",
        "## 基本信息",
        f"- 事件类型: {s.get('event_type')}",
        f"- 线程 tid: {s.get('filtered_tid')}",
        f"- 采样窗口: [{tr.get('start')}, {tr.get('end')}] ms (时长 {tr.get('duration')} ms)",
        f"- 总样本数: {s.get('total_samples')}, 总 cycles: {s.get('total_cycles')}",
        "",
        "## Top 热点函数 (叶子, 占比 = 该叶子样本 / 全部叶子样本)",
    ]
    top_functions_n = int(ctx.params.get("top_functions_n", 5))
    functions_df = m.get("_functions_df")
    if functions_df is not None and not functions_df.empty:
        total_func_samples = functions_df["sample_count"].sum() if "sample_count" in functions_df.columns else 1
        if total_func_samples == 0:
            total_func_samples = 1
        for _, row in functions_df.head(top_functions_n).iterrows():
            name = _clean_symbol(_strip_prefix(row.get("name", "unknown")))
            s_count = int(row.get("sample_count", 0))
            ratio = s_count / total_func_samples
            lines.append(f"- {name}: {ratio * 100:.1f}% (samples={s_count})")

    lines += ["", "## Top 热点库"]
    top_binaries_n = int(ctx.params.get("top_binaries_n", 5))
    binaries_df = m.get("_binaries_df")
    if binaries_df is not None and not binaries_df.empty:
        total_bin_samples = binaries_df["sample_count"].sum() if "sample_count" in binaries_df.columns else 1
        if total_bin_samples == 0:
            total_bin_samples = 1
        for _, row in binaries_df.head(top_binaries_n).iterrows():
            name = row.get("name", "unknown")
            s_count = int(row.get("sample_count", 0))
            ratio = s_count / total_bin_samples
            lines.append(f"- {name}: {ratio * 100:.1f}% (samples={s_count})")

    tree_lines = m.get("_folded_tree_lines") or []
    known_stacks = m.get("_folded_tree_known_stacks", 0)
    total = m.get("_folded_tree_known_samples", 0)
    used_min_pct = m.get("_folded_tree_min_pct", 2.0)
    lines += [
        "",
        "## 调用栈树 (节点标注 [N | P%] = 累计样本数(含子孙) | 占已知栈比例; "
        f"剪枝阈值 {used_min_pct}%)",
        f"# 已知栈 {known_stacks} 条 / {total} 样本",
    ]
    declared = s.get("total_samples")
    if declared:
        note = ""
        used = m.get("_paths_threshold_ratio_used")
        if used is not None:
            initial = m.get("_paths_threshold_ratio_initial", used)
            note = f";路径阈值 {used * 100:.1f}%"
            if used < initial:
                note += f"(栈分散, 从 {initial * 100:.1f}% 自动降档保覆盖率)"
        lines.append(f"# 头部声明总样本 {declared}"
                     f"(栈覆盖率 {total / declared * 100:.1f}%{note})")
    lines.extend(tree_lines)

    result["agent_report"] = "\n".join(lines)
    ctx.data = result
    return ctx

