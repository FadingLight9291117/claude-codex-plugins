"""芯片识别 MCP 工具。

通过 TraceDataCache.chip_config() 实现芯片识别功能。
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any, Dict

from core.preprocess.chip_config import (
    _extract_freq_from_df,
    _load_chips_db,
    _match_chips_with_details,
)
from core.preprocess.trace_data_cache import get_trace_data_cache


def identify_chip(sqlite_path: str) -> Dict[str, Any]:
    """芯片识别入口(被 MCP tool 调用)。

    通过 TraceDataCache.chip_config() 获取芯片配置,并转换为现有 schema 输出。
    (sqlite_path, mtime) 路径级缓存保留,避免重复构建 cache。
    """
    if not Path(sqlite_path).exists():
        raise FileNotFoundError(f"SQLite 数据库不存在: {sqlite_path}")

    cache_key = (str(Path(sqlite_path).resolve()), Path(sqlite_path).stat().st_mtime)
    if cache_key in _identify_cache:
        return _identify_cache[cache_key]

    conn = sqlite3.connect(sqlite_path)
    try:
        cache = get_trace_data_cache(conn)
        chip_config = cache.chip_config()
        start_ns, end_ns = cache.trace_range()
        start_ms = start_ns / 1_000_000.0
        end_ms = end_ns / 1_000_000.0

        # 提取 per_cpu_freq 用于输出 schema
        # 注意:cache.measure('cpu_frequency') 返回 kHz(与 measure 表原始 value 一致),
        # chip 匹配期望 MHz → 需 /1000(与 trace_data_cache._build_chip_config 对齐)
        freq_rows = cache.measure("cpu_frequency", start_ns, end_ns)
        per_cpu_freq = []
        if freq_rows:
            import pandas as pd
            df = pd.DataFrame(freq_rows, columns=['ts', 'dur', 'value', 'cpu'])
            df = df.rename(columns={'cpu': 'cpuid'})
            df['freq'] = df['value'] / 1000
            df['data_type'] = 'freq'
            per_cpu_freq = _extract_freq_from_df(df)

        # 构造 matched_chips(保持现有 schema)
        if chip_config.get("chip_model") == "Unknown_chip":
            matched_chips = [{
                "chip_model": "Unknown_chip",
                "vendor": "Unknown",
                "total_logical_cpus": chip_config.get("total_logical_cpus", 0),
                "clusters": chip_config.get("clusters", []),
                "similarity_score": 0.0,
                "max_freq_diff_mhz": -1,
                "is_default_fallback": True,
            }]
        else:
            # 真实匹配:从 chips_db 取完整 chip dict 构造 matched_chips
            chips_db = _load_chips_db()
            cm = next(
                (c for c in chips_db
                 if c.get('chip_model') == chip_config.get('chip_model')),
                None,
            )
            if cm:
                # 重算 similarity_score(从 per_cpu_freq 反推最佳匹配)
                cpu_count = chip_config.get("total_logical_cpus", 0)
                matched_details = _match_chips_with_details(cpu_count, per_cpu_freq) if per_cpu_freq else []
                score = matched_details[0].get("similarity_score", 1.0) if matched_details else 1.0
                max_diff = matched_details[0].get("max_freq_diff_mhz", 0) if matched_details else 0
                matched_chips = [{
                    "chip_model": cm.get("chip_model"),
                    "vendor": cm.get("vendor"),
                    "total_logical_cpus": cm.get("total_logical_cpus"),
                    "clusters": cm.get("clusters"),
                    "similarity_score": score,
                    "max_freq_diff_mhz": max_diff,
                    "match_details": {
                        "cpu_count_match": True,
                        "cluster_config_match": True,
                        "smt_config_match": True,
                        "freq_range_match": True,
                    },
                }]
            else:
                # chips_db 找不到(理论不会发生),走 unknown fallback
                matched_chips = [{
                    "chip_model": "Unknown_chip",
                    "vendor": "Unknown",
                    "total_logical_cpus": chip_config.get("total_logical_cpus", 0),
                    "clusters": chip_config.get("clusters", []),
                    "similarity_score": 0.0,
                    "max_freq_diff_mhz": -1,
                    "is_default_fallback": True,
                }]

        result = {
            "sqlite_path": sqlite_path,
            "trace_time_range": {
                "start_ms": start_ms,
                "end_ms": end_ms,
                "duration_ms": end_ms - start_ms,
            },
            "cpu_topology": {
                "total_logical_cpus": chip_config.get("total_logical_cpus", 0),
                "per_cpu_freq": per_cpu_freq,
            },
            "matched_chips": matched_chips,
        }
    finally:
        conn.close()

    _identify_cache[cache_key] = result
    return result


def clear_identify_cache() -> None:
    """清空芯片识别路径级缓存(测试与热更新场景使用)。"""
    _identify_cache.clear()


# 路径级缓存(与 cache 连接级缓存互补)
_identify_cache: Dict[tuple, Dict[str, Any]] = {}
