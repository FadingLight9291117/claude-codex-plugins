"""统一查询引擎。

职责:
- SQL 模板渲染（template_vars 替换 + sqlite3 命名参数绑定）
- 动态参数三层合并: sql_params 默认值 < group override_params < agent indicator_params
- group 递归展开（委托 ConfigRegistry.expand_indicators）
- 大数据采样: 时序分桶聚合 / 非时序 Top N / 标量直接透传
- 火焰图等指标的预处理引擎分发（preprocess.engine）
"""
from __future__ import annotations

import re
import sqlite3
import statistics
import time
from typing import Any, Optional

from core.registry import ConfigRegistry, IndicatorMeta
from core.observability import get_observability_logger
from core.preprocess import PreprocessError
from core.preprocess.trace_data_cache import get_trace_data_cache


class QueryEngine:
    """SQL 渲染 + 批量执行 + 大数据采样 + 预处理引擎调度。"""

    def __init__(self, registry: ConfigRegistry):
        self.registry = registry

    # -----------------------------------------------------------------
    # 单条 SQL 构建
    # -----------------------------------------------------------------

    def build_query(
        self,
        indicator_name: str,
        base_params: dict,
        override_params: Optional[dict] = None,
        agent_params: Optional[dict] = None,
    ) -> tuple[str, dict, dict]:
        """构建单条 SQL 的渲染结果。

        Returns:
            rendered_sql:    替换 template_vars 后、保留 :xxx 命名参数的 SQL
            sqlite_bindings: 提供给 cursor.execute 的命名参数字典
            query_metadata:  指标元信息（params_used, row_limit, is_timeseries 等）
        """
        meta = self.registry.atomic_indicators[indicator_name]
        sql = meta.sql or ""

        # 1. 三层参数合并（低 → 高优先级）
        final_params: dict = {}

        # L1: template_vars（配置级常量）
        final_params.update(meta.template_vars)

        # L2: sql_params 默认值
        for p in meta.sql_params:
            if not p.required and p.default is not None:
                final_params[p.name] = p.default
            elif not p.required and p.default is None and p.name not in final_params:
                # 显式 default: null 也要落参（避免 :cluster 绑定时缺 key）
                final_params.setdefault(p.name, None)

        # L3: Group override_params
        if override_params:
            final_params.update(override_params)

        # L4: Agent 显式传入（最高优先级）
        if agent_params:
            final_params.update(agent_params)

        # L5: 强制注入 base_params（start_ms / end_ms 等）
        final_params.update(base_params)

        # 2. 必填参数校验
        for p in meta.sql_params:
            if p.required and p.name not in final_params:
                raise ValueError(
                    f"指标 {indicator_name} 缺少必填参数: {p.name}"
                )

        # 3. template_vars 字面替换（这些不走 sqlite3 绑定，是配置级常量）
        for key, val in meta.template_vars.items():
            placeholder = f":{key}"
            if placeholder in sql:
                sql = sql.replace(placeholder, str(val))
                final_params.pop(key, None)

        # 4. 收集剩余 :xxx 占位符 → sqlite3 命名参数绑定
        placeholders = set(re.findall(r":(\w+)", sql))
        binding = {p: final_params[p] for p in placeholders if p in final_params}
        missing = placeholders - set(binding.keys())
        if missing:
            raise ValueError(
                f"指标 {indicator_name} SQL 渲染后仍缺少参数: {missing}"
            )

        # 5. 元数据
        # params_used 保留全量 final_params（含 start_ms/end_ms/tid/chip_model 等），
        # 供 stub SQL 指标在 _run_pipeline / _resolve_preprocess_params 中兜底取值。
        # stub SQL（Path A cache 迁移）场景下 binding 为空，但算子仍需这些参数。
        query_meta = {
            "indicator": indicator_name,
            "params_used": dict(final_params),
            "row_limit": final_params.get("limit", 500),
            "aggregation_applied": final_params.get(
                "granularity", meta.default_granularity
            ),
            "is_timeseries": self._is_timeseries(meta),
        }

        return sql, binding, query_meta

    # -----------------------------------------------------------------
    # 批量执行（含 group 展开 + 大数据采样 + 预处理）
    # -----------------------------------------------------------------

    def execute(
        self,
        sqlite_path: str,
        indicator_names: list[str],
        base_params: dict,
        agent_params: Optional[dict] = None,
        group_overrides: Optional[dict] = None,
        max_rows_per_indicator: int = 500,
        summary_only: bool = False,
        iterate: Optional[list[dict]] = None,
    ) -> dict:
        """批量查询指标，支持 group 展开、参数合并、大数据采样、预处理引擎。

        summary_only: bool = True 时，只返回 summary 不返回 data 数组（对有 summary 的指标生效）
        iterate: list[dict] 非空时，框架自动循环执行，item.xxx 代换参数后聚合结果
        """
        # 先把未知指标过滤掉，记录到 errors，其余交给 expand_indicators
        known_names: list[str] = []
        early_errors: list[dict] = []
        _log = get_observability_logger("query_engine")
        from core.observability import get_observability_session_id
        _session_id = get_observability_session_id()
        for name in indicator_names:
            if name in self.registry.indicators:
                known_names.append(name)
            else:
                early_errors.append({"indicator": name, "error": "未知指标"})

        expanded = self.registry.expand_indicators(known_names)
        _log.debug("group_expanded", session_id=_session_id, group_count=len([n for n in known_names
                                                       if self.registry.indicators.get(n, None)
                                                       and self.registry.indicators[n].type == "group"]),
                   atom_count=len(expanded))

        # 使用连接缓存避免重复 open/close（性能优化）
        from core.db_pool import get_cached_connection
        conn = get_cached_connection(sqlite_path)
        cursor = conn.cursor()

        results: dict = {}
        errors: list[dict] = list(early_errors)
        query_metas: list[dict] = []

        # iterate 模式：确定迭代列表和每次执行时的基础参数
        iteration_items = iterate if iterate else [None]  # None 表示单次执行

        try:
            for item in iteration_items:
                # 对 base_params 和 agent_params 做 item.xxx 代换
                if item is not None:
                    bp = self._substitute_item_params(base_params, item)
                    ap = self._substitute_item_params(agent_params, item) if agent_params else None
                else:
                    bp = base_params
                    ap = agent_params

                for name, overrides, group_chain, group_defaults in expanded:
                    meta = self.registry.atomic_indicators.get(name)
                    if not meta:
                        errors.append({"indicator": name, "error": "未知指标"})
                        continue

                    try:
                        # 参数查找顺序（低 → 高优先级）
                        # 1. group_defaults（最低，从 group YAML 继承，只取当前指标名下的默认值）
                        ind_agent_params = dict(group_defaults.get(name, {}))
                        # 2. ap 中的 per-indicator 或 group 级别（高于 group_defaults）
                        if ap:
                            # 2a. ap[name] 直接覆盖
                            if name in ap:
                                ind_agent_params = {**ind_agent_params, **(ap[name] or {})}
                            # 2b. ap[group_name] 作为次高优先级（仅当 ind_agent_params 仍无该 key 时）
                            elif group_chain:
                                for group_name in reversed(group_chain):
                                    if group_name in ap:
                                        for k, v in (ap[group_name] or {}).items():
                                            if k not in ind_agent_params:
                                                ind_agent_params[k] = v
                                        break
                        # 3. overrides（最高，覆盖一切）
                        if overrides:
                            ind_agent_params = {**ind_agent_params, **overrides}

                        effective_summary_only = ind_agent_params.get("summary_only", False) if ind_agent_params else summary_only
                        _log.debug("query_start", session_id=_session_id, indicator=name,
                                   start_ms=bp.get("start_ms"), end_ms=bp.get("end_ms"),
                                   indicator_params=ind_agent_params)

                        sql, binding, qmeta = self.build_query(
                            name, bp, overrides, ind_agent_params
                        )
                        query_start_ts = time.time()

                        # 预处理引擎分支
                        if meta.preprocess:
                            result_obj = self._execute_with_preprocess(
                                conn, meta, sql, binding, qmeta,
                                overrides, ind_agent_params, name,
                            )
                            self._accumulate_result(results, name, result_obj, item, effective_summary_only, meta)
                            query_metas.append(qmeta)
                            elapsed_ms = int((time.time() - query_start_ts) * 1000)
                            _log.debug("query_complete", session_id=_session_id, indicator=name,
                                       elapsed_ms=elapsed_ms, truncated=qmeta.get("truncated", False))
                            continue

                        cursor.execute(sql, binding)
                        rows = cursor.fetchall()
                        total_rows = len(rows)
                        limit = min(qmeta["row_limit"], max_rows_per_indicator)

                        # 大数据处理
                        if total_rows > limit:
                            rows = self._downsample(
                                rows, limit, meta, qmeta["is_timeseries"]
                            )
                            qmeta["truncated"] = True
                            qmeta["total_rows_before_truncation"] = total_rows
                            qmeta["sampling_strategy"] = (
                                "bucket_aggregate" if qmeta["is_timeseries"] else "top_n"
                            )
                        else:
                            qmeta["truncated"] = False

                        rows_data = [dict(r) if not isinstance(r, dict) else r for r in rows]

                        schema_type = meta.result_schema.get("type", "array")
                        if schema_type == "object":
                            data_field: Any = rows_data[0] if rows_data else {}
                            qmeta["truncated"] = False
                        else:
                            data_field = rows_data

                        result_obj = {
                            "type": schema_type,
                            "meta": {
                                "display_name": meta.display_name,
                                "unit": meta.unit,
                                "category": meta.category,
                                "schema_type": schema_type,
                                "row_count": (
                                    len(rows_data) if schema_type != "object" else 1
                                ),
                                "is_timeseries": qmeta["is_timeseries"],
                                **{
                                    k: v for k, v in qmeta.items()
                                    if k not in ("indicator", "params_used", "is_timeseries")
                                },
                            },
                            "data": data_field,
                        }
                        self._accumulate_result(results, name, result_obj, item, effective_summary_only, meta)
                        query_metas.append(qmeta)
                        elapsed_ms = int((time.time() - query_start_ts) * 1000)
                        _log.debug("query_complete", session_id=_session_id, indicator=name,
                                   elapsed_ms=elapsed_ms, truncated=qmeta.get("truncated", False))

                    except Exception as e:  # noqa: BLE001
                        errors.append({
                            "indicator": name,
                            "error": str(e),
                            "sql": locals().get("sql"),
                        })
                        _log.error("query_error", session_id=_session_id, indicator=name,
                                   error=str(e))
        finally:
            # 连接由 db_pool 管理，不在此关闭（LRU 复用）
            pass

        # iterate 模式结果转换：将 _iterate_items 包装为正规格式
        final_results: dict = {}
        for rname, rval in results.items():
            if "_iterate_items" in rval:
                final_results[rname] = {
                    "type": rval.get("type"),
                    "iterate_results": rval["_iterate_items"],
                    "meta": {"iterate_count": len(rval["_iterate_items"])},
                }
            else:
                final_results[rname] = rval

        legend = self._post_process_agent_output(final_results, errors)
        return {
            "indicators": final_results,
            "legend": legend,
            "errors": errors,
        }

    # -----------------------------------------------------------------
    # Agent 友好化后处理（spec §4）
    # -----------------------------------------------------------------

    def _post_process_agent_output(self, results: dict, errors: list) -> dict:
        """Agent 友好化后处理（spec §4.1/§4.3/§4.4）。

        1. meta 字段白名单过滤
        2. 移除 indicator 顶层 type 字段
        3. 聚合 _legend_fragments 到顶层 legend
        4. 生成 _digest_line（含 digest_label 的指标）

        Returns:
            legend dict（聚合后的图例）
        """
        legend: dict = {}
        for ind_name, ind_obj in results.items():
            if not isinstance(ind_obj, dict):
                continue
            # 1. 移除顶层 type
            ind_obj.pop("type", None)

            # 2. meta 白名单
            meta = ind_obj.get("meta") or {}
            original_truncated = meta.get("truncated", False)
            original_empty = meta.get("empty", False)
            new_meta = {
                "display_name": meta.get("display_name"),
                "unit": meta.get("unit"),
            }
            # empty 信号仅空数据时保留（与 truncated 同模式，避免 False 噪音）
            if original_empty:
                new_meta["empty"] = True
                if "reason" in meta:
                    new_meta["reason"] = meta["reason"]
            # 截断信号仅截断时保留
            if original_truncated:
                new_meta["truncated"] = True
                if "total_rows_before_truncation" in meta:
                    new_meta["total_rows_before_truncation"] = meta["total_rows_before_truncation"]
            # 过滤 None 值
            new_meta = {k: v for k, v in new_meta.items() if v is not None}
            ind_obj["meta"] = new_meta

            # 3. 聚合 _legend_fragments
            data = ind_obj.get("data")
            if isinstance(data, dict):
                fragments = data.pop("_legend_fragments", {})
                if isinstance(fragments, dict):
                    legend.update(fragments)

            # 4. 生成 _digest_line
            meta_obj = self.registry.atomic_indicators.get(ind_name)
            digest_label = getattr(meta_obj, "digest_label", None) if meta_obj else None
            headline = data.get("headline") if isinstance(data, dict) else None
            if digest_label and headline:
                results[ind_name]["_digest_line"] = f"[{digest_label}] {headline}"
        return legend

    # -----------------------------------------------------------------
    # iterate 模式 helper
    # -----------------------------------------------------------------

    def _substitute_item_params(
        self,
        params: Optional[dict],
        item: dict,
    ) -> dict:
        """对 params 做 item.xxx 代换。

        对 params 的 key 和 value 递归展开 item.xxx 形式的字符串。
        只处理字符串值，不修改非字符串值。
        """
        if params is None:
            return None
        result = {}
        for k, v in params.items():
            if isinstance(v, str) and v.startswith("item."):
                # 提取 item.xxx 中的属性路径
                attr_path = v[5:]  # 去掉 "item." 前缀
                parts = attr_path.split(".")
                cur = item
                for part in parts:
                    if isinstance(cur, dict) and part in cur:
                        cur = cur[part]
                    else:
                        cur = None
                        break
                result[k] = cur
            elif isinstance(v, dict):
                result[k] = self._substitute_item_params(v, item)
            else:
                result[k] = v
        return result

    def _accumulate_result(
        self,
        results: dict,
        name: str,
        result_obj: dict,
        item: Optional[dict],
        summary_only: bool,
        meta,
    ) -> None:
        """对 iterate 模式的执行结果做聚合。

        单次执行（item=None）：直接写入 results
        多次执行（item 非 None）：追加到 results[name]["_iterate_items"]
        summary_only 模式下截断 data 数组（有 summary 的指标才截断）
        """
        if item is None:
            # 单次执行
            data_obj = result_obj.get("data") or {}
            if summary_only and data_obj.get("summary") is not None:
                result_obj = dict(result_obj)
                result_obj["data"] = {"summary": data_obj["summary"]}
            results[name] = result_obj
        else:
            # iterate 模式：追加到 _iterate_items
            if name not in results:
                results[name] = {
                    "_iterate_items": [],
                    "type": result_obj.get("type"),
                }
            data_obj = result_obj.get("data") or {}
            if summary_only and data_obj.get("summary") is not None:
                result_obj = dict(result_obj)
                result_obj["data"] = {"summary": data_obj["summary"]}
            results[name]["_iterate_items"].append({
                "item": item,
                "result": result_obj,
            })

    # -----------------------------------------------------------------
    # 预处理引擎
    # -----------------------------------------------------------------

    def _execute_with_preprocess(
        self,
        conn: sqlite3.Connection,
        meta: IndicatorMeta,
        sql: str,
        binding: dict,
        qmeta: dict,
        overrides: dict,
        ind_agent_params: dict,
        indicator_name: str,
    ) -> dict:
        """指标声明了 preprocess 时调度对应引擎，返回结构化结果。

        支持两种声明形态：
        - preprocess.pipeline: [op, op, ...]   多阶段算子组合（推荐，灵活）
        - preprocess.engine:   single_engine   单一内置引擎（向后兼容）
        """
        preprocess = meta.preprocess or {}
        pipeline = preprocess.get("pipeline")
        engine_name = preprocess.get("engine")

        if pipeline:
            return self._run_pipeline(
                conn, meta, sql, binding, qmeta, overrides,
                ind_agent_params, pipeline, indicator_name,
            )

        if engine_name == "flamegraph_collapse":
            return self._run_flamegraph_collapse(
                conn, meta, sql, binding, qmeta, overrides, ind_agent_params,
            )

        # Todo: 支持更多内置引擎（如 histogram_summary、trace_anomaly 等）
        raise ValueError(f"未支持的预处理声明: {preprocess}")

    def _build_empty_result(self, meta) -> dict:
        """preprocess 指标空数据时返回最小化结构。

        返回 {type, meta: {..., empty: True, reason}, data: None}，
        跳过整个 preprocess pipeline。
        """
        schema_type = meta.result_schema.get("type", "object")
        return {
            "type": schema_type,
            "meta": {
                "display_name": meta.display_name,
                "unit": meta.unit,
                "category": meta.category,
                "schema_type": schema_type,
                "is_timeseries": False,
                "empty": True,
                # _run_pipeline 已保证调用时 meta.empty_reason 非空；
                # fallback 仅为防御性，供未来其他调用点使用
                "reason": meta.empty_reason or "时间窗内无数据（可能未开启相关 trace tag）",
            },
            "data": None,
        }

    def _run_pipeline(
        self,
        conn: sqlite3.Connection,
        meta: IndicatorMeta,
        sql: str,
        binding: dict,
        qmeta: dict,
        overrides: dict,
        ind_agent_params: dict,
        pipeline_steps: list[dict],
        indicator_name: str,
    ) -> dict:
        """preprocess.pipeline 形态：把多步算子串起来跑。"""
        import pandas as pd  # 延迟导入

        from core.preprocess import PreprocessContext, run_pipeline

        _log = get_observability_logger("query_engine")
        from core.observability import get_observability_session_id as _get_sid
        _sid = _get_sid()
        _log.info("preprocess_pipeline_start", session_id=_sid, indicator=indicator_name,
                  pipeline_steps=[s.get("op") if isinstance(s, dict) else str(s)
                                  for s in pipeline_steps])

        # SQL 数据拉取单独计时(含 SQL 执行 + IO 读取)
        # 注意:原 preprocess_pipeline_end 包含了 read_sql_query 时间,
        # 导致 analyse_tools_cost.py 的 SQL 列接近 0,真实瓶颈被归到 Preproc
        sql_fetch_start_ts = time.time()
        raw_df = pd.read_sql_query(sql, conn, params=binding)
        sql_fetch_ms = int((time.time() - sql_fetch_start_ts) * 1000)
        _log.info("preprocess_sql_fetch_complete", session_id=_sid,
                  indicator=indicator_name,
                  elapsed_ms=sql_fetch_ms,
                  row_count=len(raw_df))
        # 空数据预检:仅对声明了 empty_reason 的指标返回最小化结构
        # (未声明 empty_reason 的指标走完整 preprocess,保留其结构化空输出)
        if raw_df.empty and meta.empty_reason:
            _log.info("preprocess_pipeline_empty_short_circuit", session_id=_sid,
                       indicator=indicator_name)
            qmeta["truncated"] = False
            return self._build_empty_result(meta)

        # stub SQL 场景（Path A cache 迁移）下 binding 为空，
        # 需从 qmeta["params_used"] 兜底取 start_ms/end_ms/tid 等，
        # 否则 ctx.meta 里这些值为 None，算子拿到 frame_start_ns=0 导致空数据。
        final_params = qmeta.get("params_used", {})
        sql_filter_params = {}
        for k in ("tid", "cpu_ids"):
            v = binding.get(k)
            if v is not None:
                sql_filter_params[k] = v
            elif final_params.get(k) is not None:
                sql_filter_params[k] = final_params[k]
        ctx = PreprocessContext(
            data=raw_df,
            meta={
                "start_ms": binding.get("start_ms") or final_params.get("start_ms"),
                "end_ms": binding.get("end_ms") or final_params.get("end_ms"),
                **sql_filter_params,
            },
            sqlite_conn=conn,
            indicator_meta=meta,
            trace_cache=get_trace_data_cache(conn),
        )

        def resolver(params_decl: dict) -> dict:
            return self._resolve_preprocess_params(
                params_decl, overrides, ind_agent_params, meta,
                final_params=final_params,
            )

        # 算子执行单独计时(不含 SQL 拉取)
        pipeline_start_ts = time.time()
        try:
            ctx = run_pipeline(pipeline_steps, ctx, param_resolver=resolver,
                               session_id=_sid, indicator=indicator_name)
            elapsed_ms = int((time.time() - pipeline_start_ts) * 1000)
            _log.info("preprocess_pipeline_end", session_id=_sid, indicator=indicator_name,
                      elapsed_ms=elapsed_ms)
        except PreprocessError:
            raise
        except Exception as exc:  # noqa: BLE001
            _log.error("preprocess_error", session_id=_sid, indicator=indicator_name,
                       error=f"算子 pipeline 执行失败: {exc}")
            raise PreprocessError(
                f"算子 pipeline 执行失败: {exc}"
            ) from exc
        qmeta["truncated"] = False  # 算子链已自行控制返回大小

        # ctx.data 应是最终 dict（最后一步算子负责收敛）
        final = ctx.data if isinstance(ctx.data, dict) else {"data": ctx.data}
        schema_type = meta.result_schema.get("type", "object")

        return {
            "type": schema_type,
            "meta": {
                "display_name": meta.display_name,
                "unit": meta.unit,
                "category": meta.category,
                "schema_type": schema_type,
                "is_timeseries": False,
                **(final.get("meta", {}) if isinstance(final, dict) else {}),
            },
            "data": final,
        }

    def _run_flamegraph_collapse(
        self,
        conn: sqlite3.Connection,
        meta: IndicatorMeta,
        sql: str,
        binding: dict,
        qmeta: dict,
        overrides: dict,
        agent_params: dict,
    ) -> dict:
        """火焰图归一化合并 + 四层折叠预处理。"""
        # 延迟导入，避免上层无 pandas 时也能 import core.query_engine
        import pandas as pd
        from core.flamegraph_collapse import flamegraph_collapse

        raw_df = pd.read_sql_query(sql, conn, params=binding)

        # 解析 preprocess.params 中的 :xxx 引用 → agent_params/overrides 实参
        params_decl = (meta.preprocess or {}).get("params", {}) or {}
        resolved = self._resolve_preprocess_params(
            params_decl, overrides, agent_params, meta,
        )

        result = flamegraph_collapse(raw_df, **resolved)

        qmeta["truncated"] = False  # 预处理引擎已自行控制返回大小
        schema_type = meta.result_schema.get("type", "object")

        return {
            "type": schema_type,
            "meta": {
                "display_name": meta.display_name,
                "unit": meta.unit,
                "category": meta.category,
                "schema_type": schema_type,
                "is_timeseries": False,
                **result.get("meta", {}),
            },
            "data": result,
        }

    def _resolve_preprocess_params(
        self,
        decl: dict,
        overrides: dict,
        agent_params: dict,
        meta: IndicatorMeta,
        final_params: Optional[dict] = None,
    ) -> dict:
        """把 preprocess.params 里 :xxx 形式的引用解析为实参值。

        final_params 兜底：stub SQL 场景下 agent_params/overrides 都为空，
        但 base_params（start_ms/end_ms/tid/chip_model 等）已在 build_query
        合入 final_params，这里作为最后一道兜底，避免算子拿到 None。
        """
        resolved: dict = {}
        for key, val in decl.items():
            if isinstance(val, str) and val.startswith(":"):
                ref_name = val[1:]
                if ref_name in agent_params:
                    resolved[key] = agent_params[ref_name]
                elif ref_name in overrides:
                    resolved[key] = overrides[ref_name]
                elif ref_name in meta.template_vars:
                    resolved[key] = meta.template_vars[ref_name]
                elif final_params and ref_name in final_params:
                    resolved[key] = final_params[ref_name]
                else:
                    sp = next(
                        (p for p in meta.sql_params if p.name == ref_name),
                        None,
                    )
                    resolved[key] = sp.default if sp else None
            else:
                resolved[key] = val
        return resolved

    # -----------------------------------------------------------------
    # 采样
    # -----------------------------------------------------------------

    def _downsample(self, rows, limit, meta, is_timeseries):
        if len(rows) <= limit:
            return rows
        if is_timeseries:
            return self._timeseries_bucket_aggregate(rows, limit, meta)
        # 非时序：SQL 已 ORDER BY，直接截断
        return rows[:limit]

    def _timeseries_bucket_aggregate(self, rows, limit, meta):
        """时序数据分桶聚合，保留尖峰点。"""
        bucket_size = max(1, len(rows) // limit)
        aggregated: list[dict] = []

        for i in range(0, len(rows), bucket_size):
            bucket = rows[i:i + bucket_size]
            bucket_dicts = [dict(r) for r in bucket]

            values = [
                r.get("value", 0)
                for r in bucket_dicts
                if isinstance(r.get("value"), (int, float))
            ]
            if not values:
                continue

            max_val = max(values)
            max_idx = values.index(max_val)
            peak_point = bucket_dicts[max_idx]

            ts_start = bucket_dicts[0].get("ts", bucket_dicts[0].get("timestamp_ms"))
            ts_end = bucket_dicts[-1].get("ts", bucket_dicts[-1].get("timestamp_ms"))

            aggregated.append({
                "ts_start": ts_start,
                "ts_end": ts_end,
                "value_avg": round(statistics.mean(values), 2),
                "value_max": max_val,
                "value_min": min(values),
                "sample_count": len(bucket),
                "peak_point": peak_point,
            })

        return aggregated[:limit]

    def _is_timeseries(self, meta: IndicatorMeta) -> bool:
        schema = meta.result_schema or {}
        if schema.get("type") == "array" and "items" in schema:
            props = schema["items"].get("properties", {})
            return "ts" in props or "timestamp_ms" in props
        return False


def engine_name_or_default(meta: IndicatorMeta) -> str:
    """工具函数：从 meta 取 preprocess.engine 字段。"""
    return (meta.preprocess or {}).get("engine", "none")
