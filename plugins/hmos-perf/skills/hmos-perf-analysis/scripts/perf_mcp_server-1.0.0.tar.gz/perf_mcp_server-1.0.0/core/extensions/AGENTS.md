<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-06-11 -->

# core/extensions — Optional Database Augmentation

## Purpose
Optional extensions that enrich the SQLite trace database with additional data before analysis. Currently focused on page cache event parsing — extracting Linux kernel page cache add/delete events from raw ftrace files and inserting them into the trace database as a structured table.

## Key Files

| File | Description |
|------|-------------|
| `__init__.py` | Re-exports extend_db_with_page_cache from db_extender |
| `page_cache_parser.py` | Parses mm_filemap_add_to_page_cache / mm_filemap_delete_from_page_cache events from raw .ftrace files using regex. Returns PageCacheEvent dataclass objects (ts_ns, cpu, itid, comm, pid, dev, inode, pfn, index, offset, is_add). |
| `db_extender.py` | Creates a page_cache_io table in the existing SQLite trace DB and populates it with parsed page cache events from a .ftrace file. Returns statistics dict. |

## For AI Agents

### Working In This Directory
- Extensions are optional — core analysis works without them.
- New extensions should follow the same pattern: parser (+ dataclasses) + db_extender that injects parsed data into the SQLite DB.
- Keep extensions self-contained; don't create dependencies on specific indicators or skills.

### Testing Requirements
- Test with real ftrace files that contain page cache events.
- Verify the extended DB table is queryable by standard indicators after augmentation.

### Common Patterns
- Parse raw text traces with regex into dataclass objects.
- Extend the SQLite DB with CREATE TABLE + INSERT statements.
- Return statistics dict so callers can verify what was added.

## Dependencies

### Internal
- None — extensions are self-contained.

### External
- `sqlite3` (stdlib) — Database operations
- `re` (stdlib) — Regex parsing of ftrace events
