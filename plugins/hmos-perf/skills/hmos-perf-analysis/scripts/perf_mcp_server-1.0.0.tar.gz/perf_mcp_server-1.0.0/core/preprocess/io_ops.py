# -*- coding: utf-8 -*-
"""IO性能分析预处理算子。

基于 filesystem_io 表数据进行后处理：
1. compute_io_latency_percentiles: 计算时延百分位数分布
2. compute_io_concurrency: 计算时间片内并发IO数
3. compute_io_size_distribution: 计算IO大小分段分布
4. compute_read_write_ratio: 计算读写比例

数据来源: filesystem_io 表
  - start_time, end_time, duration (ns)
  - is_write: 1=写, 0=读
  - request_bytes: 请求大小
"""
from __future__ import annotations

from core.observability import get_module_logger

import pandas as pd

from .base import PreprocessContext, register_operator

log = get_module_logger(__name__)


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def _percentile(data: list[float], p: float) -> float:
    """线性插值百分位数。"""
    if not data:
        return 0.0
    sorted_data = sorted(data)
    n = len(sorted_data)
    idx = p / 100.0 * (n - 1)
    lo = int(idx)
    hi = min(lo + 1, n - 1)
    if lo == hi:
        return round(sorted_data[lo], 3)
    frac = idx - lo
    return round(sorted_data[lo] + frac * (sorted_data[hi] - sorted_data[lo]), 3)


# ---------------------------------------------------------------------------
# compute_io_latency_percentiles
# ---------------------------------------------------------------------------

@register_operator("compute_io_latency_percentiles")
def compute_io_latency_percentiles(ctx: PreprocessContext) -> PreprocessContext:
    """计算IO时延百分位数分布。

    输入:
        ctx.data: DataFrame 含列 latency_us, is_write, start_ms
    输出:
        ctx.data: dict 含 meta / distribution / top_latency_events
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"type": "io_latency_percentile", "total_events": 0},
            "distribution": {},
            "top_latency_events": [],
        }
        return ctx

    latencies = df["latency_us"].dropna().tolist()
    total = len(latencies)

    if not latencies:
        ctx.data = {
            "meta": {"type": "io_latency_percentile", "total_events": 0},
            "distribution": {},
            "top_latency_events": [],
        }
        return ctx

    sorted_lat = sorted(latencies)
    distribution = {
        "p50": _percentile(sorted_lat, 50),
        "p90": _percentile(sorted_lat, 90),
        "p95": _percentile(sorted_lat, 95),
        "p99": _percentile(sorted_lat, 99),
        "min": round(sorted_lat[0], 3),
        "max": round(sorted_lat[-1], 3),
        "avg": round(sum(sorted_lat) / total, 3),
    }

    # 过滤条件回显
    filter_is_write = ctx.params.get("is_write")

    # 固定返回 top 10，避免数据量过大（top_latency_events 仅用于调试参考）
    top_n = int(ctx.params.get("top_n", 10))
    top_df = df.nlargest(top_n, "latency_us")[["start_ms", "latency_us", "is_write"]]
    top_events = top_df.to_dict(orient="records")

    ctx.data = {
        "meta": {
            "type": "io_latency_percentile",
            "total_events": total,
            "filter_is_write": filter_is_write,
        },
        "distribution": distribution,
        "top_latency_events": top_events,
    }
    return ctx


# ---------------------------------------------------------------------------
# compute_io_concurrency
# ---------------------------------------------------------------------------

@register_operator("compute_io_concurrency")
def compute_io_concurrency(ctx: PreprocessContext) -> PreprocessContext:
    """计算时间片内IO并发数。

    输入:
        ctx.data: DataFrame 含列 start_ms, end_ms, duration_us, is_write, itid, ipid
    输出:
        ctx.data: dict 含 meta / time_series / summary
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"bucket_ms": 20, "total_events": 0},
            "time_series": [],
            "summary": {},
        }
        return ctx

    bucket_ms = int(ctx.params.get("bucket_ms", 20))
    df = df.copy()
    df = df.sort_values("start_ms").reset_index(drop=True)

    # 确定时间范围
    min_ts = df["start_ms"].min()
    max_ts = df["end_ms"].max()
    buckets = int((max_ts - min_ts) / bucket_ms) + 1

    time_series = []
    for i in range(buckets):
        bucket_start = min_ts + i * bucket_ms
        bucket_end = bucket_start + bucket_ms

        # 统计与该时间片重叠的IO请求
        mask = (df["start_ms"] < bucket_end) & (df["end_ms"] > bucket_start)
        bucket_df = df[mask]

        concurrent = len(bucket_df)
        read_concurrent = len(bucket_df[bucket_df.get("is_write", 0) == 0]) if "is_write" in bucket_df.columns else 0
        write_concurrent = len(bucket_df[bucket_df.get("is_write", 0) == 1]) if "is_write" in bucket_df.columns else 0

        time_series.append({
            "ts_ms": int(bucket_start),
            "concurrent_count": concurrent,
            "read_concurrent": read_concurrent,
            "write_concurrent": write_concurrent,
        })

    # 计算汇总
    counts = [t["concurrent_count"] for t in time_series]
    summary = {
        "avg_concurrency": round(sum(counts) / len(counts), 2) if counts else 0,
        "max_concurrency": max(counts) if counts else 0,
        "p95_concurrency": _percentile(sorted(counts), 95) if counts else 0,
    }

    ctx.data = {
        "meta": {"bucket_ms": bucket_ms, "total_events": len(df)},
        "time_series": time_series,
        "summary": summary,
    }
    return ctx


# ---------------------------------------------------------------------------
# compute_io_size_distribution
# ---------------------------------------------------------------------------

@register_operator("compute_io_size_distribution")
def compute_io_size_distribution(ctx: PreprocessContext) -> PreprocessContext:
    """计算IO大小指数分段分布。

    输入:
        ctx.data: DataFrame 含列 request_bytes, actual_bytes, is_write
    输出:
        ctx.data: dict 含 meta / distribution
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"total_count": 0, "total_size_bytes": 0},
            "distribution": {},
        }
        return ctx

    sizes = df["request_bytes"].dropna().tolist()
    total = len(sizes)
    total_bytes = sum(sizes)

    # 指数分段: 0-4KB, 4KB-16KB, 16KB-64KB, 64KB-256KB, 256KB-1MB, >1MB
    buckets = {
        "0-4KB": (0, 4096),
        "4KB-16KB": (4096, 16384),
        "16KB-64KB": (16384, 65536),
        "64KB-256KB": (65536, 262144),
        "256KB-1MB": (262144, 1048576),
        ">1MB": (1048576, float("inf")),
    }

    distribution = {}
    random_count = 0
    sequential_count = 0

    for label, (low, high) in buckets.items():
        bucket_sizes = [s for s in sizes if low <= s < high]
        count = len(bucket_sizes)
        distribution[label] = {
            "count": count,
            "total_bytes": sum(bucket_sizes),
        }
        # 64KB 分界: < 64KB 为小IO(随机), >= 64KB 为大IO(顺序)
        if low < 65536:  # 0-64KB 范围累加
            random_count += count
        else:
            sequential_count += count

    avg_size = total_bytes / total if total > 0 else 0
    random_ratio = random_count / total if total > 0 else 0

    ctx.data = {
        "meta": {
            "total_count": total,
            "total_size_bytes": int(total_bytes),
            "avg_size_bytes": round(avg_size, 2),
            "random_io_count": random_count,
            "sequential_io_count": sequential_count,
            "random_io_ratio": round(random_ratio, 4),
        },
        "distribution": distribution,
    }
    return ctx


# ---------------------------------------------------------------------------
# compute_read_write_ratio
# ---------------------------------------------------------------------------

@register_operator("compute_read_write_ratio")
def compute_read_write_ratio(ctx: PreprocessContext) -> PreprocessContext:
    """计算读写IO比例。

    输入:
        ctx.data: DataFrame 含列 read_bytes, write_bytes, read_count, write_count
    输出:
        ctx.data: dict 含各项比例
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"time_range_ms": 0, "total_count": 0},
            "read_total_bytes": 0,
            "write_total_bytes": 0,
            "read_total_count": 0,
            "write_total_count": 0,
            "read_bytes_ratio": 0,
            "write_bytes_ratio": 0,
            "read_count_ratio": 0,
            "write_count_ratio": 0,
            "read_write_bytes_ratio": "0:0",
            "read_write_count_ratio": "0:0",
        }
        return ctx

    # 单行聚合结果，安全处理空值和NaN
    def safe_get_int(df, col):
        if len(df) > 0 and col in df.columns:
            val = df[col].iloc[0]
            if pd.notna(val):
                return int(val)
        return 0

    read_bytes = safe_get_int(df, "read_bytes")
    write_bytes = safe_get_int(df, "write_bytes")
    read_count = safe_get_int(df, "read_count")
    write_count = safe_get_int(df, "write_count")

    total_bytes = read_bytes + write_bytes
    total_count = read_count + write_count

    ctx.data = {
        "meta": {
            "time_range_ms": 0,  # 由上层填充
            "total_count": total_count,
        },
        "read_total_bytes": read_bytes,
        "write_total_bytes": write_bytes,
        "read_total_count": read_count,
        "write_total_count": write_count,
        "read_bytes_ratio": round(read_bytes / total_bytes, 4) if total_bytes else 0,
        "write_bytes_ratio": round(write_bytes / total_bytes, 4) if total_bytes else 0,
        "read_count_ratio": round(read_count / total_count, 4) if total_count else 0,
        "write_count_ratio": round(write_count / total_count, 4) if total_count else 0,
        "read_write_bytes_ratio": f"{read_bytes}:{write_bytes}" if write_bytes else f"{read_bytes}:0",
        "read_write_count_ratio": f"{read_count}:{write_count}" if write_count else f"{read_count}:0",
    }
    return ctx

# ---------------------------------------------------------------------------
# compute_io_priority_latency
# ---------------------------------------------------------------------------

@register_operator("compute_io_priority_latency")
def compute_io_priority_latency(ctx: PreprocessContext) -> PreprocessContext:
    """计算按优先级分组的IO时延分布。

    输入:
        ctx.data: DataFrame 含列 latency_us, priority, thread_type
    输出:
        ctx.data: dict 含 meta / by_priority_band / rt_vs_normal
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"type": "io_latency_by_priority", "total_events": 0},
            "by_priority_band": {},
            "rt_vs_normal": {},
        }
        return ctx

    def get_priority_band(priority):
        if priority is None:
            return None
        if priority >= 120:
            return "top"
        elif priority >= 100:
            return "high"
        elif priority >= 50:
            return "medium"
        else:
            return "low"

    if "priority" in df.columns:
        df = df.copy()
        df["priority_band"] = df["priority"].apply(get_priority_band)

    by_band = {}
    rt_latencies = []
    normal_latencies = []

    for band in ["top", "high", "medium", "low"]:
        band_df = df[df.get("priority_band", "") == band]
        if len(band_df) == 0:
            continue
        latencies = band_df["latency_us"].dropna().tolist()
        if latencies:
            by_band[band] = {
                "p50": _percentile(sorted(latencies), 50),
                "p90": _percentile(sorted(latencies), 90),
                "p99": _percentile(sorted(latencies), 99),
                "avg": round(sum(latencies) / len(latencies), 3),
                "count": len(latencies),
            }

    if "thread_type" in df.columns:
        rt_df = df[df["thread_type"] == "rt"]
        normal_df = df[df["thread_type"] == "normal"]
        rt_latencies = rt_df["latency_us"].dropna().tolist() if len(rt_df) else []
        normal_latencies = normal_df["latency_us"].dropna().tolist() if len(normal_df) else []

    rt_vs_normal = {}
    if rt_latencies and normal_latencies:
        rt_p50 = _percentile(sorted(rt_latencies), 50)
        normal_p50 = _percentile(sorted(normal_latencies), 50)
        rt_avg = sum(rt_latencies) / len(rt_latencies)
        normal_avg = sum(normal_latencies) / len(normal_latencies)
        rt_vs_normal = {
            "rt_p50": rt_p50,
            "normal_p50": normal_p50,
            "rt_avg": round(rt_avg, 3),
            "normal_avg": round(normal_avg, 3),
            "rt_over_normal_ratio": round(rt_avg / normal_avg, 2) if normal_avg else 0,
        }

    ctx.data = {
        "meta": {"type": "io_latency_by_priority", "total_events": len(df)},
        "by_priority_band": by_band,
        "rt_vs_normal": rt_vs_normal,
    }
    return ctx


# ---------------------------------------------------------------------------
# compute_dstate_by_priority
# ---------------------------------------------------------------------------

@register_operator("compute_dstate_by_priority")
def compute_dstate_by_priority(ctx: PreprocessContext) -> PreprocessContext:
    """计算D-IO阻塞时长按调度类分布。

    输入:
        ctx.data: DataFrame 含列 dstate_ms, priority, tid, tname
    输出:
        ctx.data: dict 含 meta / by_sched_class / priority_inversion

    调度类:
        - interrupt: priority >= 100 (中断线程)
        - rt: 40 < priority < 100 (RT线程)
        - cfs: priority <= 40 (CFS线程)
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"type": "dstate_io_by_priority", "total_dstate_events": 0, "total_dstate_ms": 0},
            "by_sched_class": {},
            "priority_inversion": {"detected": False},
        }
        return ctx

    def get_sched_class(priority):
        if priority is None:
            return None
        if priority >= 100:
            return "interrupt"
        elif priority > 40:
            return "rt"
        else:
            return "cfs"

    if "priority" in df.columns:
        df = df.copy()
        df["sched_class"] = df["priority"].apply(get_sched_class)

    total_events = len(df)
    total_ms = float(df["dstate_ms"].sum()) if "dstate_ms" in df.columns else 0.0

    by_class = {}
    for cls in ["interrupt", "rt", "cfs"]:
        cls_df = df[df.get("sched_class", "") == cls]
        if len(cls_df) == 0:
            continue
        by_class[cls] = {
            "event_count": len(cls_df),
            "total_ms": round(float(cls_df["dstate_ms"].sum()), 3) if "dstate_ms" in cls_df.columns else 0,
            "avg_ms": round(float(cls_df["dstate_ms"].mean()), 3) if "dstate_ms" in cls_df.columns else 0,
        }

    # 优先级反转检测: RT线程被CFS线程阻塞
    rt_blocked_ms = float(df[df.get("sched_class", "") == "rt"]["dstate_ms"].sum()) if len(df) else 0
    cfs_blocked_ms = float(df[df.get("sched_class", "") == "cfs"]["dstate_ms"].sum()) if len(df) else 0

    # 找出长时间D-IO的CFS线程(可能阻塞RT线程)
    culprit_threads = []
    if "cfs" in by_class and "tname" in df.columns:
        cfs_df = df[df.get("sched_class", "") == "cfs"]
        if len(cfs_df) > 0:
            thread_blocks = cfs_df.groupby(["tid", "tname"])["dstate_ms"].sum().sort_values(ascending=False).head(5)
            culprit_threads = [
                {"tid": int(tid), "tname": str(tname), "total_dstate_ms": float(ms)}
                for (tid, tname), ms in thread_blocks.items()
            ]

    priority_inversion = {
        "detected": rt_blocked_ms > 0 and cfs_blocked_ms > rt_blocked_ms,
        "rt_blocked_ms": round(rt_blocked_ms, 3),
        "culprit_threads": culprit_threads,
    }

    ctx.data = {
        "meta": {"type": "dstate_io_by_priority", "total_dstate_events": total_events, "total_dstate_ms": round(total_ms, 3)},
        "by_sched_class": by_class,
        "priority_inversion": priority_inversion,
    }
    return ctx


# ---------------------------------------------------------------------------
# compute_io_concurrency_agg (for aggregated SQL output)
# ---------------------------------------------------------------------------

@register_operator("compute_io_concurrency_agg")
def compute_io_concurrency_agg(ctx: PreprocessContext) -> PreprocessContext:
    """计算IO并发数（从聚合SQL结果）。

    输入:
        ctx.data: DataFrame 含列 bucket_id, total_count, read_count, write_count
        bucket_id = start_time / 1000000 / bucket_ms  (start_time in ns, bucket_ms)
    输出:
        ctx.data: dict 含 meta / time_series / summary
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"type": "io_concurrency", "bucket_ms": 20, "total_events": 0},
            "time_series": [],
            "summary": {},
        }
        return ctx

    bucket_ms = int(ctx.params.get("bucket_ms", 20))
    total_events = int(df["total_count"].sum()) if "total_count" in df.columns else 0

    # 过滤无效 bucket (参考 OSS io_metric_parser.py line 267-272)
    # 条件: (带宽<500MB/s 或 延迟<1000μs) 且 有读写
    def should_keep_row(row):
        total = int(row.get("total_count", 0)) if "total_count" in row else 0
        if total == 0:
            return False
        read_bytes = float(row.get("read_bytes", 0)) if "read_bytes" in row else 0.0
        write_bytes = float(row.get("write_bytes", 0)) if "write_bytes" in row else 0.0
        if read_bytes == 0 and write_bytes == 0:
            return False
        # 带宽 MB/s = bytes / (bucket_ms / 1000) / 1024 / 1024
        read_bw = read_bytes * 1000 / bucket_ms / 1024 / 1024 if bucket_ms > 0 else 0.0
        write_bw = write_bytes * 1000 / bucket_ms / 1024 / 1024 if bucket_ms > 0 else 0.0
        # 延迟 μs = ns / 1000
        read_lat_val = row.get("avg_read_latency_ns")
        write_lat_val = row.get("avg_write_latency_ns")
        read_latency = float(read_lat_val) / 1000 if read_lat_val is not None else 0.0
        write_latency = float(write_lat_val) / 1000 if write_lat_val is not None else 0.0
        return (read_bw < 500 or write_bw < 500 or read_latency < 1000 or write_latency < 1000)

    df = df[df.apply(should_keep_row, axis=1)]

    # 生成时序数据
    time_series = []
    for _, row in df.iterrows():
        bucket_id = int(row["bucket_id"])
        ts_ms = bucket_id * bucket_ms
        total = int(row["total_count"]) if "total_count" in row else 0
        read = int(row["read_count"]) if "read_count" in row else 0
        write = int(row["write_count"]) if "write_count" in row else 0
        read_lat_val = row.get("avg_read_latency_ns")
        write_lat_val = row.get("avg_write_latency_ns")
        avg_read_lat_us = float(read_lat_val) / 1000 if read_lat_val is not None else 0.0
        avg_write_lat_us = float(write_lat_val) / 1000 if write_lat_val is not None else 0.0
        time_series.append({
            "ts_ms": ts_ms,
            "concurrent_count": total,
            "read_concurrent": read,
            "write_concurrent": write,
            "avg_read_latency_us": round(avg_read_lat_us, 3),
            "avg_write_latency_us": round(avg_write_lat_us, 3),
            "concurrent_read_num": int(row.get("concurrent_read_num", 0)) if "concurrent_read_num" in row else 0,
            "concurrent_write_num": int(row.get("concurrent_write_num", 0)) if "concurrent_write_num" in row else 0,
            "concurrent_read_details": str(row.get("concurrent_read_details") or ""),
            "concurrent_write_details": str(row.get("concurrent_write_details") or ""),
        })

    # 计算汇总
    counts = [t["concurrent_count"] for t in time_series]
    read_counts = [t["read_concurrent"] for t in time_series]
    write_counts = [t["write_concurrent"] for t in time_series]

    time_range_ms = 0
    if time_series:
        time_range_ms = time_series[-1]["ts_ms"] - time_series[0]["ts_ms"] + bucket_ms

    summary = {
        "avg_concurrency": round(sum(counts) / len(counts), 2) if counts else 0,
        "max_concurrency": max(counts) if counts else 0,
        "p95_concurrency": _percentile(sorted(counts), 95) if counts else 0,
        "avg_read_concurrency": round(sum(read_counts) / len(read_counts), 2) if read_counts else 0,
        "avg_write_concurrency": round(sum(write_counts) / len(write_counts), 2) if write_counts else 0,
        "max_read_concurrency": max(read_counts) if read_counts else 0,
        "max_write_concurrency": max(write_counts) if write_counts else 0,
    }

    # summary_only=true 时，提取峰值信息到 summary，不返回 time_series
    if ctx.params.get("summary_only"):
        if time_series:
            max_item = max(time_series, key=lambda x: x["concurrent_count"])
            summary["max_concurrency_ts_ms"] = max_item["ts_ms"]
            summary["max_concurrency_read"] = max_item["read_concurrent"]
            summary["max_concurrency_write"] = max_item["write_concurrent"]
            summary["max_concurrency_latency_us"] = max_item.get("avg_read_latency_us", 0)
            summary["max_concurrency_read_details"] = max_item.get("concurrent_read_details", "")
            summary["max_concurrency_write_details"] = max_item.get("concurrent_write_details", "")

            sorted_by_conc = sorted(time_series, key=lambda x: x["concurrent_count"], reverse=True)
            summary["high_concurrency_periods"] = [
                {
                    "ts_ms": t["ts_ms"],
                    "concurrent_count": t["concurrent_count"],
                    "read_concurrent": t["read_concurrent"],
                    "write_concurrent": t["write_concurrent"],
                    "avg_read_latency_us": t.get("avg_read_latency_us", 0),
                    "avg_write_latency_us": t.get("avg_write_latency_us", 0),
                    "concurrent_read_num": t.get("concurrent_read_num", 0),
                    "concurrent_write_num": t.get("concurrent_write_num", 0),
                    "concurrent_read_details": t.get("concurrent_read_details", ""),
                    "concurrent_write_details": t.get("concurrent_write_details", "")
                }
                for t in sorted_by_conc[:5]
            ]
        ctx.data = {
            "meta": {"type": "io_concurrency", "bucket_ms": bucket_ms, "total_events": total_events, "time_range_ms": time_range_ms},
            "summary": summary,
        }
    else:
        ctx.data = {
            "meta": {"type": "io_concurrency", "bucket_ms": bucket_ms, "total_events": total_events, "time_range_ms": time_range_ms},
            "time_series": time_series,
            "summary": summary,
        }
    return ctx


# ---------------------------------------------------------------------------
# format_page_cache_evict (将多行 SQL 结果重组为 yaml schema 结构)
# ---------------------------------------------------------------------------

@register_operator("format_page_cache_evict")
def format_page_cache_evict(ctx: PreprocessContext) -> PreprocessContext:
    """将 page_cache_evict SQL 的多行结果重组为 yaml 定义的结构。

    输入:
        ctx.data: DataFrame 含列 evict_pattern, count (多行)
    输出:
        ctx.data: dict 含 meta / patterns / analysis
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"time_range_ms": 0},
            "patterns": {
                "fast_evict": {"count": 0},
                "normal_evict": {"count": 0},
                "re_add": {"count": 0},
                "last_hold": {"count": 0}
            },
            "analysis": {"fast_evict_ratio": 0}
        }
        return ctx

    result = {
        "meta": {"time_range_ms": 0},
        "patterns": {
            "fast_evict": {"count": 0},
            "normal_evict": {"count": 0},
            "re_add": {"count": 0},
            "last_hold": {"count": 0}
        },
        "analysis": {"fast_evict_ratio": 0}
    }

    for _, row in df.iterrows():
        pattern = str(row.get("evict_pattern", ""))
        count = int(row.get("count", 0))
        if pattern in result["patterns"]:
            result["patterns"][pattern]["count"] = count

    # 计算 fast_evict_ratio
    total = sum(p["count"] for p in result["patterns"].values())
    if total > 0:
        result["analysis"]["fast_evict_ratio"] = round(result["patterns"]["fast_evict"]["count"] / total, 4)

    ctx.data = result
    return ctx


# ---------------------------------------------------------------------------
# format_hot_file_cache (确保返回完整的热点文件数组)
# ---------------------------------------------------------------------------

@register_operator("format_hot_file_cache")
def format_hot_file_cache(ctx: PreprocessContext) -> PreprocessContext:
    """确保 hot_file_cache 返回完整的热点文件列表数组。

    输入:
        ctx.data: DataFrame 含列 i_ino, comm, access_count, add_count, delete_count, unique_pages (多行)
    输出:
        ctx.data: dict 含 meta / hot_files
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"time_range_ms": 0, "total_files": 0},
            "hot_files": []
        }
        return ctx

    hot_files = []
    for _, row in df.iterrows():
        hot_files.append({
            "i_ino": int(row.get("i_ino", 0)),
            "comm": str(row.get("comm", "")),
            "access_count": int(row.get("access_count", 0)),
            "add_count": int(row.get("add_count", 0)),
            "delete_count": int(row.get("delete_count", 0)),
            "unique_pages": int(row.get("unique_pages", 0))
        })

    ctx.data = {
        "meta": {"time_range_ms": 0, "total_files": len(hot_files)},
        "hot_files": hot_files
    }
    return ctx


# ---------------------------------------------------------------------------
# format_io_bandwidth (将时序 SQL 结果重组为 yaml schema 结构)
# ---------------------------------------------------------------------------

@register_operator("format_io_bandwidth")
def format_io_bandwidth(ctx: PreprocessContext) -> PreprocessContext:
    """将 io_bandwidth SQL 的多行时序结果重组为 yaml 定义的结构。

    输入:
        ctx.data: DataFrame 含列 ts_100ms, read_bytes, write_bytes, total_bytes,
                  io_count, read_bw_bytes_s, write_bw_bytes_s (多行)
    输出:
        ctx.data: dict 含 meta / summary / data (时序数组)
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"time_range_ms": 0},
            "summary": {
                "avg_read_bw_mb": 0, "avg_write_bw_mb": 0,
                "peak_read_bw_mb": 0, "peak_write_bw_mb": 0,
                "total_read_mb": 0, "total_write_mb": 0,
                "total_io_count": 0
            },
            "data": []
        }
        return ctx

    total_read = int(df["read_bytes"].sum())
    total_write = int(df["write_bytes"].sum())
    total_count = int(df["io_count"].sum())

    peak_read = float(df["read_bw_bytes_s"].max()) / (1024 * 1024) if "read_bw_bytes_s" in df.columns and df["read_bw_bytes_s"].notna().any() else 0.0
    peak_write = float(df["write_bw_bytes_s"].max()) / (1024 * 1024) if "write_bw_bytes_s" in df.columns and df["write_bw_bytes_s"].notna().any() else 0.0

    n = len(df)
    avg_read_bw = float(df["read_bw_bytes_s"].sum()) / n / (1024 * 1024) if "read_bw_bytes_s" in df.columns and df["read_bw_bytes_s"].notna().any() else 0.0
    avg_write_bw = float(df["write_bw_bytes_s"].sum()) / n / (1024 * 1024) if "write_bw_bytes_s" in df.columns and df["write_bw_bytes_s"].notna().any() else 0.0

    time_range_ms = 0
    if len(df) > 1:
        ts_min = int(df["ts_100ms"].iloc[0])
        ts_max = int(df["ts_100ms"].iloc[-1])
        time_range_ms = (ts_max - ts_min) * 100

    rows = []
    for _, row in df.iterrows():
        ts = int(row.get("ts_100ms", 0))
        read_bw = float(row["read_bw_bytes_s"]) / (1024 * 1024) if pd.notna(row.get("read_bw_bytes_s")) else 0.0
        write_bw = float(row["write_bw_bytes_s"]) / (1024 * 1024) if pd.notna(row.get("write_bw_bytes_s")) else 0.0
        # random/seq bytes to bandwidth (bytes / 0.1s / 1024 / 1024 = MB/s)
        random_read_bytes = float(row.get("random_read_bytes", 0))
        seq_read_bytes = float(row.get("seq_read_bytes", 0))
        random_write_bytes = float(row.get("random_write_bytes", 0))
        seq_write_bytes = float(row.get("seq_write_bytes", 0))
        rows.append({
            "ts_100ms": ts,
            "read_bytes": int(row.get("read_bytes", 0)),
            "write_bytes": int(row.get("write_bytes", 0)),
            "total_bytes": int(row.get("total_bytes", 0)),
            "io_count": int(row.get("io_count", 0)),
            "read_bw_mb": round(read_bw, 3),
            "write_bw_mb": round(write_bw, 3),
            "random_read_bw_mb": round(random_read_bytes / 0.1 / 1024 / 1024, 3),
            "seq_read_bw_mb": round(seq_read_bytes / 0.1 / 1024 / 1024, 3),
            "random_write_bw_mb": round(random_write_bytes / 0.1 / 1024 / 1024, 3),
            "seq_write_bw_mb": round(seq_write_bytes / 0.1 / 1024 / 1024, 3),
            "concurrent_num": int(row.get("concurrent_num", 0)),
        })

    ctx.data = {
        "meta": {"time_range_ms": time_range_ms},
        "summary": {
            "avg_read_bw_mb": round(avg_read_bw, 3),
            "avg_write_bw_mb": round(avg_write_bw, 3),
            "peak_read_bw_mb": round(peak_read, 3),
            "peak_write_bw_mb": round(peak_write, 3),
            "total_read_mb": round(total_read / (1024 * 1024), 3),
            "total_write_mb": round(total_write / (1024 * 1024), 3),
            "total_io_count": total_count
        },
    }
    if not ctx.params.get("summary_only"):
        ctx.data["data"] = rows
    return ctx


# ---------------------------------------------------------------------------
# format_io_iops (将时序 SQL 结果重组为 yaml schema 结构)
# ---------------------------------------------------------------------------

@register_operator("format_io_iops")
def format_io_iops(ctx: PreprocessContext) -> PreprocessContext:
    """将 io_iops SQL 的多行时序结果重组为 yaml 定义的结构。

    输入:
        ctx.data: DataFrame 含列 ts_100ms, read_count, write_count, total_count (多行)
    输出:
        ctx.data: dict 含 meta / summary / data (时序数组)
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"time_range_ms": 0},
            "summary": {
                "total_read_count": 0, "total_write_count": 0,
                "avg_read_iops": 0, "avg_write_iops": 0,
                "peak_read_iops": 0, "peak_write_iops": 0
            },
            "data": []
        }
        return ctx

    total_read = int(df["read_count"].sum())
    total_write = int(df["write_count"].sum())

    peak_read = int(df["read_count"].max())
    peak_write = int(df["write_count"].max())

    n = len(df)
    avg_read = float(df["read_count"].sum()) / n
    avg_write = float(df["write_count"].sum()) / n

    rows = []
    for _, row in df.iterrows():
        rows.append({
            "ts_100ms": int(row.get("ts_100ms", 0)),
            "read_count": int(row.get("read_count", 0)),
            "write_count": int(row.get("write_count", 0)),
            "total_count": int(row.get("total_count", 0))
        })

    result = {
        "meta": {"time_range_ms": 0},
        "summary": {
            "total_read_count": total_read,
            "total_write_count": total_write,
            "avg_read_iops": round(avg_read / 0.1, 2),
            "avg_write_iops": round(avg_write / 0.1, 2),
            "peak_read_iops": peak_read,
            "peak_write_iops": peak_write
        },
    }
    if not ctx.params.get("summary_only"):
        result["data"] = rows
    ctx.data = result
    return ctx


# ---------------------------------------------------------------------------
# format_io_latency (将原始IO事件列表重组为 yaml schema 结构)
# ---------------------------------------------------------------------------

@register_operator("format_io_latency")
def format_io_latency(ctx: PreprocessContext) -> PreprocessContext:
    """将 io_latency SQL 的原始IO事件列表重组为 yaml 定义的结构。

    输入:
        ctx.data: DataFrame 含列 start_ms, end_ms, duration_us, request_bytes,
                  is_write, is_block, tid, tname, pid, pname
    输出:
        ctx.data: dict 含 meta / summary / data (IO事件数组)
    """

    df = ctx.data
    if not isinstance(df, pd.DataFrame) or not len(df):
        ctx.data = {
            "meta": {"time_range_ms": 0, "total_events": 0},
            "summary": {
                "p50_us": 0, "p90_us": 0, "p95_us": 0, "p99_us": 0,
                "min_us": 0, "max_us": 0, "avg_us": 0,
                "total_read_count": 0, "total_write_count": 0,
                "total_bytes": 0, "avg_size_bytes": 0
            },
            "data": []
        }
        return ctx

    total_events = len(df)
    total_read = int((df["is_write"] == 0).sum())
    total_write = int((df["is_write"] == 1).sum())
    total_bytes = int(df["request_bytes"].sum()) if "request_bytes" in df.columns else 0
    avg_size = float(total_bytes / total_events) if total_events > 0 else 0

    # 计算延迟百分位数
    latencies = df["duration_us"].dropna().tolist() if "duration_us" in df.columns else []
    if latencies:
        sorted_lat = sorted(latencies)
        n = len(sorted_lat)
        def pct(data, p):
            idx = int(p / 100.0 * (n - 1))
            return data[min(idx, n - 1)]
        p50 = pct(sorted_lat, 50)
        p90 = pct(sorted_lat, 90)
        p95 = pct(sorted_lat, 95)
        p99 = pct(sorted_lat, 99)
        min_lat = sorted_lat[0]
        max_lat = sorted_lat[-1]
        avg_lat = sum(sorted_lat) / n
    else:
        p50 = p90 = p95 = p99 = min_lat = max_lat = avg_lat = 0

    rows = []
    for _, row in df.iterrows():
        rows.append({
            "start_ms": int(row.get("start_ms", 0)),
            "end_ms": int(row.get("end_ms", 0)),
            "duration_us": round(float(row.get("duration_us", 0)), 3) if pd.notna(row.get("duration_us")) else 0,
            "request_bytes": int(row.get("request_bytes", 0)),
            "is_write": int(row.get("is_write", 0)),
            "is_block": int(row.get("is_block", 0)) if "is_block" in row and pd.notna(row.get("is_block")) else 0,
            "tid": int(row.get("tid", 0)) if pd.notna(row.get("tid")) else 0,
            "tname": str(row.get("tname", "")) if pd.notna(row.get("tname")) else "",
            "pid": int(row.get("pid", 0)) if pd.notna(row.get("pid")) else 0,
            "pname": str(row.get("pname", "")) if pd.notna(row.get("pname")) else ""
        })

    time_range_ms = 0
    if total_events > 1 and "start_ms" in df.columns:
        ts_min = int(df["start_ms"].min())
        ts_max = int(df["start_ms"].max())
        time_range_ms = ts_max - ts_min

    ctx.data = {
        "meta": {"time_range_ms": time_range_ms, "total_events": total_events},
        "summary": {
            "p50_us": round(p50, 3),
            "p90_us": round(p90, 3),
            "p95_us": round(p95, 3),
            "p99_us": round(p99, 3),
            "min_us": round(min_lat, 3),
            "max_us": round(max_lat, 3),
            "avg_us": round(avg_lat, 3),
            "total_read_count": total_read,
            "total_write_count": total_write,
            "total_bytes": total_bytes,
            "avg_size_bytes": round(avg_size, 1)
        },
        "data": rows
    }
    return ctx
