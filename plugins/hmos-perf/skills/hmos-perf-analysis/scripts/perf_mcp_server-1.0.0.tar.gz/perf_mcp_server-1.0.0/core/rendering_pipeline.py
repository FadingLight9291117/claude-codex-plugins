"""渲染管线检测 (v3.3 动态 YAML 架构, 2-query optimized)。

对齐 SmartPerfetto renderingPipelineDetectionSkillGenerator.ts 的完整逻辑，
一个文件涵盖：Pipeline 加载 → SQL 生成 → 检测执行 → 结果组装。

2-query 优化检测流程（原 9 步合并为 Q1+Q2）：
  Q1: 打分+排名 (原 Steps 1+2, 共享 CTE 只计算 1 次)
  Q2: 辅助信号 (原 Steps 3-8, 标量子查询隔离故障)
  缓存: OrderedDict LRU (maxsize=8), key=(sqlite_path, package_name)

核心原理：通用聚合公式替代硬编码 CASE WHEN，新增管线只需改 YAML。

主要接口：
  detect_rendering_pipeline(sqlite_path, package_name?) -> PipelineDetectionResult
"""
from __future__ import annotations

from core.observability import get_module_logger
import json
import sqlite3
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from core.rendering.models import (
    CommonIssue,
    DetectionRules,
    DetectionSignal,
    PipelineAnalysis,
    PipelineDefinition,
    PipelineKeySlice,
    PipelineMeta,
    PipelineThreadRole,
    PinInstruction,
    ScoringSignal,
    SmartFilterConfig,
    TeachingContent,
)

logger = get_module_logger(__name__)

# LRU cache for pipeline detection results. Key: (sqlite_path, package_name).
# OrderedDict with FIFO eviction, maxsize=8. Single-threaded (stdio MCP transport).
_pipeline_cache: OrderedDict[tuple, 'PipelineDetectionResult'] = OrderedDict()


# ═══════════════════════════════════════════════════════════════════════════
# 配置常量
# ═══════════════════════════════════════════════════════════════════════════

SCORE_THRESHOLD = 0.3
MAX_CANDIDATES = 5

# Pipelines that represent orthogonal features (or composition layers) and
# should NOT win the primary pipeline selection. They can still appear in
# the "features" list or be detected separately.
NON_PRIMARY_PIPELINE_IDS: set = set()

# Pipelines whose detection signals live outside the app processes (e.g.
# SurfaceFlinger / system_server), so we should score them using global
# counts instead of app-filtered counts.
GLOBAL_SCOPE_PIPELINE_IDS: set = set()

# Pipelines that should be surfaced in the "features" list.
FEATURE_PIPELINE_IDS: set = set()

DEFAULT_PIPELINE_ID = "HARMONY_ARKUI"
DEFAULT_DOC_PATH = "rendering_pipelines/harmony_arkui.md"


# ═══════════════════════════════════════════════════════════════════════════
# Pipeline YAML 加载
# ═══════════════════════════════════════════════════════════════════════════

def _load_pipelines(pipelines_dir: str | Path = "config/pipelines") -> Dict[str, PipelineDefinition]:
    """扫描 config/pipelines/ 下所有 *.skill.yaml，返回 {pipeline_id: PipelineDefinition}。"""
    pipelines_dir = Path(pipelines_dir)
    result: Dict[str, PipelineDefinition] = {}

    if not pipelines_dir.exists():
        logger.warning("Pipeline 目录不存在: %s", pipelines_dir)
        return result

    for yaml_file in sorted(pipelines_dir.glob("*.skill.yaml")):
        if yaml_file.name.startswith("_") or yaml_file.name == "index.yaml":
            continue
        try:
            data = yaml.safe_load(yaml_file.read_text(encoding="utf-8"))
            if not data:
                continue
            pipeline = _parse_pipeline(data)
            if pipeline:
                result[pipeline.meta.pipeline_id] = pipeline
                logger.debug("Loaded pipeline: %s (%s)", pipeline.meta.pipeline_id, pipeline.meta.display_name)
        except Exception as e:
            logger.error("Failed to load pipeline %s: %s", yaml_file.name, e)

    logger.info("PipelineLoader: loaded %d pipeline definitions", len(result))
    return result


def _parse_pipeline(data: dict) -> Optional[PipelineDefinition]:
    meta_data = data.get("meta", {})
    meta = PipelineMeta(
        pipeline_id=meta_data.get("pipeline_id", ""),
        display_name=meta_data.get("display_name", ""),
        description=meta_data.get("description", ""),
        icon=meta_data.get("icon", ""),
        family=meta_data.get("family", ""),
        doc_path=meta_data.get("doc_path"),
        s_article_ref=meta_data.get("s_article_ref"),
        four_features=meta_data.get("four_features"),
        deviation_anchors=meta_data.get("deviation_anchors"),
        subvariants_note=meta_data.get("subvariants_note"),
        layer_signature=meta_data.get("layer_signature"),
        thread_locations=meta_data.get("thread_locations"),
        impeller_advantage=meta_data.get("impeller_advantage"),
        known_traps=meta_data.get("known_traps"),
        difference_from_standalone_chrome=meta_data.get("difference_from_standalone_chrome"),
    )
    detection = _parse_detection(data["detection"]) if data.get("detection") else None
    teaching = _parse_teaching(data["teaching"]) if data.get("teaching") else None
    auto_pin = _parse_auto_pin(data["auto_pin"]) if data.get("auto_pin") else None
    analysis = _parse_analysis(data["analysis"]) if data.get("analysis") else None

    return PipelineDefinition(
        name=data.get("name", ""),
        version=data.get("version", "1.0"),
        type=data.get("type", "pipeline_definition"),
        category=data.get("category", "rendering"),
        meta=meta,
        detection=detection,
        teaching=teaching,
        auto_pin=auto_pin,
        analysis=analysis,
    )


def _parse_detection(data: dict) -> DetectionRules:
    required_signals = [
        DetectionSignal(
            thread=sig.get("thread"),
            thread_pattern=sig.get("thread_pattern"),
            slice=sig.get("slice"),
            slice_pattern=sig.get("slice_pattern"),
            min_count=sig.get("min_count", 1),
        )
        for sig in data.get("required_signals", [])
    ]
    scoring_signals = [
        ScoringSignal(
            signal=sig.get("signal", ""),
            thread=sig.get("thread"),
            thread_pattern=sig.get("thread_pattern"),
            slice=sig.get("slice"),
            slice_pattern=sig.get("slice_pattern"),
            weight=sig.get("weight", 0),
            min_count=sig.get("min_count", 1),
            condition=sig.get("condition"),
        )
        for sig in data.get("scoring_signals", [])
    ]
    exclude_if = [
        DetectionSignal(
            thread=sig.get("thread"),
            thread_pattern=sig.get("thread_pattern"),
            slice=sig.get("slice"),
            slice_pattern=sig.get("slice_pattern"),
            min_count=sig.get("min_count", 1),
        )
        for sig in data.get("exclude_if", [])
    ]
    return DetectionRules(
        required_signals=required_signals or None,
        scoring_signals=scoring_signals or None,
        exclude_if=exclude_if or None,
        min_frames=data.get("min_frames"),
    )


def _parse_teaching(data: dict) -> TeachingContent:
    thread_roles = [
        PipelineThreadRole(
            thread=tr.get("thread", ""),
            role=tr.get("role", ""),
            description=tr.get("description", ""),
            trace_tags=tr.get("trace_tags"),
        )
        for tr in data.get("thread_roles", [])
    ]
    key_slices = [
        PipelineKeySlice(
            name=ks.get("name", ""),
            thread=ks.get("thread", ""),
            description=ks.get("description", ""),
        )
        for ks in data.get("key_slices", [])
    ]
    return TeachingContent(
        title=data.get("title", ""),
        summary=data.get("summary", ""),
        mermaid=data.get("mermaid"),
        thread_roles=thread_roles,
        key_slices=key_slices,
    )


def _parse_auto_pin(data: dict) -> Dict[str, Any]:
    instructions = []
    for instr in data.get("instructions", []):
        smart_filter_data = instr.get("smart_filter")
        smart_filter = None
        if smart_filter_data:
            smart_filter = SmartFilterConfig(
                enabled=smart_filter_data.get("enabled", False),
                description=smart_filter_data.get("description"),
                detection_sql=smart_filter_data.get("detection_sql"),
                fallback_sql=smart_filter_data.get("fallback_sql"),
            )
        instructions.append(
            PinInstruction(
                pattern=instr.get("pattern", ""),
                match_by=instr.get("match_by", "name"),
                priority=instr.get("priority", 0),
                reason=instr.get("reason", ""),
                expand=instr.get("expand"),
                main_thread_only=instr.get("main_thread_only"),
                smart_filter=smart_filter,
            )
        )
    return {"instructions": instructions}


def _parse_analysis(data: dict) -> PipelineAnalysis:
    common_issues = [
        CommonIssue(
            id=issue.get("id", ""),
            name=issue.get("name", ""),
            description=issue.get("description"),
            detection_skill=issue.get("detection_skill"),
        )
        for issue in data.get("common_issues", [])
    ]
    return PipelineAnalysis(
        common_issues=common_issues or None,
        recommended_skills=data.get("recommended_skills"),
    )


# ═══════════════════════════════════════════════════════════════════════════
# SQL 工具
# ═══════════════════════════════════════════════════════════════════════════

def _sql_str(value: str) -> str:
    escaped = value.replace("'", "''")
    return f"'{escaped}'"


def _sql_val(value: str | int | float | None) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, (int, float)):
        return str(value)
    return _sql_str(str(value))


def _normalize_int(value, fallback: int = 1, *, positive: bool = True) -> int:
    try:
        parsed = int(value) if value is not None else fallback
    except (ValueError, TypeError):
        return fallback
    if positive and parsed <= 0:
        return fallback
    if not positive and parsed < 0:
        return fallback
    return parsed


# ═══════════════════════════════════════════════════════════════════════════
# 共用 CTE: dominant_process + dominant_pkg + app_filter_ipids
# ═══════════════════════════════════════════════════════════════════════════

# RS (render_service) is a system-level composition layer (equivalent to SurfaceFlinger),
# not an app process. It should be excluded from dominant_app detection and handled
# separately via harmony_rs_analysis composite skill.
_DOMINANT_PROCESS_CTE = """
dominant_process AS (
  SELECT
    p.ipid,
    p.name as process_name,
    COUNT(*) as render_cnt
  FROM callstack s
  JOIN thread t ON s.callid = t.itid
  JOIN process p ON t.ipid = p.ipid
  WHERE s.name IS NOT NULL
    AND (
      -- System process filter: when process names are available
-- NOTE: use LTRIM(RTRIM()) to strip only leading/trailing tabs.
    -- SQLite TRIM() only strips spaces, and REPLACE removes ALL tabs (not just leading).
    (p.name IS NOT NULL AND p.name != ''
     AND LTRIM(RTRIM(p.name, CHAR(9)), CHAR(9)) NOT LIKE '/system/%'
     AND LTRIM(RTRIM(p.name, CHAR(9)), CHAR(9)) NOT LIKE 'render_service%')
    OR
    -- Fallback: when process names are empty, filter by thread name
    -- NOTE: also guard by process name to exclude render_service with leading \t
    (LTRIM(RTRIM(COALESCE(p.name, ''), CHAR(9)), CHAR(9)) NOT LIKE 'render_service%'
       AND t.name NOT IN ('RSMainThread', 'VSyncGenerator', 'HwcThread', 'RSUniRenderThre',
                      'render_service', 'gpu-work-server', 'GpuWatchdog',
                      'gpu-mem-pool', 'gpu-boost-rpch', 'gpu-boost-rpdw'))
    )
    AND s.name IS NOT NULL
    AND (
      -- HarmonyOS signals: ArkUI (H: prefix format)
      (s.name GLOB 'H:RequestNextVSync*')
      OR (s.name GLOB 'H:Animate*')
      OR (s.name GLOB 'H:VSyncConnection*')
      OR (s.name GLOB 'H:Add VSyncConnection*')
      OR (s.name GLOB 'H:AcquireBuffer*')
      OR (s.name GLOB 'H:ArkUI*')
      OR (s.name GLOB '*UIVsyncTask*')
      OR (s.name GLOB '*OnVsyncEvent*')
      OR (s.name GLOB '*FlushMessages*')
      OR (s.name GLOB '*ReceiveVsync*')
      OR (s.name GLOB '*RSMainThread::ProcessCommandUni*')
      OR (s.name GLOB '*MarshRSTransactionData*')
      -- HarmonyOS signals: KMP (Compose)
      OR (s.name GLOB '*Recomposer*')
      OR (s.name GLOB '*RenderView*onDraw*')
      OR (s.name GLOB '*RootNodeOwner*draw*')
      -- HarmonyOS signals: React Native
      OR (s.name GLOB '*RNView*')
      OR (s.name GLOB '*RNNode*')
      OR (s.name GLOB '*RNComponent*')
      -- HarmonyOS signals: Flutter
      OR (s.name GLOB '*flutter*VsyncProcessCallback*')
      OR (s.name GLOB '*flutter*GPURasterizer*Draw*')
      OR (s.name GLOB '*flutter*Animator*BeginFrame*')
      OR (s.name GLOB '*Impeller*')
      OR (s.name GLOB '*FlushBuffer*')
      -- HarmonyOS signals: Web (VizCompositor)
      OR (s.name GLOB '*ExternalBeginFrameSourceOHOS*OnVSyncImpl*')
      OR (s.name GLOB '*IssueBeginFrame*')
      OR (s.name GLOB '*SubmitCompositorFrame*')
      OR (s.name GLOB '*SwapBufferAck*')
      OR (t.name GLOB 'VizCompositor*')
      OR (t.name GLOB 'Compositor')
    )
  GROUP BY p.ipid
  HAVING COUNT(*) > 5
  ORDER BY render_cnt DESC
  LIMIT 1
),
dominant_pkg AS (
  SELECT
    CASE
      WHEN instr(process_name, ':') > 0
      THEN substr(process_name, 1, instr(process_name, ':') - 1)
      ELSE process_name
    END as pkg,
    CASE WHEN process_name IS NULL OR process_name = '' THEN ipid ELSE NULL END as fallback_ipid
  FROM dominant_process
)
"""


# ═══════════════════════════════════════════════════════════════════════════
# HarmonyOS Schema 适配
# trace_streamer 输出使用 callstack/thread/process，与 SmartPerfetto 的
# slice/thread_track/thread 不同。直接使用 HarmonyOS 表结构。
# ═══════════════════════════════════════════════════════════════════════════


def _app_filter_cte(package_name: Optional[str] = None) -> str:
    pkg = (package_name or "").strip()
    # Exclude system composition layers (RS / SurfaceFlinger) from app filter
    # Note: leading comma is required because _DOMINANT_PROCESS_CTE ends with
    # dominant_pkg AS (...) without a trailing comma.
    # Also handles empty process_name: when dominant_pkg.fallback_ipid is set,
    # use ipid directly instead of GLOB matching on empty names.
    #
    # For multi-process rendering frameworks (e.g., Web), we also include processes
    # that have web-specific rendering signals (VizCompositor, CompositorGpu, etc.)
    # even if they're not the dominant process.
    if pkg:
        return f""", app_filter_ipids AS (
  SELECT p.ipid
  FROM process p
  WHERE {_sql_str(pkg)} <> '' AND p.name GLOB {_sql_str(pkg + '*')}
  UNION
  SELECT p.ipid
  FROM process p
  JOIN dominant_pkg dp
  WHERE {_sql_str(pkg)} = ''
    AND (
      (dp.pkg IS NOT NULL AND dp.pkg <> '' AND p.name GLOB dp.pkg || '*')
      OR (dp.fallback_ipid IS NOT NULL AND p.ipid = dp.fallback_ipid)
    )
    -- NOTE: use LTRIM(RTRIM()) to strip only leading/trailing tabs.
    AND LTRIM(RTRIM(p.name, CHAR(9)), CHAR(9)) NOT LIKE '/system/%'
    AND LTRIM(RTRIM(p.name, CHAR(9)), CHAR(9)) NOT LIKE 'render_service%'
  UNION
  -- Include processes with web rendering signals (multi-process web frameworks)
  SELECT DISTINCT t.ipid
  FROM thread t
  WHERE t.name GLOB 'VizCompositor*'
     OR t.name GLOB 'CompositorGpu*'
     OR t.name GLOB 'Compositor*'
     OR t.name GLOB '*webview*'
     OR t.name GLOB '*WebView*'
)"""
    return """, app_filter_ipids AS (
  SELECT p.ipid
  FROM process p
  JOIN dominant_pkg dp
  WHERE (
    (dp.pkg IS NOT NULL AND dp.pkg <> '' AND p.name GLOB dp.pkg || '*')
    OR (dp.fallback_ipid IS NOT NULL AND p.ipid = dp.fallback_ipid)
  )
  -- NOTE: use LTRIM(RTRIM()) to strip only leading/trailing tabs.
  AND LTRIM(RTRIM(p.name, CHAR(9)), CHAR(9)) NOT LIKE '/system/%'
  AND LTRIM(RTRIM(p.name, CHAR(9)), CHAR(9)) NOT LIKE 'render_service%'
  UNION
  -- Include processes with web rendering signals (multi-process web frameworks)
  SELECT DISTINCT t.ipid
  FROM thread t
  WHERE t.name GLOB 'VizCompositor*'
     OR t.name GLOB 'CompositorGpu*'
     OR t.name GLOB 'Compositor*'
     OR t.name GLOB '*webview*'
     OR t.name GLOB '*WebView*'
)"""


# ═══════════════════════════════════════════════════════════════════════════
# 信号组件构建
# ═══════════════════════════════════════════════════════════════════════════

def _build_signal_components(signal) -> List[dict]:
    components: List[dict] = []
    if getattr(signal, "thread", None):
        components.append({"source": "t", "op": "eq", "pattern": signal.thread})
    if getattr(signal, "thread_pattern", None):
        components.append({"source": "t", "op": "glob", "pattern": signal.thread_pattern})
    if getattr(signal, "slice", None):
        components.append({"source": "s", "op": "eq", "pattern": signal.slice})
    if getattr(signal, "slice_pattern", None):
        components.append({"source": "s", "op": "glob", "pattern": signal.slice_pattern})
    return components


def _describe_signal_key(signal) -> str:
    if getattr(signal, "thread", None):
        return f"thread:{signal.thread}"
    if getattr(signal, "thread_pattern", None):
        return f"thread_pattern:{signal.thread_pattern}"
    if getattr(signal, "slice", None):
        return f"slice:{signal.slice}"
    if getattr(signal, "slice_pattern", None):
        return f"slice_pattern:{signal.slice_pattern}"
    return "unknown"


# ═══════════════════════════════════════════════════════════════════════════
# Step 1: signal_defs VALUES
# ═══════════════════════════════════════════════════════════════════════════

def _build_signal_defs_sql(pipelines: List[PipelineDefinition]) -> str:
    signal_id = 0
    rows: List[str] = []

    for pipeline in pipelines:
        pipeline_id = pipeline.meta.pipeline_id
        detection = pipeline.detection
        if not detection:
            continue

        scope = "g" if pipeline_id in GLOBAL_SCOPE_PIPELINE_IDS else "a"

        for req in (detection.required_signals or []):
            components = _build_signal_components(req)
            if not components:
                continue
            min_count = _normalize_int(getattr(req, "min_count", None), 1)
            name = _describe_signal_key(req)
            current_id = signal_id
            signal_id += 1
            for comp in components:
                rows.append(
                    f"({current_id}, {_sql_val(pipeline_id)}, 'r', {_sql_val(name)}, "
                    f"0, {min_count}, {_sql_val(comp['source'])}, {_sql_val(comp['op'])}, "
                    f"{_sql_val(comp['pattern'])}, {_sql_val(scope)})"
                )

        for sc in (detection.scoring_signals or []):
            components = _build_signal_components(sc)
            if not components:
                continue
            min_count = _normalize_int(getattr(sc, "min_count", None), 1)
            weight = _normalize_int(getattr(sc, "weight", None), 0, positive=False)
            signal_name = getattr(sc, "signal", "") or "unnamed"
            current_id = signal_id
            signal_id += 1
            for comp in components:
                rows.append(
                    f"({current_id}, {_sql_val(pipeline_id)}, 's', {_sql_val(signal_name)}, "
                    f"{weight}, {min_count}, {_sql_val(comp['source'])}, {_sql_val(comp['op'])}, "
                    f"{_sql_val(comp['pattern'])}, {_sql_val(scope)})"
                )

        for ex in (detection.exclude_if or []):
            components = _build_signal_components(ex)
            if not components:
                continue
            name = _describe_signal_key(ex)
            current_id = signal_id
            signal_id += 1
            for comp in components:
                rows.append(
                    f"({current_id}, {_sql_val(pipeline_id)}, 'e', {_sql_val(name)}, "
                    f"0, 1, {_sql_val(comp['source'])}, {_sql_val(comp['op'])}, "
                    f"{_sql_val(comp['pattern'])}, {_sql_val(scope)})"
                )

    if not rows:
        return f"(0, {_sql_val(DEFAULT_PIPELINE_ID)}, 's', 'noop', 0, 1, 's', 'eq', '__noop__', 'a')"
    return ",\n        ".join(rows)


def _build_pipeline_list_sql(pipelines: List[PipelineDefinition]) -> str:
    if not pipelines:
        return f"({_sql_val(DEFAULT_PIPELINE_ID)})"
    return ",\n        ".join(f"({_sql_val(p.meta.pipeline_id)})" for p in pipelines)


def _build_pipeline_docs_sql(pipelines: List[PipelineDefinition]) -> str:
    if not pipelines:
        return f"({_sql_val(DEFAULT_PIPELINE_ID)}, {_sql_val(DEFAULT_DOC_PATH)})"
    return ",\n        ".join(
        f"({_sql_val(p.meta.pipeline_id)}, {_sql_val(p.meta.doc_path)})"
        for p in pipelines
    )


def _build_min_frames_sql(pipelines: List[PipelineDefinition]) -> str:
    if not pipelines:
        return f"({_sql_val(DEFAULT_PIPELINE_ID)}, {_sql_val(None)})"
    return ",\n        ".join(
        f"({_sql_val(p.meta.pipeline_id)}, {_sql_val(p.detection.min_frames if p.detection and p.detection.min_frames not in (None, 0) else None)})"
        for p in pipelines
    )


# ═══════════════════════════════════════════════════════════════════════════
# Q1: 打分 + 排名 (Steps 1+2 merged, single SQL)
# ═══════════════════════════════════════════════════════════════════════════

def _build_q1_scoring_sql(
    pipelines: List[PipelineDefinition],
    package_name: Optional[str] = None,
) -> str:
    """Q1: Merge Steps 1+2 into a single SQL — scoring + ranking.

    Shared CTEs (dominant_process, dominant_pkg, app_filter_ipids,
    thread_counts, slice_counts) are computed once.
    Step2's ranked CTE directly references scores CTE — no subquery nesting.
    """
    pipeline_list_sql = _build_pipeline_list_sql(pipelines)
    signal_defs_sql = _build_signal_defs_sql(pipelines)
    pipeline_docs_sql = _build_pipeline_docs_sql(pipelines)
    min_frames_sql = _build_min_frames_sql(pipelines)
    app_filter = _app_filter_cte(package_name)

    non_primary_list = ", ".join(_sql_val(pid) for pid in NON_PRIMARY_PIPELINE_IDS)
    feature_ids_list = ", ".join(_sql_val(pid) for pid in FEATURE_PIPELINE_IDS)

    return f"""
WITH
{_DOMINANT_PROCESS_CTE}
{app_filter},
thread_counts AS (
  SELECT
    t.name as thread_name,
    SUM(CASE WHEN t.ipid IN (SELECT ipid FROM app_filter_ipids) THEN 1 ELSE 0 END) as app_cnt,
    COUNT(*) as global_cnt
  FROM thread t
  WHERE t.name IS NOT NULL
  GROUP BY t.name
),
slice_counts AS (
  SELECT
    s.name as slice_name,
    SUM(CASE WHEN p.ipid IN (SELECT ipid FROM app_filter_ipids) THEN 1 ELSE 0 END) as app_cnt,
    COUNT(*) as global_cnt
  FROM callstack s
  JOIN thread t ON s.callid = t.itid
  JOIN process p ON t.ipid = p.ipid
  WHERE s.name IS NOT NULL
  GROUP BY s.name
),
pipeline_list(pipeline_id) AS (
  VALUES
  {pipeline_list_sql}
),
signal_defs(signal_id, pipeline_id, signal_type, signal_name, weight, min_count, source, op, pattern, scope) AS (
  VALUES
  {signal_defs_sql}
),
signal_counts AS (
  SELECT
    sd.signal_id,
    sd.pipeline_id,
    sd.signal_type,
    sd.signal_name,
    sd.weight,
    sd.min_count,
    SUM(
      CASE
        WHEN sd.source = 't' THEN
          CASE WHEN sd.scope = 'g' THEN COALESCE(tc.global_cnt, 0)
               ELSE COALESCE(tc.app_cnt, 0) END
        WHEN sd.source = 's' THEN
          CASE WHEN sd.scope = 'g' THEN COALESCE(sc.global_cnt, 0)
               ELSE COALESCE(sc.app_cnt, 0) END
        ELSE 0
      END
    ) as cnt
  FROM signal_defs sd
  LEFT JOIN thread_counts tc
    ON sd.source = 't'
   AND (
     (sd.op = 'eq' AND tc.thread_name = sd.pattern)
     OR (sd.op = 'glob' AND tc.thread_name GLOB sd.pattern)
   )
  LEFT JOIN slice_counts sc
    ON sd.source = 's'
   AND (
     (sd.op = 'eq' AND sc.slice_name = sd.pattern)
     OR (sd.op = 'glob' AND sc.slice_name GLOB sd.pattern)
   )
  GROUP BY sd.signal_id, sd.pipeline_id, sd.signal_type, sd.signal_name,
           sd.weight, sd.min_count
),
signal_agg AS (
  SELECT
    pipeline_id,
    MIN(
      CASE
        WHEN signal_type = 'r' THEN CASE WHEN cnt >= min_count THEN 1 ELSE 0 END
        ELSE 1
      END
    ) as required_ok,
    MAX(
      CASE
        WHEN signal_type = 'e' THEN CASE WHEN cnt > 0 THEN 1 ELSE 0 END
        ELSE 0
      END
    ) as excluded,
    SUM(CASE WHEN signal_type = 's' THEN weight ELSE 0 END) as total_weight,
    SUM(CASE WHEN signal_type = 's' AND cnt >= min_count THEN weight ELSE 0 END) as matched_weight,
    MAX(CASE WHEN signal_type = 's' THEN cnt ELSE 0 END) as frame_count
  FROM signal_counts
  GROUP BY pipeline_id
),
pipeline_scores AS (
  SELECT
    pl.pipeline_id,
    COALESCE(sa.required_ok, 1) as required_ok,
    COALESCE(sa.excluded, 0) as excluded,
    COALESCE(sa.total_weight, 0) as total_weight,
    COALESCE(sa.matched_weight, 0) as matched_weight,
    COALESCE(sa.frame_count, 0) as frame_count
  FROM pipeline_list pl
  LEFT JOIN signal_agg sa ON sa.pipeline_id = pl.pipeline_id
),
scores AS (
  SELECT
    pipeline_id,
    required_ok,
    excluded,
    total_weight,
    matched_weight,
    frame_count,
    CASE
      WHEN required_ok = 1 AND excluded = 0 AND total_weight > 0
      THEN matched_weight * 1.0 / total_weight
      ELSE 0
    END as score
  FROM pipeline_scores
),
pipeline_docs(pipeline_id, doc_path) AS (
  VALUES
  {pipeline_docs_sql}
),
min_frames(pipeline_id, min_frames) AS (
  VALUES
  {min_frames_sql}
),
ranked AS (
  SELECT
    ps.pipeline_id,
    ps.score,
    ROW_NUMBER() OVER (ORDER BY ps.score DESC, ps.pipeline_id ASC) as rank
  FROM scores ps
  LEFT JOIN min_frames mf ON mf.pipeline_id = ps.pipeline_id
  WHERE ps.score >= {SCORE_THRESHOLD}
    {f"AND ps.pipeline_id NOT IN ({non_primary_list})" if non_primary_list else ""}
    AND (mf.min_frames IS NULL OR ps.frame_count >= mf.min_frames)
),
primary_pipeline AS (
  SELECT pipeline_id, score FROM ranked WHERE rank = 1
),
candidates AS (
  SELECT pipeline_id, score, rank FROM ranked WHERE rank <= {MAX_CANDIDATES}
),
features AS (
  SELECT
    pipeline_id,
    score,
    ROW_NUMBER() OVER (ORDER BY score DESC, pipeline_id ASC) as rank
  FROM scores
  WHERE pipeline_id IN ({feature_ids_list})
    AND score >= {SCORE_THRESHOLD}
),
candidate_list AS (
  SELECT GROUP_CONCAT(pipeline_id || ':' || ROUND(score, 2), ',') as candidates_list
  FROM (
    SELECT pipeline_id, score FROM candidates ORDER BY rank ASC
  )
),
feature_list AS (
  SELECT GROUP_CONCAT(pipeline_id || ':' || ROUND(score, 2), ',') as features_list
  FROM (
    SELECT pipeline_id, score FROM features ORDER BY rank ASC
  )
),
scores_json_agg AS (
  SELECT json_group_array(
    json_object('pipeline_id', pipeline_id, 'required_ok', required_ok,
                'excluded', excluded, 'total_weight', total_weight,
                'matched_weight', matched_weight, 'score', score)
  ) as scores_json
  FROM scores
),
result AS (
  SELECT
    COALESCE((SELECT pipeline_id FROM primary_pipeline), {_sql_val(DEFAULT_PIPELINE_ID)}) as primary_pipeline_id,
    COALESCE((SELECT score FROM primary_pipeline), 0.50) as primary_confidence,
    COALESCE((SELECT candidates_list FROM candidate_list), '') as candidates_list,
    COALESCE((SELECT features_list FROM feature_list), '') as features_list
)
SELECT
  r.primary_pipeline_id,
  r.primary_confidence,
  r.candidates_list,
  r.features_list,
  COALESCE(
    (SELECT doc_path FROM pipeline_docs WHERE pipeline_id = r.primary_pipeline_id),
    {_sql_val(DEFAULT_DOC_PATH)}
  ) as doc_path,
  COALESCE((SELECT scores_json FROM scores_json_agg), '[]') as scores_json
FROM result r
"""


# ═══════════════════════════════════════════════════════════════════════════
# Q2: 辅助信号 (Steps 3-8 merged, scalar subqueries, no cross-join)
# ═══════════════════════════════════════════════════════════════════════════

def _build_q2_auxiliary_sql(
    package_name: Optional[str] = None,
    include_layer_signals: bool = False,
) -> str:
    """Q2: Merge Steps 3-8 into a single SQL using scalar subqueries.

    Each auxiliary signal CTE is read via scalar subquery in the final SELECT,
    so any single CTE returning NULL does NOT affect other fields (no annihilation).

    Args:
        package_name: Optional package filter.
        include_layer_signals: If True, include layer_signals CTE (requires
            process_measure_filter table to exist). If False, layer signals
            default values are returned inline.
    """
    app_filter = _app_filter_cte(package_name)

    layer_cte = ""
    layer_select = """,
  0 as app_layer_count,
  '' as app_layer_names,
  0 as has_surfaceview_layer,
  0 as has_video_layer,
  0 as has_flutter_layer,
  0 as has_camera_layer"""

    if include_layer_signals:
        layer_cte = """,
app_layers AS (
  SELECT DISTINCT mf.name
  FROM process_measure_filter mf
  WHERE mf.name GLOB '*RosenWeb*'
     OR mf.name GLOB '*flutter*Surface'
     OR mf.name GLOB '*HDC_PREVIEWSurface*'
),
layer_sigs AS (
  SELECT
    COUNT(*) as app_layer_count,
    COALESCE(GROUP_CONCAT(name, ','), '') as app_layer_names,
    CASE WHEN EXISTS (SELECT 1 FROM app_layers WHERE name GLOB '*RosenWeb*') THEN 1 ELSE 0 END as has_surfaceview_layer,
    0 as has_video_layer,
    CASE WHEN EXISTS (SELECT 1 FROM app_layers WHERE name GLOB '*flutter*Surface') THEN 1 ELSE 0 END as has_flutter_layer,
    CASE WHEN EXISTS (SELECT 1 FROM app_layers WHERE name GLOB '*HDC_PREVIEWSurface*') THEN 1 ELSE 0 END as has_camera_layer
  FROM app_layers
)"""
        layer_select = """,
  (SELECT app_layer_count FROM layer_sigs) as app_layer_count,
  (SELECT app_layer_names FROM layer_sigs) as app_layer_names,
  (SELECT has_surfaceview_layer FROM layer_sigs) as has_surfaceview_layer,
  (SELECT has_video_layer FROM layer_sigs) as has_video_layer,
  (SELECT has_flutter_layer FROM layer_sigs) as has_flutter_layer,
  (SELECT has_camera_layer FROM layer_sigs) as has_camera_layer"""

    return f"""
WITH
{_DOMINANT_PROCESS_CTE}
{app_filter},
thread_counts AS (
  SELECT t.name as thread_name, COUNT(*) as cnt
  FROM thread t
  WHERE t.name IS NOT NULL AND t.ipid IN (SELECT ipid FROM app_filter_ipids)
  GROUP BY t.name
),
slice_counts AS (
  SELECT s.name as slice_name, COUNT(*) as cnt
  FROM callstack s
  JOIN thread t ON s.callid = t.itid
  JOIN process p ON t.ipid = p.ipid
  WHERE s.name IS NOT NULL AND p.ipid IN (SELECT ipid FROM app_filter_ipids)
  GROUP BY s.name
),
subvariants AS (
  SELECT
    CASE
      WHEN COALESCE((SELECT SUM(cnt) FROM thread_counts
                     WHERE thread_name = 'VizCompositorThread'
                        OR thread_name GLOB 'VizCompositorThread*'
                        OR thread_name = 'VizCompositor'
                        OR thread_name GLOB 'VizCompositor*'), 0) > 0
      THEN 'SURFACE_CONTROL'
      ELSE 'N/A'
    END as webview_mode,
    CASE
      WHEN COALESCE((SELECT SUM(cnt) FROM thread_counts WHERE thread_name IN ('ui', '1.ui')), 0) > 0
           AND COALESCE((SELECT SUM(cnt) FROM slice_counts WHERE slice_name GLOB '*Impeller*' OR slice_name GLOB '*EntityPass*'), 0) > 0
      THEN 'IMPELLER'
      WHEN COALESCE((SELECT SUM(cnt) FROM thread_counts WHERE thread_name IN ('ui', '1.ui')), 0) > 0
           AND COALESCE((SELECT SUM(cnt) FROM slice_counts WHERE slice_name GLOB '*SkGpu*' OR slice_name GLOB '*SkiaGpu*'), 0) > 0
           AND COALESCE((SELECT SUM(cnt) FROM slice_counts WHERE slice_name GLOB '*EntityPass*'), 0) = 0
      THEN 'SKIA'
      WHEN COALESCE((SELECT SUM(cnt) FROM thread_counts WHERE thread_name IN ('ui', '1.ui')), 0) > 0
      THEN 'UNKNOWN'
      ELSE 'N/A'
    END as flutter_engine,
    CASE
      WHEN COALESCE((SELECT SUM(cnt) FROM thread_counts WHERE thread_name GLOB 'UnityMain*'), 0) > 0 THEN 'UNITY'
      WHEN COALESCE((SELECT SUM(cnt) FROM thread_counts WHERE thread_name GLOB 'GameThread*' OR thread_name GLOB 'RHIThread*'), 0) > 0 THEN 'UNREAL'
      WHEN COALESCE((SELECT SUM(cnt) FROM thread_counts WHERE thread_name GLOB 'GodotMain*'), 0) > 0 THEN 'GODOT'
      ELSE 'N/A'
    END as game_engine
),
trace_reqs AS (
  SELECT
    CASE
      WHEN NOT EXISTS (SELECT 1 FROM thread t WHERE t.name GLOB 'VizCompositorTh*' OR t.name GLOB 'CompositorGpuTh*' LIMIT 1)
      THEN NULL
      WHEN NOT EXISTS (
        SELECT 1 FROM callstack s
        WHERE s.name GLOB '*Graphics*Pipeline*'
           OR s.name GLOB '*SkiaOutputSurface*'
        LIMIT 1
      )
      THEN 'web: Graphics.Pipeline/SkiaOutputSurface slices missing (enable atrace: nweb)'
      ELSE NULL
    END as hint_web,
    CASE
      WHEN NOT EXISTS (SELECT 1 FROM process p WHERE p.name GLOB '*render_service*' LIMIT 1)
      THEN 'rs: render_service process missing (need system tracing / root)'
      ELSE NULL
    END as hint_rs
),
marker_slices AS (
  SELECT
    p.ipid,
    p.name as process_name,
    t.tid,
    t.name as thread_name,
    p.pid
  FROM callstack s
  JOIN thread t ON s.callid = t.itid
  JOIN process p ON t.ipid = p.ipid
  WHERE p.ipid IN (SELECT ipid FROM app_filter_ipids)
    AND s.name IS NOT NULL
    AND (
      (s.name GLOB '*FlushMessages*')
      OR (s.name GLOB '*SwapBuffers*')
      OR (s.name GLOB '*FlushBuffer*')
    )
),
active_procs_agg AS (
  SELECT json_group_array(
    json_object('ipid', ipid, 'process_name', process_name,
                'frame_count', frame_count, 'render_thread_tid', render_thread_tid)
  ) as procs_json
  FROM (
    SELECT ipid, process_name, COUNT(*) as frame_count,
      MAX(CASE WHEN tid = pid OR thread_name GLOB 'RS*Render*' OR thread_name GLOB '*.raster' OR thread_name GLOB 'CompositorGpuTh*' THEN tid ELSE NULL END) as render_thread_tid
    FROM marker_slices
    GROUP BY ipid
    HAVING frame_count > 5
    ORDER BY frame_count DESC
    LIMIT 10
  )
),
extra_rhythm AS (
  SELECT
    COALESCE((SELECT SUM(cnt) FROM slice_counts WHERE slice_name GLOB '*PlayerLoop*' OR slice_name GLOB '*FEngineLoop*' OR slice_name GLOB '*MainLoop*'), 0) as engine_main_loop_count,
    COALESCE((SELECT SUM(cnt) FROM slice_counts WHERE slice_name GLOB '*processCaptureRequest*' OR slice_name GLOB '*processCaptureResult*'), 0) as camera_capture_count,
    CASE
      WHEN COALESCE((SELECT SUM(cnt) FROM slice_counts WHERE slice_name GLOB '*PlayerLoop*' OR slice_name GLOB '*FEngineLoop*' OR slice_name GLOB '*MainLoop*'), 0) > 0 THEN 'engine_main_loop'
      WHEN COALESCE((SELECT SUM(cnt) FROM slice_counts WHERE slice_name GLOB '*processCaptureRequest*'), 0) > 0 THEN 'camera_sensor_trigger'
      ELSE 'vsync_app_only'
    END as primary_rhythm_source
){layer_cte}
SELECT
  (SELECT webview_mode FROM subvariants) as webview_mode,
  (SELECT flutter_engine FROM subvariants) as flutter_engine,
  (SELECT game_engine FROM subvariants) as game_engine,
  (SELECT hint_web FROM trace_reqs) as hint_web,
  (SELECT hint_rs FROM trace_reqs) as hint_rs,
  COALESCE((SELECT procs_json FROM active_procs_agg), '[]') as active_procs_json,
  (SELECT engine_main_loop_count FROM extra_rhythm) as engine_main_loop_count,
  (SELECT camera_capture_count FROM extra_rhythm) as camera_capture_count,
  (SELECT primary_rhythm_source FROM extra_rhythm) as primary_rhythm_source{layer_select}
"""


# ═══════════════════════════════════════════════════════════════════════════
# 结果数据类
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class ActiveRenderingProcess:
    ipid: int
    process_name: str
    frame_count: int
    render_thread_tid: Optional[int] = None


@dataclass
class TraceRequirements:
    hint_web: Optional[str] = None
    hint_rs: Optional[str] = None


@dataclass
class PipelineCandidate:
    id: str
    confidence: float


@dataclass
class Subvariants:
    webview_mode: str = "N/A"
    buffer_mode: str = "UNKNOWN"
    flutter_engine: str = "N/A"
    game_engine: str = "N/A"


@dataclass
class LayerSignals:
    app_layer_count: int = 0
    app_layer_names: str = ""
    has_surfaceview_layer: int = 0
    has_video_layer: int = 0
    has_flutter_layer: int = 0
    has_camera_layer: int = 0


@dataclass
class ExtraRhythmSignals:
    swappy_count: int = 0
    swappy_vk_count: int = 0
    achoreographer_count: int = 0
    set_frame_rate_count: int = 0
    engine_main_loop_count: int = 0
    camera_capture_count: int = 0
    mediacodec_pacing_count: int = 0
    primary_rhythm_source: str = "vsync_app_only"


@dataclass
class BufferqueuePathSignals:
    blast_bq_count: int = 0
    apply_transaction_count: int = 0
    queue_buffer_count: int = 0
    update_tex_image_count: int = 0
    lock_canvas_count: int = 0
    unlock_canvas_post_count: int = 0
    asurface_transaction_count: int = 0
    bufferqueue_path: str = "UNKNOWN"


@dataclass
class PipelineDetectionResult:
    primary_pipeline_id: str
    primary_confidence: float
    candidates_list: str
    features_list: str
    doc_path: Optional[str] = None
    subvariants: Subvariants = field(default_factory=Subvariants)
    trace_requirements: TraceRequirements = field(default_factory=TraceRequirements)
    active_rendering_processes: List[ActiveRenderingProcess] = field(default_factory=list)
    layer_signals: LayerSignals = field(default_factory=LayerSignals)
    extra_rhythm_signals: ExtraRhythmSignals = field(default_factory=ExtraRhythmSignals)
    bufferqueue_path_signals: BufferqueuePathSignals = field(default_factory=BufferqueuePathSignals)
    candidates: List[PipelineCandidate] = field(default_factory=list)
    pipeline_scores: List[Dict[str, Any]] = field(default_factory=list)
    pipeline_bundle: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pipeline_result": {
                "primary_pipeline_id": self.primary_pipeline_id,
                "primary_confidence": self.primary_confidence,
                "candidates_list": self.candidates_list,
                "features_list": self.features_list,
                "doc_path": self.doc_path,
            },
            "subvariants": {
                "webview_mode": self.subvariants.webview_mode,
                "buffer_mode": self.subvariants.buffer_mode,
                "flutter_engine": self.subvariants.flutter_engine,
                "game_engine": self.subvariants.game_engine,
            },
            "trace_requirements": {
                "hint_web": self.trace_requirements.hint_web,
                "hint_rs": self.trace_requirements.hint_rs,
            },
            "active_rendering_processes": [
                {"ipid": p.ipid, "process_name": p.process_name,
                 "frame_count": p.frame_count, "render_thread_tid": p.render_thread_tid}
                for p in self.active_rendering_processes
            ],
            "layer_signals": {
                "app_layer_count": self.layer_signals.app_layer_count,
                "app_layer_names": self.layer_signals.app_layer_names,
                "has_surfaceview_layer": self.layer_signals.has_surfaceview_layer,
                "has_video_layer": self.layer_signals.has_video_layer,
                "has_flutter_layer": self.layer_signals.has_flutter_layer,
                "has_camera_layer": self.layer_signals.has_camera_layer,
            },
            "extra_rhythm_signals": {
                "swappy_count": self.extra_rhythm_signals.swappy_count,
                "swappy_vk_count": self.extra_rhythm_signals.swappy_vk_count,
                "achoreographer_count": self.extra_rhythm_signals.achoreographer_count,
                "set_frame_rate_count": self.extra_rhythm_signals.set_frame_rate_count,
                "engine_main_loop_count": self.extra_rhythm_signals.engine_main_loop_count,
                "camera_capture_count": self.extra_rhythm_signals.camera_capture_count,
                "mediacodec_pacing_count": self.extra_rhythm_signals.mediacodec_pacing_count,
                "primary_rhythm_source": self.extra_rhythm_signals.primary_rhythm_source,
            },
            "bufferqueue_path_signals": {
                "blast_bq_count": self.bufferqueue_path_signals.blast_bq_count,
                "apply_transaction_count": self.bufferqueue_path_signals.apply_transaction_count,
                "queue_buffer_count": self.bufferqueue_path_signals.queue_buffer_count,
                "update_tex_image_count": self.bufferqueue_path_signals.update_tex_image_count,
                "lock_canvas_count": self.bufferqueue_path_signals.lock_canvas_count,
                "unlock_canvas_post_count": self.bufferqueue_path_signals.unlock_canvas_post_count,
                "asurface_transaction_count": self.bufferqueue_path_signals.asurface_transaction_count,
                "bufferqueue_path": self.bufferqueue_path_signals.bufferqueue_path,
            },
            "candidates": [{"id": c.id, "confidence": c.confidence} for c in self.candidates],
            "pipeline_scores": self.pipeline_scores,
            "pipeline_bundle": self.pipeline_bundle,
        }


# ═══════════════════════════════════════════════════════════════════════════
# 诊断函数：分析管道信号匹配（用于调试管线检测）
# ═══════════════════════════════════════════════════════════════════════════

def debug_signal_match(
    sqlite_path: str,
    pipelines_dir: str | Path = "config/pipelines",
    top_n: int = 30,
) -> Dict[str, Any]:
    """诊断信号匹配：查询实际的线程名和 callstack 名，与 pipeline 信号模式对比。

    返回:
        包含以下键的字典:
        - schema_type: "harmonyos" | "smartperfetto" | "unknown"
        - thread_names: List[{"name": str, "count": int, "ipid": int}]
        - callstack_names: List[{"name": str, "count": int}]
        - pipeline_signals: Dict[pipeline_id, List[signal_def]]
        - matched_signals: Dict[pipeline_id, List[matched_signal]]
    """
    db_path = Path(sqlite_path)
    if not db_path.exists():
        raise FileNotFoundError(f"SQLite 数据库不存在: {sqlite_path}")

    pipelines = _load_pipelines(pipelines_dir)
    conn = sqlite3.connect(sqlite_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    # 查询线程名（取 top N，按计数降序）
    thread_names: List[Dict[str, Any]] = []
    try:
        rows = _safe_query_all(cursor, f"""
            SELECT name, COUNT(*) as cnt, ipid
            FROM thread
            WHERE name IS NOT NULL AND name != ''
            GROUP BY name
            ORDER BY cnt DESC
            LIMIT {top_n}
        """)
        thread_names = [
            {"name": r[0], "count": r[1], "ipid": r[2] if len(r) > 2 else None}
            for r in rows
        ]
    except sqlite3.Error:
        pass

    # 查询 callstack 名（取 top N，按计数降序）
    callstack_names: List[Dict[str, Any]] = []
    try:
        rows = _safe_query_all(cursor, f"""
            SELECT name, COUNT(*) as cnt
            FROM callstack
            WHERE name IS NOT NULL AND name != ''
            GROUP BY name
            ORDER BY cnt DESC
            LIMIT {top_n}
        """)
        callstack_names = [
            {"name": r[0], "count": r[1]}
            for r in rows
        ]
    except sqlite3.Error:
        pass

    # 构建信号定义列表（用于对比）
    pipeline_signals: Dict[str, List[Dict[str, Any]]] = {}
    for pipeline in pipelines.values():
        detection = pipeline.detection
        if not detection:
            continue
        pid = pipeline.meta.pipeline_id
        signals: List[Dict[str, Any]] = []
        for req in (detection.required_signals or []):
            signals.append({
                "type": "required",
                "thread_pattern": getattr(req, "thread_pattern", None),
                "slice_pattern": getattr(req, "slice_pattern", None),
                "min_count": getattr(req, "min_count", 1),
            })
        for sc in (detection.scoring_signals or []):
            signals.append({
                "type": "scoring",
                "signal": getattr(sc, "signal", ""),
                "thread_pattern": getattr(sc, "thread_pattern", None),
                "slice_pattern": getattr(sc, "slice_pattern", None),
                "weight": getattr(sc, "weight", 0),
            })
        for ex in (detection.exclude_if or []):
            signals.append({
                "type": "exclude",
                "thread_pattern": getattr(ex, "thread_pattern", None),
                "slice_pattern": getattr(ex, "slice_pattern", None),
            })
        pipeline_signals[pid] = signals

    # 匹配信号：检查每个 pipeline 信号是否有对应的实际数据
    import fnmatch
    matched_signals: Dict[str, List[Dict[str, Any]]] = {}
    for pid, signals in pipeline_signals.items():
        matched: List[Dict[str, Any]] = []
        for sig in signals:
            thread_pat = sig.get("thread_pattern")
            slice_pat = sig.get("slice_pattern")
            matched_count = 0
            match_name = ""
            if thread_pat:
                for tn in thread_names:
                    if fnmatch.fnmatch(tn["name"], thread_pat):
                        matched_count = tn["count"]
                        match_name = tn["name"]
                        break
            elif slice_pat:
                for cn in callstack_names:
                    if fnmatch.fnmatch(cn["name"], slice_pat):
                        matched_count = cn["count"]
                        match_name = cn["name"]
                        break
            matched.append({
                "type": sig["type"],
                "signal": sig.get("signal", ""),
                "pattern": thread_pat or slice_pat,
                "matched_count": matched_count,
                "matched_name": match_name,
                "min_count": sig.get("min_count", 1),
                "required_ok": matched_count >= sig.get("min_count", 1),
            })
        matched_signals[pid] = matched

    return {
        "schema_type": "harmonyos",
        "thread_names": thread_names,
        "callstack_names": callstack_names,
        "pipeline_signals": pipeline_signals,
        "matched_signals": matched_signals,
    }


# ═══════════════════════════════════════════════════════════════════════════
# 安全 SQL 执行
# ═══════════════════════════════════════════════════════════════════════════

def _safe_query(cursor: sqlite3.Cursor, sql: str) -> Optional[sqlite3.Row]:
    try:
        cursor.execute(sql)
        return cursor.fetchone()
    except sqlite3.Error as e:
        logger.warning("SQL 执行失败: %s", e)
        return None


def _safe_query_all(cursor: sqlite3.Cursor, sql: str) -> List[sqlite3.Row]:
    try:
        cursor.execute(sql)
        return cursor.fetchall()
    except sqlite3.Error as e:
        logger.warning("SQL 执行失败: %s", e)
        return []


# ═══════════════════════════════════════════════════════════════════════════
# 检测引擎
# ═══════════════════════════════════════════════════════════════════════════

def _parse_candidates(candidates_list: str) -> List[PipelineCandidate]:
    if not candidates_list:
        return []
    candidates = []
    for item in candidates_list.split(","):
        item = item.strip()
        if not item or ":" not in item:
            continue
        pid, score = item.rsplit(":", 1)
        try:
            candidates.append(PipelineCandidate(id=pid.strip(), confidence=float(score.strip())))
        except ValueError:
            pass
    return candidates


def _build_pipeline_bundle(
    pipelines: Dict[str, PipelineDefinition],
    primary_pipeline_id: str,
) -> Optional[Dict[str, Any]]:
    """聚合主管线的 teaching 内容（对齐 SmartPerfetto pipeline_bundle）。"""
    pipeline = pipelines.get(primary_pipeline_id)
    if not pipeline or not pipeline.teaching:
        return None
    teaching = pipeline.teaching
    return {
        "pipeline_id": primary_pipeline_id,
        "title": teaching.title,
        "summary": teaching.summary,
        "mermaid": teaching.mermaid,
        "thread_roles": [
            {"thread": tr.thread, "role": tr.role, "description": tr.description}
            for tr in teaching.thread_roles
        ],
        "key_slices": [
            {"name": ks.name, "thread": ks.thread, "description": ks.description}
            for ks in teaching.key_slices
        ],
        # Additional meta fields
        "layer_signature": pipeline.meta.layer_signature,
        "s_article_ref": pipeline.meta.s_article_ref,
        "deviation_anchors": pipeline.meta.deviation_anchors,
        "four_features": pipeline.meta.four_features,
        "subvariants_note": pipeline.meta.subvariants_note,
        "thread_locations": pipeline.meta.thread_locations,
    }


def detect_rendering_pipeline(
    sqlite_path: str,
    package_name: Optional[str] = None,
    pipelines_dir: str | Path = "config/pipelines",
) -> PipelineDetectionResult:
    """检测渲染管线（2-query optimized flow）。

    Q1: 打分+排名 (Steps 1+2 merged, shared CTEs computed once).
    Q2: 辅助信号 (Steps 3-8 merged, scalar subqueries for fault isolation).
    Cache: LRU dict (maxsize=8), key=(sqlite_path, package_name).
    """
    # LRU cache check
    cache_key = (sqlite_path, package_name)
    if cache_key in _pipeline_cache:
        _pipeline_cache.move_to_end(cache_key)
        logger.info("管线检测缓存命中: db=%s, package=%s", sqlite_path, package_name)
        return _pipeline_cache[cache_key]

    db_path = Path(sqlite_path)
    if not db_path.exists():
        raise FileNotFoundError(f"SQLite 数据库不存在: {sqlite_path}")

    pipelines = _load_pipelines(pipelines_dir)
    pipeline_list = list(pipelines.values())

    logger.info("开始管线检测: db=%s, package=%s, pipelines=%d", sqlite_path, package_name, len(pipeline_list))
    t_total_start = time.time()

    conn = sqlite3.connect(sqlite_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    try:
        # ── Q1: 打分+排名 (Steps 1+2) ──
        t0 = time.time()
        q1_sql = _build_q1_scoring_sql(pipeline_list, package_name)
        q1_row = _safe_query(cursor, q1_sql)
        logger.info("[PERF] Q1 打分+排名: %.3fs", time.time() - t0)

        if q1_row:
            primary_id = q1_row["primary_pipeline_id"]
            primary_confidence = q1_row["primary_confidence"]
            candidates_list = q1_row["candidates_list"] or ""
            features_list = q1_row["features_list"] or ""
            doc_path = q1_row["doc_path"]
            # Parse pipeline_scores from Q1's scores_json
            try:
                pipeline_scores = json.loads(q1_row["scores_json"] or "[]")
            except (json.JSONDecodeError, TypeError):
                pipeline_scores = []
        else:
            primary_id = DEFAULT_PIPELINE_ID
            primary_confidence = 0.50
            candidates_list = ""
            features_list = ""
            doc_path = None
            pipeline_scores = []

        # ── Q2: 辅助信号 (Steps 3-8) ──
        # Python-layer check for process_measure_filter table
        include_layer_signals = False
        try:
            pmf_check = _safe_query_all(
                cursor,
                "SELECT name FROM sqlite_master WHERE type='table' AND name='process_measure_filter'"
            )
            include_layer_signals = len(pmf_check) > 0
        except sqlite3.Error:
            pass

        t0 = time.time()
        subvariants = Subvariants()
        trace_requirements = TraceRequirements()
        active_processes: List[ActiveRenderingProcess] = []
        layer_signals = LayerSignals()
        extra_rhythm = ExtraRhythmSignals()

        try:
            q2_sql = _build_q2_auxiliary_sql(package_name, include_layer_signals=include_layer_signals)
            q2_row = _safe_query(cursor, q2_sql)
            logger.info("[PERF] Q2 辅助信号: %.3fs", time.time() - t0)

            if q2_row:
                subvariants = Subvariants(
                    webview_mode=q2_row["webview_mode"] if q2_row["webview_mode"] else "N/A",
                    buffer_mode="UNKNOWN",  # Android concept removed
                    flutter_engine=q2_row["flutter_engine"] if q2_row["flutter_engine"] else "N/A",
                    game_engine=q2_row["game_engine"] if q2_row["game_engine"] else "N/A",
                )
                trace_requirements = TraceRequirements(
                    hint_web=q2_row["hint_web"] if "hint_web" in q2_row.keys() else None,
                    hint_rs=q2_row["hint_rs"] if "hint_rs" in q2_row.keys() else None,
                )
                # Parse active_procs_json
                try:
                    procs_json = q2_row["active_procs_json"] or "[]"
                    procs_list = json.loads(procs_json)
                    active_processes = [
                        ActiveRenderingProcess(
                            ipid=p["ipid"],
                            process_name=p["process_name"],
                            frame_count=p["frame_count"],
                            render_thread_tid=p.get("render_thread_tid"),
                        )
                        for p in procs_list
                    ]
                except (json.JSONDecodeError, KeyError, TypeError):
                    active_processes = []

                if include_layer_signals:
                    layer_signals = LayerSignals(
                        app_layer_count=q2_row["app_layer_count"] if "app_layer_count" in q2_row.keys() else 0,
                        app_layer_names=q2_row["app_layer_names"] if "app_layer_names" in q2_row.keys() else "",
                        has_surfaceview_layer=q2_row["has_surfaceview_layer"] if "has_surfaceview_layer" in q2_row.keys() else 0,
                        has_video_layer=q2_row["has_video_layer"] if "has_video_layer" in q2_row.keys() else 0,
                        has_flutter_layer=q2_row["has_flutter_layer"] if "has_flutter_layer" in q2_row.keys() else 0,
                        has_camera_layer=q2_row["has_camera_layer"] if "has_camera_layer" in q2_row.keys() else 0,
                    )

                extra_rhythm = ExtraRhythmSignals(
                    swappy_count=0,  # Android concept removed
                    swappy_vk_count=0,  # Android concept removed
                    achoreographer_count=0,  # Android concept removed
                    set_frame_rate_count=0,  # Android concept removed
                    engine_main_loop_count=q2_row["engine_main_loop_count"] if "engine_main_loop_count" in q2_row.keys() else 0,
                    camera_capture_count=q2_row["camera_capture_count"] if "camera_capture_count" in q2_row.keys() else 0,
                    mediacodec_pacing_count=0,  # Android concept removed
                    primary_rhythm_source=q2_row["primary_rhythm_source"] if "primary_rhythm_source" in q2_row.keys() else "vsync_app_only",
                )
        except sqlite3.Error as e:
            # Q2 failure: Q1 result still valid, fill auxiliary defaults
            logger.warning("Q2 辅助信号查询失败(降级为默认值): %s", e)

        # Step 8: BufferQueue — Android concept, always defaults
        bq_signals = BufferqueuePathSignals()

        # Assemble result + pipeline_bundle
        candidates = _parse_candidates(candidates_list)
        pipeline_bundle = _build_pipeline_bundle(pipelines, primary_id)

        result = PipelineDetectionResult(
            primary_pipeline_id=primary_id,
            primary_confidence=primary_confidence,
            candidates_list=candidates_list,
            features_list=features_list,
            doc_path=doc_path,
            subvariants=subvariants,
            trace_requirements=trace_requirements,
            active_rendering_processes=active_processes,
            layer_signals=layer_signals,
            extra_rhythm_signals=extra_rhythm,
            bufferqueue_path_signals=bq_signals,
            candidates=candidates,
            pipeline_scores=pipeline_scores,
            pipeline_bundle=pipeline_bundle,
        )

        # Store in LRU cache
        _pipeline_cache[cache_key] = result
        if len(_pipeline_cache) > 8:
            _pipeline_cache.popitem(last=False)

        logger.info("管线检测完成: primary=%s (%.2f), subvariants=%s, total=%.3fs",
                     primary_id, primary_confidence, subvariants.__dict__, time.time() - t_total_start)

        return result

    finally:
        conn.close()
