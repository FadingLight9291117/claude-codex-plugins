"""线程查询构建算子：从不同渲染框架的丢帧数据中提取线程查询信息。

设计目标：
- 从 analyze_frame_drops 返回的嵌套结构中提取线程查询信息
- 支持 rs、ui、flutter、web 等多个渲染框架
- 提取 jank_severity 大于 normal 的帧
- 提取 start_ts、end_ts、vsyncid、tid
- 如果 thread_list 内包含多个 tid，需要组装多个 thread_query

路由逻辑（confirmed interval 驱动）：
- 有 confirmed interval（渲染帧也丢帧）→ 使用 interval 中的 frames
- 无 confirmed interval → 兜底使用 all_render_jank_frames

输出格式：
{
    "thread_queries": [
        {
            "tag": "rs_vsyncId:745267",
            "start_ms": 12345.678,
            "end_ms": 12354.011,
            "tid": 33461,
            "thread_name": "rs",
            "query_reason": "rs_frame",
            "priority": 1,
            "frame_type": "rs",
            "vsync_id": "vsyncId:745267"
        },
        ...
    ]
}
"""
from __future__ import annotations

from core.observability import get_module_logger
import re
from typing import Any, Dict, List

from .base import PreprocessContext, register_operator
from utils.process_name import get_process_name

log = get_module_logger(__name__)

# 丢帧严重程度排序映射（数值越大越优先）
JANK_SEVERITY_RANK = {"normal": 0, "minor": 1, "major": 2, "severe": 3}

# ---------------------------------------------------------------------------
# 排序键函数
# ---------------------------------------------------------------------------
def _sort_key_default(f: dict) -> tuple:
    """默认排序键：frame.jank_severity DESC → duration DESC → interval_idx ASC"""
    severity = f["frame"].get("jank_severity", "normal")
    return (
        -JANK_SEVERITY_RANK.get(severity, 0),
        -(f["frame"].get("end_ts", 0) - f["frame"].get("start_ts", 0)),
        f["interval_idx"],
    )

# ---------------------------------------------------------------------------
# 算子实现
# ---------------------------------------------------------------------------
@register_operator("build_thread_queries_from_jank_intervals")
def build_thread_queries_from_jank_intervals(ctx: PreprocessContext) -> PreprocessContext:
    """从 jank_intervals 中提取线程查询信息。

    路由逻辑：
    - 有 confirmed interval（渲染帧也丢帧）→ 使用 interval 中的 frames
    - 无 confirmed interval → 兜底使用 all_render_jank_frames

    输入 ctx.data: analyze_frame_drops 返回的嵌套结构
    {
        "jank_intervals": {
            "intervals": [...],
            "rs": {"summary": {...}},
            "flutter": {"summary": {...}},
            "ui": {"summary": {...}},
            "web": {"summary": {...}}
        },
        "pipeline_type": "HARMONY_ARKUI"
    }

    输入 ctx.meta:
      - thread_query_top_n (int): thread_queries 总数截断，默认 50
      - all_render_jank_frames (list): 全量渲染丢帧帧，用于无 fence 丢帧时的兜底
      - package_name (str, optional): 包名/进程名过滤器，仅收集匹配的帧；RS帧始终收集；匹配不到时回退全量
        支持多种格式：中文名(微信)、HarmonyOS进程名(.tencent.wechat)、Android包名(com.tencent.mm)，通过 get_process_name 统一解析

    输出 ctx.data: 添加 thread_queries[]
    """
    data: Dict[str, Any] = ctx.data
    jank_intervals_data: Dict[str, Any] = data.get("jank_intervals", {})
    intervals: List[Dict[str, Any]] = jank_intervals_data.get("intervals", [])
    all_render_jank_frames: List[Dict[str, Any]] = ctx.meta.get("all_render_jank_frames", [])

    collected_frames: List[Dict[str, Any]] = []
    seen_frame_keys: set[str] = set()  # 去重 key: frame_type + vsync_id

    def _add_frame(frame, frame_type, interval_idx, source="matched"):
        key = f"{frame_type}_{frame.get('rsVsyncId') or frame.get('flutterVsyncId') or frame.get('uiVsyncId') or frame.get('webVsyncId', '')}"
        if key in seen_frame_keys:
            return
        seen_frame_keys.add(key)
        collected_frames.append({
            "frame": frame,
            "frame_type": frame_type,
            "interval_idx": interval_idx,
            "source": source,
        })

    # 路由逻辑：intervals 仅包含 confirmed_severity != normal 的 interval
    # （server.py 已过滤掉 confirmed_severity==normal 的 interval）
    has_confirmed_intervals = len(intervals) > 0

    if has_confirmed_intervals:
        # 有 confirmed interval → 使用 interval 中的 frames
        for interval in intervals:
            interval_idx = interval.get("interval_idx", 0)
            frames_dict: Dict[str, Any] = interval.get("frames", {})
            for frame_type, frame in frames_dict.items():
                _add_frame(frame, frame_type, interval_idx, source="interval_frame")
    else:
        # 无 confirmed interval → 兜底使用 all_render_jank_frames
        for rjf in all_render_jank_frames:
            _add_frame(rjf["frame"], rjf["frame_type"], -1, source="all_render_jank")

    # 包名/进程名过滤：仅收集匹配包名或进程名的对应帧，RS帧始终收集
    # 支持多种输入格式：中文名(微信)、HarmonyOS进程名(.tencent.wechat)、Android包名(com.tencent.mm)
    # 通过 get_process_name 将各种格式统一解析为中文名，再与帧的 package_name 字段匹配
    pkg_filter: str | None = ctx.meta.get("package_name")
    if pkg_filter:
        pkg_lower = pkg_filter.lower().strip()
        # 解析过滤词为中文名（如 com.tencent.mm → 微信, .tencent.wechat → 微信）
        resolved = get_process_name(pkg_filter).lower().strip()
        filter_variants = {pkg_lower}
        if resolved != pkg_lower:
            filter_variants.add(resolved)
        matched = []
        for cf in collected_frames:
            # RS帧始终收集
            if cf["frame_type"] == "rs":
                matched.append(cf)
                continue
            frame = cf["frame"]
            # 去除 HiTrace 进程名前导 \t（CHAR(9)）
            pn = (frame.get("process_name") or "").strip().lower()
            pkg = (frame.get("package_name") or "").strip().lower()
            if any(fv in pn or fv in pkg for fv in filter_variants):
                matched.append(cf)
        # 匹配不到非RS帧时回退到全量
        non_rs_matched = [cf for cf in matched if cf["frame_type"] != "rs"]
        if non_rs_matched:
            collected_frames = matched
            log.info(
                "build_thread_queries_from_jank_intervals: package_name=%s 过滤后 %d 帧 (RS=%d, 其他=%d)",
                pkg_filter, len(matched),
                sum(1 for cf in matched if cf["frame_type"] == "rs"),
                len(non_rs_matched),
            )
        else:
            log.info(
                "build_thread_queries_from_jank_intervals: package_name=%s 无匹配非RS帧，回退全量 %d 帧",
                pkg_filter, len(collected_frames),
            )

    # 排序 + top_n 截断
    top_n = ctx.meta.get("thread_query_top_n", 50)
    if not isinstance(top_n, int):
        top_n = 50

    collected_frames.sort(key=_sort_key_default)
    top_frames = collected_frames[:top_n]

    log.info(
        "build_thread_queries_from_jank_intervals: %d collected → %d frames (top %d), "
        "sources: interval_frame=%d, all_render_jank=%d",
        len(collected_frames), len(top_frames), top_n,
        sum(1 for f in collected_frames if f.get("source") == "interval_frame"),
        sum(1 for f in collected_frames if f.get("source") == "all_render_jank"),
    )

    # 提取 thread_queries（每帧所有线程，不截断）
    thread_queries: List[Dict[str, Any]] = []
    for frame_info in top_frames:
        _extract_thread_queries_from_frame(
            frame_info["frame"],
            frame_info["frame_type"],
            frame_info["interval_idx"],
            thread_queries,
        )

    data["thread_queries"] = thread_queries
    ctx.data = data
    return ctx


def _extract_thread_queries_from_frame(
    frame: Dict[str, Any],
    frame_type: str,
    interval_idx: int,
    thread_queries: List[Dict[str, Any]],
) -> None:
    """从单个帧数据中提取线程查询信息。

    按 priority ASC + dur_ms DESC 排序，保留所有线程（由 top_n 控制总量）。

    Args:
        frame: 帧数据字典，包含 start_ts、end_ts、jank_severity、thread_list 等
        frame_type: 帧类型（rs/flutter/ui/web）
        interval_idx: 区间索引
        thread_queries: 输出的线程查询列表（会被修改）
    """
    effective_severity = frame.get("jank_severity", "normal")
    if effective_severity == "normal":
        return

    # 获取时间戳（ns → ms）
    start_ts = frame.get("start_ts", 0)
    end_ts = frame.get("end_ts", 0)
    start_ms = start_ts / 1_000_000
    end_ms = end_ts / 1_000_000

    # 获取 vsync_id
    vsync_id = None
    if frame_type == "rs":
        vsync_id = frame.get("rsVsyncId")
    elif frame_type == "flutter":
        vsync_id = frame.get("flutterVsyncId")
    elif frame_type == "ui":
        vsync_id = frame.get("uiVsyncId")
    elif frame_type == "web":
        vsync_id = frame.get("webVsyncId")

    if not vsync_id:
        return

    # 获取线程列表
    thread_list: List[Dict[str, Any]] = frame.get("thread_list", [])
    if not thread_list:
        return

    # 按优先级 ASC + dur_ms DESC 排序（不截断，由 top_n 控制帧数总量）
    sorted_threads = sorted(
        thread_list,
        key=lambda t: (
            _get_thread_priority(frame_type, t.get("name", "")),
            -t.get("dur_ms", 0.0),
        ),
    )

    # 为每个线程创建一个 thread_query
    for thread_info in sorted_threads:
        tid = thread_info.get("tid")
        thread_name = thread_info.get("name", "unknown")

        if tid is None:
            continue

        tq = {
            "tag": f"{frame_type}_{vsync_id}",
            "start_ms": round(start_ms, 3),
            "end_ms": round(end_ms, 3),
            "tid": tid,
            "thread_name": thread_name,
            "query_reason": f"{frame_type}_frame",
            "priority": _get_thread_priority(frame_type, thread_name),
            "frame_type": frame_type,
            "vsync_id": vsync_id,
            "interval_idx": interval_idx,
            "jank_severity": effective_severity,
        }
        if "dur_ms" in thread_info:
            tq["thread_dur_ms"] = thread_info["dur_ms"]
        thread_queries.append(tq)

    log.info(
        "build_thread_queries_from_jank_intervals: frame_type=%s, vsync_id=%s, "
        "jank_severity=%s, thread_count=%d (all threads)",
        frame_type, vsync_id, effective_severity, len(thread_list),
    )


def _get_thread_priority(frame_type: str, thread_name: str) -> int:
    """根据帧类型和线程名返回线程优先级。

    Args:
        frame_type: 帧类型（rs/flutter/ui/web）
        thread_name: 线程名

    Returns:
        1: 主要线程（造成丢帧的线程）
        2: 相关线程（次要线程）
    """
    if frame_type == "rs":
        # RS 帧主要线程：RSUniRenderThread (渲染) 和 render_service (vsync 消费者)
        if re.search(r"RSUniRenderThre", thread_name, re.IGNORECASE):
            return 1
        return 2

    elif frame_type == "flutter":
        # Flutter 帧主要线程：raster
        if re.search(r"raster", thread_name, re.IGNORECASE):
            return 1
        if re.search(r"ui", thread_name, re.IGNORECASE):
            return 1
        return 2

    elif frame_type == "web":
        # Web 帧主要线程：CompositorGpuThread
        if re.search(r"CompositorGpuTh", thread_name, re.IGNORECASE):
            return 1
        return 2

    elif frame_type == "ui":
        # UI 帧只有一个线程，优先级为 1
        return 1

    return 2


@register_operator("build_thread_queries_from_jank_startup")
def build_thread_queries_from_jank_startup(ctx: PreprocessContext) -> PreprocessContext:
    """从 launch_process[] 拼接可见进程的 thread_queries 为扁平数组。

    输入 ctx.data: {"launch_process": [{..., "thread_queries": [...]}]}
    输出 ctx.data: 添加 "thread_queries" 扁平数组

    参数:
      max_visible_processes (int): 最多保留的可见进程数，按 total_launch_ms DESC
                                   取 Top N；超出部分标记 filtered=True。默认 3。

    注意：tag 格式 {app_name}_{tid} 已由 build_launch_thread_queries 在
    per_process_thread_queries 中直接生成，本算子只需扁平拼接，无需重标 tag。
    """
    import pandas as pd  # noqa: F811 — for pd.notna()

    data: Dict[str, Any] = ctx.data
    launch_process: List[Dict[str, Any]] = data.get("launch_process", [])
    max_visible = ctx.params.get("max_visible_processes", 3)
    pkg_filter: str | None = ctx.params.get("package_name")

    # 包名/进程名过滤：仅收集匹配的进程，匹配不到时回退全量
    # 支持：中文名(微信)、HarmonyOS进程名(.tencent.wechat)、Android包名(com.tencent.mm)
    if pkg_filter:
        pkg_lower = pkg_filter.lower().strip()
        resolved = get_process_name(pkg_filter).lower().strip()
        filter_variants = {pkg_lower}
        if resolved != pkg_lower:
            filter_variants.add(resolved)
        matched_processes = []
        for proc in launch_process:
            pn = (proc.get("process_name") or "").strip().lower()
            pkg = (proc.get("package_name") or "").strip().lower()
            if any(fv in pn or fv in pkg for fv in filter_variants):
                matched_processes.append(proc)
        if matched_processes:
            log.info(
                "build_thread_queries_from_jank_startup: package_name=%s 过滤后 %d/%d 进程",
                pkg_filter, len(matched_processes), len(launch_process),
            )
            launch_process = matched_processes
        else:
            log.info(
                "build_thread_queries_from_jank_startup: package_name=%s 无匹配进程，回退全量 %d 进程",
                pkg_filter, len(launch_process),
            )

    # Step 1: 分离可见 / 不可见进程
    visible_indices: List[int] = []  # (index in launch_process, total_launch_ms)
    invisible_count = 0
    for idx, process in enumerate(launch_process):
        if not process.get("is_user_visible", False):
            invisible_count += 1
            continue
        tlm = process.get("total_launch_ms")
        # pd.notna() per project convention: SQLite NULL → pandas NaN
        ms = tlm if pd.notna(tlm) else 0.0
        visible_indices.append((idx, ms))

    # Step 2: 按 total_launch_ms DESC 排序，去重后取 Top N
    visible_indices.sort(key=lambda x: x[1], reverse=True)

    def _dedup_key(proc):
        an = proc.get("app_name", "")
        ipid = proc.get("ipid")  # process ID (not thread ID app_main_tid)
        return an if an else f"_ipid_{ipid}"

    seen_keys = set()
    unique_visible = []
    for idx, ms in visible_indices:  # already sorted DESC
        proc = launch_process[idx]
        key = _dedup_key(proc)
        if key not in seen_keys:
            seen_keys.add(key)
            unique_visible.append((idx, ms))

    top_keys = {_dedup_key(launch_process[vi[0]]) for vi in unique_visible[:max_visible]}
    top_indices = set()
    for idx, ms in visible_indices:
        if _dedup_key(launch_process[idx]) in top_keys:
            top_indices.add(idx)

    exceeded_indices = {vi[0] for vi in visible_indices if vi[0] not in top_indices}

    # Step 3: 拼接 thread_queries + 标记 filtered
    thread_queries: List[Dict[str, Any]] = []
    included_count = 0
    exceeded_count = 0
    for idx, process in enumerate(launch_process):
        if not process.get("is_user_visible", False):
            continue
        if idx in exceeded_indices:
            exceeded_count += 1
            process["filtered"] = True
            continue
        # Top N: include thread_queries
        included_count += 1
        # Note: all fields from per_process_thread_queries (including 'phase') are
        # intentionally passed through here. Do not add field filtering without
        # updating launch_ops._extract_6field_query accordingly.
        proc_tqs = process.get("thread_queries", [])
        thread_queries.extend(proc_tqs)

    data["thread_queries"] = thread_queries

    log.info(
        "build_thread_queries_from_jank_startup: %d visible (top %d included, %d exceeded) / %d invisible → %d thread_queries",
        included_count + exceeded_count, included_count, exceeded_count,
        invisible_count, len(thread_queries),
    )
    return ctx
