# core/extensions - Database extension utilities
from .db_extender import extend_db_with_page_cache

__all__ = ["extend_db_with_page_cache"]
