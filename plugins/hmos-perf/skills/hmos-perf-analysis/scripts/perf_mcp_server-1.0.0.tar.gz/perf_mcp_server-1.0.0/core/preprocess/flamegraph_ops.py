"""火焰图四层折叠算子（pipeline 形态）。

把 ``core.flamegraph_collapse`` 中的 Layer 0～3 函数包装成可单独串接的
预处理算子，从而：

- 简单场景仍可用 ``preprocess.engine: flamegraph_collapse`` 一键跑完整四层
- 复杂场景可在 ``preprocess.pipeline`` 中按需取舍（例如关掉系统库折叠、
  调整剪枝阈值、追加自定义算子）

每个算子都遵守 ``run(ctx) -> ctx`` 协议，``ctx.data`` 在阶段之间是 DataFrame，
最后一步 ``finalize_flamegraph`` 把 DataFrame 收敛为 LLM 友好的 dict。
"""
from __future__ import annotations

from typing import Any

from .base import PreprocessContext, register_operator


# ---------------------------------------------------------------------------
# Layer 0: 同类归一化合并
# ---------------------------------------------------------------------------

@register_operator("normalize_and_collapse")
def normalize_and_collapse(ctx: PreprocessContext) -> PreprocessContext:
    """Layer 0: 函数名归一化后合并同类项，写入 instance_count / collapsed_from。"""
    from core.flamegraph_collapse import collapse_similar_functions

    df = ctx.data
    original_count = len(df)
    df = collapse_similar_functions(df)
    ctx.data = df
    ctx.meta["original_functions"] = original_count
    ctx.meta["after_collapse_similar"] = len(df)
    return ctx


# ---------------------------------------------------------------------------
# Layer 1: self_time 阈值剪枝
# ---------------------------------------------------------------------------

@register_operator("prune_by_self_time")
def prune_by_self_time(ctx: PreprocessContext) -> PreprocessContext:
    """Layer 1: 把 self_time 低于 threshold_ms 的函数剪掉，耗时上抛父节点。

    params:
        threshold_ms (number, default 5.0)
    """
    from core.flamegraph_collapse import prune_by_self_time as _prune

    threshold = float(ctx.params.get("threshold_ms", 5.0))
    df = _prune(ctx.data, threshold)
    ctx.data = df
    ctx.meta["after_prune"] = len(df)
    ctx.meta["noise_threshold_ms"] = threshold
    return ctx


# ---------------------------------------------------------------------------
# Layer 2: 系统库折叠
# ---------------------------------------------------------------------------

@register_operator("collapse_system_libs")
def collapse_system_libs(ctx: PreprocessContext) -> PreprocessContext:
    """Layer 2: 把系统库函数折叠为 ``__system__``，自身耗时上抛业务父节点。

    params:
        enabled (bool, default True): 关闭后此步成为 no-op，便于调试
    """
    from core.flamegraph_collapse import collapse_system_libs as _collapse

    if not ctx.params.get("enabled", True):
        ctx.meta["system_lib_collapsed"] = False
        return ctx
    ctx.data = _collapse(ctx.data)
    ctx.meta["system_lib_collapsed"] = True
    return ctx


# ---------------------------------------------------------------------------
# Layer 3: 热点路径 / 残留噪声 / 递归 / 瓶颈
# ---------------------------------------------------------------------------

@register_operator("extract_hot_paths")
def extract_hot_paths(ctx: PreprocessContext) -> PreprocessContext:
    """Layer 3: 抽取 Top N 热点路径并合并细碎残留噪声。

    params:
        top_n (int, default 20)
        min_path_ratio (float, default 0.05)
    """
    from core.flamegraph_collapse import (
        extract_hot_paths as _extract,
        merge_residual_noise,
    )

    top_n = int(ctx.params.get("top_n", 20))
    ratio = float(ctx.params.get("min_path_ratio", 0.05))
    paths = _extract(ctx.data, top_n)
    paths = merge_residual_noise(paths, ratio)
    ctx.meta["hot_paths"] = paths
    return ctx


@register_operator("detect_recursion")
def detect_recursion(ctx: PreprocessContext) -> PreprocessContext:
    """检测直接 / 间接递归调用循环。"""
    from core.flamegraph_collapse import detect_recursion as _detect

    ctx.meta["recursive_loops"] = _detect(ctx.data)
    return ctx


@register_operator("rank_bottleneck_functions")
def rank_bottleneck_functions(ctx: PreprocessContext) -> PreprocessContext:
    """按 self_time_ms 取 Top N 瓶颈函数。"""
    top_n = int(ctx.params.get("top_n", 20))
    df = ctx.data
    bottleneck_df = df.nlargest(top_n, "self_time_ms")

    cols = [
        "func_name", "self_time_ms", "total_time_ms",
        "call_count", "parent_name", "collapsed_from",
    ]
    items = []
    for _, row in bottleneck_df.iterrows():
        item: dict[str, Any] = {}
        for col in cols:
            key = "name" if col == "func_name" else (
                "parent" if col == "parent_name" else col
            )
            item[key] = row.get(col)
        items.append(item)
    ctx.meta["bottleneck_functions"] = items
    return ctx


@register_operator("finalize_flamegraph")
def finalize_flamegraph(ctx: PreprocessContext) -> PreprocessContext:
    """收敛 DataFrame → dict，输出 LLM 友好的最终结构。

    要求前置算子已经把 hot_paths / recursive_loops / bottleneck_functions
    写入 ctx.meta；此算子负责把它们从 meta 提到 data 下，便于 query_metrics
    返回值结构对齐。
    """
    summary = {
        "meta": {
            "type": "flamegraph_summary",
            "original_functions": ctx.meta.get("original_functions"),
            "after_collapse_similar": ctx.meta.get("after_collapse_similar"),
            "after_prune": ctx.meta.get("after_prune"),
            "noise_threshold_ms": ctx.meta.get("noise_threshold_ms"),
            "system_lib_collapsed": ctx.meta.get("system_lib_collapsed", False),
        },
        "hot_paths": ctx.meta.get("hot_paths", []),
        "recursive_loops": ctx.meta.get("recursive_loops", []),
        "bottleneck_functions": ctx.meta.get("bottleneck_functions", []),
    }
    ctx.data = summary
    return ctx
