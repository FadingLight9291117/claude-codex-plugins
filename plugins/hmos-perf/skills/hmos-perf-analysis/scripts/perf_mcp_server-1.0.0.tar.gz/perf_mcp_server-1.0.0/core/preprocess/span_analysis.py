"""并行化机会点区间识别 helper 模块。

提供:
- analyze_parallelism_opportunity_intervals: 主入口(注册到 _TOOL_CALLABLE,不暴露 MCP tool)
- find_startup_candidates / find_startup_window / query_spans: 启动推导 + span 拆解
- render_index_text: 总览表 markdown 渲染
- decode_span_name: H:Et 型 span 名解码

定位:
- 不注册为算子(无 @register_operator)
- 不暴露为 MCP tool(无 @mcp.tool() 装饰器)
- 通过 register_executor_tools 注册到 _TOOL_CALLABLE,仅 skill YAML 的 step 可调用
"""
from __future__ import annotations

import json
import re
import sqlite3


def decode_span_name(name: str) -> dict:
    """解码 H:Et 型 span 名,提取 sender_tid/task_name 等结构化字段。
    失败或非 H:Et 返回 {}(LLM 用 span_name 原样判断)。

    格式: H:Et:<Sender tid>,<Send time>,<Expect handle time>,<Task name>,<Prio>,[<Sender 源码位置>]|I40
    例:   H:Et:46609,1234.567,1240.0,InitModule,2,[src/main/ets/startup/Task.ts:29:1]|I40
    """
    if not name.startswith("H:Et:"):
        return {}
    body = name[5:]  # 去掉 "H:Et:"
    # 去 |I40 后缀
    if "|" in body:
        body = body.rsplit("|", 1)[0]
    parts = body.split(",")
    if len(parts) < 5:
        return {}
    return {
        "type": "h_et",
        "sender_tid": int(parts[0]) if parts[0].isdigit() else None,
        "send_time": float(parts[1]) if _is_float(parts[1]) else None,
        "expect_handle_time": float(parts[2]) if _is_float(parts[2]) else None,
        "task_name": parts[3] or None,
        "prio": int(parts[4]) if parts[4].isdigit() else None,
        "sender_source": parts[5].strip("[]") if len(parts) > 5 else None,
    }


def _is_float(s: str) -> bool:
    """判断字符串是否能转为 float"""
    try:
        float(s)
        return True
    except (ValueError, TypeError):
        return False


# ---------------------------------------------------------------------------
# 启动窗口推导常量
# ---------------------------------------------------------------------------

STARTUP_THREAD_MARKER = "H:void OHOS::AppExecFwk::MainThread::HandleLaunchAbility"
FIRSTFRAME_MARKER_PREFIX = "H:RSJankStats::ReportEventFirstFrame app pid "


# ---------------------------------------------------------------------------
# 启动推导 + span 拆解 helper(来自 ZIP 包 span_analysis.py + cli/hiperf_cli.py)
# ---------------------------------------------------------------------------


def find_startup_candidates(conn: sqlite3.Connection) -> list[dict]:
    """找含 HandleLaunchAbility 标记的线程(启动线程候选),按标记首现 ts 升序。"""
    rows = conn.execute(
        "SELECT t.tid, t.name, MIN(c.ts) / 1e6"
        " FROM callstack c JOIN thread t ON c.callid = t.itid"
        " WHERE c.name LIKE ? GROUP BY t.tid ORDER BY 3",
        (STARTUP_THREAD_MARKER + "%",),
    ).fetchall()
    return [{"tid": int(r[0]), "process_name": str(r[1]),
             "first_marker_ts_ms": float(r[2])} for r in rows]


def find_target_tid_from_firstframe(conn: sqlite3.Connection) -> int | None:
    """全局搜 ReportEventFirstFrame app pid <pid>,返回首个命中的 pid 作为目标 tid。

    解析逻辑: name = 'H:RSJankStats::ReportEventFirstFrame app pid <pid>|M0538'
    全局只有一条(用户启动的应用首帧),直接取 <pid> 作为目标 tid。
    解析失败(非数字、name 异常)返回 None,调用方降级到候选逻辑。
    """
    row = conn.execute(
        "SELECT name FROM callstack"
        " WHERE name LIKE ? ORDER BY ts",
        (FIRSTFRAME_MARKER_PREFIX + "%",),
    ).fetchone()
    if not row:
        return None
    name = str(row[0])
    pid_str = name[len(FIRSTFRAME_MARKER_PREFIX):].split("|")[0].strip()
    return int(pid_str) if pid_str.isdigit() else None


def find_startup_window(conn: sqlite3.Connection,
                        tid: int) -> tuple[float | None, float | None, str | None]:
    """推导启动窗口: (begin_ms, end_ms, process_name),查不到为 None。

    begin = 该线程首个 depth=0 真 Trace(cookie IS NULL)的 ts。
    end   = 全局搜 'ReportEventFirstFrame app pid <tid>' 且 ts > begin 的最早一条;
            pid 边界精确(= 精确串 或 LIKE 'prefix<tid>|%'),防止 1208 误匹配 12085。
    """
    row = conn.execute(
        "SELECT MIN(c.ts) / 1e6 FROM callstack c"
        " JOIN thread t ON c.callid = t.itid"
        " WHERE t.tid = ? AND c.depth = 0 AND c.cookie IS NULL",
        (tid,),
    ).fetchone()
    begin_ms = row[0] if row else None

    row = conn.execute("SELECT name FROM thread WHERE tid = ?", (tid,)).fetchone()
    process_name = str(row[0]) if row else None

    end_ms = None
    if begin_ms is not None:
        exact = FIRSTFRAME_MARKER_PREFIX + str(tid)
        row = conn.execute(
            "SELECT MIN(ts) / 1e6 FROM callstack"
            " WHERE (name = ? OR name LIKE ?) AND ts > ?",
            (exact, exact + "|%", begin_ms * 1e6),
        ).fetchone()
        end_ms = row[0] if row else None

    return begin_ms, end_ms, process_name


def query_spans(conn: sqlite3.Connection, tid: int, begin_ms: float, end_ms: float,
                min_dur_ms: float) -> tuple[list[dict], dict]:
    """查询 depth=0 顶层 span(按 dur 降序)及阈值隐藏聚合。

    筛选: callid=thread.itid, depth=0, cookie IS NULL(真 Trace,排除异步
    event —— 异步 event 在 depth=0 会时间重叠,真 Trace 不会),时间窗交集
    (ts+dur>begin AND ts<end),dur>=min_dur。
    totals 中 all/shown/hidden 的 hidden 指被 dur 阈值隐藏的部分。
    """
    base = """
      FROM callstack c JOIN thread t ON c.callid = t.itid
      WHERE t.tid = :tid AND c.depth = 0 AND c.cookie IS NULL
        AND c.ts + c.dur > :begin_ns AND c.ts < :end_ns
    """
    params = {"tid": tid, "begin_ns": begin_ms * 1e6, "end_ns": end_ms * 1e6}

    row = conn.execute(
        f"SELECT COUNT(*), COALESCE(SUM(c.dur), 0) {base}", params
    ).fetchone()
    count_all, dur_all_ns = int(row[0]), float(row[1])

    shown = conn.execute(
        f"SELECT c.id, c.name, c.ts / 1e6, c.dur / 1e6 {base} AND c.dur >= :min_dur_ns"
        " ORDER BY c.dur DESC",
        {**params, "min_dur_ns": min_dur_ms * 1e6},
    ).fetchall()
    spans = [{"id": int(r[0]), "name": str(r[1]), "ts_ms": float(r[2]), "dur_ms": float(r[3])}
             for r in shown]

    dur_shown = sum(s["dur_ms"] for s in spans)
    dur_all_ms = dur_all_ns / 1e6
    totals = {
        "count_all": count_all,
        "dur_all_ms": dur_all_ms,
        "count_shown": len(spans),
        "dur_shown_ms": dur_shown,
        "count_hidden": count_all - len(spans),
        "dur_hidden_ms": dur_all_ms - dur_shown,
    }
    return spans, totals


def render_index_text(spans: list[dict], totals: dict, startup_window: dict) -> str:
    """生成 markdown 总览表(窗口/dur/样本/密度),供 LLM 直接读"""
    sw = startup_window
    lines = [
        "# 启动 span 总览",
        "",
        f"- 启动进程: {sw.get('process_name')} (tid={sw.get('tid')})",
        f"- 启动窗口: [{sw.get('begin_ms'):.3f}, {sw.get('end_ms'):.3f}] ms"
        f" (时长 {sw.get('end_ms', 0) - sw.get('begin_ms', 0):.2f}ms)",
        f"- span 总数: {totals.get('count_all')} (shown {totals.get('count_shown')},"
        f" hidden {totals.get('count_hidden')})",
        f"- dur 总和: {totals.get('dur_all_ms'):.2f} ms"
        f" (shown {totals.get('dur_shown_ms'):.2f} ms, hidden {totals.get('dur_hidden_ms'):.2f} ms)",
        "",
        "## span 列表(dur 降序)",
        "| # | name | ts_ms | dur_ms |",
        "|---|---|---|---|",
    ]
    for i, s in enumerate(spans, 1):
        # name 截断到 60 字符避免表格过宽
        name_short = s["name"][:60] + "..." if len(s["name"]) > 60 else s["name"]
        lines.append(f"| {i} | {name_short} | {s['ts_ms']:.3f} | {s['dur_ms']:.3f} |")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Task 8: 主入口 + helper
# ---------------------------------------------------------------------------


def _safe_tag(span_id: int, span_name: str) -> str:
    """生成文件名安全的 tag: parallelism_span_<id>_<转义名前缀>"""
    safe = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', span_name)[:40]
    return f"parallelism_span_{span_id}_{safe}"


def _dur_to_priority(dur_ms: float, all_spans: list) -> int:
    """dur 越大优先级越高(1 最大),按 dur 降序排名"""
    sorted_durs = sorted([s["dur_ms"] for s in all_spans], reverse=True)
    return sorted_durs.index(dur_ms) + 1


def analyze_parallelism_opportunity_intervals(
    sqlite_path: str,
    tid: int | None = None,
    min_dur_ms: float = 5.0,
) -> str:
    """并行化机会点区间识别。

    自动推导启动线程(HandleLaunchAbility 标记)与启动窗口(首个真Trace → ReportEventFirstFrame),
    返回 callstack depth=0 顶层 span 列表(dur≥min_dur_ms),作为并行化机会点候选区间。

    tid 识别优先级链:
    1. 用户传 tid → 直接用,不校验
    2. FirstFrame marker → 全局搜 ReportEventFirstFrame app pid,取 pid 为 tid
    3. 单候选 → 取唯一候选
    4. 多候选 → 选 first_marker_ts 最早的 + warning

    返回 JSON 字符串(供 SkillExecutor 解析):
    - 正常: {sqlite_path, startup_window, thread_queries[], totals, index_text, warnings[]}
      thread_queries 每项: {tag, start_ms, end_ms, tid, thread_name, query_reason, priority,
                            span_id, span_name, dur_ms, decoded}
      warnings 非空时表示目标进程识别走了降级路径
    - 错误: {sqlite_path, error}
    """
    conn = sqlite3.connect(sqlite_path)
    try:
        warnings: list[str] = []

        # 优先级 1: 用户传 tid 直接用(不校验,尊重用户意图)
        if tid is None:
            candidates = find_startup_candidates(conn)
            if not candidates:
                return json.dumps({"sqlite_path": sqlite_path, "error": "未找到启动线程(HandleLaunchAbility 标记)"})

            # 优先级 2: FirstFrame marker
            target_tid = find_target_tid_from_firstframe(conn)
            if target_tid is not None:
                tid = target_tid
                # 边缘 case: FirstFrame pid 不在候选中 → 信任 marker + warning
                candidate_tids = {c["tid"] for c in candidates}
                if tid not in candidate_tids:
                    warnings.append(
                        f"FirstFrame pid={tid} 未命中 HandleLaunchAbility 候选"
                        f"({sorted(candidate_tids)}),信任 marker"
                    )
            # 优先级 3: 单候选
            elif len(candidates) == 1:
                tid = candidates[0]["tid"]
            # 优先级 4: 多候选 + 无 FirstFrame → 选最早候选 + warning
            else:
                tid = candidates[0]["tid"]  # candidates 已按 first_marker_ts 升序
                warnings.append(
                    f"未找到 FirstFrame marker,自动选最早候选 tid={tid}"
                    f" ({candidates[0]['process_name']})"
                )
        # 用户传 tid 时不校验(不再返回 candidates + error)

        begin_ms, end_ms, process_name = find_startup_window(conn, tid)
        if begin_ms is None:
            return json.dumps({"sqlite_path": sqlite_path, "error": f"tid={tid} 无 depth=0 真 Trace"})
        if end_ms is None:
            return json.dumps({"sqlite_path": sqlite_path, "error": f"未找到 ReportEventFirstFrame app pid {tid}"})
        if end_ms <= begin_ms:
            return json.dumps({"sqlite_path": sqlite_path, "error": f"启动窗口异常: end({end_ms:.3f}) <= begin({begin_ms:.3f})"})

        spans, totals = query_spans(conn, tid, begin_ms, end_ms, min_dur_ms)
        # 关键: 把 spans 转成 thread_queries 格式,复用框架 per-frame 文件生成机制
        thread_queries = [
            {
                "tag": _safe_tag(span["id"], span["name"]),
                "start_ms": span["ts_ms"],
                "end_ms": span["ts_ms"] + span["dur_ms"],
                "tid": tid,
                "thread_name": process_name,
                "query_reason": "parallelism_span",
                "priority": _dur_to_priority(span["dur_ms"], spans),
                "span_id": span["id"],
                "span_name": span["name"],
                "dur_ms": span["dur_ms"],
                "decoded": decode_span_name(span["name"]),
            }
            for span in spans
        ]
        index_text = render_index_text(
            spans, totals,
            {"begin_ms": begin_ms, "end_ms": end_ms, "process_name": process_name, "tid": tid}
        )

        return json.dumps({
            "sqlite_path": sqlite_path,
            "startup_window": {
                "begin_ms": begin_ms, "end_ms": end_ms,
                "duration_ms": end_ms - begin_ms,
                "process_name": process_name, "tid": tid,
            },
            "thread_queries": thread_queries,
            "totals": totals,
            "index_text": index_text,
            "warnings": warnings,
        })
    finally:
        conn.close()
