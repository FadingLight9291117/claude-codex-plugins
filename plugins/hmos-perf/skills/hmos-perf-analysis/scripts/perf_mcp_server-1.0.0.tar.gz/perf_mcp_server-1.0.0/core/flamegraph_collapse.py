"""火焰图 / 堆栈指标的同类归一化合并 + 四层折叠引擎（v2.2）。

四层折叠流程:
- Layer 0: 同类函数归一化合并（normalize + collapse_similar_functions）
- Layer 1: Self-time 阈值剪枝（prune_by_self_time）
- Layer 2: 系统库折叠（collapse_system_libs）
- Layer 3: 调用链去重 + Top N（extract_hot_paths）

关键原则: Layer 0 必须先于 Layer 1 执行，否则同类细碎函数（如
allocate-1932/5392/8821）会被错误剪枝，导致瓶颈被掩盖。

由 QueryEngine 在指标声明 `preprocess.engine: flamegraph_collapse` 时调用。
"""
from __future__ import annotations

import re
from typing import Any


# ---------------------------------------------------------------------------
# Layer 0: 函数名归一化
# ---------------------------------------------------------------------------

# 函数名归一化规则（按优先级顺序匹配，命中即返回）
NORMALIZATION_RULES: list[tuple[str, str]] = [
    # P0: 去掉函数参数列表（第一个 ( 及其后的内容）
    (r"(.+?)\(.+$", r"\1"),                # FlushVsync(unsigned long) → FlushVsync

    # 去掉末尾数字后缀（线程ID、对象地址、编译器内联编号）
    (r"(.+)-\d+$", r"\1"),                # allocate-1932 → allocate
    (r"(.+)_\d+$", r"\1"),                # allocate_1932 → allocate
    (r"(.+)#\d+$", r"\1"),                # allocate#1932 → allocate

    # 去掉内存地址后缀
    (r"(.+)@0x[0-9a-fA-F]+$", r"\1"),     # allocate@0x7ffe → allocate

    # 去掉匿名/lambda 的随机后缀
    (r"(.+)\.lambda_\d+", r"\1"),         # foo.lambda_123 → foo.lambda
    (r"(.+)\.<anonymous>", r"\1"),        # foo.<anonymous> → foo

    # 去掉行号后缀（某些工具会附加）
    (r"(.+):\d+$", r"\1"),                # foo.cpp:123 → foo.cpp

    # 模板实例化去参数（C++ std::vector<T> → std::vector）
    (r"(std::\w+)<[^>]+>", r"\1"),

    # Java/Kotlin 匿名类去编号
    (r"(.+)\$\d+$", r"\1"),               # MainActivity$1 → MainActivity

    # 协程/异步任务去编号
    (r"(.+)\$suspendImpl\d+", r"\1"),     # foo$suspendImpl123 → foo
]


def normalize_func_name(name: str) -> str:
    """把带后缀的函数名归一化为基类名（命中即返回）。"""
    if not name or name == "root":
        return name
    for pattern, replacement in NORMALIZATION_RULES:
        new_name = re.sub(pattern, replacement, name)
        if new_name != name:
            return new_name
    return name


def collapse_similar_functions(df: Any) -> Any:
    """归一化函数名后，按 (normalized_name, parent_name, depth) 分组合并。

    保留 instance_count 与 collapsed_from（合并明细），
    供 LLM 推理时识别 "这是 N 个细碎实例的聚合"。
    """

    df = df.copy()
    df["normalized_name"] = df["func_name"].apply(normalize_func_name)
    df["normalized_parent"] = df["parent_name"].apply(
        lambda x: normalize_func_name(x) if x else None
    )

    grouped = df.groupby(
        ["normalized_name", "normalized_parent", "depth"], dropna=False
    ).agg({
        "self_time_ms": "sum",
        "total_time_ms": "sum",
        "call_count": "sum",
        "func_name": lambda x: list(x.unique()),
    }).reset_index()

    instance_counts = (
        df.groupby(
            ["normalized_name", "normalized_parent", "depth"], dropna=False
        ).size().reset_index(name="instance_count")
    )
    grouped = grouped.merge(
        instance_counts,
        on=["normalized_name", "normalized_parent", "depth"],
    )

    # 把归一化后的名字写回到标准列
    grouped = grouped.rename(columns={
        "func_name": "original_names",
        "normalized_name": "func_name",
        "normalized_parent": "parent_name",
    })

    def build_collapse_note(row: dict) -> str | None:
        if row["instance_count"] > 1:
            names = row.get("original_names") or []
            head = ", ".join(names[:5])
            if len(names) > 5:
                head += f" 等共 {len(names)} 个"
            return f"合并了 {row['instance_count']} 个实例: {head}"
        return None

    grouped["collapsed_from"] = grouped.apply(build_collapse_note, axis=1)
    return grouped


# ---------------------------------------------------------------------------
# Layer 1: 阈值剪枝
# ---------------------------------------------------------------------------

def prune_by_self_time(df: Any, threshold_ms: float = 5.0) -> Any:
    """self_time < threshold 的函数视为噪声，把耗时合并给父函数后剪枝。"""
    df = df.copy()
    df["pruned"] = df["self_time_ms"] < threshold_ms

    for _, row in df[df["pruned"]].iterrows():
        parent_mask = df["func_name"] == row["parent_name"]
        if parent_mask.any():
            df.loc[parent_mask, "self_time_ms"] += row["self_time_ms"]

    return df[~df["pruned"]].drop(columns=["pruned"])


# ---------------------------------------------------------------------------
# Layer 2: 系统库折叠
# ---------------------------------------------------------------------------

# 系统库识别正则（命中后函数名替换为 __system__）
SYSTEM_PATTERNS: list[str] = [
    r"libc\.",
    r"libbinder",
    r"android\.os\.",
    r"android\.view\.",
    r"skia::",
    r"gfx::",
    r"jni::",
    r"Java_android",
    r"__kernel",
    # Todo: 扩展到 OpenGL/Vulkan、Skia、HAL 层
]


def collapse_system_libs(df: Any) -> Any:
    """把系统库函数替换为 __system__，自身耗时上抛给最近的非系统父节点。"""
    df = df.copy()

    def is_system(name: str | None) -> bool:
        if not name:
            return False
        return any(re.search(p, name) for p in SYSTEM_PATTERNS)

    df["is_system"] = df["func_name"].apply(is_system)

    # 系统函数 self_time 上抛给最近的非系统祖先
    for _, row in df[df["is_system"]].iterrows():
        ancestor = row["parent_name"]
        visited: set[str] = set()
        while ancestor and ancestor not in visited:
            visited.add(ancestor)
            mask = df["func_name"] == ancestor
            if not mask.any():
                break
            if not df.loc[mask, "is_system"].values[0]:
                df.loc[mask, "self_time_ms"] += row["self_time_ms"]
                break
            ancestor = df.loc[mask, "parent_name"].values[0]

    df.loc[df["is_system"], "func_name"] = "__system__"
    df.loc[df["is_system"], "parent_name"] = None
    return df.drop(columns=["is_system"])


# ---------------------------------------------------------------------------
# Layer 3: 路径提取与去重
# ---------------------------------------------------------------------------

def extract_hot_paths(df: Any, top_n: int = 20) -> list[dict]:
    """从调用树中提取 Top N 耗时路径。

    每条路径含: path 字符串、total/self_time、call_count、leaf_function、深度、节点列表。
    """
    paths: list[dict] = []
    candidates = df.nlargest(top_n * 3, "total_time_ms")

    for _, row in candidates.iterrows():
        path_nodes = trace_path_to_root(df, row["func_name"])
        paths.append({
            "path": " → ".join(n["func_name"] for n in path_nodes),
            "total_time_ms": row["total_time_ms"],
            "self_time_ms": row["self_time_ms"],
            "call_count": row["call_count"],
            "leaf_function": row["func_name"],
            "depth": len(path_nodes),
            "nodes": path_nodes,
        })

    seen: set[str] = set()
    unique: list[dict] = []
    for p in sorted(paths, key=lambda x: x["total_time_ms"], reverse=True):
        if p["path"] in seen:
            continue
        seen.add(p["path"])
        unique.append(p)
        if len(unique) >= top_n:
            break
    return unique


def trace_path_to_root(df: Any, func_name: str) -> list[dict]:
    """从函数名回溯到根节点，重建调用链。"""
    path: list[dict] = []
    current = func_name
    visited: set[str] = set()

    while current and current not in visited:
        visited.add(current)
        mask = df["func_name"] == current
        if not mask.any():
            break

        row = df.loc[mask].iloc[0]
        path.insert(0, {
            "func_name": row["func_name"],
            "self_time_ms": row["self_time_ms"],
            "total_time_ms": row["total_time_ms"],
            "collapsed_from": row.get("collapsed_from"),
        })
        current = row["parent_name"]

    return path


def merge_residual_noise(paths: list[dict], min_path_ratio: float = 0.05) -> list[dict]:
    """路径中占总耗时 < min_path_ratio 的节点合并为 __other_small_funcs__。"""
    for path in paths:
        total = path["total_time_ms"] or 0
        filtered: list[dict] = []
        other_time = 0.0
        other_count = 0

        for node in path["nodes"]:
            ratio = (node["self_time_ms"] / total) if total > 0 else 0
            if ratio >= min_path_ratio:
                filtered.append(node)
            else:
                other_time += node["self_time_ms"]
                other_count += 1

        if other_time > 0:
            ratio_str = f"{(other_time / total * 100):.1f}%" if total > 0 else "0%"
            filtered.append({
                "func_name": "__other_small_funcs__",
                "self_time_ms": other_time,
                "note": f"合并了 {other_count} 个占总耗时 {ratio_str} 的细碎函数",
            })
        path["nodes"] = filtered

    return paths


# ---------------------------------------------------------------------------
# 递归检测
# ---------------------------------------------------------------------------

def detect_recursion(df: Any) -> list[dict]:
    """检测直接 / 间接递归调用循环。"""
    loops: list[dict] = []

    # 直接递归: func_name == parent_name
    direct = df[df["func_name"] == df["parent_name"]]
    for _, row in direct.iterrows():
        loops.append({
            "cycle": f"{row['func_name']} → {row['func_name']}",
            "depth": row["depth"],
            "total_time_ms": row["total_time_ms"],
            "type": "direct",
        })

    # 间接递归（三元环 A→B→C→A 的简化检测）
    for _, row in df.iterrows():
        parent = row["parent_name"]
        if not parent:
            continue
        gp_mask = df["func_name"] == parent
        if not gp_mask.any():
            continue
        grandparent = df.loc[gp_mask].iloc[0]["parent_name"]
        if grandparent and grandparent == row["func_name"]:
            loops.append({
                "cycle": f"{row['func_name']} → {parent} → {row['func_name']}",
                "depth": row["depth"],
                "total_time_ms": row["total_time_ms"],
                "type": "indirect",
            })

    # 去重
    seen: set[str] = set()
    unique: list[dict] = []
    for loop in loops:
        if loop["cycle"] in seen:
            continue
        seen.add(loop["cycle"])
        unique.append(loop)

    return unique


# ---------------------------------------------------------------------------
# 主入口（四层折叠）
# ---------------------------------------------------------------------------

def flamegraph_collapse(
    df: Any,
    *,
    noise_threshold_ms: float = 5.0,
    system_collapse: bool = True,
    top_n_paths: int = 20,
    min_path_ratio: float = 0.05,
) -> dict:
    """四层折叠主入口，把细碎函数聚合成 LLM 友好的大块结果。

    Returns: {
      "meta": {original_functions, after_collapse_similar, after_prune, ...},
      "hot_paths": [...],
      "recursive_loops": [...],
      "bottleneck_functions": [...],
    }
    """
    original_count = len(df)

    # Layer 0: 同类归一化合并
    df = collapse_similar_functions(df)
    after_collapse = len(df)

    # Layer 1: self_time 阈值剪枝
    df = prune_by_self_time(df, noise_threshold_ms)
    after_prune = len(df)

    # Layer 2: 系统库折叠
    if system_collapse:
        df = collapse_system_libs(df)

    # Layer 3: 热点路径提取 + 残留噪声合并
    hot_paths = extract_hot_paths(df, top_n_paths)
    hot_paths = merge_residual_noise(hot_paths, min_path_ratio)

    # 递归检测
    recursive_loops = detect_recursion(df)

    # 瓶颈函数 Top N（按 self_time 排序）
    bottleneck_cols = [
        "func_name", "self_time_ms", "total_time_ms",
        "call_count", "parent_name", "collapsed_from",
    ]
    bottleneck_df = df.nlargest(top_n_paths, "self_time_ms")
    bottlenecks = [
        {col if col != "func_name" else "name": row[col] for col in bottleneck_cols}
        for _, row in bottleneck_df.iterrows()
    ]

    return {
        "meta": {
            "type": "flamegraph_summary",
            "original_functions": original_count,
            "after_collapse_similar": after_collapse,
            "after_prune": after_prune,
            "noise_threshold_ms": noise_threshold_ms,
            "system_lib_collapsed": system_collapse,
        },
        "hot_paths": hot_paths,
        "recursive_loops": recursive_loops,
        "bottleneck_functions": bottlenecks,
    }
