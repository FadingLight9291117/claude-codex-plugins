"""Web 帧检测预处理算子。

用于 HarmonyOS Web 渲染管线的帧重建：
- 收集 "RealSwapBuffers" 函数
- 通过父函数查找 trace_id 作为 webVsyncId
- 收集中间函数：H:LatencyInfo.Flow、H:Graphics.Pipeline、H:Scheduler::RunNextTask、
  H:ProxyImpl::ReadyToCommit、H:RasterTask
- 组合函数成 web 帧
- 线程去重
- 使用 "H:SendVsyncTo conn: NWeb" 作为第一个帧的开始时间
"""

import re
from typing import Any, Dict, List, Optional, Set
from core.observability import get_module_logger

from core.preprocess.base import (
    PreprocessContext,
    register_operator,
)
from .frame_rate_ops import _compute_jank_severity, _get_frame_rate_records, _match_frame_rate
from .frame_ops import load_tid_process_map
from utils.process_name import get_process_name

log = get_module_logger(__name__)


def _extract_trace_id(name: str) -> Optional[str]:
    """从函数名中提取 trace_id。

    例如：
    - "H:Graphics.Pipeline | trace_id=196834 | step=FinishBufferSwap|M62" -> "196834"
    - "H:Graphics.Pipeline | trace_id=12345 | step=IssueBeginFrame|M62" -> "12345"
    - "H:Graphics.Pipeline | trace_id=-3674058713908622061 | step=FinishBufferSwap|M62" -> "-3674058713908622061"

    Args:
        name: callstack.name 字段

    Returns:
        trace_id 字符串，未找到返回 None
    """
    match = re.search(r"trace_id=(-?\d+)", name)
    return match.group(1) if match else None


def _find_trace_id_recursive(
    event_id: int,
    callstack_by_id: Dict[int, Dict[str, Any]],
    depth: int = 0,
    max_depth: int = 20,
) -> Optional[str]:
    """递归查询 parent_id 链，查找包含 trace_id 的函数名。

    使用预加载的 callstack_by_id 字典进行内存查找，避免逐条递归 SQL 查询。

    终止条件：
    - 找到包含 trace_id=xxx 的函数名（如 H:Graphics.Pipeline | trace_id=196834）
    - depth >= max_depth（防止无限递归）
    - event_id 为 None 或 0
    - callstack_by_id 中查无此行

    Args:
        event_id: callstack.id
        callstack_by_id: 预加载的 {id: {name, parent_id}} 字典
        depth: 当前递归深度
        max_depth: 最大递归深度

    Returns:
        trace_id 字符串，未找到返回 None
    """
    if depth >= max_depth or not event_id:
        return None

    entry = callstack_by_id.get(event_id)
    if not entry:
        return None

    name = entry["name"]
    parent_id = entry["parent_id"]

    # 检查当前函数名是否包含 trace_id
    trace_id = _extract_trace_id(name)
    if trace_id:
        return trace_id

    # 递归查找父函数
    return _find_trace_id_recursive(parent_id, callstack_by_id, depth + 1, max_depth)


@register_operator("build_web_frames")
def build_web_frames(ctx: PreprocessContext) -> PreprocessContext:
    """构建 Web 帧数据。

    实现：
    1. 收集 "RealSwapBuffers" 函数
    2. 通过父函数查找 trace_id 作为 webVsyncId
    3. 使用 "H:SendVsyncTo conn: NWeb" 作为第一个帧的开始时间
       （时间最接近第一个 RealSwapBuffers，同时小于第一个 RealSwapBuffers）
    4. 收集中间函数：H:LatencyInfo.Flow、H:Graphics.Pipeline、H:Scheduler::RunNextTask、
       H:ProxyImpl::ReadyToCommit、H:RasterTask
    5. 组合函数成 web 帧
    6. 线程去重
    7. 基于 frame_rate 计算 jank severity

    输出 ctx.data:
    {
        "web_frames": [{
            "start_ts": 51572462086670,
            "end_ts": 51572470420003,
            "dur_ms": 8.353,
            "webVsyncId": "12345",
            "jank_severity": "minor",
            "thread_list": [{"tid": 33461, "name": "1.ui"}],
            "frame_rate": 60
        }],
        "summary": {
            "total_frames": 50,
            "jank_count": 10,
            "minor_count": 5,
            "major_count": 3,
            "severe_count": 2
        }
    }
    """
    try:
        conn = ctx.sqlite_conn
        params = ctx.params

        default_frame_rate = int(params.get("frame_rate", 60))
        # 优先从 ctx.meta 读取帧率记录（由上游算子注入）
        frame_rate_records: Optional[List[Dict[str, Any]]] = ctx.meta.get("frame_rate_records")
        # 如果为空，调用公共函数查询
        if not frame_rate_records:
            frame_rate_records = _get_frame_rate_records(conn)

        # 预加载 tid → process_name 映射（用于帧的 process_name/package_name 字段）
        tid_process_map = load_tid_process_map(conn)

        # -------------------- 1. 查询 RealSwapBuffers 事件 --------------------
        # callstack 表没有 tid 列，通过 LEFT JOIN thread (callid=itid) 获取 tid
        cur_swap = conn.execute("""
            SELECT c.id, c.ts, c.dur, c.name, c.parent_id, t.tid
            FROM callstack c
            LEFT JOIN thread t ON t.itid = c.callid
            WHERE c.name LIKE '%RealSwapBuffers%'
            ORDER BY c.ts
        """)
        swap_events = [
            {
                "id": r[0],
                "ts": r[1],
                "dur": r[2],
                "name": r[3],
                "parent_id": r[4],
                "tid": r[5],
            }
            for r in cur_swap.fetchall()
        ]
        log.info("build_web_frames: RealSwapBuffers 事件数=%d", len(swap_events))

        if not swap_events:
            ctx.data = {
                "web_frames": [],
                "summary": {
                    "total_frames": 0,
                    "jank_count": 0,
                    "normal_count": 0,
                    "minor_count": 0,
                    "major_count": 0,
                    "severe_count": 0,
                },
            }
            ctx.meta["web_frames"] = []
            ctx.meta["web_summary"] = {
                "total_frames": 0,
                "jank_count": 0,
                "normal_count": 0,
                "minor_count": 0,
                "major_count": 0,
                "severe_count": 0,
            }
            return ctx

        # -------------------- 2. 预加载 callstack 到内存 --------------------
        # 使用递归 CTE 一次性加载所有 RealSwapBuffers 及其完整 parent 链
        # 递归链仅需 id/name/parent_id/ts/dur，不需要 tid
        cur_all = conn.execute("""
            WITH RECURSIVE ancestors AS (
                SELECT id, name, parent_id, ts, dur FROM callstack WHERE name LIKE '%RealSwapBuffers%'
                UNION ALL
                SELECT c.id, c.name, c.parent_id, c.ts, c.dur
                FROM callstack c
                INNER JOIN ancestors a ON c.id = a.parent_id
                WHERE a.parent_id IS NOT NULL AND a.parent_id > 0 AND a.parent_id < 2147483647
            )
            SELECT DISTINCT id, name, parent_id, ts, dur FROM ancestors
        """)
        callstack_by_id: Dict[int, Dict[str, Any]] = {}
        for row in cur_all.fetchall():
            callstack_by_id[row[0]] = {
                "name": row[1],
                "parent_id": row[2],
                "ts": row[3],
                "dur": row[4],
            }
        log.info("build_web_frames: 预加载 %d 条记录到内存", len(callstack_by_id))

        # -------------------- 3. 为每个 RealSwapBuffers 查找 trace_id --------------------
        swap_with_trace_id = []
        for swap in swap_events:
            trace_id = _find_trace_id_recursive(swap["id"], callstack_by_id)
            swap_with_trace_id.append({
                **swap,
                "trace_id": trace_id,
            })

        # -------------------- 4. 查询 H:SendVsyncTo conn: NWeb 事件（用于第一个帧的开始时间）--------------------
        # 找到时间最接近第一个 RealSwapBuffers，同时小于第一个 RealSwapBuffers 的 vsync 事件
        first_swap_ts = swap_events[0]["ts"]
        cur_vsync = conn.execute("""
            SELECT c.ts
            FROM callstack c
            WHERE c.name LIKE 'H:SendVsyncTo conn: NWeb%' AND c.ts < ?
            ORDER BY c.ts DESC
            LIMIT 1
        """, (first_swap_ts,))
        first_vsync_row = cur_vsync.fetchone()
        first_vsync_ts = first_vsync_row[0] if first_vsync_row else None

        # -------------------- 5. 查询中间函数 --------------------
        intermediate_patterns = [
            "H:LatencyInfo.Flow%",
            "H:Graphics.Pipeline%",
            "H:Scheduler::RunNextTask%",
            "H:ProxyImpl::ReadyToCommit%",
            "H:RasterTask%",
        ]

        intermediate_events = []
        for pattern in intermediate_patterns:
            # callstack 表没有 tid 列，通过 LEFT JOIN thread (callid=itid) 获取 tid
            # 过滤 dur IS NULL 的行（极少数事件无 duration，无法参与帧时间范围计算）
            cur_int = conn.execute("""
                SELECT c.id, c.ts, c.dur, c.name, t.tid
                FROM callstack c
                LEFT JOIN thread t ON t.itid = c.callid
                WHERE c.name LIKE ? AND c.dur IS NOT NULL
                ORDER BY c.ts
            """, (pattern,))
            for r in cur_int.fetchall():
                intermediate_events.append({
                    "id": r[0],
                    "ts": r[1],
                    "dur": r[2],
                    "name": r[3],
                    "tid": r[4],
                })

        log.info("build_web_frames: 中间函数事件数=%d", len(intermediate_events))

        # -------------------- 5.5. 查询线程名映射 (tid -> name) --------------------
        # 用于构建 thread_list 标准字段
        cur_threads = conn.execute("""
            SELECT tid, name FROM thread
        """)
        tid_to_name: Dict[int, str] = {}
        for row in cur_threads.fetchall():
            tid_to_name[row[0]] = row[1] if row[1] else ""

        # -------------------- 6. 构建帧链路 --------------------
        # 逻辑：
        # - 每个 RealSwapBuffers 是一个帧的结束点
        # - 前一个 RealSwapBuffers 的结束时间 = 当前帧的开始时间
        # - 第一个 RealSwapBuffers 可能没有开始时间，使用 first_vsync_ts
        # - 收集同一帧内的中间函数（基于时间范围）

        web_frames = []

        for i, swap in enumerate(swap_with_trace_id):
            swap_end_ts = swap["ts"] + swap["dur"]

            if i == 0:
                # 第一个帧，使用 first_vsync_ts 作为开始时间
                frame_start_ts = first_vsync_ts if first_vsync_ts else swap["ts"]
            else:
                # 使用前一个 swap 的结束时间作为当前帧的开始时间
                prev_swap = swap_with_trace_id[i - 1]
                frame_start_ts = prev_swap["ts"] + prev_swap["dur"]

            frame_dur = swap_end_ts - frame_start_ts
            dur_ms = frame_dur / 1_000_000.0  # 纳秒转毫秒

            # 收集该帧时间范围内的中间函数
            frame_intermediate = []
            for int_event in intermediate_events:
                int_start = int_event["ts"]
                int_end = int_event["ts"] + int_event["dur"]
                if frame_start_ts <= int_start and int_end <= swap_end_ts:
                    frame_intermediate.append(int_event)

            # 线程去重
            threads: Set[int] = set()
            threads.add(swap["tid"])
            for int_event in frame_intermediate:
                threads.add(int_event["tid"])

            # 构建 thread_list (标准格式: [{"tid": int, "name": str}])
            thread_list = []
            for tid in threads:
                thread_name = tid_to_name.get(tid, str(tid))
                thread_list.append({"tid": tid, "name": thread_name})

            # 使用动态帧率计算 severity
            effective_rate = _match_frame_rate(frame_start_ts, frame_rate_records)
            if effective_rate is None:
                effective_rate = default_frame_rate
            severity = _compute_jank_severity(dur_ms, float(effective_rate))

            # 构建帧数据（标准字段，与 RS/Flutter 帧一致）
            # Web 帧的进程名：RealSwapBuffers 事件对应的线程所属进程
            _proc_name = tid_process_map.get(swap.get("tid"), "") if swap.get("tid") else ""
            web_frames.append({
                "start_ts": frame_start_ts,
                "end_ts": swap_end_ts,
                "dur_ms": dur_ms,
                "webVsyncId": swap["trace_id"],
                "thread_list": thread_list,
                "jank_severity": severity,
                "frame_rate": int(effective_rate),
                "process_name": _proc_name,
                "package_name": get_process_name(_proc_name) if _proc_name else "",
            })

        # -------------------- 7. 构建摘要 --------------------
        total_frames = len(web_frames)
        normal_count = sum(1 for f in web_frames if f["jank_severity"] == "normal")
        minor_count = sum(1 for f in web_frames if f["jank_severity"] == "minor")
        major_count = sum(1 for f in web_frames if f["jank_severity"] == "major")
        severe_count = sum(1 for f in web_frames if f["jank_severity"] == "severe")
        jank_count = minor_count + major_count + severe_count

        summary = {
            "total_frames": total_frames,
            "jank_count": jank_count,
            "normal_count": normal_count,
            "minor_count": minor_count,
            "major_count": major_count,
            "severe_count": severe_count,
        }

        log.info(
            "build_web_frames: 构建完成 - 总帧数=%d, normal=%d, minor=%d, major=%d, severe=%d",
            total_frames, normal_count, minor_count, major_count, severe_count,
        )

        ctx.data = {
            "web_frames": web_frames,
            "summary": summary,
        }
        ctx.meta["web_frames"] = web_frames
        ctx.meta["web_summary"] = summary

    except Exception as e:
        log.error("build_web_frames: 执行失败: %s", e)
        ctx.data = {
            "web_frames": [],
            "summary": {
                "total_frames": 0,
                "jank_count": 0,
                "normal_count": 0,
                "minor_count": 0,
                "major_count": 0,
                "severe_count": 0,
            },
        }
        ctx.meta["web_frames"] = []
        ctx.meta["web_summary"] = {
            "total_frames": 0,
            "jank_count": 0,
            "normal_count": 0,
            "minor_count": 0,
            "major_count": 0,
            "severe_count": 0,
        }

    return ctx
