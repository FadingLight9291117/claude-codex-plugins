# -*- coding: utf-8 -*-
"""TraceDataCache：轻量对象树（方案 D）。

设计原则（spec: docs/superpowers/specs/2026-07-25-trace-data-cache-architecture-design.md）:
- 不建 trace_list（避免 oss_tracetools 的 3.76s 遍历成本）
- 内部数据保留 list of tuple（避免 DataFrame 适配层开销）
- 算子通过 ThreadInfo 适配器访问（业务代码简洁）
- WakeupChainIndex 复用现有实现（O(1) prev 指针）
"""
from __future__ import annotations

import bisect
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from core.observability import (
    get_module_logger,
    get_observability_logger,
    get_observability_session_id as _get_obs_sid,
)

if TYPE_CHECKING:
    from core.preprocess.wakeup_chain_index import WakeupChainIndex

log = get_module_logger(__name__)
_obs = get_observability_logger("trace_cache")

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:  # pragma: no cover - 降级路径，运行环境通常有 numpy
    import types as _types
    np = _types.SimpleNamespace()  # type: ignore[assignment]
    _HAS_NUMPY = False


# ---------------------------------------------------------------------------
# 连接级单例缓存
# ---------------------------------------------------------------------------
_global_cache_by_conn: Dict[int, "TraceDataCache"] = {}
_conn_fingerprint: Dict[int, int] = {}


def _compute_fp(sqlite_conn) -> int:
    """连接指纹（防 id(conn) 复用导致缓存串场）。

    与 wakeup_chain_index._conn_identity 同语义（Task 11 删除了 sleep_ops._sleep_conn_identity）。
    """
    if sqlite_conn is None:
        return 0
    try:
        row = sqlite_conn.execute("SELECT rowid FROM sqlite_master LIMIT 1").fetchone()
        return hash((id(sqlite_conn), row))
    except Exception as e:
        log.debug(f"无法计算连接指纹，回退到 id(conn): {e}")
        return id(sqlite_conn)


def get_trace_data_cache(sqlite_conn) -> "TraceDataCache":
    """获取连接级单例 TraceDataCache。

    同一 SQLite 连接只构建一次，后续调用直接返回缓存。
    指纹校验防 id(conn) 复用导致缓存串场。
    """
    if sqlite_conn is None:
        return TraceDataCache(None)
    conn_id = id(sqlite_conn)
    fp = _compute_fp(sqlite_conn)
    if conn_id in _global_cache_by_conn and _conn_fingerprint.get(conn_id) != fp:
        # 指纹失效（id 复用），清理
        del _global_cache_by_conn[conn_id]
    if conn_id not in _global_cache_by_conn:
        _global_cache_by_conn[conn_id] = TraceDataCache(sqlite_conn)
        _conn_fingerprint[conn_id] = fp
    else:
        # 命中缓存：同一 conn_id 复用已有 TraceDataCache
        _obs.info("trace_cache_hit", session_id=_get_obs_sid(), conn_id=conn_id)
    return _global_cache_by_conn[conn_id]


def _filter_intersection(
    sorted_list: list,
    ts_only_np: Any,
    start_ns: int,
    end_ns: int,
    dur_idx: int = 1,
    dur_only_np: Any = None,
) -> list:
    """区间交集：(ts+dur) > start_ns AND ts < end_ns。

    借用 oss_tracetools get_list_time_slice 思路，但用 numpy mask 加速。

    返回原始行（不做 clamp）：
    - 命中的行可能横跨窗口边界
    - 业务方法（如 get_running_duration）需要再 clamp 到窗口内累加

    dur_idx: tuple 中 dur 字段的索引（thread_state/sched_slice/measure 默认 1；
              callstack 因 callid 在前，dur 在索引 2）
    dur_only_np: 预存的 dur numpy 数组（按 ts 升序对齐），可选。
        - 传入时直接用，省掉每次调用重建 dur 数组的 list comp 开销
        - 未传入时回退到 list comp 重建（保持向后兼容）
    """
    if len(sorted_list) == 0:
        return []
    # bisect_left 严格 ts < end_ns（规则 30）；bisect_right 会含 ts==end_ns 的边界行
    idx_hi = bisect.bisect_left(ts_only_np, end_ns)
    if idx_hi == 0:
        return []
    cand_ts = ts_only_np[:idx_hi]
    if dur_only_np is not None:
        # 性能优化：复用预存 dur 数组（避免每次调用重建 list comp）
        cand_dur = dur_only_np[:idx_hi]
    else:
        cand_dur = np.array([r[dur_idx] or 0 for r in sorted_list[:idx_hi]], dtype=np.int64)
    mask = (cand_ts + cand_dur) > start_ns
    return [sorted_list[i] for i in np.where(mask)[0]]


class TraceDataCache:
    """轻量对象树：dict 分组 + ThreadInfo 适配 + 唤醒链 O(1) 索引。"""

    def __init__(self, sqlite_conn):
        self._conn = sqlite_conn

        # === dict 分组（懒加载）===
        self._thread_state: Optional[Dict[int, List[Tuple]]] = None
        self._thread_state_ts: Optional[Dict[int, Any]] = None
        self._thread_state_dur: Optional[Dict[int, Any]] = None  # 预存 dur 数组（性能优化）

        self._callstack: Optional[Dict[int, List[Tuple]]] = None
        self._callstack_ts: Optional[Dict[int, Any]] = None
        self._callstack_dur: Optional[Dict[int, Any]] = None

        self._sched_slice: Optional[Dict[int, List[Tuple]]] = None
        self._sched_slice_ts: Optional[Dict[int, Any]] = None
        self._sched_slice_dur: Optional[Dict[int, Any]] = None

        self._measure: Optional[Dict[str, List[Tuple]]] = None
        self._measure_ts: Optional[Dict[str, Any]] = None
        self._measure_dur: Optional[Dict[str, Any]] = None

        self._measure_no_cpu: Optional[Dict[str, List[Tuple]]] = None  # measure_filter (无 cpu 列)
        self._measure_no_cpu_ts: Optional[Dict[str, Any]] = None
        self._measure_no_cpu_dur: Optional[Dict[str, Any]] = None

        self._thread_meta: Optional[Dict[int, Tuple[str, int, int]]] = None  # itid → (name, tid, ipid)
        self._process_meta: Optional[Dict[int, str]] = None  # ipid → name
        self._ipid_to_pid: Optional[Dict[int, int]] = None  # ipid → pid
        self._tid_to_itid: Optional[Dict[int, int]] = None

        self._args_dict: Optional[Dict[int, str]] = None  # argset → caller_name

        self._trace_range: Optional[Tuple[int, int]] = None

        self._wakeup_index: Optional[Any] = None  # WakeupChainIndex
        self._thread_info_cache: Dict[int, "ThreadInfo"] = {}

        # === Derived views (sleep_ops 专用)：从 _callstack / _thread_state 提取，
        # 避免每个 item 重建 dictcomp（204 items × 0.2s = 40s 浪费）。
        # sleep_ops 的 _get_blocked_function_from_cache / _stat_thread_state_from_cache
        # 需要 (ts, dur, name, depth) / (ts, dur, state) 格式 + ts_only + max_dur 辅助结构。
        self._sleep_callstack_view: Optional[Tuple[
            Dict[int, List[Tuple[int, int, str, int]]],  # callstack_cache
            Dict[int, List[int]],                          # ts_only_cache
            Dict[int, int],                                # max_dur_cache
        ]] = None
        self._sleep_thread_state_view: Optional[Tuple[
            Dict[int, List[Tuple[int, int, str]]],  # thread_state_cache
            Dict[int, List[int]],                     # ts_only_cache
        ]] = None
        self._sleep_prio_map: Optional[Dict[int, int]] = None

        # === animation_ops 专用 derived view ===
        self._animation_callstack_view: Optional[Tuple[
            Dict[int, List[Tuple]],  # {itid: [(ts, dur, name, cookie, id)]}
            Dict[int, Any],          # {itid: numpy ts_only}
        ]] = None

        # === chip_config 算力表（连接级缓存） ===
        self._chip_config: Optional[Dict[str, Any]] = None
        self._cpuid_cluster_map: Optional[Dict[int, Optional[str]]] = None
        self._cpuid_sibling_map: Optional[Dict[int, Optional[int]]] = None

    # === 核心访问接口（骨架，后续 Task 实现）===
    def get_thread(self, tid: int) -> "ThreadInfo":
        """获取线程适配器（懒创建、缓存）。"""
        if tid not in self._thread_info_cache:
            self._thread_info_cache[tid] = ThreadInfo(tid, self)
        return self._thread_info_cache[tid]

    def trace_range(self) -> Tuple[int, int]:
        """trace 时间范围 (min_ts, max_ts + max_dur)。"""
        if self._trace_range is None:
            self._build_trace_range()
        return self._trace_range or (0, 0)

    def wakeup_index(self) -> "WakeupChainIndex":
        """唤醒链 O(1) 索引（直接复用 get_wakeup_index）。"""
        if self._wakeup_index is None:
            from core.preprocess.wakeup_chain_index import get_wakeup_index
            self._wakeup_index = get_wakeup_index(self._conn)
        return self._wakeup_index

    # === 懒加载构建方法（Task 2-4 实现）===
    def _build_trace_range(self):
        if self._conn is None:
            self._trace_range = (0, 0)
            return
        try:
            row = self._conn.execute(
                "SELECT MIN(ts), MAX(ts), MAX(dur) FROM thread_state"
            ).fetchone()
            if row and row[0] is not None:
                min_ts = row[0]
                max_ts_end = (row[1] or 0) + (row[2] or 0)
                self._trace_range = (min_ts, max_ts_end)
            else:
                self._trace_range = (0, 0)
        except Exception as e:
            log.debug(f"无法构建 trace_range，回退到 (0, 0): {e}")
            self._trace_range = (0, 0)

    def thread_state(self, itid: int, start_ns: int, end_ns: int) -> list:
        """区间交集过滤（bisect + numpy mask）。

        tuple 结构: (ts, dur, state, cpu, tid, pid, itid, arg_setid)
        - 前 7 字段保持原有位置（ThreadInfo / sleep_thread_state_view 按位置取前 3-7 字段）
        - arg_setid 末尾追加，供 uninterruptible_dstate 通过 cache.block_reason() 反查 caller
        """
        if self._thread_state is None:
            self._build_thread_state()
        assert self._thread_state is not None
        assert self._thread_state_ts is not None
        ev_list = self._thread_state.get(itid, [])
        ts_only = self._thread_state_ts.get(itid, np.array([]))
        dur_only = self._thread_state_dur.get(itid) if self._thread_state_dur else None
        return _filter_intersection(ev_list, ts_only, start_ns, end_ns, dur_only_np=dur_only)

    def thread_state_all(self) -> Dict[int, List[Tuple]]:
        """返回全量 thread_state 字典（itid→list of tuples），触发懒加载。

        用于 thread_sched_ops._build_df_from_cache 等需要遍历全量 itid 的场景。
        """
        if self._thread_state is None:
            self._build_thread_state()
        return self._thread_state or {}

    def _build_thread_state(self):
        """全量拉取 thread_state，按 itid 分组。

        thread_state 实际 schema: id, ts, dur, cpu, itid, tid, pid, state, arg_setid
        （无 tname 列；tname 由 thread 表的 itid→name 关联取，本缓存不直接持有）

        tuple 结构: (ts, dur, state, cpu, tid, pid, itid, arg_setid)
        - 前 7 字段保持原有位置（ThreadInfo / sleep_thread_state_view 按位置取前 3-7 字段）
        - arg_setid 末尾追加，供 uninterruptible_dstate 通过 cache.block_reason() 反查 caller
        """
        if self._conn is None:
            self._thread_state = {}
            self._thread_state_ts = {}
            return
        try:
            rows = self._conn.execute(
                "SELECT ts, dur, state, cpu, tid, pid, itid, arg_setid "
                "FROM thread_state ORDER BY itid, ts"
            ).fetchall()
        except Exception as e:
            log.debug(f"无法拉取 thread_state: {e}")
            self._thread_state = {}
            self._thread_state_ts = {}
            return
        data: Dict[int, List[Tuple]] = {}
        for r in rows:
            itid = r[6]
            data.setdefault(itid, []).append(tuple(r))
        ts_only: Dict[int, Any] = {
            itid: np.array([t[0] for t in lst], dtype=np.int64)
            for itid, lst in data.items()
        }
        # 预存 dur 数组（性能优化）：避免 _filter_intersection 每次调用重建 list comp
        # thread_state tuple: (ts, dur, ...) - dur 在索引 1
        dur_only: Dict[int, Any] = {
            itid: np.array([t[1] or 0 for t in lst], dtype=np.int64)
            for itid, lst in data.items()
        }
        self._thread_state = data
        self._thread_state_ts = ts_only
        self._thread_state_dur = dur_only
        _obs.info("trace_cache_prefetch_complete", session_id=_get_obs_sid(), table="thread_state",
                  row_count=sum(len(v) for v in data.values()),
                  itid_count=len(data))

    # === Task 3: callstack / sched_slice / measure 懒加载 ===

    def callstack(self, itid: int, start_ns: int, end_ns: int) -> list:
        """callstack 区间交集过滤（按 callid 分组，callid=itid per Rule 20）。

        区间语义：(ts+dur) > start_ns AND ts < end_ns（区间相交）。
        注意：原 SQL1/SQL2 使用 end_ts 落在窗口内（上界 <=），此处统一为区间相交。
        SQL5/SQL6 原本即区间相交，无差异。经 E2E 验证 89 item 结果一致。

        callstack tuple: (callid, ts, dur, name, depth, parent_id, id, cookie, argsetid)
        dur 在索引 2（callid 在 0，ts 在 1），需通过 dur_idx=2 告知 _filter_intersection。
        id/cookie/argsetid 在末尾追加，不影响 sleep_callstack_view 等已有消费者（按位置取前 6 字段）。
        """
        if self._callstack is None:
            self._build_callstack()
        assert self._callstack is not None
        assert self._callstack_ts is not None
        ev_list = self._callstack.get(itid, [])
        ts_only = self._callstack_ts.get(itid, np.array([]))
        dur_only = self._callstack_dur.get(itid) if self._callstack_dur else None
        return _filter_intersection(ev_list, ts_only, start_ns, end_ns, dur_idx=2, dur_only_np=dur_only)

    def callstack_all(self) -> Dict[int, List[Tuple]]:
        """返回全量 callstack 字典（itid→list of tuples），触发懒加载。

        用于 game_render_ops 等需要遍历全量 itid 或访问 argsetid 的场景。
        """
        if self._callstack is None:
            self._build_callstack()
        return self._callstack or {}

    def _build_callstack(self):
        """全量拉取 callstack，按 callid 分组（callid=itid per Rule 20）。

        callstack 表无 itid 列；GOLDEN RULES Rule 20 规定 callstack.callid IS
        thread.id（即 itid），因此用 callid 作为分组键。

        tuple 结构: (callid, ts, dur, name, depth, parent_id, id, cookie, argsetid)
        - 前 6 字段保持原有位置（sleep_callstack_view 按 r[1:5] 取 ts/dur/name/depth）
        - id/cookie 末尾追加，供 marker_ops.build_marker_tree 使用
        - argsetid 末尾追加，供 game_render_ops._identify_static_pids 反查 args
        """
        if self._conn is None:
            self._callstack = {}
            self._callstack_ts = {}
            return
        try:
            rows = self._conn.execute(
                "SELECT callid, ts, dur, name, depth, parent_id, id, cookie, argsetid "
                "FROM callstack ORDER BY callid, ts"
            ).fetchall()
        except Exception as e:
            log.debug(f"无法拉取 callstack: {e}")
            self._callstack = {}
            self._callstack_ts = {}
            return
        data: Dict[int, List[Tuple]] = {}
        for r in rows:
            callid = r[0]  # callid IS itid per Rule 20
            data.setdefault(callid, []).append(tuple(r))
        ts_only: Dict[int, Any] = {
            itid: np.array([t[1] for t in lst], dtype=np.int64)
            for itid, lst in data.items()
        }
        # 预存 dur 数组（性能优化）：callstack tuple dur 在索引 2
        dur_only: Dict[int, Any] = {
            itid: np.array([t[2] or 0 for t in lst], dtype=np.int64)
            for itid, lst in data.items()
        }
        self._callstack = data
        self._callstack_ts = ts_only
        self._callstack_dur = dur_only
        _obs.info("trace_cache_prefetch_complete", session_id=_get_obs_sid(), table="callstack",
                  row_count=sum(len(v) for v in data.values()),
                  itid_count=len(data))

    def sched_slice(self, itid: int, start_ns: int, end_ns: int) -> list:
        """sched_slice 区间交集过滤（按 itid 分组）。"""
        if self._sched_slice is None:
            self._build_sched_slice()
        assert self._sched_slice is not None
        assert self._sched_slice_ts is not None
        ev_list = self._sched_slice.get(itid, [])
        ts_only = self._sched_slice_ts.get(itid, np.array([]))
        dur_only = self._sched_slice_dur.get(itid) if self._sched_slice_dur else None
        return _filter_intersection(ev_list, ts_only, start_ns, end_ns, dur_only_np=dur_only)

    def _build_sched_slice(self):
        """全量拉取 sched_slice，按 itid 分组。"""
        if self._conn is None:
            self._sched_slice = {}
            self._sched_slice_ts = {}
            return
        try:
            rows = self._conn.execute(
                "SELECT ts, dur, cpu, end_state, priority, itid "
                "FROM sched_slice ORDER BY itid, ts"
            ).fetchall()
        except Exception as e:
            log.debug(f"无法拉取 sched_slice: {e}")
            self._sched_slice = {}
            self._sched_slice_ts = {}
            return
        data: Dict[int, List[Tuple]] = {}
        for r in rows:
            itid = r[5]
            data.setdefault(itid, []).append(tuple(r))
        ts_only: Dict[int, Any] = {
            itid: np.array([t[0] for t in lst], dtype=np.int64)
            for itid, lst in data.items()
        }
        # 预存 dur 数组（性能优化）：sched_slice tuple dur 在索引 1
        dur_only: Dict[int, Any] = {
            itid: np.array([t[1] or 0 for t in lst], dtype=np.int64)
            for itid, lst in data.items()
        }
        self._sched_slice = data
        self._sched_slice_ts = ts_only
        self._sched_slice_dur = dur_only
        _obs.info("trace_cache_prefetch_complete", session_id=_get_obs_sid(), table="sched_slice",
                  row_count=sum(len(v) for v in data.values()),
                  itid_count=len(data))

    def measure(self, filter_name: str, start_ns: int, end_ns: int) -> list:
        """measure 区间交集过滤（按 filter_name 分组）。"""
        if self._measure is None:
            self._build_measure()
        assert self._measure is not None
        assert self._measure_ts is not None
        ev_list = self._measure.get(filter_name, [])
        ts_only = self._measure_ts.get(filter_name, np.array([]))
        dur_only = self._measure_dur.get(filter_name) if self._measure_dur else None
        return _filter_intersection(ev_list, ts_only, start_ns, end_ns, dur_only_np=dur_only)

    def _build_measure(self):
        """全量拉取 measure，按 filter_name 分组（JOIN cpu_measure_filter）。

        measure 表无 filter_name 列，只有 filter_id；需 JOIN cpu_measure_filter
        (id, name, cpu) 解析 filter_id → name。tuple 形如 (ts, dur, value, cpu)。
        """
        if self._conn is None:
            self._measure = {}
            self._measure_ts = {}
            return
        try:
            rows = self._conn.execute(
                "SELECT m.ts, m.dur, m.value, cmf.cpu, cmf.name "
                "FROM measure m "
                "JOIN cpu_measure_filter cmf ON m.filter_id = cmf.id "
                "ORDER BY cmf.name, m.ts"
            ).fetchall()
        except Exception as e:
            log.debug(f"无法拉取 measure: {e}")
            self._measure = {}
            self._measure_ts = {}
            return
        data: Dict[str, List[Tuple]] = {}
        for r in rows:
            filter_name = r[4]
            data.setdefault(filter_name, []).append(tuple(r[:4]))
        ts_only: Dict[str, Any] = {
            fn: np.array([t[0] for t in lst], dtype=np.int64)
            for fn, lst in data.items()
        }
        # 预存 dur 数组（性能优化）：measure tuple dur 在索引 1
        dur_only: Dict[str, Any] = {
            fn: np.array([t[1] or 0 for t in lst], dtype=np.int64)
            for fn, lst in data.items()
        }
        self._measure = data
        self._measure_ts = ts_only
        self._measure_dur = dur_only
        _obs.info("trace_cache_prefetch_complete", session_id=_get_obs_sid(), table="measure",
                  row_count=sum(len(v) for v in data.values()),
                  filter_name_count=len(data))

    # === measure_filter（无 cpu 列，如温度传感器）===

    def measure_no_cpu(self, filter_name: str, start_ns: int, end_ns: int) -> list:
        """measure_filter 区间交集过滤（按 filter_name 分组，无 cpu 列）。

        与 measure() 类似，但 JOIN measure_filter（无 cpu 列），返回 (ts, dur, value)。
        适用于 shell_frame_temp / soc_temp 等非 per-cpu 传感器。
        """
        if self._measure_no_cpu is None:
            self._build_measure_no_cpu()
        assert self._measure_no_cpu is not None
        assert self._measure_no_cpu_ts is not None
        ev_list = self._measure_no_cpu.get(filter_name, [])
        ts_only = self._measure_no_cpu_ts.get(filter_name, np.array([]))
        dur_only = self._measure_no_cpu_dur.get(filter_name) if self._measure_no_cpu_dur else None
        return _filter_intersection(ev_list, ts_only, start_ns, end_ns, dur_only_np=dur_only)

    def _build_measure_no_cpu(self):
        """全量拉取 measure + measure_filter（无 cpu 列），按 filter_name 分组。

        与 _build_measure 不同：此处 JOIN measure_filter（而非 cpu_measure_filter），
        用于 shell_frame_temp / soc_temp 等全局传感器（无 per-cpu 维度）。
        tuple 形如 (ts, dur, value)。
        """
        if self._conn is None:
            self._measure_no_cpu = {}
            self._measure_no_cpu_ts = {}
            return
        try:
            rows = self._conn.execute(
                "SELECT m.ts, m.dur, m.value, mf.name "
                "FROM measure m "
                "JOIN measure_filter mf ON m.filter_id = mf.id "
                "ORDER BY mf.name, m.ts"
            ).fetchall()
        except Exception as e:
            log.debug(f"无法拉取 measure_no_cpu: {e}")
            self._measure_no_cpu = {}
            self._measure_no_cpu_ts = {}
            return
        data: Dict[str, List[Tuple]] = {}
        for r in rows:
            filter_name = r[3]
            data.setdefault(filter_name, []).append(tuple(r[:3]))
        ts_only: Dict[str, Any] = {
            fn: np.array([t[0] for t in lst], dtype=np.int64)
            for fn, lst in data.items()
        }
        # 预存 dur 数组（性能优化）：measure_no_cpu tuple dur 在索引 1
        dur_only: Dict[str, Any] = {
            fn: np.array([t[1] or 0 for t in lst], dtype=np.int64)
            for fn, lst in data.items()
        }
        self._measure_no_cpu = data
        self._measure_no_cpu_ts = ts_only
        self._measure_no_cpu_dur = dur_only
        _obs.info("trace_cache_prefetch_complete", session_id=_get_obs_sid(), table="measure_no_cpu",
                  row_count=sum(len(v) for v in data.values()),
                  filter_name_count=len(data))

    # === Task 4: thread/process 元数据 + block_reason ===

    def thread_meta(self, itid: int) -> Optional[Tuple[str, int, int]]:
        """返回 (name, tid, ipid)，无则 None。"""
        if self._thread_meta is None:
            self._build_thread_meta()
        assert self._thread_meta is not None
        return self._thread_meta.get(itid)

    def thread_meta_all(self) -> Dict[int, Tuple[str, int, int]]:
        """返回全量 itid→(name, tid, ipid) 字典（用于批量场景）。

        sleep_ops.compute_thread_sleep_summary 在 204 个 item 上 iterate，
        每个 item 原先循环调用 thread_meta(itid) 200+ 次构建 name/tid/ipid 映射，
        40800+ 次函数调用开销显著。批量取一次 dict 后用 .get() 查找，
        减少 200x 函数调用 → 1 次 + 200 次 dict lookup。
        """
        if self._thread_meta is None:
            self._build_thread_meta()
        assert self._thread_meta is not None
        return self._thread_meta

    def process_name_all(self) -> Dict[int, str]:
        """返回全量 ipid→name 字典（用于批量场景）。

        同 thread_meta_all 的批量优化动机。
        """
        if self._process_meta is None:
            self._build_process_meta()
        assert self._process_meta is not None
        return self._process_meta

    def ipid_to_pid_all(self) -> Dict[int, int]:
        """返回全量 ipid→pid 字典（用于 animation_ops 等）。

        cache 中 ipid 是进程内部 ID，pid 是系统 PID。
        原始 SQL 返回 p.pid，cache 路径通过本映射获取等价值。
        """
        if self._ipid_to_pid is None:
            self._build_process_meta()
        assert self._ipid_to_pid is not None
        return self._ipid_to_pid

    def tid_to_itid_all(self) -> Dict[int, int]:
        """返回全量 tid→itid 字典（用于批量场景）。"""
        if self._tid_to_itid is None:
            self._build_thread_meta()
        assert self._tid_to_itid is not None
        return self._tid_to_itid

    def thread_name(self, itid: int) -> str:
        """itid → name（无则返回空串）。"""
        meta = self.thread_meta(itid)
        return meta[0] if meta else ""

    def tid_to_itid(self, tid: int) -> int:
        """tid → itid 映射（无则返回 0）。"""
        if self._tid_to_itid is None:
            self._build_thread_meta()
        assert self._tid_to_itid is not None
        return self._tid_to_itid.get(tid, 0)

    def process_name(self, ipid: int) -> str:
        """ipid → 进程名（无则返回空串）。"""
        if self._process_meta is None:
            self._build_process_meta()
        assert self._process_meta is not None
        return self._process_meta.get(ipid, "")

    def block_reason(self, arg_setid: int) -> Optional[str]:
        """从 args + data_dict 反查 block_reason caller 函数名。

        数据链路：arg_setid → args(argset, key=3, datatype=1).value → data_dict.id → data_dict.data
        """
        if self._args_dict is None:
            self._build_args()
        assert self._args_dict is not None
        return self._args_dict.get(arg_setid)

    def _build_thread_meta(self):
        """一次性拉取 thread 表，构建 itid→(name, tid, ipid) + tid→itid。"""
        if self._conn is None:
            self._thread_meta = {}
            self._tid_to_itid = {}
            return
        try:
            rows = self._conn.execute(
                "SELECT itid, name, tid, ipid FROM thread"
            ).fetchall()
        except Exception as e:
            log.debug(f"无法拉取 thread 表: {e}")
            self._thread_meta = {}
            self._tid_to_itid = {}
            return
        self._thread_meta = {r[0]: (r[1], r[2], r[3]) for r in rows}
        self._tid_to_itid = {r[2]: r[0] for r in rows}
        _obs.info("trace_cache_prefetch_complete", session_id=_get_obs_sid(), table="thread_meta",
                  row_count=len(self._thread_meta),
                  itid_count=len(self._thread_meta))

    def _build_process_meta(self):
        """拉取 process 表，构建 ipid → name 和 ipid → pid。"""
        if self._conn is None:
            self._process_meta = {}
            self._ipid_to_pid = {}
            return
        try:
            rows = self._conn.execute("SELECT ipid, name, pid FROM process").fetchall()
            self._process_meta = {r[0]: r[1] for r in rows}
            self._ipid_to_pid = {r[0]: r[2] for r in rows if r[2] is not None}
        except Exception:
            # 旧版 trace.db 的 process 表可能没有 pid 列，降级为仅 ipid→name
            try:
                rows = self._conn.execute("SELECT ipid, name FROM process").fetchall()
                self._process_meta = {r[0]: r[1] for r in rows}
                self._ipid_to_pid = {}
            except Exception as e:
                log.debug(f"无法拉取 process 表: {e}")
                self._process_meta = {}
                self._ipid_to_pid = {}
                return
        _obs.info("trace_cache_prefetch_complete", session_id=_get_obs_sid(), table="process_meta",
                  row_count=len(self._process_meta),
                  itid_count=len(self._process_meta))

    def _build_args(self):
        """拉取 args + data_dict，构建 {argset: caller_name} 字典。

        真实数据链路（参考 uninterruptible_dstate.yaml:50-53）：
          thread_state.arg_setid → args.argset (key=3, datatype=1) → args.value → data_dict.id → data_dict.data

        即 block_reason 的 caller 名在 data_dict.data 里，不在 args.data 里。
        """
        if self._conn is None:
            self._args_dict = {}
            return
        try:
            rows = self._conn.execute(
                "SELECT a.argset, d.data "
                "FROM args a "
                "LEFT JOIN data_dict d ON a.value = d.id "
                "WHERE a.key = 3 AND a.datatype = 1"
            ).fetchall()
            # 扁平 {argset: caller_name}
            self._args_dict = {r[0]: r[1] for r in rows if r[1] is not None}
            _obs.info("trace_cache_prefetch_complete", session_id=_get_obs_sid(), table="args",
                      row_count=len(self._args_dict),
                      itid_count=len(self._args_dict))
        except Exception as e:
            log.debug(f"无法拉取 args/data_dict: {e}")
            self._args_dict = {}

    # === sleep_ops 专用 derived views（Task 8）===
    # sleep_ops 的 _get_blocked_function_from_cache / _stat_thread_state_from_cache
    # 需要 (ts, dur, name, depth) / (ts, dur, state) 格式 + ts_only + max_dur 辅助结构。
    # 这些 dict comp 构建耗时 ~0.2s，204 items × 0.2s = 40s 浪费，需连接级缓存。

    def sleep_callstack_view(self) -> Tuple[
        Dict[int, List[Tuple[int, int, str, int]]],
        Dict[int, List[int]],
        Dict[int, int],
    ]:
        """sleep_ops 专用 callstack 视图：(ts, dur, name, depth) + ts_only + max_dur。

        从 cache._callstack 一次性构建，连接级缓存，避免 204 items 重建 dictcomp。
        Returns: (callstack_cache, ts_only_cache, max_dur_cache)
        """
        if self._sleep_callstack_view is None:
            if self._callstack is None:
                self._build_callstack()
            raw = self._callstack or {}
            # cache.callstack tuple: (callid, ts, dur, name, depth, parent_id, id, cookie, argsetid)
            # sleep_ops 期望: (ts, dur, name, depth) — 取前 6 字段中的 1-4 位置
            cs_cache: Dict[int, List[Tuple[int, int, str, int]]] = {
                itid: [(r[1], r[2], r[3], r[4]) for r in lst]
                for itid, lst in raw.items()
            }
            ts_only: Dict[int, List[int]] = {
                itid: [t[0] for t in lst]
                for itid, lst in cs_cache.items()
            }
            max_dur: Dict[int, int] = {
                itid: max((t[1] or 0) for t in lst) if lst else 0
                for itid, lst in cs_cache.items()
            }
            self._sleep_callstack_view = (cs_cache, ts_only, max_dur)
        return self._sleep_callstack_view

    def sleep_thread_state_view(self) -> Tuple[
        Dict[int, List[Tuple[int, int, str]]],
        Dict[int, List[int]],
    ]:
        """sleep_ops 专用 thread_state 视图：(ts, dur, state) + ts_only。

        从 cache._thread_state 一次性构建，连接级缓存，避免 204 items 重建 dictcomp。
        Returns: (thread_state_cache, ts_only_cache)
        """
        if self._sleep_thread_state_view is None:
            if self._thread_state is None:
                self._build_thread_state()
            raw = self._thread_state or {}
            # cache.thread_state tuple: (ts, dur, state, cpu, tid, pid, itid, arg_setid)
            # sleep_ops 期望: (ts, dur, state) — 取前 3 字段，arg_setid 末尾不影响
            ts_cache: Dict[int, List[Tuple[int, int, str]]] = {
                itid: [(r[0], r[1] or 0, r[2] or "") for r in lst]
                for itid, lst in raw.items()
            }
            ts_only: Dict[int, List[int]] = {
                itid: [t[0] for t in lst]
                for itid, lst in ts_cache.items()
            }
            self._sleep_thread_state_view = (ts_cache, ts_only)
        return self._sleep_thread_state_view

    def sleep_prio_map(self) -> Dict[int, int]:
        """sleep_ops 专用 prio_map：每个 itid 的首条 sched_slice priority。

        语义对齐原 legacy _get_prio_full（已删除）：无 sched_slice 数据时不加入 dict，
        后续 prio_map.get(w_from, -1) 返回 -1（而非 0）。
        """
        if self._sleep_prio_map is None:
            if self._sched_slice is None:
                self._build_sched_slice()
            raw = self._sched_slice or {}
            # cache.sched_slice tuple: (ts, dur, cpu, end_state, priority, itid)
            # 首条 priority（已 ORDER BY itid, ts，lst[0] 即首条）
            prio_map: Dict[int, int] = {}
            for itid, lst in raw.items():
                if lst:
                    prio_map[itid] = lst[0][4]
            self._sleep_prio_map = prio_map
        return self._sleep_prio_map

    def animation_callstack_view(self) -> Tuple[
        Dict[int, List[Tuple]],
        Dict[int, Any],
    ]:
        """animation_ops 专用 callstack 视图：仅含 cookie IS NOT NULL 且 name LIKE 'H:%' 的行。

        从 cache._callstack 一次性构建，连接级缓存。
        避免 animation_ops 每个 item 遍历全量 793K 行做 Python 过滤。

        Returns: (anim_cache, ts_only_cache)
          anim_cache:  {itid: [(ts, dur, name, cookie, id)]}
          ts_only_cache: {itid: numpy int64 array}
        """
        if self._animation_callstack_view is None:
            if self._callstack is None:
                self._build_callstack()
            raw = self._callstack or {}
            # cache.callstack tuple: (callid, ts, dur, name, depth, parent_id, id, cookie, argsetid)
            anim_cache: Dict[int, List[Tuple]] = {}
            for itid, lst in raw.items():
                filtered = [
                    (r[1], r[2], r[3], r[7], r[6])
                    for r in lst
                    if r[7] is not None and r[3] and r[3].startswith("H:") and r[2] is not None and r[2] > 0
                ]
                if filtered:
                    anim_cache[itid] = filtered
            ts_only_cache: Dict[int, Any] = {
                itid: np.array([t[0] for t in lst], dtype=np.int64)
                for itid, lst in anim_cache.items()
            }
            self._animation_callstack_view = (anim_cache, ts_only_cache)
        return self._animation_callstack_view

    # === chip_config 算力表(Task: chip-config-trace-cache)===

    def chip_config(self) -> Dict[str, Any]:
        """返回芯片配置 dict(含 clusters/gpu)。

        首次调用:从 measure('cpu_frequency') 提取频点 →
        _match_chips_with_details → 失败用 _build_unknown_chip_config(self) 兜底。
        后续调用:直接命中缓存(O(1))。
        """
        if self._chip_config is None:
            self._build_chip_config()
        return self._chip_config or {}

    def cluster_of(self, cpuid: int) -> Optional[str]:
        """cpuid → cluster name(懒加载,委托 chip_config + get_cluster_name)。"""
        if self._cpuid_cluster_map is None:
            self._build_chip_config()
        return self._cpuid_cluster_map.get(int(cpuid)) if self._cpuid_cluster_map else None

    def sibling_of(self, cpuid: int) -> Optional[int]:
        """cpuid → sibling cpuid(懒加载,委托 chip_config + get_sibling_cpuid)。"""
        if self._cpuid_sibling_map is None:
            self._build_chip_config()
        return self._cpuid_sibling_map.get(int(cpuid)) if self._cpuid_sibling_map else None

    def _build_chip_config(self):
        """首次构建 chip_config + cpuid 映射。

        数据来源:measure('cpu_frequency') 已缓存的全量频点数据。
        """
        if self._conn is None:
            self._chip_config = {}
            self._cpuid_cluster_map = {}
            self._cpuid_sibling_map = {}
            return
        try:
            # 延迟导入避免循环依赖(chip_config.py 在 TYPE_CHECKING 下引用 TraceDataCache)
            import pandas as pd  # noqa: F401 -- 局部延迟导入,避免顶层 numpy/pandas 双重依赖

            from core.preprocess.chip_config import (
                _build_unknown_chip_config,
                _extract_freq_from_df,
                _load_chips_db,
                _match_chips_with_details,
                get_cluster_name,
                get_sibling_cpuid,
            )

            start_ns, end_ns = self.trace_range()
            freq_rows = self.measure('cpu_frequency', start_ns, end_ns)

            if not freq_rows:
                # 全 trace 范围没数据,直接 Unknown fallback
                chip_config = _build_unknown_chip_config(self)
            else:
                # 构造 df 复用 find_chip_by_params 的接口
                df = pd.DataFrame(freq_rows, columns=['ts', 'dur', 'value', 'cpu'])
                # measure('cpu_frequency') 返回 kHz,chip_config 匹配期望 MHz
                df = df.rename(columns={'cpu': 'cpuid'})
                df['freq'] = df['value'] / 1000
                df['data_type'] = 'freq'
                cpu_count = int(df['cpuid'].max()) + 1
                per_cpu_freq = _extract_freq_from_df(df)
                matched = _match_chips_with_details(cpu_count, per_cpu_freq)

                if matched:
                    # matched[0] 含 chip_model/vendor/clusters/similarity_score
                    # 从 chip_database 加载完整 chip dict
                    chips_db = _load_chips_db()
                    cm = next(
                        (c for c in chips_db
                         if c.get('chip_model') == matched[0]['chip_model']),
                        None,
                    )
                    # 若 chips_db 中找不到 matched[0]['chip_model'](理论上不会发生),
                    # 退到 _build_unknown_chip_config(self) 兜底
                    # 注意:_build_unknown_chip_config 内部会再调 cache.measure('cpu_frequency')
                    # 但 cache.measure 已懒加载,本次调用命中缓存无 SQL 开销
                    chip_config = cm or _build_unknown_chip_config(self)
                else:
                    # 自动匹配失败,走 Unknown fallback
                    chip_config = _build_unknown_chip_config(self)

            # 构建 cpuid → cluster / sibling 映射
            cpuid_cluster_map: Dict[int, Optional[str]] = {}
            cpuid_sibling_map: Dict[int, Optional[int]] = {}
            for cpuid in range(chip_config.get('total_logical_cpus', 0)):
                cpuid_cluster_map[cpuid] = get_cluster_name(cpuid, chip_config)
                cpuid_sibling_map[cpuid] = get_sibling_cpuid(cpuid, chip_config)

            self._chip_config = chip_config
            self._cpuid_cluster_map = cpuid_cluster_map
            self._cpuid_sibling_map = cpuid_sibling_map

            _obs.info(
                "trace_cache_prefetch_complete",
                session_id=_get_obs_sid(),
                table="chip_config",
                chip_model=chip_config.get('chip_model'),
                cpu_count=len(cpuid_cluster_map),
            )
        except Exception as e:
            log.debug(f"无法构建 chip_config,回退到空: {e}")
            self._chip_config = {}
            self._cpuid_cluster_map = {}
            self._cpuid_sibling_map = {}


class ThreadInfo:
    """线程级适配器：包装 cache + 提供业务方法。

    设计原则：
    - 不持有独立数据（避免重复缓存）
    - 业务方法内部委托 cache.xxx() + clamp 到窗口
    - **所有累加方法都 clamp 到 [start_ns, end_ns]**（保证时间守恒）
    - 对齐 thread_sched_ops.py:282-284 的 clamp 逻辑
    """

    def __init__(self, tid: int, cache: "TraceDataCache"):
        self.tid = tid
        self._cache = cache

    @property
    def itid(self) -> int:
        return self._cache.tid_to_itid(self.tid)

    @property
    def name(self) -> str:
        return self._cache.thread_name(self.itid)

    @property
    def process_name(self) -> str:
        meta = self._cache.thread_meta(self.itid)
        if meta is None:
            return ''
        return self._cache.process_name(meta[2])

    def get_running_duration(self, start_ns: int, end_ns: int) -> float:
        """Running 总时长（ms），每行 clamp 到 [start_ns, end_ns]。

        trace.db 中 ts/dur 单位为 ns，返回值转换为 ms。
        """
        states = self._cache.thread_state(self.itid, start_ns, end_ns)
        total_ns = 0
        for ts, dur, state, *_ in states:
            if state != 'Running' or dur is None:
                continue
            ts_end = ts + dur
            clamp_lo = ts if ts > start_ns else start_ns
            clamp_hi = ts_end if ts_end < end_ns else end_ns
            delta = clamp_hi - clamp_lo
            if delta > 0:
                total_ns += delta
        return float(total_ns) / 1e6

    def get_runnable_duration(self, start_ns: int, end_ns: int) -> float:
        """Runnable gap 总时长（ms）。

        连续 Running 行之间的 gap 累加，gap 必须 >= 0。
        clamp：prev_end 用 maximum 兜底到 start_ns，cur_start 用 minimum 兜底到 end_ns。
        trace.db 中 ts/dur 单位为 ns，返回值转换为 ms。
        """
        states = self._cache.thread_state(self.itid, start_ns, end_ns)
        if len(states) < 2:
            return 0.0
        ts_arr = np.array([s[0] for s in states], dtype=np.int64)
        dur_arr = np.array([s[1] or 0 for s in states], dtype=np.int64)
        state_arr = np.array([s[2] for s in states])
        running_mask = state_arr == 'Running'
        if running_mask.sum() < 2:
            return 0.0
        running_idx = np.where(running_mask)[0]
        prev_end_raw = ts_arr[running_idx[:-1]] + dur_arr[running_idx[:-1]]
        prev_end = np.maximum(prev_end_raw, start_ns)
        cur_start_raw = ts_arr[running_idx[1:]]
        cur_start = np.minimum(cur_start_raw, end_ns)
        gaps = cur_start - prev_end
        return float(gaps[gaps >= 0].sum()) / 1e6

    def get_state_distribution(self, start_ns: int, end_ns: int) -> dict:
        """各状态时长分布（ms；每行 clamp 到窗口）。

        trace.db 中 ts/dur 单位为 ns，返回值转换为 ms。
        """
        states = self._cache.thread_state(self.itid, start_ns, end_ns)
        result = {'running': 0, 'runnable': 0, 'sleeping': 0,
                 'd_io': 0, 'd_nio': 0, 'd': 0, 'd_w': 0,
                 'i': 0, 'x': 0, 'z': 0}
        for ts, dur, state, *_ in states:
            if dur is None:
                continue
            ts_end = ts + dur
            clamp_lo = ts if ts > start_ns else start_ns
            clamp_hi = ts_end if ts_end < end_ns else end_ns
            delta = clamp_hi - clamp_lo
            if delta <= 0:
                continue
            if state == 'Running':
                result['running'] += delta
            elif state in ('R', 'R+'):
                result['runnable'] += delta
            elif state == 'S':
                result['sleeping'] += delta
            elif state == 'D-IO':
                result['d_io'] += delta
            elif state == 'D-NIO':
                result['d_nio'] += delta
            elif state == 'D|W':
                result['d_w'] += delta
            elif state == 'D':
                result['d'] += delta
            elif state == 'I':
                result['i'] += delta
            elif state == 'X':
                result['x'] += delta
            elif state == 'Z':
                result['z'] += delta
        return {k: v / 1e6 for k, v in result.items()}

    def get_cpu_exec_slice(self, start_ns: int, end_ns: int) -> list:
        """CPU 占用切片（Running 状态的 cpu_exec_info），clamp 到窗口。"""
        states = self._cache.thread_state(self.itid, start_ns, end_ns)
        result = []
        for ts, dur, state, cpu, tid, pid, *_ in states:
            if state != 'Running' or dur is None or cpu is None:
                continue
            ts_end = ts + dur
            clamp_lo = ts if ts > start_ns else start_ns
            clamp_hi = ts_end if ts_end < end_ns else end_ns
            clamp_dur = clamp_hi - clamp_lo
            if clamp_dur > 0:
                result.append((clamp_lo, clamp_dur, cpu, tid, pid))
        return result

    def get_priority_first(self) -> int:
        """首条 priority（用 trace_range 作窗口上界）。"""
        start_ns, end_ns = self._cache.trace_range()
        slices = self._cache.sched_slice(self.itid, start_ns, end_ns)
        return slices[0][4] if slices else 0

    def get_migration_count(self, start_ns: int, end_ns: int) -> int:
        """CPU 迁移次数。"""
        slices = self._cache.sched_slice(self.itid, start_ns, end_ns)
        if len(slices) < 2:
            return 0
        cpu_arr = np.array([s[2] for s in slices])
        return int((cpu_arr[1:] != cpu_arr[:-1]).sum())

    def get_preemption_count(self, start_ns: int, end_ns: int) -> int:
        """被抢占次数（R+状态）。"""
        slices = self._cache.sched_slice(self.itid, start_ns, end_ns)
        return sum(1 for s in slices if s[3] == 'R+')

    def get_wakeup_chain(self, start_ns: int, end_ns: int, max_depth: int = 5) -> list:
        """获取唤醒链（O(1) prev 指针跳转）。

        chain 字段 tid/from_itid/ts/prev_idx 来自 WakeupChainIndex.find_chain；
        name/process_name 由本方法补充查询。
        """
        idx = self._cache.wakeup_index()
        chain, _wake_ts_list = idx.find_chain(self.tid, start_ns, end_ns)
        for node in chain:
            from_itid = node.get("from_itid")
            if from_itid:
                meta = self._cache.thread_meta(from_itid)
                node["name"] = meta[0] if meta else ''
                node["process_name"] = (
                    self._cache.process_name(meta[2]) if meta else ''
                )
            else:
                node["name"] = ''
                node["process_name"] = ''
        return chain[:max_depth] if max_depth > 0 else chain
