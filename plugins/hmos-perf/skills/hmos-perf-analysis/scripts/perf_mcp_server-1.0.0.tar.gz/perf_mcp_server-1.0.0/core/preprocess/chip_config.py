"""芯片配置管理模块。

职责：
- 加载 config/chips/chip_database.json（全局单例缓存）
- 提供 cpuid -> sibling/cluster 查询函数
- 提供芯片匹配函数（find_chip_by_params）
- 被 smt_ops.py 和 chip_identify.py 共用
"""
from __future__ import annotations

import json
from core.observability import get_module_logger
import sqlite3
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

import pandas as pd

if TYPE_CHECKING:
    from core.preprocess.trace_data_cache import TraceDataCache

log = get_module_logger(__name__)

# ---------------------------------------------------------------------------
# 配置路径与缓存
# ---------------------------------------------------------------------------

_CONFIG_PATH = Path(__file__).parent.parent.parent / "config" / "chips" / "chip_database.json"
_chips_db: Optional[List[Dict[str, Any]]] = None

# 芯片识别结果缓存：key = (sqlite_path, mtime) → identify_chip result
_identify_cache: Dict[tuple, Dict[str, Any]] = {}

# Issue #4: 芯片配置不存在时的兜底芯片型号
_UNKNOWN_CHIP_MODEL = "Unknown_chip"

# Issue #8: 频点匹配容差(MHz)
# 工程机或受限于温控/功耗策略限频时,实测频点可能偏离 spec 1~2 MHz。
# 允许实测在 [spec_min - tol, spec_max + tol] 范围内视为匹配。
_FREQ_TOLERANCE_MHZ = 1


def _build_unknown_chip_config(cache: "TraceDataCache") -> Dict[str, Any]:
    """基于实测频点自动分组生成 Unknown 芯片配置。

    流程:
    1. 从 cache.measure('cpu_frequency', *cache.trace_range()) 取 CPU 频点 rows
       → 按 cpuid 分组,计算每核 freq_min/freq_max
       (cache.measure 已懒加载,本次调用命中缓存无 SQL 开销)
    2. 从 cache.measure('gpu_frequency', *cache.trace_range()) 取 GPU 频点 rows
       → 计算 GPU freq_max(取最大值),无数据则为 None
       (与 CPU 频点共用 trace_range 时间窗口)
    3. 基于相同 (freq_min, freq_max) 配对聚合 cluster
    4. 按 freq_max 从大到小排序 cluster
    5. 赋 compute_scale: 最大=1.0, 后续每个 * (2/3), 保留 4 位小数
       例: 3 个 cluster → 1.0, 0.6667, 0.4444
    6. cluster_name = "Unknown_Cluster_0", "Unknown_Cluster_1", ...
    7. smt_enabled = False, smt_pairs = None
    8. cpuid_range = [min(cpu_ids), max(cpu_ids)]
    9. 若 freq_rows 为空 → 回退到单 cluster0(compute_scale=1.0, freq_min/max=0),
       CPU 数从 thread_state 表 MAX(cpu)+1 获取
    """
    try:
        start_ns, end_ns = cache.trace_range()
    except Exception:
        start_ns, end_ns = 0, 0

    cpu_freq_rows = cache.measure("cpu_frequency", start_ns, end_ns) if hasattr(cache, "measure") else []
    gpu_freq_rows = cache.measure("gpu_frequency", start_ns, end_ns) if hasattr(cache, "measure") else []

    # GPU 频点取 max value
    gpu_rated_max: Optional[int] = None
    if gpu_freq_rows:
        try:
            gpu_rated_max = int(max(row[2] for row in gpu_freq_rows if row[2] is not None))
        except (ValueError, TypeError):
            gpu_rated_max = None

    # 空数据 fallback: 单 cluster0
    if not cpu_freq_rows:
        cpu_count = _get_cpu_count_from_thread_state(cache)
        safe_count = max(cpu_count, 1)
        return {
            "chip_model": _UNKNOWN_CHIP_MODEL,
            "vendor": "Unknown",
            "total_logical_cpus": safe_count,
            "clusters": [
                {
                    "cluster_name": "Unknown_Cluster_0",
                    "cpuid_range": [0, safe_count - 1],
                    "smt_enabled": False,
                    "smt_pairs": None,
                    "freq_min_mhz": 0,
                    "freq_max_mhz": 0,
                    "compute_scale": 1.0,
                }
            ],
            "gpu": {"rated_max_mhz": gpu_rated_max},
        }

    # 按 cpuid 分组,计算每核 freq_min/freq_max
    # cpu_freq_rows: [(ts, dur, value, cpu), ...]
    per_cpu: Dict[int, List[int]] = {}
    for row in cpu_freq_rows:
        # row: (ts, dur, value, cpu)
        cpu = int(row[3]) if len(row) > 3 else 0
        val = int(row[2]) if len(row) > 2 and row[2] is not None else 0
        per_cpu.setdefault(cpu, []).append(val)

    cpu_freq_summary: Dict[int, Tuple[int, int]] = {}  # cpu → (freq_min, freq_max)
    for cpu, vals in per_cpu.items():
        cpu_freq_summary[cpu] = (min(vals), max(vals))

    # 基于相同 (min, max) 配对聚合 cluster
    # key: (freq_min, freq_max), value: list of cpuid
    cluster_groups: Dict[Tuple[int, int], List[int]] = {}
    for cpu, (fmin, fmax) in cpu_freq_summary.items():
        key = (fmin, fmax)
        cluster_groups.setdefault(key, []).append(cpu)

    # 按 freq_max 从大到小排序 cluster
    sorted_clusters = sorted(
        cluster_groups.items(),
        key=lambda kv: kv[0][1],  # by freq_max
        reverse=True,
    )

    # 赋 compute_scale: 1.0, *(2/3), *(2/3)^2, ...
    clusters_out: List[Dict[str, Any]] = []
    for idx, ((fmin, fmax), cpus) in enumerate(sorted_clusters):
        compute_scale = round((2 / 3) ** idx, 4)
        cpus_sorted = sorted(cpus)
        clusters_out.append({
            "cluster_name": f"Unknown_Cluster_{idx}",
            "cpuid_range": [cpus_sorted[0], cpus_sorted[-1]],
            "smt_enabled": False,
            "smt_pairs": None,
            "freq_min_mhz": fmin,
            "freq_max_mhz": fmax,
            "compute_scale": compute_scale,
        })

    total_cpus = len(per_cpu)

    return {
        "chip_model": _UNKNOWN_CHIP_MODEL,
        "vendor": "Unknown",
        "total_logical_cpus": total_cpus,
        "clusters": clusters_out,
        "gpu": {"rated_max_mhz": gpu_rated_max},
    }


def _get_cpu_count_from_thread_state(cache: "TraceDataCache") -> int:
    """从 cache._conn 查 thread_state 表 MAX(cpu)+1 作为 CPU 数 fallback。

    优先使用 cache._conn;若不可用则尝试 cache._cpu_count_from_thread(测试替身);
    均不可用时返回 1。
    """
    try:
        # 测试替身优先:若 cache 暴露 _cpu_count_from_thread(非零),直接使用
        test_count = getattr(cache, "_cpu_count_from_thread", None)
        if test_count:
            return int(test_count)
        conn = getattr(cache, "_conn", None)
        if conn is None:
            return 1
        row = conn.execute("SELECT MAX(cpu) FROM thread_state").fetchone()
        if row and row[0] is not None:
            return int(row[0]) + 1
    except Exception:
        pass
    return 1


# ---------------------------------------------------------------------------
# 配置加载
# ---------------------------------------------------------------------------

def _load_chips_db() -> List[Dict[str, Any]]:
    """加载芯片配置库（懒加载，全局单例缓存）。"""
    global _chips_db
    if _chips_db is None:
        if not _CONFIG_PATH.exists():
            log.error("芯片配置库不存在: %s", _CONFIG_PATH)
            _chips_db = []
            return _chips_db
        with open(_CONFIG_PATH, encoding="utf-8") as f:
            data = json.load(f)
        _chips_db = data.get("chips", [])
        log.info("加载芯片配置库: %d 个芯片", len(_chips_db))
    return _chips_db


def reload_chips_db() -> None:
    """强制重新加载芯片配置库（用于热更新）。"""
    global _chips_db
    _chips_db = None
    _load_chips_db()


# ---------------------------------------------------------------------------
# cpuid 查询函数
# ---------------------------------------------------------------------------

def get_cluster_name(cpuid: int, chip_config: Dict[str, Any]) -> Optional[str]:
    """从芯片配置获取 cpuid 所属的 cluster 名称。"""
    for cl in chip_config.get("clusters", []):
        cpuid_range = cl.get("cpuid_range", [])
        if len(cpuid_range) == 2 and cpuid_range[0] <= cpuid <= cpuid_range[1]:
            return cl.get("cluster_name")
    return None


def get_sibling_cpuid(cpuid: int, chip_config: Dict[str, Any]) -> Optional[int]:
    """从芯片配置获取 cpuid 的 sibling CPU ID。

    Returns:
        sibling CPU ID（如果有 SMT）
        None（如果该核无 SMT，即 smt_enabled=false 或不在任何 smt_pairs 中）
    """
    for cl in chip_config.get("clusters", []):
        if not cl.get("smt_enabled"):
            continue
        for pair in cl.get("smt_pairs", []):
            if len(pair) != 2:
                continue
            if pair[0] == cpuid:
                return pair[1]
            if pair[1] == cpuid:
                return pair[0]
    return None


# ---------------------------------------------------------------------------
# 芯片匹配
# ---------------------------------------------------------------------------

def _extract_freq_from_df(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """从 DataFrame 提取每核频点分布（MIN/MAX）。

    DataFrame 包含 freq 类型记录，格式：{cpuid, freq, ts_start, ts_end, data_type}
    """
    freq_df = df[df["data_type"] == "freq"]
    if freq_df.empty:
        return []

    result = []
    for cpuid in sorted(freq_df["cpuid"].unique()):
        cpu_freq = freq_df[freq_df["cpuid"] == cpuid]
        result.append({
            "cpuid": int(cpuid),
            "freq_min": int(cpu_freq["freq"].min()),
            "freq_max": int(cpu_freq["freq"].max()),
        })
    return result


def _build_chip_cpuid_set(chip: Dict[str, Any]) -> set[int]:
    """从芯片配置构建其覆盖的所有 cpuid 集合。"""
    cpus: set[int] = set()
    for cl in chip.get("clusters", []):
        cpuid_range = cl.get("cpuid_range", [])
        if len(cpuid_range) == 2:
            cpus.update(range(cpuid_range[0], cpuid_range[1] + 1))
    return cpus


def _calc_freq_match(
    cpu_info: Dict[str, Any],
    clusters: List[Dict[str, Any]],
) -> tuple[bool, int]:
    """检查单个 CPU 频点是否匹配芯片配置。

    Returns:
        (is_match, max_freq_diff): is_match=False 时 max_freq_diff=-1
    """
    cpuid = cpu_info["cpuid"]
    db_min = cpu_info["freq_min"]
    db_max = cpu_info["freq_max"]

    matched_cluster = None
    for cl in clusters:
        cpuid_range = cl.get("cpuid_range", [])
        if len(cpuid_range) == 2 and cpuid_range[0] <= cpuid <= cpuid_range[1]:
            matched_cluster = cl
            break

    if not matched_cluster:
        return False, -1

    cl_min = matched_cluster.get("freq_min_mhz", 0)
    cl_max = matched_cluster.get("freq_max_mhz", 0)
    # Issue #8: 加 freq 容差,容忍工程机实测频点偏离 spec 1 MHz
    if cl_min > 0 and db_min < cl_min - _FREQ_TOLERANCE_MHZ:
        return False, -1
    if cl_max > 0 and db_max > cl_max + _FREQ_TOLERANCE_MHZ:
        return False, -1

    diff = abs(db_max - cl_max) if cl_max > 0 else 0
    return True, diff


def _iter_matching_chips(
    cpu_count: int,
    per_cpu_freq: List[Dict[str, Any]],
):
    """遍历所有匹配的芯片配置 Yeilds (chip, max_freq_diff)。"""
    chips = _load_chips_db()
    db_cpus = {cpu["cpuid"] for cpu in per_cpu_freq}

    for chip in chips:
        if chip.get("total_logical_cpus", 0) != cpu_count:
            continue

        chip_cpus = _build_chip_cpuid_set(chip)
        if chip_cpus != db_cpus:
            continue

        clusters = chip.get("clusters", [])
        max_freq_diff = 0
        for cpu_info in per_cpu_freq:
            matched, diff = _calc_freq_match(cpu_info, clusters)
            if not matched:
                max_freq_diff = -1
                break
            if diff > max_freq_diff:
                max_freq_diff = diff

        if max_freq_diff == -1:
            continue

        yield chip, max_freq_diff


def _match_chips(
    cpu_count: int,
    per_cpu_freq: List[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """按频点相似度匹配芯片配置（取最佳匹配）。"""
    candidates = list(_iter_matching_chips(cpu_count, per_cpu_freq))
    if not candidates:
        return None
    candidates.sort(key=lambda x: x[1])
    return candidates[0][0]


def _match_chips_with_details(
    cpu_count: int,
    per_cpu_freq: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """匹配芯片，返回详细信息列表（相似度分数）。"""
    result = []
    for chip, max_freq_diff in _iter_matching_chips(cpu_count, per_cpu_freq):
        similarity_score = max(0.0, 1.0 - (max_freq_diff / 5000.0))
        result.append({
            "chip_model": chip.get("chip_model"),
            "vendor": chip.get("vendor"),
            "total_logical_cpus": chip.get("total_logical_cpus"),
            "clusters": chip.get("clusters"),
            "similarity_score": round(similarity_score, 3),
            "max_freq_diff_mhz": max_freq_diff,
        })
    result.sort(key=lambda x: x["similarity_score"], reverse=True)
    return result


# ---------------------------------------------------------------------------
# 公开查询函数(从 thread_sched_ops.py 迁出 + 新增 cpuid 映射查询)
# ---------------------------------------------------------------------------

def get_top_cluster(chip_config: Dict[str, Any]) -> Dict[str, Any]:
    """返回 compute_scale 最大的 cluster 配置。

    不同芯片的 cluster 名称和数量不同,用 compute_scale 统一识别,
    避免硬编码 cluster 名。
    """
    clusters = chip_config.get("clusters", [])
    if not clusters:
        return {}
    return max(clusters, key=lambda c: c.get("compute_scale", 0))


def get_cpu_load_by_compute_scale(
    cluster_name: str, freq_mhz: float, chip_config: Dict[str, Any]
) -> float:
    """用 compute_scale 计算算力值,结果与 CpuFreqLoadInfo.get_cpu_load_by_freq 一致。

    公式：load = compute_scale * 1024 * (freq / freq_max)
    BASE 归一化基准：最大 cluster 的 compute_scale = 1.0 对应 1024。
    """
    for cluster in chip_config.get("clusters", []):
        if cluster.get("cluster_name") == cluster_name:
            freq_max = cluster.get("freq_max_mhz", 0)
            if freq_max <= 0:
                return 0.0
            return cluster.get("compute_scale", 0) * 1024 * (freq_mhz / freq_max)
    return 0.0


def get_top_cluster_max_load(chip_config: Dict[str, Any]) -> float:
    """返回 top cluster 最大算力(最高频点,不考虑限频)。"""
    top_cluster = get_top_cluster(chip_config)
    return top_cluster.get("compute_scale", 0) * 1024


def get_cpuid_cluster_map(chip_config: Dict[str, Any]) -> Dict[int, Optional[str]]:
    """从 chip_config 构建 cpuid → cluster_name 映射。"""
    result: Dict[int, Optional[str]] = {}
    for cl in chip_config.get("clusters", []):
        cpuid_range = cl.get("cpuid_range", [])
        if len(cpuid_range) == 2:
            for cpuid in range(cpuid_range[0], cpuid_range[1] + 1):
                result[cpuid] = cl.get("cluster_name")
    return result


def get_cpuid_sibling_map(chip_config: Dict[str, Any]) -> Dict[int, Optional[int]]:
    """从 chip_config 构建 cpuid → sibling_cpuid 映射(O(1) 查找)。"""
    result: Dict[int, Optional[int]] = {}
    for cl in chip_config.get("clusters", []):
        cpuid_range = cl.get("cpuid_range", [])
        if len(cpuid_range) != 2:
            continue
        for cpuid in range(cpuid_range[0], cpuid_range[1] + 1):
            result[cpuid] = None
        if not cl.get("smt_enabled"):
            continue
        for pair in cl.get("smt_pairs", []) or []:
            if len(pair) != 2:
                continue
            result[pair[0]] = pair[1]
            result[pair[1]] = pair[0]
    return result


class _DfChipAdapter:
    """Adapts a freq DataFrame to the cache interface for _build_unknown_chip_config.

    Used by find_chip_by_params / identify_chip, which still receive a df rather than a cache.
    """

    def __init__(self, df: pd.DataFrame):
        self._df = df
        self._conn = None  # _get_cpu_count_from_thread_state will return 1

    def trace_range(self):
        if self._df.empty:
            return (0, 0)
        # freq data in ns
        max_ts = int(self._df['ts'].max()) if 'ts' in self._df.columns else 0
        return (0, max_ts)

    def measure(self, filter_name, start_ns, end_ns):
        """Return freq rows for the given filter.

        Note: ignores start_ns/end_ns — _build_unknown_chip_config only uses
        per-cpu min/max freq across the full trace, not time-windowed stats.
        """
        if filter_name != 'cpu_frequency':
            return []
        # df has columns ts, dur, freq, cpuid, data_type after rename
        # Return list of (ts, dur, value, cpu)
        if 'data_type' not in self._df.columns:
            return []
        freq_df = self._df[self._df['data_type'] == 'freq']
        if freq_df.empty:
            return []
        out = []
        for _, row in freq_df.iterrows():
            ts = int(row.get('ts', 0)) if 'ts' in row else 0
            dur = int(row.get('dur', 0)) if 'dur' in row else 0
            val = int(row.get('freq', 0)) if 'freq' in row else 0
            cpu = int(row.get('cpuid', 0)) if 'cpuid' in row else 0
            out.append((ts, dur, val, cpu))
        return out


def find_chip_by_params(
    chip_model: Optional[str],
    df: pd.DataFrame,
) -> Optional[Dict[str, Any]]:
    """根据参数查找匹配的芯片配置。

    优先级：
    1. 显式传入 chip_model → 精确匹配
    2. 从 df 提取频点分布 → 频点相似度匹配

    Args:
        chip_model: 芯片型号名称（可选）
        df: DataFrame，包含 freq 和 running 记录

    Returns:
        匹配的芯片配置，或 None
    """
    # 1. 显式指定芯片名
    if chip_model:
        # Issue #4: Unknown_chip 走动态兜底，不查 chips_db
        if chip_model == _UNKNOWN_CHIP_MODEL:
            return _build_unknown_chip_config(_DfChipAdapter(df))
        chips = _load_chips_db()
        for c in chips:
            if c.get("chip_model") == chip_model:
                return c
        return None

    # 2. 自动匹配：从 df 提取频点
    cpu_count = int(df["cpuid"].max()) + 1
    per_cpu_freq = _extract_freq_from_df(df)
    return _match_chips(cpu_count, per_cpu_freq)


def get_gpu_rated_max_mhz(chip_model: Optional[str]) -> Optional[int]:
    """从芯片配置库查询 GPU 额定最大频点(MHz)。

    Args:
        chip_model: 芯片型号名(如 'TESTCHIP_B');None 或 'Unknown_chip' → 返回 None

    Returns:
        GPU 额定最大频点(MHz),配置缺失或 chip_model 未知时返回 None
    """
    if not chip_model or chip_model == _UNKNOWN_CHIP_MODEL:
        return None
    chips = _load_chips_db()
    for c in chips:
        if c.get("chip_model") == chip_model:
            gpu = c.get("gpu") or {}
            val = gpu.get("rated_max_mhz")
            return int(val) if val is not None else None
    return None


# ---------------------------------------------------------------------------
# MCP tool 用函数（完整探测，含 DB 查询）
# ---------------------------------------------------------------------------

def identify_chip(sqlite_path: str) -> Dict[str, Any]:
    """芯片识别主函数（被 MCP tool 调用）。

    完整探测流程：
    1. 查询 trace 时间范围
    2. 查询每核频点分布
    3. 与芯片配置库匹配（频点相似度）

    结果按 (sqlite_path, mtime) 缓存，避免重复 DB 查询。

    Returns:
        {
            "sqlite_path": str,
            "trace_time_range": {"start_ms", "end_ms", "duration_ms"},
            "cpu_topology": {"total_logical_cpus", "per_cpu_freq"},
            "matched_chips": [{chip_model, vendor, clusters, similarity_score}, ...]
        }
    """
    if not Path(sqlite_path).exists():
        raise FileNotFoundError(f"SQLite 数据库不存在: {sqlite_path}")

    cache_key = (str(Path(sqlite_path).resolve()), Path(sqlite_path).stat().st_mtime)
    if cache_key in _identify_cache:
        log.debug("使用缓存的芯片识别结果: %s", sqlite_path)
        return _identify_cache[cache_key]

    start_ms, end_ms = _get_trace_time_range(sqlite_path)
    cpu_count = _get_cpu_count(sqlite_path)
    per_cpu_freq = _get_cpu_freq_info(sqlite_path, start_ms, end_ms)
    matched_chips = _match_chips_with_details(cpu_count, per_cpu_freq)

    # Issue #4: 无匹配时使用 Unknown_chip 兜底，避免下游 matched_chips[0] 取值异常
    if not matched_chips:
        log.warning(
            "未匹配到芯片配置 (cpu_count=%d, per_cpu_freq=%s), "
            "使用 Unknown_chip 兜底配置 (cluster=unknown_cluster)",
            cpu_count,
            per_cpu_freq,
        )
        # 构造 adapter:per_cpu_freq 是 list of {cpuid, freq_min, freq_max}
        # 展开为 freq rows DataFrame,符合 _DfChipAdapter 期望
        _freq_rows = []
        for info in per_cpu_freq:
            cpu = int(info.get("cpuid", 0))
            fmin = int(info.get("freq_min", 0))
            fmax = int(info.get("freq_max", 0))
            # 用 2 行表示 min/max 频点,_build_unknown_chip_config 会按 cpuid 分组取 min/max
            _freq_rows.append({"ts": 0, "dur": 1000000, "freq": fmin,
                               "cpuid": cpu, "data_type": "freq"})
            _freq_rows.append({"ts": 1000000, "dur": 1000000, "freq": fmax,
                               "cpuid": cpu, "data_type": "freq"})
        _fallback_df = pd.DataFrame(_freq_rows) if _freq_rows else pd.DataFrame(
            {"ts": [], "dur": [], "freq": [], "cpuid": [], "data_type": []}
        )
        fallback = _build_unknown_chip_config(_DfChipAdapter(_fallback_df))
        matched_chips = [{
            "chip_model": fallback["chip_model"],
            "vendor": fallback["vendor"],
            "total_logical_cpus": fallback["total_logical_cpus"],
            "clusters": fallback["clusters"],
            "similarity_score": 0.0,
            "max_freq_diff_mhz": -1,
            "is_default_fallback": True,
        }]

    result = {
        "sqlite_path": sqlite_path,
        "trace_time_range": {
            "start_ms": start_ms,
            "end_ms": end_ms,
            "duration_ms": end_ms - start_ms,
        },
        "cpu_topology": {
            "total_logical_cpus": cpu_count,
            "per_cpu_freq": per_cpu_freq,
        },
        "matched_chips": matched_chips,
    }

    _identify_cache[cache_key] = result
    log.debug("芯片识别结果已缓存: %s", sqlite_path)
    return result


def clear_identify_cache() -> None:
    """清空芯片识别缓存。"""
    global _identify_cache
    _identify_cache.clear()
    log.info("芯片识别缓存已清空")


# ---------------------------------------------------------------------------
# 内部辅助函数
# ---------------------------------------------------------------------------

def _get_trace_time_range(db_path: str) -> tuple[float, float]:
    """从 trace_range 表读取时间范围（ns → ms）。"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT start_ts, end_ts FROM trace_range LIMIT 1")
        row = cursor.fetchone()
        if row and row[0] is not None and row[1] is not None:
            return float(row[0]) / 1_000_000, float(row[1]) / 1_000_000

        # 降级
        for table in ["thread", "process", "sched_slice", "thread_state", "measure"]:
            for col in ["ts", "start_ts"]:
                try:
                    cursor.execute(f"SELECT MIN({col}), MAX({col}) FROM {table}")
                    r = cursor.fetchone()
                    if r and r[0] is not None:
                        min_ts = float(r[0]) / 1_000_000
                        max_ts = float(r[1]) / 1_000_000
                        return min_ts, max_ts
                except sqlite3.Error:
                    continue
        raise ValueError(f"无法从 {db_path} 中提取 trace 时间范围")
    finally:
        conn.close()


def _get_cpu_count(db_path: str) -> int:
    """获取逻辑 CPU 总数。"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "SELECT COUNT(DISTINCT cpu) FROM cpu_measure_filter WHERE name = 'cpu_frequency'"
        )
        row = cursor.fetchone()
        if row and row[0]:
            return int(row[0])

        cursor.execute("SELECT MAX(cpu) FROM thread_state")
        row = cursor.fetchone()
        if row and row[0] is not None:
            return int(row[0]) + 1
        raise ValueError(f"无法从 {db_path} 中获取 CPU 数量")
    finally:
        conn.close()


def _get_cpu_freq_info(
    db_path: str,
    start_ms: float,
    end_ms: float,
) -> List[Dict[str, Any]]:
    """查询每核频点范围（MIN/MAX）。"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT
                cmf.cpu AS cpuid,
                MIN(m.value / 1000) AS freq_min,
                MAX(m.value / 1000) AS freq_max
            FROM measure m
            JOIN cpu_measure_filter cmf ON m.filter_id = cmf.id
            WHERE cmf.name = 'cpu_frequency'
                AND m.ts >= :start_ms * 1000000
                AND m.ts < :end_ms * 1000000
            GROUP BY cmf.cpu
            ORDER BY cpuid
        """, {"start_ms": start_ms, "end_ms": end_ms})
        return [
            {"cpuid": row[0], "freq_min": int(row[1]), "freq_max": int(row[2])}
            for row in cursor.fetchall()
        ]
    finally:
        conn.close()
