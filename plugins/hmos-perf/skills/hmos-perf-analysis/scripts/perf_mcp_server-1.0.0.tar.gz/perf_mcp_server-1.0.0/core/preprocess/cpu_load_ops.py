"""CPU 负载聚合算子（pipeline 形态）。

多核负载聚合涉及跨核数据关联，SQL 多表 JOIN 聚合 O(n²)，
Python 字典聚合 O(n)，因此采用后处理方式。

算子流水线：
    Layer 1: load_aggregate_per_core    按时间窗聚合各核的 per-core 负载
    Layer 2: load_aggregate_total       计算整体负载（所有核的算术平均值）
    Layer 3: format_cpu_load_summary    收敛为 LLM 友好的 { per_core: [...], total: [...] } 字典

CPU 负载计算逻辑：
    - 负载 = 1 - (idle_time / total_time)
    - idle 定义：end_state == 'S'（睡眠/阻塞态）
    - 活跃态：end_state in ('R', 'R+', 'D', 'X') 等
"""
from __future__ import annotations

from typing import Any, Dict, Optional

import pandas as pd

from .base import PreprocessContext, PreprocessError, register_operator

# Running 状态标识（只有 Running 才占用 CPU，但 SQL 已过滤）
_RUNNING_STATE = "Running"  # noqa: F841


# ---------------------------------------------------------------------------
# Layer 1: 按核聚合
# ---------------------------------------------------------------------------

@register_operator("load_aggregate_per_core")
def load_aggregate_per_core(ctx: PreprocessContext) -> PreprocessContext:
    """按时间窗聚合各 CPU 核的负载。

    输入:
        ctx.data: DataFrame 含列 ts / cpu / dur / state
                  - ts: 时间戳(ms)，来自 thread_state.ts / 1_000_000
                  - cpu: CPU 核 ID
                  - dur: 持续时间(ns)
                  - state: 线程状态（仅 Running 状态的行被查询）
    输出:
        ctx.data: 仍是 DataFrame
        ctx.meta["per_core"]: 各核负载列表
        ctx.meta["cpu_count"]: CPU 核数量
    params:
        time_field (str, default "ts"):        时间戳字段名
        cpu_field (str, default "cpu"):        CPU 核 ID 字段名
        dur_field (str, default "dur"):        持续时间字段名
        state_field (str, default "state"):    状态字段名（已废弃，仅保留兼容）
        window_ms (number, default 100):       时间窗大小(ms)，同窗内数据聚合
    """
    df = ctx.data
    time_field = ctx.params.get("time_field", "ts")
    cpu_field = ctx.params.get("cpu_field", "cpu")
    dur_field = ctx.params.get("dur_field", "dur")
    window_ms = float(ctx.params.get("window_ms", 100.0))

    required = {time_field, cpu_field, dur_field}
    missing = required - set(getattr(df, "columns", []))
    if missing:
        raise PreprocessError(
            f"load_aggregate_per_core 输入缺少列: {sorted(missing)}; "
            f"请确认 SQL 输出已包含 {sorted(required)}"
        )

    if not len(df):
        ctx.meta["per_core"] = []
        ctx.meta["cpu_count"] = 0
        return ctx

    df = df.copy()

    # 按时间窗分组
    if window_ms > 0:
        df["time_window"] = (df[time_field] // window_ms) * window_ms
        group_cols = [cpu_field, "time_window"]
    else:
        df["time_window"] = df[time_field]
        group_cols = [cpu_field, "time_window"]

    # 聚合每个时间窗内每个 CPU 的 Running 时长
    # 注意：这里 running_dur 已经是纳秒，ts 是 ms
    grouped = df.groupby(group_cols, as_index=False, sort=False)
    agg_df = grouped.agg(
        running_dur=(dur_field, "sum"),
    )

    # 计算每个时间窗的全局起止时间（所有 CPU 的 min/max）
    window_stats = df.groupby("time_window").agg(
        global_start=(time_field, "min"),
        global_end=(time_field, "max"),
    )
    window_stats["actual_dur_ms"] = (window_stats["global_end"] - window_stats["global_start"] + 0.1).clip(lower=0.1)
    window_stats = window_stats.reset_index()

    # 通过 merge 将 actual_dur_ms 关联到每个 (cpu, time_window) 组
    agg_df = agg_df.reset_index()
    agg_df = agg_df.merge(window_stats[["time_window", "actual_dur_ms"]], on="time_window", how="left")

    # 向量化计算负载百分比: (running_dur_ns / 1_000_000 / actual_dur_ms) * 100
    agg_df["value"] = ((agg_df["running_dur"] / 1_000_000 / agg_df["actual_dur_ms"]) * 100).clip(upper=100.0).round(2)
    agg_df = agg_df.rename(columns={"time_window": time_field})

    # 收集 CPU 核数量
    cpu_count = int(agg_df[cpu_field].nunique())
    ctx.meta["cpu_count"] = cpu_count

    # 转换为列表格式
    per_core_records = agg_df[[time_field, cpu_field, "value"]].sort_values(
        [cpu_field, time_field]
    ).to_dict(orient="records")

    ctx.meta["per_core"] = per_core_records
    ctx.data = df.drop(columns=["time_window"], errors="ignore")
    return ctx


# ---------------------------------------------------------------------------
# Layer 2: 计算整体负载
# ---------------------------------------------------------------------------

@register_operator("load_aggregate_total")
def load_aggregate_total(ctx: PreprocessContext) -> PreprocessContext:
    """计算整体 CPU 负载（所有核的算术平均值）。

    输入:
        ctx.meta["per_core"]: load_aggregate_per_core 输出的各核负载列表
        ctx.meta["cpu_count"]: CPU 核数量
    输出:
        ctx.meta["total"]: 整体负载时序列表，每条记录含 ts 和 value（平均值）
    params:
        time_field (str, default "ts"):        时间戳字段名
        cpu_field (str, default "cpu"):        CPU 核 ID 字段名
    """
    per_core = ctx.meta.get("per_core", [])
    time_field = ctx.params.get("time_field", "ts")
    cpu_field = ctx.params.get("cpu_field", "cpu")

    if not per_core:
        ctx.meta["total"] = []
        return ctx

    # 转换为 DataFrame 方便处理
    df = pd.DataFrame(per_core)

    # 按时间戳聚合：所有核负载的算术平均值
    grouped = df.groupby(time_field, as_index=False, sort=True)
    total_df = grouped.agg(**{
        cpu_field: (cpu_field, "count"),
        "value": ("value", "mean"),
    })
    total_df["value"] = total_df["value"].round(2)

    # 转换为列表格式
    ctx.meta["total"] = total_df[[time_field, "value"]].to_dict(orient="records")
    return ctx


# ---------------------------------------------------------------------------
# Layer 3: 聚合 cluster stats + hotspots
# ---------------------------------------------------------------------------

@register_operator("load_aggregate_summary")
def load_aggregate_summary(ctx: PreprocessContext) -> PreprocessContext:
    """计算 per_cluster 统计和高负载核热点。

    输入:
        ctx.meta["per_core"]: 各核负载列表
        ctx.meta["cpu_count"]: CPU 核数量
        ctx.trace_cache: 连接级 cache（提供 cluster_of(cpuid)）
    输出:
        ctx.meta["load_summary"]: 包含 avg/max/min/per_cluster/hotspots 的 dict
    """
    per_core = ctx.meta.get("per_core", [])
    cpu_count = ctx.meta.get("cpu_count", 0)

    summary: Dict[str, Any] = {
        "avg_load": None,
        "max_load": None,
        "min_load": None,
        "duration_ms": None,
        "cpu_count": cpu_count,
        "per_cluster": {},
        "hotspots": [],
    }

    if not per_core:
        ctx.meta["load_summary"] = summary
        return ctx

    total_df = ctx.meta.get("total", [])
    if total_df:
        values = [r["value"] for r in total_df]
        summary["avg_load"] = round(sum(values) / len(values), 1)
        summary["max_load"] = round(max(values), 1)
        summary["min_load"] = round(min(values), 1)
        summary["duration_ms"] = round(total_df[-1]["ts"] - total_df[0]["ts"], 1)

    # cpu → cluster 映射(从连接级 cache 获取,cache 不可用时降级到 unknown)
    cpu_cluster_map: Dict[int, Optional[str]] = {}
    cache = ctx.trace_cache
    if cache is not None:
        for cpu in range(cpu_count):
            cpu_cluster_map[cpu] = cache.cluster_of(cpu)
    else:
        for cpu in range(cpu_count):
            cpu_cluster_map[cpu] = "unknown"

    # per_cluster 聚合
    core_df = pd.DataFrame(per_core)
    if not core_df.empty:
        core_df["cluster"] = core_df["cpu"].map(cpu_cluster_map)
        for cluster, grp in core_df.groupby("cluster"):
            loads = grp["value"].tolist()
            summary["per_cluster"][cluster] = {
                "avg_load": round(sum(loads) / len(loads), 1),
                "max_load": round(max(loads), 1),
                "cpu_count": int(grp["cpu"].nunique()),
            }

    # hotspots: 平均负载 > 90% 的核 TOP3
    cpu_avg = core_df.groupby("cpu")["value"].mean().reset_index()
    cpu_avg.columns = ["cpu", "avg_load"]
    hot = cpu_avg[cpu_avg["avg_load"] > 90].sort_values("avg_load", ascending=False).head(3)
    summary["hotspots"] = [
        {"cpu": int(r["cpu"]), "avg_load": round(r["avg_load"], 1)}
        for r in hot.to_dict(orient="records")
    ]

    ctx.meta["load_summary"] = summary
    return ctx


# ---------------------------------------------------------------------------
# Layer 4: 收敛输出
# ---------------------------------------------------------------------------

@register_operator("format_cpu_load_summary")
def format_cpu_load_summary(ctx: PreprocessContext) -> PreprocessContext:
    """把 ctx.meta 中的 per_core / total / cpu_count / load_summary 收敛为 LLM 友好的最终 dict。"""
    per_core = ctx.meta.get("per_core", [])
    total = ctx.meta.get("total", [])
    cpu_count = ctx.meta.get("cpu_count", 0)
    load_summary = ctx.meta.get("load_summary", {})

    result = {
        "meta": {
            "type": "cpu_load_summary",
            "cpu_count": cpu_count,
        },
        "summary": {
            "avg_load": load_summary.get("avg_load"),
            "max_load": load_summary.get("max_load"),
            "min_load": load_summary.get("min_load"),
            "duration_ms": load_summary.get("duration_ms"),
            "cpu_count": cpu_count,
            "per_cluster": load_summary.get("per_cluster", {}),
            "hotspots": load_summary.get("hotspots", []),
        },
        "per_core": per_core,
        "total": total,
    }
    ctx.data = result
    return ctx
