"""UI 帧链路构建算子。

从 UI 渲染链路（SendVsyncTo → ReceiveVsync）重建帧数据，
支持按 uiVsyncId 或时间范围筛选，基于 frame_rate 动态计算 jank severity。

    输出格式：
{
    "ui_frames": [{
        "uiVsyncId": "uiVsyncId:12345",
        "start_ts": 51572462086670,
        "end_ts": 51572470420003,
        "dur_ms": 8.353,
        "jank_severity": "minor",
        "thread_list": [{"tid": 33461, "name": "1.ui"}],
        "process_name": "com.tencent.wechat",
        "package_name": "微信"
    }],
    "summary": {
        "total_frames": 50,
        "jank_count": 10,
        "minor_count": 5,
        "major_count": 3,
        "severe_count": 2
    }
}
"""
from __future__ import annotations

from core.observability import get_module_logger
import re
from typing import Any, Dict, List, Optional, Tuple

from .base import PreprocessContext, register_operator
from .frame_ops import load_tid_process_map
from utils.process_name import get_process_name
from .frame_rate_ops import _compute_jank_severity, _get_frame_rate_records, _match_frame_rate, clip_frame_overlaps

log = get_module_logger(__name__)

# ---------------------------------------------------------------------------
# 正则常量
# ---------------------------------------------------------------------------

# H:SendVsyncTo conn: WM_51804, now:18273727806980
# Note: some traces have space after 'now:' colon, use \s* to be tolerant
SEND_VSYNC_UI_RE = re.compile(r'H:SendVsyncTo\s+conn:\s*WM[^,]*,\s*now:\s*(\d+)')

# H:ReceiveVsync name: WM_51804 dataCount: 24bytes now:18273727806980 expectedEnd: 18273744511742 vsyncId: 12345
RECV_VSYNC_UI_RE = re.compile(
    r'H:ReceiveVsync\s+name:\s*WM[^,]*\s+dataCount:\s*\d+\s*bytes\s+now:\s*(\d+).*?expectedEnd:\s*(\d+).*?vsyncId:\s*(\d+)'
)


# ---------------------------------------------------------------------------
# 解析函数
# ---------------------------------------------------------------------------


def _parse_send_vsync(name: str) -> Optional[int]:
    """解析 SendVsyncTo conn: WM, 返回 now_value。

    Args:
        name: callstack.name 字符串

    Returns:
        now_value 或 None
    """
    if not name:
        return None
    m = SEND_VSYNC_UI_RE.search(name)
    if m:
        return int(m.group(1))
    return None


def _parse_recv_vsync(name: str) -> Optional[Tuple[int, int, str]]:
    """解析 ReceiveVsync name:WM, 返回 (now_value, expected_end, uiVsyncId)。

    Args:
        name: callstack.name 字符串

    Returns:
        (now_value, expected_end, uiVsyncId_str) 或 None
    """
    if not name:
        return None
    m = RECV_VSYNC_UI_RE.search(name)
    if m:
        now_value = int(m.group(1))
        expected_end = int(m.group(2))
        uiVsyncId_str = m.group(3)
        return (now_value, expected_end, uiVsyncId_str)
    return None


# ---------------------------------------------------------------------------
# 匹配函数
# ---------------------------------------------------------------------------


def _match_send_recv(
    send_list: List[Tuple[int, int, int, str]],
    recv_list: List[Tuple[int, int, int, str, int, str, int]],
    time_window_ns: int = 1_000_000,
) -> List[Tuple[int, int, int, str, int, str, int]]:
    """通过 now 时间戳差 < time_window_ns 匹配 SendVsyncTo 和 ReceiveVsync。

    Args:
        send_list: [(ts, now_value, tid, thread_name), ...]
        recv_list: [(ts, now_value, expected_end, uiVsyncId_str, tid, thread_name, dur), ...]
        time_window_ns: now 时间戳允许的最大偏差（默认 1ms）

    Returns:
        [(send_ts, recv_ts, expected_end, uiVsyncId_str, recv_tid, recv_thread_name, recv_dur), ...]
    """
    result: List[Tuple[int, int, int, str, int, str, int]] = []
    used_recv: set = set()

    for s_ts, s_now, _s_tid, _s_thread_name in send_list:
        best_idx = -1
        best_diff = time_window_ns + 1

        for r_idx, (r_ts, r_now, r_end, r_vsync, r_tid, r_thread_name, _r_dur) in enumerate(recv_list):
            if r_idx in used_recv:
                continue
            diff = abs(s_now - r_now)
            if diff < best_diff:
                best_diff = diff
                best_idx = r_idx

        if best_idx >= 0 and best_diff <= time_window_ns:
            used_recv.add(best_idx)
            r_ts, _r_now, r_end, r_vsync, r_tid, r_thread_name, r_dur = recv_list[best_idx]
            result.append((s_ts, r_ts, r_end, r_vsync, r_tid, r_thread_name, r_dur))

    return result


# ---------------------------------------------------------------------------
# 算子实现
# ---------------------------------------------------------------------------


@register_operator("build_ui_frames")
def build_ui_frames(ctx: PreprocessContext) -> PreprocessContext:
    """构建 UI 帧链路（SendVsyncTo → ReceiveVsync）。

    参数（来自 ctx.params）：
    - ui_vsync_ids: list | None，帧号列表 ["uiVsyncId:12345"]，非空时按帧号筛选
    - start_ts: int | None，时间范围起始 ns
    - end_ts: int | None，时间范围结束 ns
    - frame_rate: int = 60

    输出 ctx.data:
    {
        "ui_frames": [{
            "uiVsyncId": "uiVsyncId:12345",
            "start_ts": 51572462086670,
            "end_ts": 51572470420003,
            "dur_ms": 8.353,
            "jank_severity": "minor",
            "thread_list": [{"tid": 33461, "name": "1.ui"}],
            "process_name": "com.tencent.wechat",
            "package_name": "微信"
        }],
        "summary": {
            "total_frames": 50,
            "jank_count": 10,
            "minor_count": 5,
            "major_count": 3,
            "severe_count": 2
        }
    }
    """
    # sqlite_conn 为 None 时返回空数据
    if not ctx.sqlite_conn:
        ctx.data = _empty_result()
        return ctx

    conn = ctx.sqlite_conn
    params = ctx.params

    ui_vsync_ids: Optional[List[str]] = params.get("ui_vsync_ids")
    start_ts: Optional[int] = params.get("start_ts")
    end_ts: Optional[int] = params.get("end_ts")
    default_frame_rate: int = int(params.get("frame_rate", 60))
    # 优先从 ctx.meta 读取帧率记录（由上游算子注入）
    frame_rate_records: Optional[List[Dict[str, Any]]] = ctx.meta.get("frame_rate_records")
    # 如果为空，调用公共函数查询
    if not frame_rate_records:
        frame_rate_records = _get_frame_rate_records(conn)

    # 预加载 tid → process_name 映射（用于帧的 process_name/package_name 字段）
    tid_process_map = load_tid_process_map(conn)

    try:
        # -------------------- 1. 查询 SendVsyncTo（WM conn） --------------------
        send_sql = """
            SELECT c.id, c.ts, c.dur, c.name, t.tid, t.name as thread_name
            FROM callstack c
            LEFT JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE '%H:SendVsyncTo conn: WM%'
        """
        send_rows = conn.execute(send_sql).fetchall()
        log.info("build_ui_frames: SendVsyncTo 行数=%d", len(send_rows))

        send_list: List[Tuple[int, int, int, str]] = []  # (ts, now_value, tid, thread_name)
        for row in send_rows:
            _id, ts, _dur, name, tid, thread_name = row
            now_val = _parse_send_vsync(name)
            if now_val is not None:
                send_list.append((ts, now_val, tid or 0, thread_name or ""))

        # -------------------- 2. 查询 ReceiveVsync（WM name） --------------------
        recv_sql = """
            SELECT c.id, c.ts, c.dur, c.name, t.tid, t.name as thread_name
            FROM callstack c
            LEFT JOIN thread t ON c.callid = t.itid
            WHERE c.name LIKE '%H:ReceiveVsync name:WM%'
        """
        recv_rows = conn.execute(recv_sql).fetchall()
        log.info("build_ui_frames: ReceiveVsync 行数=%d", len(recv_rows))

        recv_list: List[Tuple[int, int, int, str, int, str, int]] = []  # (ts, now_value, expected_end, uiVsyncId_str, tid, thread_name, dur)
        for row in recv_rows:
            _id, ts, dur, name, tid, thread_name = row
            parsed = _parse_recv_vsync(name)
            if parsed is not None:
                now_val, expected_end, uiVsyncId_str = parsed
                recv_list.append((ts, now_val, expected_end, uiVsyncId_str, tid or 0, thread_name or "", dur or 0))

        # -------------------- 3. 匹配链路 --------------------
        matched_sr = _match_send_recv(send_list, recv_list)

        log.info(
            "build_ui_frames: 匹配结果 send=%d, recv=%d, matched_sr=%d",
            len(send_list), len(recv_list), len(matched_sr),
        )

        # -------------------- 4. 筛选 --------------------
        target_vsync_ids: Optional[set] = None
        if ui_vsync_ids:
            target_vsync_ids = set()
            for vid in ui_vsync_ids:
                vid_str = str(vid)
                numeric = vid_str.replace("uiVsyncId:", "") if vid_str.startswith("uiVsyncId:") else vid_str
                target_vsync_ids.add(numeric)

        ui_frames: List[Dict[str, Any]] = []

        for (s_ts, r_ts, expected_end, uiVsyncId_str, recv_tid, recv_thread_name, recv_dur) in matched_sr:
            # ui_vsync_ids 优先筛选
            if target_vsync_ids is not None:
                if uiVsyncId_str not in target_vsync_ids:
                    continue
            else:
                if start_ts is not None and s_ts < start_ts:
                    continue
                if end_ts is not None and s_ts > end_ts:
                    continue

            # start_ts = SendVsyncTo 的 callstack.ts
            frame_start_ts = s_ts

            # end_ts = ReceiveVsync.ts + dur
            frame_end_ts = r_ts + recv_dur  # 使用 ReceiveVsync 的实际持续时间作为帧结束时间

            dur_ms = round((frame_end_ts - frame_start_ts) / 1_000_000, 3)
            # 使用动态帧率计算 severity
            effective_rate = _match_frame_rate(frame_start_ts, frame_rate_records)
            if effective_rate is None:
                effective_rate = default_frame_rate
            severity = _compute_jank_severity(dur_ms, float(effective_rate))

            # 收集线程信息
            thread_list: List[Dict[str, Any]] = []
            if recv_tid:
                thread_list.append({"tid": recv_tid, "name": recv_thread_name})

            # UI 帧的进程名：H:ReceiveVsync name:WM 事件对应的线程所属进程
            _proc_name = tid_process_map.get(recv_tid, "") if recv_tid else ""
            ui_frames.append({
                "uiVsyncId": f"vsyncId:{uiVsyncId_str}",
                "start_ts": frame_start_ts,
                "end_ts": frame_end_ts,
                "dur_ms": dur_ms,
                "jank_severity": severity,
                "frame_rate": int(effective_rate),
                "thread_list": thread_list,
                "process_name": _proc_name,
                "package_name": get_process_name(_proc_name) if _proc_name else "",
            })

        # -------------------- 4.5 帧范围裁剪：防止流水线重叠 --------------------
        # 前一帧未完成时，当前帧的 vsync 已下发，start_ts 可能早于上一帧 end_ts，
        # 导致查询窗口包含上一帧数据。裁剪并重算 severity。
        clip_frame_overlaps(ui_frames, frame_rate_records, default_frame_rate)

        # -------------------- 5. 统计摘要 --------------------
        total_frames = len(ui_frames)
        minor_count = sum(1 for f in ui_frames if f["jank_severity"] == "minor")
        major_count = sum(1 for f in ui_frames if f["jank_severity"] == "major")
        severe_count = sum(1 for f in ui_frames if f["jank_severity"] == "severe")
        jank_count = minor_count + major_count + severe_count

        ctx.data = {
            "ui_frames": ui_frames,
            "summary": {
                "total_frames": total_frames,
                "jank_count": jank_count,
                "minor_count": minor_count,
                "major_count": major_count,
                "severe_count": severe_count,
            },
        }

        log.info(
            "build_ui_frames: 完成, total=%d, minor=%d, major=%d, severe=%d",
            total_frames, minor_count, major_count, severe_count,
        )

    except Exception as e:
        log.error("build_ui_frames: 执行失败: %s", e)
        ctx.data = _empty_result()

    return ctx


def _empty_result() -> Dict[str, Any]:
    """返回空结果结构。"""
    return {
        "ui_frames": [],
        "summary": {
            "total_frames": 0,
            "jank_count": 0,
            "minor_count": 0,
            "major_count": 0,
            "severe_count": 0,
        },
    }
