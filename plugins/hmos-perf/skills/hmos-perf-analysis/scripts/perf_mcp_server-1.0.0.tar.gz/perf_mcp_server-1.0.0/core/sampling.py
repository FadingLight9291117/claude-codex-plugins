"""通用采样与统计工具。

被 QueryEngine 调用以处理大数据返回。设计原则:
- 行数 ≤ 100：原始返回（无需调本模块）
- 100 < 行数 ≤ 500：均匀采样或 Top N
- 行数 > 500：分桶聚合（每桶含 avg/max/min/peak_point）

模块拆分目的: 让采样策略可独立测试与替换，
QueryEngine._downsample 是这里函数的薄封装。
"""
from __future__ import annotations

import statistics
from typing import Any, Iterable


# ---------------------------------------------------------------------------
# 时序分桶聚合
# ---------------------------------------------------------------------------

def timeseries_bucket_aggregate(
    rows: list[dict],
    target_count: int,
    *,
    value_field: str = "value",
    ts_field: str = "ts",
) -> list[dict]:
    """把超长时序压缩为 target_count 个桶。

    每个桶保留:
    - ts_start / ts_end: 时间区间
    - value_avg / value_max / value_min: 桶内统计
    - sample_count: 桶内原始点数
    - peak_point: 桶内尖峰点的原始记录（保留所有列）
    """
    if not rows or len(rows) <= target_count:
        return rows

    bucket_size = max(1, len(rows) // target_count)
    aggregated: list[dict] = []

    for i in range(0, len(rows), bucket_size):
        bucket = rows[i:i + bucket_size]
        values = [
            r.get(value_field, 0)
            for r in bucket
            if isinstance(r.get(value_field), (int, float))
        ]
        if not values:
            continue

        max_val = max(values)
        max_idx = values.index(max_val)
        peak_point = bucket[max_idx]

        aggregated.append({
            "ts_start": bucket[0].get(ts_field) or bucket[0].get("timestamp_ms"),
            "ts_end": bucket[-1].get(ts_field) or bucket[-1].get("timestamp_ms"),
            "value_avg": round(statistics.mean(values), 2),
            "value_max": max_val,
            "value_min": min(values),
            "sample_count": len(bucket),
            "peak_point": peak_point,
        })

    return aggregated[:target_count]


# ---------------------------------------------------------------------------
# 非时序 Top N
# ---------------------------------------------------------------------------

def top_n_by_field(
    rows: list[dict],
    n: int,
    *,
    field: str = "value",
    descending: bool = True,
) -> list[dict]:
    """按数值字段排序取 Top N。SQL 已 ORDER BY 时可直接 rows[:n]，
    本函数主要用于 SQL 未排序、需要服务端兜底的场景。"""
    if len(rows) <= n:
        return rows
    return sorted(rows, key=lambda r: r.get(field, 0), reverse=descending)[:n]


# ---------------------------------------------------------------------------
# 直方图（用于"分布"类查询的服务端预聚合）
# ---------------------------------------------------------------------------

def histogram(
    values: Iterable[float],
    bins: int = 10,
    *,
    range_min: float | None = None,
    range_max: float | None = None,
) -> list[dict]:
    """生成简单等距直方图，返回 [{bin_start, bin_end, count, ratio}]。

    Todo: 支持非等距分桶（百分位分桶、对数分桶）。
    """
    vals = list(values)
    if not vals:
        return []

    lo = range_min if range_min is not None else min(vals)
    hi = range_max if range_max is not None else max(vals)
    if lo == hi:
        return [{
            "bin_start": lo, "bin_end": hi,
            "count": len(vals), "ratio": 1.0,
        }]

    width = (hi - lo) / bins
    counts = [0] * bins
    for v in vals:
        idx = min(int((v - lo) / width), bins - 1)
        if idx < 0:
            idx = 0
        counts[idx] += 1

    total = len(vals)
    return [
        {
            "bin_start": lo + i * width,
            "bin_end": lo + (i + 1) * width,
            "count": c,
            "ratio": round(c / total, 4),
        }
        for i, c in enumerate(counts)
    ]


# ---------------------------------------------------------------------------
# 标量直接透传
# ---------------------------------------------------------------------------

def scalar_passthrough(rows: list[dict]) -> Any:
    """标量对象指标的"透传": 取首行展开为对象。"""
    if not rows:
        return {}
    return dict(rows[0])


# ---------------------------------------------------------------------------
# 入口分发器（对外暴露的统一采样接口）
# ---------------------------------------------------------------------------

def downsample(
    rows: list,
    limit: int,
    *,
    is_timeseries: bool,
    schema_type: str = "array",
) -> list:
    """根据类型分派到具体采样器。

    Todo: 支持更复杂的策略选择（如基于行数自动选 raw / sample / bucket）。
    """
    if schema_type == "object":
        return rows  # 标量对象不截断
    if len(rows) <= limit:
        return rows
    if is_timeseries:
        return timeseries_bucket_aggregate(rows, limit)
    return rows[:limit]
