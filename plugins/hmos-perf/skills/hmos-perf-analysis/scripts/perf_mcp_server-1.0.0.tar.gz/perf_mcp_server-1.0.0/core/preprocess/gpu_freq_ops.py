"""GPU 频点分布预处理算子。

包含算子（通过 ``@register_operator`` 注册）：

- ``gpu_freq_aggregate``：扫描线求 freq ∩ running 交集，按频点聚合生成 summary，
  服务 ``gpu_freq`` 指标。idle 期间（无 running 覆盖）不计入分布。
- ``gpu_freq_residency``：按 ``bucket_ms`` 分桶，每桶计算 freq ∩ running 交集的
  time-weighted 平均频点，服务 ``gpu_freq_ts`` 指标。idle 桶不输出，不 forward-fill。

输入 ``ctx.data`` 为 pandas DataFrame，列要求：
- ``ts_start`` (int, ns)：区间起点
- ``ts_end``   (int, ns)：区间终点（SQL 层已用 trace_range.end_ts 填充 NULL dur）
- ``freq_mhz`` (int, NULL for running rows)：频点值（SQL 层已从 kHz /1000 转换）
- ``data_type`` (str)：'freq' 或 'running'；'running' 行表示 GPU 处于运行态

输出：``ctx.data = {"summary": {...}, "data": [...]}``。

设计依据：``docs/superpowers/plans/2026-06-29-gpu-freq-revision.md`` 修订 3/4。
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from .base import PreprocessContext, PreprocessError, register_operator

__all__ = ["gpu_freq_aggregate", "gpu_freq_residency"]


# ---------------------------------------------------------------------------
# gpu_freq_aggregate
# ---------------------------------------------------------------------------

@register_operator("gpu_freq_aggregate")
def gpu_freq_aggregate(ctx: PreprocessContext) -> PreprocessContext:
    """扫描线求 freq ∩ running 交集，按频点聚合，生成 summary + per-freq data。

    服务指标：``gpu_freq``。

    关键点：
    - ``total_duration_ms`` = 交集时长之和（≤ running_duration_ms）
    - ``running_duration_ms`` = running 区间总时长
    - ``duration_ratio`` 分母 = running_total_ns
    - ``entry_count`` 已移除（交集后"该频点出现的区间数"语义模糊）
    - 无 running 覆盖的 idle 期间不计入分布
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame):
        raise PreprocessError("gpu_freq_aggregate: ctx.data 期望为 DataFrame")

    required_cols = {"ts_start", "ts_end", "freq_mhz", "data_type"}
    missing = required_cols - set(df.columns)
    if missing:
        raise PreprocessError(
            f"gpu_freq_aggregate: 缺少必要列: {sorted(missing)}"
        )

    # 空输入处理
    if df.empty:
        ctx.data = _empty_result()
        return ctx

    df = df.copy()
    df["ts_start"] = df["ts_start"].astype("int64")
    df["ts_end"] = df["ts_end"].astype("int64")
    df = df[df["ts_end"] > df["ts_start"]]

    df_freq = df[df["data_type"] == "freq"].copy()
    df_running = df[df["data_type"] == "running"].copy()

    # 无频点或无 running → 空结果
    if df_freq.empty or df_running.empty:
        ctx.data = _empty_result()
        return ctx

    # 扫描线求 freq ∩ running 交集
    # 收集事件：(ts, type, payload)
    # type: 'F'=freq开始, 'E'=freq结束, 'R'=running开始, 'X'=running结束
    events: List[tuple] = []
    for _, row in df_freq.iterrows():
        ts_s, ts_e, freq = int(row["ts_start"]), int(row["ts_end"]), int(row["freq_mhz"])
        if ts_e > ts_s:
            events.append((ts_s, "F", freq))
            events.append((ts_e, "E", freq))
    for _, row in df_running.iterrows():
        ts_s, ts_e = int(row["ts_start"]), int(row["ts_end"])
        if ts_e > ts_s:
            events.append((ts_s, "R", None))
            events.append((ts_e, "X", None))

    # 排序：同 ts 时，结束事件优先于开始事件（避免零长重叠）
    # 顺序：E=0, X=0, F=1, R=1
    order_map = {"E": 0, "X": 0, "F": 1, "R": 1}
    events.sort(key=lambda e: (e[0], order_map.get(e[1], 2)))

    # 扫描
    current_freq: Optional[int] = None  # None 表示无频点覆盖
    is_running = False
    last_ts: Optional[int] = None
    # 累加器：freq -> total_ns（同一频点的多段交集会累加）
    freq_dur: Dict[int, int] = {}

    for ts, typ, payload in events:
        if last_ts is not None and current_freq is not None and is_running:
            dur = ts - last_ts
            if dur > 0:
                freq_dur[current_freq] = freq_dur.get(current_freq, 0) + dur
        # 更新状态
        if typ == "F":
            current_freq = payload
        elif typ == "E":
            if current_freq == payload:
                current_freq = None
        elif typ == "R":
            is_running = True
        elif typ == "X":
            is_running = False
        last_ts = ts

    if not freq_dur:
        ctx.data = _empty_result()
        return ctx

    total_ns = sum(freq_dur.values())
    # running 总时长：单独算 df_running 的 dur 之和
    running_total_ns = int((df_running["ts_end"] - df_running["ts_start"]).sum())

    data: List[Dict[str, Any]] = []
    weighted_sum = 0
    for freq in sorted(freq_dur.keys()):
        dur_ns = freq_dur[freq]
        dur_ms = dur_ns / 1_000_000.0
        ratio = dur_ns / running_total_ns * 100 if running_total_ns > 0 else 0.0
        data.append({
            "freq_mhz": int(freq),
            "total_duration_ms": round(dur_ms, 3),
            "duration_ratio": round(ratio, 1),
        })
        weighted_sum += freq * dur_ns

    avg_freq = weighted_sum / total_ns if total_ns > 0 else 0.0

    summary = {
        "distinct_freq_count": len(data),
        "total_duration_ms": round(total_ns / 1_000_000.0, 3),
        "running_duration_ms": round(running_total_ns / 1_000_000.0, 3),
        "avg_freq_mhz": round(avg_freq, 1),
        "min_freq_mhz": int(min(freq_dur.keys())),
        "max_freq_mhz": int(max(freq_dur.keys())),
    }

    ctx.data = {"summary": summary, "data": data}
    return ctx


def _empty_result() -> Dict[str, Any]:
    """构造空结果（空输入/无 running/无 freq/无交集时使用）。"""
    return {
        "summary": {
            "distinct_freq_count": 0,
            "total_duration_ms": 0.0,
            "running_duration_ms": 0.0,
            "avg_freq_mhz": 0.0,
            "min_freq_mhz": None,
            "max_freq_mhz": None,
        },
        "data": [],
    }


# ---------------------------------------------------------------------------
# gpu_freq_residency
# ---------------------------------------------------------------------------

def _empty_residency_result() -> Dict[str, Any]:
    """构造 residency 空结果（空输入/无 running/无 freq/无交集时使用）。"""
    return {
        "summary": {
            "bucket_count": 0,
            "total_duration_ms": 0.0,
            "running_duration_ms": 0.0,
            "avg_freq_mhz": 0.0,
            "min_freq_mhz": None,
            "max_freq_mhz": None,
        },
        "data": [],
    }


@register_operator("gpu_freq_residency")
def gpu_freq_residency(ctx: PreprocessContext) -> PreprocessContext:
    """按 ``bucket_ms`` 分桶，每桶计算 freq ∩ running 交集的 time-weighted 平均频点。

    服务指标：``gpu_freq_ts``。

    关键点：
    - idle 桶（无 running 覆盖，或无 freq 重叠）不输出
    - 不 forward-fill（running 桶之间可能不连续）
    - ``bucket_count`` = 输出的 running 桶数量
    - ``total_duration_ms`` / ``running_duration_ms`` = running 区间总时长
    - 全局加权平均 = ``global_weighted_sum / global_total_overlap``
      （修正修订文档 修订 4 中的"算术平均"简化方案，正确实现跨桶 time-weighted）
    - 桶边界对齐到 ``df["ts_start"].min()``（trace 起点对齐）
    """
    df = ctx.data
    if not isinstance(df, pd.DataFrame):
        raise PreprocessError("gpu_freq_residency: ctx.data 期望为 DataFrame")

    required_cols = {"ts_start", "ts_end", "freq_mhz", "data_type"}
    missing = required_cols - set(df.columns)
    if missing:
        raise PreprocessError(
            f"gpu_freq_residency: 缺少必要列: {sorted(missing)}"
        )

    bucket_ms = ctx.params.get("bucket_ms", 10)
    try:
        bucket_ms = int(bucket_ms)
    except (TypeError, ValueError) as exc:
        raise PreprocessError(
            f"gpu_freq_residency: bucket_ms 必须为整数, got {bucket_ms!r}"
        ) from exc
    if bucket_ms <= 0:
        raise PreprocessError(
            f"gpu_freq_residency: bucket_ms must be positive, got {bucket_ms}"
        )

    bucket_ns = bucket_ms * 1_000_000

    # 空输入
    if df.empty:
        ctx.data = _empty_residency_result()
        return ctx

    df = df.copy()
    df["ts_start"] = df["ts_start"].astype("int64")
    df["ts_end"] = df["ts_end"].astype("int64")
    df = df[df["ts_end"] > df["ts_start"]]

    df_freq = df[df["data_type"] == "freq"].copy()
    df_running = df[df["data_type"] == "running"].copy()

    # 无频点或无 running → 空结果
    if df_freq.empty or df_running.empty:
        ctx.data = _empty_residency_result()
        return ctx

    t0 = int(df["ts_start"].min())
    t_end = int(df["ts_end"].max())

    # 预提取 numpy 数组以加速向量化交集计算
    freq_starts = df_freq["ts_start"].values
    freq_ends = df_freq["ts_end"].values
    freq_vals = df_freq["freq_mhz"].astype("int64").values
    run_starts = df_running["ts_start"].values
    run_ends = df_running["ts_end"].values

    running_total_ns = int((df_running["ts_end"] - df_running["ts_start"]).sum())

    data: List[Dict[str, Any]] = []
    # 记录所有"与 running 有真实交集"的原始 freq 值，用于 summary min/max。
    # 语义：min/max = GPU running 期间出现过的原始频点极值（与 gpu_freq 一致），
    # 不受 bucket 大小影响（不用 bucket 平均值的极值）。
    raw_freqs_in_running: set = set()
    global_weighted_sum = 0  # 全局加权累加（修正修订文档简化版）
    global_total_overlap = 0

    b_start = t0
    while b_start < t_end:
        b_end = min(b_start + bucket_ns, t_end)

        # freq ∩ bucket：向量化求每个 freq 区间与 [b_start, b_end] 的重叠
        f_overlap_start = np.maximum(freq_starts, b_start)
        f_overlap_end = np.minimum(freq_ends, b_end)
        f_overlap_ns = f_overlap_end - f_overlap_start
        f_mask = f_overlap_ns > 0

        if not f_mask.any():
            # 该 bucket 无 freq 覆盖 → idle 桶，不输出
            b_start = b_end
            continue

        # 对每个有重叠的 freq 区间，再与 running 求交集
        weighted_sum = 0
        total_overlap = 0
        for i in np.where(f_mask)[0]:
            fs = int(f_overlap_start[i])
            fe = int(f_overlap_end[i])
            fv = int(freq_vals[i])
            # 该 freq 段 [fs, fe] ∩ running
            r_overlap_start = np.maximum(run_starts, fs)
            r_overlap_end = np.minimum(run_ends, fe)
            r_overlap_ns = r_overlap_end - r_overlap_start
            r_mask = r_overlap_ns > 0
            if r_mask.any():
                overlap_ns = int(r_overlap_ns[r_mask].sum())
                weighted_sum += fv * overlap_ns
                total_overlap += overlap_ns
                # 该原始 freq 与 running 有交集 → 纳入极值统计
                raw_freqs_in_running.add(fv)

        if total_overlap == 0:
            # 有 freq 但无 running → idle 桶，不输出
            b_start = b_end
            continue

        avg = weighted_sum / total_overlap if total_overlap > 0 else 0.0
        avg_rounded = round(avg, 1)
        global_weighted_sum += weighted_sum
        global_total_overlap += total_overlap

        data.append({
            "ts_bucket_start": int(b_start),
            "avg_freq_mhz": avg_rounded,
        })

        b_start = b_end

    if not data:
        # 有 freq 和 running 但无重叠桶（如 freq@[0,5ms], running@[10ms,15ms]）：
        # 此处 NOT 等同于 truly-empty（空 df / 无 freq / 无 running）。
        # running_total_ns 已在 line 260 计算（非零），需保留以反映真实 running 时长。
        # 全局约束 "total_duration_ms = running total" → 二者取相同值。
        # 其余字段（bucket_count/avg/min/max/data）保持零/空。
        running_ms = round(running_total_ns / 1_000_000.0, 3)
        ctx.data = {
            "summary": {
                "bucket_count": 0,
                "total_duration_ms": running_ms,
                "running_duration_ms": running_ms,
                "avg_freq_mhz": 0.0,
                "min_freq_mhz": None,
                "max_freq_mhz": None,
            },
            "data": [],
        }
        return ctx

    # 全局 time-weighted 平均频点（修正修订文档 修订 4 的"算术平均"简化）
    overall_avg = (
        global_weighted_sum / global_total_overlap
        if global_total_overlap > 0 else 0.0
    )

    summary = {
        "bucket_count": len(data),
        "total_duration_ms": round(running_total_ns / 1_000_000.0, 3),
        "running_duration_ms": round(running_total_ns / 1_000_000.0, 3),
        "avg_freq_mhz": round(overall_avg, 1),
        # min/max 用原始频点极值（与 gpu_freq 语义一致），不受 bucket 大小影响
        "min_freq_mhz": min(raw_freqs_in_running) if raw_freqs_in_running else None,
        "max_freq_mhz": max(raw_freqs_in_running) if raw_freqs_in_running else None,
    }

    ctx.data = {"summary": summary, "data": data}
    return ctx
