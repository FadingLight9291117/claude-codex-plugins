"""Tag 指令数分析预处理算子。

将 calc_tag_instructions_v2.py 的计算逻辑封装为 @register_operator 算子，
供 analyze_tag_instructions MCP Tool 调用。
"""
from __future__ import annotations

import logging
import re
from bisect import bisect_left
from typing import Any, Dict, List, Optional, Tuple

from .base import PreprocessContext, PreprocessError, register_operator

logger = logging.getLogger(__name__)


@register_operator("find_thread")
def find_thread(ctx: PreprocessContext) -> PreprocessContext:
    """通过 thread_name 或 process_name 查找线程信息，返回 itid/tid/ipid/pid。

    参数 (ctx.params):
        sqlite_conn: SQLite 连接
        thread_name: 线程名（优先）
        process_name: 进程名（降级使用）

    输出 (ctx.data):
        {"itid": int, "tid": int, "ipid": int, "pid": int, "thread_name": str}
        未找到时 data = None
    """
    conn = ctx.params.get("sqlite_conn")
    thread_name = ctx.params.get("thread_name")
    process_name = ctx.params.get("process_name")

    if not thread_name and not process_name:
        ctx.data = None
        ctx.meta["error"] = "至少需要提供 thread_name 或 process_name"
        return ctx

    if conn is None:
        raise PreprocessError("sqlite_conn 未提供")

    cursor = conn.cursor()
    row = None

    if thread_name:
        cursor.execute(
            "SELECT itid, tid, ipid FROM thread WHERE name = ? ORDER BY itid LIMIT 1",
            (thread_name,),
        )
        row = cursor.fetchone()

    if row is None and process_name:
        cursor.execute(
            "SELECT itid, tid, ipid FROM thread WHERE name = ? AND is_main_thread = 1 ORDER BY itid LIMIT 1",
            (process_name,),
        )
        row = cursor.fetchone()

    if row is None and process_name:
        cursor.execute(
            "SELECT itid, tid, ipid FROM thread WHERE name = ? ORDER BY itid LIMIT 1",
            (process_name,),
        )
        row = cursor.fetchone()

    if row is None:
        ctx.data = None
        return ctx

    itid, tid, ipid = row

    # 获取 PID
    cursor.execute("SELECT pid FROM process WHERE ipid = ?", (ipid,))
    pid_row = cursor.fetchone()
    pid = pid_row[0] if pid_row else tid

    # Get actual thread name from thread table
    actual_thread_name = thread_name
    if not actual_thread_name:
        cursor.execute("SELECT name FROM thread WHERE itid = ?", (itid,))
        tn_row = cursor.fetchone()
        if tn_row:
            actual_thread_name = tn_row[0]

    ctx.data = {
        "itid": itid,
        "tid": tid,
        "ipid": ipid,
        "pid": pid,
        "thread_name": actual_thread_name or process_name,
    }
    return ctx


@register_operator("query_tag_intervals")
def query_tag_intervals(ctx: PreprocessContext) -> PreprocessContext:
    """查询指定线程上匹配 tag_pattern 的 callstack 区间。

    参数 (ctx.params):
        sqlite_conn: SQLite 连接
        itid: 线程 itid
        tag_pattern: LIKE 模式字符串（如 "H:UI skip%"）

    输出 (ctx.data):
        {"intervals": {id: (ts, end_ts, name), ...}, "count": int}
    """
    conn = ctx.params.get("sqlite_conn")
    itid = ctx.params.get("itid")
    tag_pattern = ctx.params.get("tag_pattern")

    if conn is None:
        raise PreprocessError("sqlite_conn 未提供")

    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, ts, dur, name FROM callstack WHERE callid = ? AND name LIKE ? AND dur IS NOT NULL AND dur > 0",
        (itid, tag_pattern),
    )

    intervals: Dict[int, tuple] = {}
    for id_val, ts, dur, name in cursor.fetchall():
        intervals[id_val] = (ts, ts + dur, name)

    ctx.data = {
        "intervals": intervals,
        "count": len(intervals),
    }
    return ctx


@register_operator("map_child_to_parent")
def map_child_to_parent(ctx: PreprocessContext) -> PreprocessContext:
    """将子 tag 映射到时间上包含它的父 tag（取最大 depth 的父 tag）。

    参数 (ctx.params):
        sqlite_conn: SQLite 连接
        itid: 线程 itid
        child_tag_pattern: 子 tag 的 LIKE 模式（如 "H:UI skip%"）
        parent_tag_pattern: 父 tag 的 LIKE 模式（如 "H:ReceiveVsync%"）
        abnormal_dur_ns: 异常阈值（ns），dur >= 此值的父 tag 记为异常

    输出 (ctx.data):
        {
            "child_intervals": {child_id: (ts, end_ts, parent_id_or_None), ...},
            "child_count": int,
            "parent_intervals": {parent_id: (ts, end_ts, name), ...},
            "parent_count": int,
            "mapped_count": int,
            "abnormal_count": int,
        }
    """
    conn = ctx.params.get("sqlite_conn")
    itid = ctx.params.get("itid")
    child_tag_pattern = ctx.params.get("child_tag_pattern")
    parent_tag_pattern = ctx.params.get("parent_tag_pattern")
    abnormal_dur_ns = ctx.params.get("abnormal_dur_ns", 4_000_000_000)

    if conn is None:
        raise PreprocessError("sqlite_conn 未提供")

    cursor = conn.cursor()

    # Step 1: Query child tags
    cursor.execute(
        "SELECT id, ts, dur FROM callstack WHERE callid = ? AND name LIKE ? AND dur IS NOT NULL AND dur > 0",
        (itid, child_tag_pattern),
    )
    child_intervals: Dict[int, tuple] = {}
    for id_val, ts, dur in cursor.fetchall():
        child_intervals[id_val] = (ts, ts + dur, None)

    # Step 2: Query parent tags filtered by abnormal_dur (dur < abnormal_dur_ns)
    cursor.execute(
        "SELECT id, ts, dur, name FROM callstack WHERE callid = ? AND name LIKE ? AND dur IS NOT NULL AND dur > 0 AND dur < ? ORDER BY ts",
        (itid, parent_tag_pattern, abnormal_dur_ns),
    )
    parent_rows = cursor.fetchall()

    # Step 3: Count abnormal parents (dur >= abnormal_dur_ns)
    cursor.execute(
        "SELECT COUNT(*) FROM callstack WHERE callid = ? AND name LIKE ? AND dur IS NOT NULL AND dur > 0 AND dur >= ?",
        (itid, parent_tag_pattern, abnormal_dur_ns),
    )
    abnormal_count = cursor.fetchone()[0]

    # Step 4: Build parent_intervals dict from rows
    parent_intervals: Dict[int, tuple] = {}
    for pid_val, ts, dur, name in parent_rows:
        parent_intervals[pid_val] = (ts, ts + dur, name)

    # Step 5: Get depth for parent tag ids
    parent_ids = list(parent_intervals.keys())
    if parent_ids:
        placeholder = ",".join("?" * len(parent_ids))
        cursor.execute(
            f"SELECT id, depth FROM callstack WHERE id IN ({placeholder})",
            parent_ids,
        )
        parent_depths = {row[0]: row[1] for row in cursor.fetchall()}
    else:
        parent_depths = {}

    # Step 6: For each child, find the parent that time-contains it with max depth
    # Optimization: parent_rows are already sorted by ts (from SQL ORDER BY ts),
    # so build a sorted list for binary search instead of O(N*M) scanning.
    parent_sorted: List[Tuple[int, int, int]] = []  # (start_ts, end_ts, parent_id)
    for parent_id, (v_ts, v_end, _) in parent_intervals.items():
        parent_sorted.append((v_ts, v_end, parent_id))
    parent_sorted.sort(key=lambda x: x[0])  # sort by start_ts

    mapped_count = 0
    tag_to_parent: Dict[int, int] = {}
    for child_id, (s_ts, s_end, _) in child_intervals.items():
        best_parent_id = None
        best_depth = -1
        # Binary search: find the rightmost parent whose start_ts <= s_ts
        lo, hi = 0, len(parent_sorted)
        while lo < hi:
            mid = (lo + hi) // 2
            if parent_sorted[mid][0] <= s_ts:
                lo = mid + 1
            else:
                hi = mid
        # Scan candidates from lo-1 backwards while start_ts <= s_ts
        # (parents that start before or at s_ts and end after or at s_end)
        for j in range(lo - 1, -1, -1):
            v_ts, v_end, parent_id = parent_sorted[j]
            if v_end < s_end:
                continue  # parent doesn't fully contain child
            # v_ts <= s_ts (guaranteed by binary search) and v_end >= s_end
            d = parent_depths.get(parent_id, 0)
            if d > best_depth:
                best_depth = d
                best_parent_id = parent_id
        if best_parent_id is not None:
            child_intervals[child_id] = (s_ts, s_end, best_parent_id)
            tag_to_parent[child_id] = best_parent_id
            mapped_count += 1

    # Step 7: Filter parent_intervals to only include matched parents (deduplicate by parent_id)
    matched_parent_ids = set(tag_to_parent.values())
    filtered_parent_intervals: Dict[int, tuple] = {}
    for pid_val in matched_parent_ids:
        if pid_val in parent_intervals:
            filtered_parent_intervals[pid_val] = parent_intervals[pid_val]

    ctx.data = {
        "child_intervals": child_intervals,
        "child_count": len(child_intervals),
        "parent_intervals": filtered_parent_intervals,
        "parent_count": len(filtered_parent_intervals),
        "mapped_count": mapped_count,
        "abnormal_count": abnormal_count,
    }
    return ctx


# ---------------------------------------------------------------------------
# calc_tag_instructions
# ---------------------------------------------------------------------------

def _calc_instructions_for_intervals(
    intervals: Dict[int, Tuple[int, int, str]],
    sched_rows: List[Tuple[int, Optional[int]]],
    perf_rows: List[Tuple[int, int]],
) -> Tuple[Dict[int, int], int]:
    """计算每个 tag 区间内的指令数。

    算法：
    1. 预排序 perf_rows 的时间戳用于二分查找
    2. 对每个 tag 区间，找到与之一期重叠的 sched_slice
    3. 计算交集: [max(sched_ts, tag_ts), min(sched_end, tag_end)]
    4. 在交集中匹配 perf_sample，取完整 event_count（不做插值）

    返回 (interval_instr, total_instr)
    """
    # Pre-sort perf_rows by timestamp for bisect
    perf_rows_sorted = sorted(perf_rows, key=lambda r: r[0])
    perf_timestamps: List[int] = [r[0] for r in perf_rows_sorted]

    interval_instr: Dict[int, int] = {}

    for id_val, (tag_start, tag_end, _name) in intervals.items():
        total = 0
        # Track which perf samples have been counted to avoid double-counting
        # within THIS tag interval. Note: used_perf_indices is per-interval by design —
        # the same perf sample may belong to multiple tag intervals and should be
        # counted independently for each (each tag interval measures its own instruction
        # cost, even if time ranges overlap).
        used_perf_indices: set = set()

        for sched_ts, sched_dur in sched_rows:
            if sched_dur is None:
                continue
            sched_end = sched_ts + sched_dur
            # Compute intersection
            inter_start = max(sched_ts, tag_start)
            inter_end = min(sched_end, tag_end)
            if inter_start >= inter_end:
                continue

            # Find perf samples in this intersection using bisect
            lo = 0
            hi = len(perf_timestamps)
            start_idx = bisect_left(perf_timestamps, inter_start, lo, hi)
            end_idx = bisect_left(perf_timestamps, inter_end, start_idx, hi)

            for idx in range(start_idx, end_idx):
                if idx not in used_perf_indices:
                    used_perf_indices.add(idx)
                    total += perf_rows_sorted[idx][1]

        interval_instr[id_val] = total

    total_instr = sum(interval_instr.values())
    return interval_instr, total_instr


@register_operator("calc_tag_instructions")
def calc_tag_instructions(ctx: PreprocessContext) -> PreprocessContext:
    """计算每个 tag 区间内的 CPU 指令数。

    参数 (ctx.params):
        intervals: {id: (start_ts, end_ts, name), ...}
        sched_rows: [(ts, dur), ...] — sched_slice 记录
        perf_rows: [(timestamp_trace, event_count), ...] — perf_sample 记录

    输出 (ctx.data):
        {"interval_instr": {id: instr_count, ...}, "total_instr": int}
    """
    intervals: Dict[int, Tuple[int, int, str]] = ctx.params.get("intervals", {})
    sched_rows: List[Tuple[int, Optional[int]]] = ctx.params.get("sched_rows", [])
    perf_rows: List[Tuple[int, int]] = ctx.params.get("perf_rows", [])

    interval_instr, total_instr = _calc_instructions_for_intervals(
        intervals, sched_rows, perf_rows
    )

    ctx.data = {
        "interval_instr": interval_instr,
        "total_instr": total_instr,
    }
    return ctx


# ---------------------------------------------------------------------------
# compute_sample_entries
# ---------------------------------------------------------------------------

def _compute_sample_entries(
    intervals: Dict[int, Tuple[int, int, str]],
    interval_instr: Dict[int, int],
    id_pattern: Optional[str],
) -> Tuple[Optional[List], Optional[List], Optional[List], int, bool, Optional[str], Optional[str]]:
    """从 interval_instr 中提取样本条目（max/avg/min/zero_count）。

    算法：
    1. 若无 id_pattern，自动从 tag name 检测 id 相关字段
    2. 分离 non_zero 和 zero entries
    3. 用 id_pattern 提取标识符；若所有非零条目的标识符相同，回退到绝对时间戳(s)
    4. 排序 non_zero by instruction count
    5. max_entry / avg_entry / min_entry
    6. zero_count

    返回 (max_entry, avg_entry, min_entry, zero_count, id_fallback,
            auto_id_pattern, auto_id_label)
    - id_fallback=True 表示提取的标识符全部相同，已回退到绝对时间戳(s)
    - auto_id_pattern/auto_id_label: 自动检测到的 id 信息（仅当 id_pattern 未提供时）
    """
    # Auto-detect id from tag names if id_pattern not provided
    auto_id_pattern = None
    auto_id_label = None
    if not id_pattern:
        auto_id_pattern, auto_id_label = _auto_detect_id_from_tags(intervals)
        id_pattern = auto_id_pattern

    non_zero: List[Tuple[int, str, int]] = []
    zero_count = 0

    for id_val, (start, end, name) in intervals.items():
        count = interval_instr.get(id_val, 0)
        if count > 0:
            non_zero.append((id_val, name, count))
        else:
            zero_count += 1

    if not non_zero:
        return None, None, None, zero_count, False, auto_id_pattern, auto_id_label

    # Extract identifiers and check if all identical → fallback to absolute timestamp
    def _extract_identifier(id_val: int, name: str) -> str:
        if id_pattern:
            m = re.search(id_pattern, name)
            if m:
                return m.group(1)
        ts = intervals[id_val][0]  # nanosecond absolute timestamp
        if ts == 0:
            logger.warning("callstack ts=0 for id=%d, cannot produce absolute timestamp; falling back to callstack id", id_val)
            return str(id_val)
        return f"{ts / 1e9:.6f}"

    extracted_ids = [_extract_identifier(id_val, name) for id_val, name, _ in non_zero]
    unique_ids = set(extracted_ids)
    id_fallback = len(unique_ids) == 1 and id_pattern is not None

    # Sort by instruction count
    non_zero.sort(key=lambda x: x[2])

    # Build entry: if id_fallback, use absolute timestamp(s) instead of extracted identifier
    def _make_entry(id_val: int, name: str, count: int) -> List:
        if id_fallback:
            ts = intervals[id_val][0]  # nanosecond absolute timestamp
            if ts == 0:
                logger.warning("callstack ts=0 for id=%d, cannot produce absolute timestamp; falling back to callstack id", id_val)
                identifier = str(id_val)
            else:
                identifier = f"{ts / 1e9:.6f}"
        else:
            identifier = _extract_identifier(id_val, name)
        return [identifier, count]

    # min: first in sorted list
    min_id, min_name, min_count = non_zero[0]
    min_entry = _make_entry(min_id, min_name, min_count)

    # max: last in sorted list
    max_id, max_name, max_count = non_zero[-1]
    max_entry = _make_entry(max_id, max_name, max_count)

    # avg: entry closest to the average of non-zero values
    avg_val = sum(x[2] for x in non_zero) / len(non_zero)
    avg_item = min(non_zero, key=lambda x: abs(x[2] - avg_val))
    avg_id, avg_name, avg_count = avg_item
    avg_entry = _make_entry(avg_id, avg_name, avg_count)

    return max_entry, avg_entry, min_entry, zero_count, id_fallback, auto_id_pattern, auto_id_label


@register_operator("compute_sample_entries")
def compute_sample_entries(ctx: PreprocessContext) -> PreprocessContext:
    """从 interval_instr 中提取样本条目（max/avg/min/zero_count）。

    参数 (ctx.params):
        intervals: {id: (start_ts, end_ts, name), ...}
        interval_instr: {id: instr_count, ...}
        id_pattern: 正则表达式用于从 tag name 中提取 identifier

    输出 (ctx.data):
        {
            "max_entry": [identifier, count] | None,
            "avg_entry": [identifier, count] | None,
            "min_entry": [identifier, count] | None,
            "zero_count": int,
            "id_fallback": bool,
            "auto_id_pattern": str | None,
            "auto_id_label": str | None,
        }
    """
    intervals: Dict[int, Tuple[int, int, str]] = ctx.params.get("intervals", {})
    interval_instr: Dict[int, int] = ctx.params.get("interval_instr", {})
    id_pattern: Optional[str] = ctx.params.get("id_pattern")

    max_entry, avg_entry, min_entry, zero_count, id_fallback, auto_id_pattern, auto_id_label = _compute_sample_entries(
        intervals, interval_instr, id_pattern
    )

    ctx.data = {
        "max_entry": max_entry,
        "avg_entry": avg_entry,
        "min_entry": min_entry,
        "zero_count": zero_count,
        "id_fallback": id_fallback,
        "auto_id_pattern": auto_id_pattern,
        "auto_id_label": auto_id_label,
    }
    return ctx


# ---------------------------------------------------------------------------
# format_tag_instruction_markdown
# ---------------------------------------------------------------------------

def _strip_tag_label(pattern: str) -> str:
    """从 tag_pattern 中移除 H: 前缀和 % 后缀，用于显示。

    例: "H:UI skip%" → "UI skip", "H:ReceiveVsync%" → "ReceiveVsync"
    """
    label = pattern
    if label.startswith("H:"):
        label = label[2:]
    if label.endswith("%"):
        label = label[:-1]
    return label


def _extract_id_label(id_pattern: Optional[str], id_label: Optional[str] = None) -> str:
    """确定样本标识符的列标题名称。

    优先级:
    1. id_label 显式指定 → 直接使用
    2. 从 id_pattern 正则推导 → 提取首个捕获组前的标识符部分
    3. 无 id_pattern → 回退到 "绝对时间(s)"

    例:
      id_label="vsyncId" → "vsyncId"
      id_pattern="vsyncId:(\\d+)" → "vsyncId"
      id_pattern=": (\\d+)" → "ID"（无法提取字母前缀时回退）
      id_pattern=None → "绝对时间(s)"
    """
    if id_label:
        return id_label
    if not id_pattern:
        return "绝对时间(s)"
    # Try to extract the identifier name before the first '(' or '['
    m = re.match(r'^([a-zA-Z_]\w*)', id_pattern)
    return m.group(1) if m else "ID"


def _auto_detect_id_from_tags(
    intervals: Dict[int, Tuple[int, int, str]],
) -> Tuple[Optional[str], Optional[str]]:
    """从 tag name 列表中自动检测 id 相关字段，返回 (id_pattern, id_label)。

    检测规则: 在 tag name 中查找以 "id"/"Id"/"ID" 结尾的键名，
    按 key:value / key[value] / key=value 格式匹配。
    要求键名以 id 结尾，避免匹配 "Valid"、"Provider" 等仅包含 id 的词。

    例:
      "ReceiveVsync name:rs vsyncId:1068453, fd:17" → ("vsyncId:(\\d+)", "vsyncId")
      "RSUniRender:...nodeId[7090991005696]..." → ("nodeId\\[(\\d+)\\]", "nodeId")
      "RSSurfaceRenderNodeDrawable::OnDraw...id:108108621807617..." → ("id:(\\d+)", "id")

    扫描 tag name 列表，找到第一个含 id 的键即返回。
    未找到则返回 (None, None)。
    """
    seen_keys = set()
    for (_start, _end, name) in intervals.values():
        # Find keys ending with "id"/"Id"/"ID" (e.g. "vsyncId", "nodeId", "id")
        # Avoids false positives like "Valid", "Provider" which merely contain "id"
        for m in re.finditer(r'(\b\w*(?:[Ii][Dd]|[Ii]d))\s*[:=\[]', name):
            key = m.group(1)
            if key in seen_keys:
                continue
            seen_keys.add(key)
            # Determine delimiter and build pattern
            after = name[m.end() - 1]  # the char after key: ':', '=', or '['
            if after == '[':
                return rf'{key}\[(\d+)\]', key
            elif after == '=':
                return rf'{key}=(\d+)', key
            else:  # ':' or space+':'
                return rf'{key}:(\d+)', key
    return None, None


def _determine_id_label(
    results: List[Dict[str, Any]],
    id_pattern: Optional[str],
    id_label_param: Optional[str],
    fallback_key: str,
) -> str:
    """确定样本标识符的列标题名称（含 auto_detect + id_fallback 逻辑）。

    优先级:
    1. id_label 显式指定 → 直接使用
    2. 从 results 中 auto_detect 的 id_label（仅当 id_pattern 未提供时）
    3. 从 id_pattern 正则推导
    4. 回退到 "绝对时间(s)"
    若 id_fallback=True（标识符全同），强制回退到 "绝对时间(s)"。
    """
    # If explicit id_label provided, use it (but still check fallback)
    if id_label_param:
        base_label = id_label_param
    elif not id_pattern:
        # Try auto-detect from results (check mode-prefixed key first)
        auto_label = None
        for r in results:
            # child_and_parent mode stores as "parent_auto_id_label",
            # single_tag mode stores as "auto_id_label"
            al = r.get("parent_auto_id_label") or r.get("auto_id_label")
            if al:
                auto_label = al
                break
        base_label = auto_label if auto_label else "绝对时间(s)"
    else:
        base_label = _extract_id_label(id_pattern)

    # If id_fallback triggered, override to 绝对时间(s)
    if any(r.get(fallback_key) for r in results):
        return "绝对时间(s)"

    return base_label


def _format_entry(entry: Optional[List]) -> Tuple[Optional[str], Optional[str]]:
    """格式化 entry 为 (identifier, instructions_str)。

    entry 格式: ["1234399", 159380] 或 None。
    返回 (identifier, "159,380") 或 (None, None)。
    """
    if entry is None:
        return None, None
    identifier = str(entry[0])
    instr = f"{entry[1]:,}"
    return identifier, instr


@register_operator("format_tag_instruction_markdown")
def format_tag_instruction_markdown(ctx: PreprocessContext) -> PreprocessContext:
    """生成 Tag 指令数分析的 Markdown 报告。

    参数 (ctx.params):
        results: list of result dicts (from query_metrics or pipeline)
        params: query params dict with query_mode, tag_pattern, etc.

    输出 (ctx.data):
        {"markdown": str}
    """
    results: List[Dict[str, Any]] = ctx.params.get("results", [])
    params: Dict[str, Any] = ctx.params.get("params", {})

    query_mode = params.get("query_mode", "single_tag")
    child_tag_pattern = params.get("child_tag_pattern", "")
    parent_tag_pattern = params.get("parent_tag_pattern", "")
    child_id_pattern = params.get("child_id_pattern")
    parent_id_pattern = params.get("parent_id_pattern")
    tag_pattern = params.get("tag_pattern", "")
    id_pattern = params.get("id_pattern")

    # Build parameter summary — match calc_tag_instructions_v2.py format
    param_lines = []
    if query_mode == "child_and_parent":
        param_lines.append(f"- 子标签: `{child_tag_pattern}`")
        if child_id_pattern:
            param_lines.append(f"- 子标签标识符提取: `{child_id_pattern}`")
        param_lines.append(f"- 父标签: `{parent_tag_pattern}`")
        if parent_id_pattern:
            param_lines.append(f"- 父标签标识符提取: `{parent_id_pattern}`")
    if query_mode == "single_tag":
        param_lines.append(f"- **Tag 模式**: {tag_pattern}")
        if id_pattern:
            param_lines.append(f"- **ID 正则**: `{id_pattern}`")

    if not param_lines:
        param_lines.append("- **Query Mode**: " + query_mode)

    # Header
    lines = []
    target_name = params.get("process_name", "") or params.get("thread_name", "")
    lines.append(f"# {target_name} Tag 指令数分析" if target_name else "# Tag 指令数分析")
    lines.append("")
    lines.append(f"- 目标进程/线程: `{target_name}`")
    lines.append(f"- 查询模式: `{query_mode}`")
    for pl in param_lines:
        lines.append(pl)
    lines.append(f"- 分析 trace 数量: {len(results)}")
    lines.append("")
    lines.append("## 各 Trace 详情")
    lines.append("")

    # Build detail table
    if query_mode == "single_tag":
        _build_single_tag_table(lines, results, params)
    else:
        _build_child_parent_table(lines, results, params)

    # Summary table
    _build_summary_table(lines, results, query_mode, params)

    ctx.data = {"markdown": "\n".join(lines)}
    return ctx


def _build_single_tag_table(
    lines: List[str],
    results: List[Dict[str, Any]],
    params: Dict[str, Any],
):
    """构建 single_tag 模式的详情表格。"""
    tag_pattern = params.get("tag_pattern", "")
    id_pattern = params.get("id_pattern")
    id_label_param = params.get("id_label")
    tag_label = _strip_tag_label(tag_pattern)

    # Determine id_label: explicit > auto_detect > derive from pattern > 绝对时间(s)
    # Also consider id_fallback
    id_label_final = _determine_id_label(results, id_pattern, id_label_param, "id_fallback")

    # Build header — column format: 最大指令数 {tag_label}.{id_label_final}
    header_parts = ["Trace", "进程名", "PID", "线程名", "TID", "线程指令数"]
    header_parts.append(f"{tag_label} 次数")
    header_parts.append(f"{tag_label} 指令数")
    header_parts.append(f"{tag_label} 占比")
    header_parts.append("零值次数")
    sample_label = f"{tag_label}.{id_label_final}"
    header_parts.extend([
        f"最大指令数 {sample_label}", "最大指令数",
        f"平均指令数 {sample_label}", "平均指令数",
        f"最小指令数 {sample_label}", "最小指令数",
    ])
    header = " | ".join(header_parts)

    separator = " | ".join(["---"] * len(header_parts))

    lines.append("| " + header + " |")
    lines.append("| " + separator + " |")

    # Data rows
    for r in results:
        row = [
            r.get("trace_file", ""),
            r.get("process_name", ""),
            str(r.get("pid", "")),
            r.get("thread_name", ""),
            str(r.get("tid", "")),
            f"{r.get('thread_total', 0):,}",
            str(r.get("tag_count", 0)),
            f"{r.get('total_instr', 0):,}",
            f"{r.get('pct', 0):.2f}%",
            str(r.get("zero_count", 0)),
        ]
        max_id, max_instr = _format_entry(r.get("max_entry"))
        avg_id, avg_instr = _format_entry(r.get("avg_entry"))
        min_id, min_instr = _format_entry(r.get("min_entry"))
        row.extend([
            max_id or "", max_instr or "",
            avg_id or "", avg_instr or "",
            min_id or "", min_instr or "",
        ])
        lines.append("| " + " | ".join(row) + " |")

    lines.append("")


def _build_child_parent_table(
    lines: List[str],
    results: List[Dict[str, Any]],
    params: Dict[str, Any],
):
    """构建 child_and_parent 模式的详情表格。"""
    child_tag_pattern = params.get("child_tag_pattern", "")
    parent_tag_pattern = params.get("parent_tag_pattern", "")
    parent_id_pattern = params.get("parent_id_pattern")
    parent_id_label_param = params.get("parent_id_label")

    child_label = _strip_tag_label(child_tag_pattern)
    parent_label = _strip_tag_label(parent_tag_pattern)
    parent_id_label_final = _determine_id_label(
        results, parent_id_pattern, parent_id_label_param, "parent_id_fallback"
    )

    # Column order: Trace / 进程名 / PID / 线程名 / TID / 线程指令数
    sample_label = f"{parent_label}.{parent_id_label_final}"
    header_parts = ["Trace", "进程名", "PID", "线程名", "TID", "线程指令数"]
    header_parts.append(f"{child_label} 次数")
    header_parts.append(f"{parent_label} 次数")
    header_parts.append(f"{parent_label} 指令数")
    header_parts.append(f"{parent_label} 占比")
    header_parts.extend([
        f"最大指令数 {sample_label}", "最大指令数",
        f"平均指令数 {sample_label}", "平均指令数",
        f"最小指令数 {sample_label}", "最小指令数",
    ])

    header = " | ".join(header_parts)
    separator = " | ".join(["---"] * len(header_parts))

    lines.append("| " + header + " |")
    lines.append("| " + separator + " |")

    for r in results:
        src = " (hiperf)" if r.get("use_hiperf") else ""
        row = [
            f"{r.get('trace_file', '')}{src}",
            r.get("process_name", ""),
            str(r.get("pid", "")),
            r.get("thread_name", ""),
            str(r.get("tid", "")),
            f"{r.get('thread_total', 0):,}",
            str(r.get("child_tag_count", 0)),
            str(r.get("parent_tag_count", 0)),
            f"{r.get('parent_total_instr', 0):,}",
            f"{r.get('parent_pct', 0):.2f}%",
        ]
        max_id, max_instr = _format_entry(r.get("parent_max_entry"))
        avg_id, avg_instr = _format_entry(r.get("parent_avg_entry"))
        min_id, min_instr = _format_entry(r.get("parent_min_entry"))
        row.extend([
            max_id or "", max_instr or "",
            avg_id or "", avg_instr or "",
            min_id or "", min_instr or "",
        ])
        lines.append("| " + " | ".join(row) + " |")

    lines.append("")


def _build_summary_table(
    lines: List[str],
    results: List[Dict[str, Any]],
    query_mode: str,
    params: Dict[str, Any],
):
    """构建汇总表格。"""
    if not results:
        return

    if query_mode == "single_tag":
        sum_thread = sum(r.get("thread_total", 0) for r in results)
        sum_count = sum(r.get("tag_count", 0) for r in results)
        sum_instr = sum(r.get("total_instr", 0) for r in results)
        lines.append("## 汇总")
        lines.append("")
        lines.append("| 指标 | 值 |")
        lines.append("|---|---|")
        lines.append(f"| Trace 数量 | {len(results)} |")
        lines.append(f"| 线程总指令数 | {sum_thread:,} |")
        lines.append(f"| Tag 总次数 | {sum_count:,} |")
        lines.append(f"| Tag 总指令数 | {sum_instr:,} |")
        lines.append(f"| Tag 指令数占比 | {sum_instr / sum_thread * 100:.2f}% |" if sum_thread else "| Tag 指令数占比 | 0.00% |")
    else:
        child_label = _strip_tag_label(params.get("child_tag_pattern", ""))
        parent_label = _strip_tag_label(params.get("parent_tag_pattern", ""))
        sum_thread = sum(r.get("thread_total", 0) for r in results)
        sum_child_count = sum(r.get("child_tag_count", 0) for r in results)
        sum_parent_count = sum(r.get("parent_tag_count", 0) for r in results)
        sum_parent_instr = sum(r.get("parent_total_instr", 0) for r in results)
        lines.append("## 汇总")
        lines.append("")
        lines.append("| 指标 | 值 |")
        lines.append("|---|---|")
        lines.append(f"| Trace 数量 | {len(results)} |")
        lines.append(f"| 线程总指令数 | {sum_thread:,} |")
        lines.append(f"| {child_label} 总次数 | {sum_child_count:,} |")
        lines.append(f"| {parent_label} 总次数 | {sum_parent_count:,} |")
        lines.append(f"| {parent_label} 总指令数 | {sum_parent_instr:,} |")
        lines.append(f"| {parent_label} 指令数占比 | {sum_parent_instr / sum_thread * 100:.2f}% |" if sum_thread else f"| {parent_label} 指令数占比 | 0.00% |")

    lines.append("")
