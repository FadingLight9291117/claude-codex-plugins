"""perf-mcp-server MCP 启动入口。

对外暴露 9 个 Tool（4 个原子工具 + 5 个元数据/查询工具）:
- get_hitrace_path        原子：获取 trace 文件路径
- convert_hitrace_to_sqlite 原子：systrace → SQLite，并返回 trace_meta
- analyze_frame_drops     原子：识别丢帧区间
- analyze_launch_phases   原子：拆解启动阶段
- list_indicators         元数据：发现指标目录（含 sql_params / result_schema）
- query_metrics           统一查询：批量查询 80+ 指标
- compare_process_instructions 一键对比：基线 vs 当前版本逐步骤进程/线程指令数，生成 CSV
- get_skill_catalog       元数据：发现工作流列表（含 routing_table）
- get_skill               元数据：获取工作流完整定义

约束: query_metrics 是唯一查询入口，80 个指标不单独暴露为 Tool。
"""
from __future__ import annotations

import logging
import os
import sqlite3
import sys
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import orjson
import json


def _json_dumps(obj: Any) -> str:
    """高性能 JSON 序列化，使用 orjson 加速大 payload。

    - 默认非 ASCII 转义（等价 json.dumps(ensure_ascii=False)）
    - 自动处理 numpy 类型
    - 对未识别类型回退到 str()
    """
    def _default(o):
        if hasattr(o, "isoformat"):
            return o.isoformat()
        if hasattr(o, "tolist"):
            return o.tolist()
        return str(o)
    return orjson.dumps(obj, default=_default, option=orjson.OPT_SERIALIZE_NUMPY).decode("utf-8")

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from core.chip_identify import identify_chip
from core.observability import get_observability_logger, get_module_logger
from core.query_engine import QueryEngine
from core.registry import ConfigRegistry
from core.skill_router import (
    get_skill as _get_skill_payload,
    list_skills as _list_skills_payload,
    routing_table as _routing_table_payload,
)
from core.skill_executor import SkillExecutor, register_executor_tools
from core.preprocess.span_analysis import analyze_parallelism_opportunity_intervals


logger = logging.getLogger("perf-mcp-server")
_handler = logging.StreamHandler(sys.stderr)
_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
logging.root.addHandler(_handler)
logging.root.setLevel(logging.INFO)


# ---------------------------------------------------------------------------
# 全局单例
# ---------------------------------------------------------------------------

CONFIG_DIR = Path(__file__).parent / "config"
REGISTRY = ConfigRegistry(CONFIG_DIR)
ENGINE = QueryEngine(REGISTRY)
EXECUTOR = SkillExecutor(REGISTRY, ENGINE)
log = get_module_logger(__name__)
mcp = FastMCP("perf-metrics-hub")


# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

# severity 级别映射（用于比较 jank_intervals 和 rs_frames 的 severity）
SEVERITY_ORDER = {"normal": 0, "minor": 1, "major": 2, "severe": 3}


# ---------------------------------------------------------------------------
# 安全工具
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 4 个原子工具
# ---------------------------------------------------------------------------

@mcp.tool()
def get_hitrace_path(
    path: str = Field(..., description="hitrace 文件路径或包含 hithrace 文件的目录路径"),
    exclude_pattern: str = Field("", description="排除文件名匹配模式(如 '_hiperf.db')，仅目录扫描时生效"),
) -> str:
    """获取指定路径下的一组 hithrace 文件路径。

    - 若输入是文件路径，直接返回该文件
    - 若输入是目录路径，扫描目录下所有 .systrace / .htrace / .ftrace / .sys / .db 文件并返回
    - exclude_pattern: 排除文件名包含该模式的文件（如 '_hiperf.db' 排除 hiperf 数据库）

    返回 JSON：
    {
      "traces": [                            // trace 文件列表
        {
          "trace_path": str,                 // 文件绝对路径
          "name": str,                       // 文件名
          "size_bytes": int                  // 文件大小（字节）
        }
      ],
      "count": int,                          // 文件数量
      "input_path": str                      // 输入的路径
    }
    """
    from pydantic.fields import FieldInfo as _FI
    if isinstance(exclude_pattern, _FI):
        exclude_pattern = exclude_pattern.default

    p = Path(path)
    result: list[dict] = []

    if not p.exists():
        raise FileNotFoundError(f"路径不存在: {path}")

    def _should_exclude(filename: str) -> bool:
        return bool(exclude_pattern and exclude_pattern in filename)

    if p.is_file():
        if p.suffix not in (".systrace", ".htrace", ".ftrace", ".sys", ".db"):
            raise ValueError(f"不支持的文件类型: {p.suffix}，仅支持 .systrace / .htrace / .ftrace / .sys / .db")
        if not _should_exclude(p.name):
            result.append({
                "trace_path": str(p.resolve()),
                "name": p.name,
                "size_bytes": p.stat().st_size,
            })
    else:
        for f in p.iterdir():
            if f.is_file() and f.suffix in (".systrace", ".htrace", ".ftrace", ".sys", ".db"):
                if not _should_exclude(f.name):
                    result.append({
                        "trace_path": str(f.resolve()),
                        "name": f.name,
                        "size_bytes": f.stat().st_size,
                    })
        result.sort(key=lambda x: x["name"])

    return _json_dumps({
        "traces": result,
        "count": len(result),
        "input_path": str(p.resolve()),
    })


def _get_trace_streamer_bin() -> Path:
    """从 tools/trace_streamer_binary/ 目录解析 trace_streamer 可执行文件路径。"""
    base = Path(__file__).parent / "tools" / "trace_streamer_binary"
    if sys.platform == "win32":
        bin_path = base / "trace_streamer_windows.exe"
    elif sys.platform == "darwin":
        bin_path = base / "trace_streamer_mac"
    else:
        bin_path = base / "trace_streamer_linux"
    if not bin_path.exists():
        raise FileNotFoundError(
            f"trace_streamer binary not found: {bin_path}，请确认 tools/trace_streamer_binary/ 目录已正确上传"
        )
    return bin_path


@mcp.tool()
def convert_hitrace_to_sqlite(
    trace_path: str = Field(..., description="systrace 文件路径"),
) -> str:
    """将 HiTrace 原始文件转换为 SQLite 数据库，并返回 trace 全量时间范围。

    返回 JSON：
    {
      "sqlite_path": str,        // 生成的 SQLite 数据库路径
      "trace_meta": {            // trace 时间范围，用于 ad_hoc_exploration Skill
        "start_ms": float,       // trace 起始时间（毫秒）
        "end_ms": float,         // trace 结束时间（毫秒）
        "duration_ms": float     // trace 总时长（毫秒）
      }
    }
    """
    import subprocess

    p = Path(trace_path)
    if not p.exists():
        raise FileNotFoundError(f"trace 文件不存在: {trace_path}")

    suffix = p.suffix.lower()

    # .db 文件直接返回时间范围，无需转换
    if suffix == ".db":
        start_ms, end_ms = _detect_trace_time_range(str(p))
        return _json_dumps({
            "sqlite_path": str(p.resolve()),
            "trace_meta": {
                "start_ms": start_ms,
                "end_ms": end_ms,
                "duration_ms": end_ms - start_ms,
            },
        })

    if suffix not in (".systrace", ".htrace", ".ftrace", ".sys"):
        raise ValueError(
            f"不支持的文件类型: {suffix}，仅支持 .systrace / .htrace / .ftrace / .sys"
        )

    db_path = str(p.with_suffix(".db"))

    # .db 缓存：若存在且比 htrace 新，直接复用。
    # 防止用户重新抓 trace（同名覆盖 htrace）后返回过时数据。
    if Path(db_path).exists():
        try:
            htrace_mtime = p.stat().st_mtime
            db_mtime = Path(db_path).stat().st_mtime
            if db_mtime >= htrace_mtime:
                start_ms, end_ms = _detect_trace_time_range(db_path)
                return _json_dumps({
                    "sqlite_path": db_path,
                    "trace_meta": {
                        "start_ms": start_ms,
                        "end_ms": end_ms,
                        "duration_ms": end_ms - start_ms,
                    },
                })
            logger.info("缓存 .db 比 htrace 旧，重新转换: %s", db_path)
        except (sqlite3.Error, ValueError) as e:
            # 缓存的 .db 损坏（上次转换被中断 / 磁盘满），删除后回退到重新转换
            logger.warning("缓存 .db 损坏，删除后重新转换: %s (err: %s)", db_path, e)
            try:
                Path(db_path).unlink(missing_ok=True)
            except OSError as del_e:
                logger.warning("删除损坏 .db 失败: %s", del_e)

    bin_path = _get_trace_streamer_bin()

    # Windows 中文路径处理：trace_streamer 无法处理含非 ASCII 字符的路径，
    # 需将文件复制到 temp 目录（ASCII 路径）执行，转换完成后将 .db 移回原位。
    ts_input, ts_output, cleanup = _get_ascii_worktree(trace_path, db_path)

    logger.info("正在调用 trace_streamer 转换: %s -> %s", ts_input, ts_output)
    try:
        ts_input_path = Path(ts_input)
        ts_output_path = Path(ts_output)
        completed = subprocess.run(
            [str(bin_path), ts_input_path.name, "-e", ts_output_path.name],
            capture_output=True,
            text=True,
            cwd=str(ts_input_path.parent),
            timeout=300,
        )
        if completed.returncode != 0:
            logger.error("trace_streamer stderr: %s", completed.stderr)
            raise RuntimeError(
                f"trace_streamer 转换失败 (exit {completed.returncode}): {completed.stderr}"
            )
        logger.info("trace_streamer 转换成功")
    except subprocess.TimeoutExpired:
        if cleanup:
            try:
                cleanup()
            except Exception as e:
                logger.warning("超时清理临时文件失败: %s", e)
        raise TimeoutError(f"trace_streamer 转换超时（5分钟）: {trace_path}")

    # 如果使用了 temp 路径，将 .db 移回原始位置
    if cleanup:
        import shutil
        try:
            shutil.move(ts_output, db_path)
        except Exception as e:
            logger.error("移动 .db 文件失败: %s", e)
            # move 失败时先清理临时文件，避免残留
            try:
                cleanup()
            except Exception as cleanup_e:
                logger.warning("move 失败后清理临时文件失败: %s", cleanup_e)
            raise RuntimeError(f"移动 .db 文件失败: {e}") from e
        try:
            cleanup()
        except Exception as e:
            logger.warning("清理临时文件失败: %s", e)

    start_ms, end_ms = _detect_trace_time_range(db_path)
    return _json_dumps({
        "sqlite_path": db_path,
        "trace_meta": {
            "start_ms": start_ms,
            "end_ms": end_ms,
            "duration_ms": end_ms - start_ms,
        },
    })


@mcp.tool()
def convert_hiperf_data(
    data_path: str = Field(..., description="hiperf .data 二进制文件路径"),
    output_db_path: str | None = None,  # 直接用 None，不要用 Field(default=None)
) -> str:
    """将 hiperf .data 二进制文件转换为 SQLite 数据库，并扩展 BRBE/SPE 表。

    流程:
      1. trace_streamer 解析 callchain + 符号表
      2. hiperf_extender 扩展 brbe_sample + spe_sample 表（含符号解析）

    返回 JSON:
    {
      "sqlite_path": str,
      "trace_meta": {"start_ms": float, "end_ms": float, "duration_ms": float},
      "brbe_stats": {
        "samples_with_brbe": int,
        "total_brbe_entries": int,
        "symbols_resolved": int,
        "symbol_resolution_rate": float
      },
      "spe_stats": {"spe_sample_count": int},
      "duration_ms": float
    }
    """
    import subprocess

    p = Path(data_path)
    if not p.exists():
        raise FileNotFoundError(f".data 文件不存在: {data_path}")

    if p.suffix.lower() != ".data":
        raise ValueError(f"不支持的文件类型: {p.suffix}，仅支持 .data")

    db_path = output_db_path or str(p.with_suffix(".db"))

    # Step 1: trace_streamer 生成基础 DB
    bin_path = _get_trace_streamer_bin()
    logger.info(
        "正在调用 trace_streamer 转换 hiperf .data: %s -> %s", data_path, db_path
    )
    completed = subprocess.run(
        # 绝对路径：output_db_path 与 .data 可能不在同一目录，
        # 不能用 cwd + basename（曾在跨目录输出时 exit 1）
        [str(bin_path), str(p.resolve()), "-e", str(Path(db_path).resolve())],
        capture_output=True,
        text=True,
        timeout=300,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"trace_streamer 转换失败 (exit {completed.returncode}): {completed.stderr}"
        )

    # Step 2: hiperf_extender 扩展 BRBE/SPE 表
    from core.extensions.hiperf_extender import extend_db_with_brbe_spe

    ext_stats = extend_db_with_brbe_spe(db_path, data_path)

    start_ms, end_ms = _detect_trace_time_range(db_path)
    return _json_dumps(
        {
            "sqlite_path": db_path,
            "trace_meta": {
                "start_ms": start_ms,
                "end_ms": end_ms,
                "duration_ms": end_ms - start_ms,
            },
            "brbe_stats": {
                "samples_with_brbe": ext_stats.get("perf_sample_matched", 0),
                "total_brbe_entries": ext_stats.get("brbe_sample_count", 0),
                "symbols_resolved": ext_stats.get("symbols_resolved", 0),
                "symbol_resolution_rate": ext_stats.get(
                    "symbol_resolution_rate", 0.0
                ),
            },
            "spe_stats": {
                "spe_sample_count": ext_stats.get("spe_sample_count", 0),
            },
            "duration_ms": ext_stats.get("duration_ms", 0.0),
        }
    )


def _needs_ascii_path_handling(path_str: str) -> bool:
    """检查路径是否需要 ASCII 处理（Windows 下有非 ASCII 字符时返回 True）。"""
    if sys.platform != "win32":
        return False
    try:
        path_str.encode("ascii")
        return False
    except UnicodeEncodeError:
        return True


def _get_ascii_worktree(
    trace_path: str, output_db_path: str
) -> tuple[str, str, Optional[Callable[[], None]]]:
    """为含中文路径的 trace 文件创建 ASCII 路径工作树。

    Returns:
        (input_path, output_db_path, cleanup_func)
        - 如果原始路径已是 ASCII，直接返回原始路径，cleanup_func 为 None
        - 如果需要转换，复制文件到 temp dir 并返回 temp 路径，cleanup_func 用于清理
    """
    if not _needs_ascii_path_handling(trace_path):
        # 路径已经是 ASCII，无需处理
        return trace_path, output_db_path, None

    import hashlib
    import os
    import shutil
    import tempfile

    p = Path(trace_path)

    # 使用系统 temp 目录，用路径 hash 生成唯一子目录名（纯 ASCII）
    temp_root = Path(tempfile.gettempdir()) / "perf_mcp_htrace_tmp"
    try:
        temp_root.mkdir(parents=True, exist_ok=True)
    except OSError:
        # temp 目录无写权限，尝试当前目录
        temp_root = Path.cwd() / ".perf_mcp_htrace_tmp"
        temp_root.mkdir(parents=True, exist_ok=True)

    # 生成唯一的 ASCII 文件名
    path_hash = hashlib.md5(str(Path(trace_path).resolve()).encode()).hexdigest()[:12]
    temp_trace = temp_root / f"input_{path_hash}{p.suffix}"
    temp_db = temp_root / f"output_{path_hash}.db"

    # 清理上次运行残留的 temp_db（上次失败可能未清理），避免 trace_streamer 行为异常
    if temp_db.exists():
        try:
            temp_db.unlink(missing_ok=True)
        except OSError as e:
            logger.warning("清理残留 temp_db 失败: %s", e)

    # 复制 htrace 文件（尝试硬链接，失败则复制）
    if not temp_trace.exists():
        try:
            try:
                os.link(str(p), str(temp_trace))
            except OSError:
                shutil.copy2(str(p), str(temp_trace))
        except Exception as e:
            raise RuntimeError(
                f"复制 trace 文件到临时目录失败: {e}"
            ) from e

    def cleanup() -> None:
        """清理临时文件。"""
        try:
            if temp_trace.exists():
                temp_trace.unlink(missing_ok=True)
            if temp_db.exists():
                temp_db.unlink(missing_ok=True)
            # 如果 temp_root 为空则删除
            try:
                if temp_root.exists() and not any(temp_root.iterdir()):
                    temp_root.rmdir()
            except OSError as e:
                logger.warning("清理临时目录失败: %s", e)
        except Exception as e:
            logger.warning("清理临时文件失败: %s", e)

    return str(temp_trace), str(temp_db), cleanup


def _detect_trace_time_range(db_path: str) -> tuple[float, float]:
    """从 trace_range 表读取 trace 全局起始/终止时间（单位 ns，需转 ms）。

    trace_range 表为 TraceStreamer 直接输出的时间范围表，精度最高。
    若该表不存在则降级遍历所有含 ts 字段的核心表推算。
    """
    if not Path(db_path).exists():
        raise FileNotFoundError(f"SQLite 数据库不存在: {db_path}")

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    try:
        # 优先使用 trace_range 表（TraceStreamer 直接输出）
        cursor.execute(
            "SELECT start_ts, end_ts FROM trace_range LIMIT 1"
        )
        row = cursor.fetchone()
        if row and row[0] is not None and row[1] is not None:
            return float(row[0]) / 1_000_000, float(row[1]) / 1_000_000

        # 降级：遍历核心表含 ts 字段，推算全局最小/最大时间戳（ns -> ms）
        core_tables = [
            "thread", "process", "sched_slice", "thread_state",
            "callstack", "frame_slice", "irq", "measure",
        ]
        ts_cols = ["ts", "start_ts"]
        min_ts: float | None = None
        max_ts: float | None = None
        for table in core_tables:
            for col in ts_cols:
                try:
                    cursor.execute(
                        f"SELECT MIN({col}), MAX({col}) FROM {table}"
                    )
                    r = cursor.fetchone()
                    if r and r[0] is not None:
                        if min_ts is None or float(r[0]) < min_ts:
                            min_ts = float(r[0])
                        if max_ts is None or float(r[1]) > max_ts:
                            max_ts = float(r[1])
                except sqlite3.Error:
                    continue
        if min_ts is not None and max_ts is not None:
            return min_ts / 1_000_000, max_ts / 1_000_000

        raise ValueError(f"无法从 {db_path} 中提取 trace 时间范围")
    finally:
        conn.close()


def filter_frames_by_jank_intervals(
    frames: list,
    jank_intervals: list,
) -> tuple[dict[int, Any], dict]:
    """按 jank_intervals 区间过滤框架帧，每个区间选耗时最大的一帧。

    Args:
        frames: 帧列表，每项包含 start_ts/end_ts/dur_ms (ns)
        jank_intervals: 丢帧区间列表，每项包含 start_ts/end_ts/frame_rate

    Returns:
        (interval_frame_map, updated_summary)
        interval_frame_map: dict[int, frame]，key 是区间下标，value 是选中的帧

    算法:
        对每个 jank_interval:
            1. 从 interval["frame_rate"] 计算扩展阈值: 3e9 / frame_rate
            2. 计算扩展 start: max(0, start_ts - threshold_ns)
            3. 找所有重叠帧（排除已被选中的帧）
               条件: frame.end_ts > expanded_start AND frame.end_ts < interval.end_ts
               - frame.end_ts > expanded_start: 帧必须延伸到扩展区域之后（存在重叠）
               - frame.end_ts < interval.end_ts: 帧必须在 interval 结束前完成（严格小于）
               - 启动点宽松：帧可以在 expanded_start 之前或之后启动
            4. 重叠帧 > 0 → 选 dur_ms 最大的帧
            5. 重叠帧 = 0 → 该区间无对应帧
    """
    if not jank_intervals or not frames:
        summary = {
            "total_frames": 0,
            "jank_count": 0,
            "normal_count": 0,
            "minor_count": 0,
            "major_count": 0,
            "severe_count": 0,
            # 向后兼容别名
            "jank_frames": 0,
            "light_count": 0,
            "medium_count": 0,
        }
        return {}, summary

    interval_frame_map: dict[int, Any] = {}
    # 使用帧索引标识，已被选中的帧不再参与后续区间的选择
    used_indices: set[int] = set()

    for interval_idx, interval in enumerate(jank_intervals):
        fr = interval.get("frame_rate", 60)
        threshold_ns = 3_000_000_000.0 / fr if fr > 0 else 50_000_000.0
        expanded_start = max(0, interval["start_ts"] - threshold_ns)

        # 找所有重叠帧（排除已被选中的帧）
        # 条件: frame.end_ts > expanded_start AND frame.end_ts < interval.end_ts
        # - frame.end_ts > expanded_start: 帧必须延伸到扩展区域之后（存在重叠）
        # - frame.end_ts < interval.end_ts: 帧必须在 interval 结束前完成（严格小于）
        # - 启动点宽松：帧可以在 expanded_start 之前或之后启动
        overlapping = [
            (idx, f) for idx, f in enumerate(frames)
            if idx not in used_indices
            and f["end_ts"] > expanded_start and f["end_ts"] < interval["end_ts"]
        ]

        if overlapping:
            # 选 dur_ms 最大的帧
            best_idx, best = max(overlapping, key=lambda x: x[1].get("dur_ms", 0))
            used_indices.add(best_idx)
            interval_frame_map[interval_idx] = best

    # 重算 summary
    total = len(interval_frame_map)
    normal = sum(1 for f in interval_frame_map.values() if f.get("jank_severity") == "normal")
    minor = sum(1 for f in interval_frame_map.values() if f.get("jank_severity") == "minor")
    major = sum(1 for f in interval_frame_map.values() if f.get("jank_severity") == "major")
    severe = sum(1 for f in interval_frame_map.values() if f.get("jank_severity") == "severe")

    summary = {
        # 标准字段
        "total_frames": total,
        "jank_count": minor + major + severe,
        "normal_count": normal,
        "minor_count": minor,
        "major_count": major,
        "severe_count": severe,
        # 向后兼容别名
        "jank_frames": minor + major + severe,
        "light_count": minor,
        "medium_count": major,
    }
    return interval_frame_map, summary


def compute_frame_summary(frames: list) -> dict:
    """从全量帧列表计算 summary（不依赖 jank_intervals）。

    与 filter_frames_by_jank_intervals 返回的 summary 字段结构一致，
    但基于全量帧而非仅匹配到 jank interval 的帧。
    """
    total = len(frames)
    normal = sum(1 for f in frames if f.get("jank_severity") == "normal")
    minor = sum(1 for f in frames if f.get("jank_severity") == "minor")
    major = sum(1 for f in frames if f.get("jank_severity") == "major")
    severe = sum(1 for f in frames if f.get("jank_severity") == "severe")
    return {
        "total_frames": total,
        "jank_count": minor + major + severe,
        "normal_count": normal,
        "minor_count": minor,
        "major_count": major,
        "severe_count": severe,
        # 向后兼容别名
        "jank_frames": minor + major + severe,
        "light_count": minor,
        "medium_count": major,
    }


@mcp.tool()
def analyze_frame_drops(
    sqlite_path: str = Field(..., description="trace.db 路径"),
    screen_id: int | None = None,  # 屏幕 ID 筛选（多屏设备），不使用 Field(default=None) 以避免 FieldInfo 作为默认值
    top_n: int = 50,  # thread_queries Top-N 数量，按 severity+duration 排序截断
    package_name: str | None = Field(default=None, description="应用中文名（如：微信、抖音）、HarmonyOS进程名（如：.tencent.wechat）或Android包名（如：com.tencent.mm）；优先传中文名；框架自动解析映射"),
) -> str:
    """识别丢帧区间：先构建渲染帧+summary，再检测 PresentFence 上屏丢帧，最后路由 thread_queries。

    流程: build_rs_frames→rs_summary → detect_pipeline → framework_frames→pipeline_summary
          → build_jank_intervals → 帧匹配 → thread_queries 路由

    提示：对于完整的丢帧分析，优先使用 run_skill(skill_id="frame_drop_analysis", ...),

    返回字段: sqlite_path, time_range, jank_intervals (含 intervals/rs/flutter/ui/web), pipeline_type, thread_queries, frame_drop_summary
    """
    from core.preprocess import PreprocessContext
    from core.preprocess.jank_interval_ops import build_jank_intervals
    from core.preprocess.rs_frame_ops import build_rs_frames
    from core.rendering_pipeline import detect_rendering_pipeline
    from core.preprocess.flutter_frame_ops import build_flutter_frames
    from core.preprocess.ui_frame_ops import build_ui_frames
    from core.preprocess.web_frame_ops import build_web_frames
    from core.preprocess.frame_rate_ops import query_frame_rate_records
    from core.preprocess.thread_query_ops import build_thread_queries_from_jank_intervals
    from pydantic.fields import FieldInfo
    # TODO: migrate all direct operator calls to run_pipeline for uniform dispatch

    # 修复: FieldInfo 比较问题
    if isinstance(package_name, FieldInfo):
        package_name = package_name.default

    conn = sqlite3.connect(sqlite_path)
    cur = conn.cursor()
    cur.execute("SELECT start_ts, end_ts FROM trace_range LIMIT 1")
    row = cur.fetchone()
    if not row:
        conn.close()
        return _json_dumps({
            "sqlite_path": sqlite_path,
            "time_range": {"start_ms": 0, "end_ms": 0, "duration_ms": 0},
            "jank_intervals": {
                "intervals": [],
                "rs": {"summary": {"total_frames": 0, "jank_count": 0, "minor_count": 0, "major_count": 0, "severe_count": 0}},
                "flutter": {"summary": {"total_frames": 0, "jank_count": 0, "minor_count": 0, "major_count": 0, "severe_count": 0}},
                "ui": {"summary": {"total_frames": 0, "jank_count": 0, "minor_count": 0, "major_count": 0, "severe_count": 0}},
                "web": {"summary": {"total_frames": 0, "jank_count": 0, "minor_count": 0, "major_count": 0, "severe_count": 0}}
            },
            "pipeline_type": "UNKNOWN",
            "thread_queries": []
        })

    start_ms = row[0] / 1_000_000
    end_ms = row[1] / 1_000_000

    # =========================================================================
    # Phase 1: 构建帧 + Summary（渲染丢帧检测，与 jank 无关）
    # =========================================================================

    # 1a. 帧率记录
    ctx_rate = PreprocessContext(data=None, meta={}, sqlite_conn=conn)
    ctx_rate = query_frame_rate_records(ctx_rate)
    frame_rate_records = ctx_rate.data.get("frame_rate_records", [])

    # 1b. RS 帧 + rs_summary（全量帧统计，不依赖 jank_intervals）
    ctx_all = PreprocessContext(data=None, meta={}, sqlite_conn=conn)
    ctx_all.params = {"start_ts": None, "end_ts": None}
    ctx_all.meta["frame_rate_records"] = frame_rate_records if frame_rate_records else []
    ctx_all = build_rs_frames(ctx_all)
    all_rs_frames_raw = ctx_all.data.get("rs_frames", [])
    rs_summary = compute_frame_summary(all_rs_frames_raw)

    # 1c. 渲染管线检测
    pipeline_type = "UNKNOWN"
    try:
        pipeline_result = detect_rendering_pipeline(sqlite_path=sqlite_path)
        pipeline_type = getattr(pipeline_result, "primary_pipeline_id", "UNKNOWN")
    except Exception:
        pass

    # 1d. 框架帧 + pipeline_summary（全量帧统计）
    flutter_frames_raw = []
    ui_frames_raw = []
    web_frames_raw = []

    if pipeline_type == "HARMONY_FLUTTER":
        try:
            ctx_flutter = PreprocessContext(data=None, meta={}, sqlite_conn=conn)
            ctx_flutter.params = {}
            ctx_flutter.meta["frame_rate_records"] = frame_rate_records if frame_rate_records else []
            ctx_flutter = build_flutter_frames(ctx_flutter)
            flutter_frames_raw = ctx_flutter.data.get("flutter_frames", [])
        except Exception:
            pass
    elif pipeline_type in ["HARMONY_ARKUI", "HARMONY_RN", "HARMONY_KMP"]:
        try:
            ctx_ui = PreprocessContext(data=None, meta={}, sqlite_conn=conn)
            ctx_ui.params = {}
            ctx_ui.meta["frame_rate_records"] = frame_rate_records if frame_rate_records else []
            ctx_ui = build_ui_frames(ctx_ui)
            ui_frames_raw = ctx_ui.data.get("ui_frames", [])
        except Exception:
            pass
    elif pipeline_type == "HARMONY_WEB_PIPELINE":
        try:
            ctx_web = PreprocessContext(data=None, meta={}, sqlite_conn=conn)
            ctx_web.params = {}
            ctx_web.meta["frame_rate_records"] = frame_rate_records if frame_rate_records else []
            ctx_web = build_web_frames(ctx_web)
            web_frames_raw = ctx_web.data.get("web_frames", [])
        except Exception:
            pass

    flutter_summary = compute_frame_summary(flutter_frames_raw)
    ui_summary = compute_frame_summary(ui_frames_raw)
    web_summary = compute_frame_summary(web_frames_raw)

    # =========================================================================
    # Phase 2: Jank Intervals + 匹配（上屏丢帧检测）
    # =========================================================================

    # 2a. build_jank_intervals（不做 summary）
    ctx = PreprocessContext(data=None, meta={}, sqlite_conn=conn)
    ctx.meta["frame_rate_records"] = frame_rate_records
    ctx = build_jank_intervals(ctx)
    jank_intervals = ctx.data.get("jank_intervals", [])
    if screen_id is not None:
        jank_intervals = [i for i in jank_intervals if i.get("screen_id") == screen_id]

    # 2b. RS 帧 → interval 匹配（vsyncId，保持现有逻辑）
    rs_frame_by_interval: dict[int, Any] = {}
    for interval_idx, interval in enumerate(jank_intervals):
        rs_vsync_id = interval.get("rsVsyncId")
        if rs_vsync_id is None:
            continue
        vid_str = str(rs_vsync_id)
        expected_numeric = vid_str.replace("vsyncId:", "") if vid_str.startswith("vsyncId:") else vid_str
        for frame in all_rs_frames_raw:
            frame_vsync = frame.get("rsVsyncId", "")
            frame_numeric = frame_vsync.replace("vsyncId:", "") if frame_vsync.startswith("vsyncId:") else frame_vsync
            if frame_numeric == expected_numeric:
                rs_frame_by_interval[interval_idx] = frame
                break  # 每个 interval 最多一个 RS 帧

    # 2c. 框架帧 → interval 匹配（时间重叠，保持现有逻辑）
    # 注意：filter_frames_by_jank_intervals 返回的 summary 被忽略，
    # 改用 Phase 1 中 compute_frame_summary 计算的全量帧 summary
    flutter_frame_map, _ = filter_frames_by_jank_intervals(flutter_frames_raw, jank_intervals)
    ui_frame_map, _ = filter_frames_by_jank_intervals(ui_frames_raw, jank_intervals)
    web_frame_map, _ = filter_frames_by_jank_intervals(web_frames_raw, jank_intervals)

    # =========================================================================
    # Phase 3: 构建输出结构 + thread_queries
    # =========================================================================

    # 3a. 构建 all_render_jank_frames（全量渲染丢帧帧，用于 thread_queries 兜底路由）
    # 注意: 此处不排序，排序由下游 thread_query_ops 算子统一负责
    all_render_jank_frames = []
    for frame in all_rs_frames_raw:
        if frame.get("jank_severity", "normal") != "normal":
            all_render_jank_frames.append({"frame": frame, "frame_type": "rs"})
    for frame in flutter_frames_raw:
        if frame.get("jank_severity", "normal") != "normal":
            all_render_jank_frames.append({"frame": frame, "frame_type": "flutter"})
    for frame in ui_frames_raw:
        if frame.get("jank_severity", "normal") != "normal":
            all_render_jank_frames.append({"frame": frame, "frame_type": "ui"})
    for frame in web_frames_raw:
        if frame.get("jank_severity", "normal") != "normal":
            all_render_jank_frames.append({"frame": frame, "frame_type": "web"})

    # 3b. 构建 intervals_with_frames（仅保留 confirmed_severity != normal 的 interval）
    interval_frame_maps = {
        "rs": rs_frame_by_interval,
        "flutter": flutter_frame_map,
        "ui": ui_frame_map,
        "web": web_frame_map,
    }

    intervals_with_frames = []
    for interval_idx, interval in enumerate(jank_intervals):
        interval_copy = interval.copy()
        interval_copy["interval_idx"] = interval_idx
        interval_copy["present_fence_severity"] = interval.get("jank_severity")

        # 仅保留 fence severity >= minor 的 interval（fence 丢帧才进入 thread_queries 路由）
        fence_severity = interval.get("jank_severity", "normal")
        if SEVERITY_ORDER.get(fence_severity, 0) < SEVERITY_ORDER.get("minor", 1):
            continue

        frames_dict = {}
        for frame_type, frame_map in interval_frame_maps.items():
            if interval_idx in frame_map:
                frames_dict[frame_type] = frame_map[interval_idx]

        # confirmed_severity: 匹配到的帧中最严重的 severity
        confirmed_severity = "normal"
        for f in frames_dict.values():
            f_sev = f.get("jank_severity", "normal")
            if SEVERITY_ORDER.get(f_sev, 0) > SEVERITY_ORDER.get(confirmed_severity, 0):
                confirmed_severity = f_sev

        # 仅保留 confirmed_severity != normal 的 interval（渲染帧也丢帧才有分析价值）
        if confirmed_severity == "normal":
            continue

        interval_copy["frames"] = frames_dict if frames_dict else {}
        intervals_with_frames.append(interval_copy)

    # 3c. 构建输出
    # 注意: all_render_jank_frames 通过 ctx.meta 传递给算子，不放入 result data
    result = {
        "sqlite_path": sqlite_path,
        "time_range": {"start_ms": start_ms, "end_ms": end_ms, "duration_ms": end_ms - start_ms},
        "jank_intervals": {
            "intervals": intervals_with_frames,
            "rs": {"summary": rs_summary},
            "flutter": {"summary": flutter_summary},
            "ui": {"summary": ui_summary},
            "web": {"summary": web_summary}
        },
        "pipeline_type": pipeline_type,
    }

    # 3e. frame_drop_summary（基于全量帧 summary）
    frame_drop_summary: dict[str, dict] = {}
    for pipeline_key, label in [("rs", "RS"), ("flutter", "Flutter"), ("ui", "UI"), ("web", "Web")]:
        summary = result.get("jank_intervals", {}).get(pipeline_key, {}).get("summary", {})
        if summary.get("total_frames", 0) > 0:
            frame_drop_summary[label] = {
                "total_frames": summary.get("total_frames", 0),
                "jank_count": summary.get("jank_count", 0),
                "minor": summary.get("minor_count", summary.get("light_count", 0)),
                "major": summary.get("major_count", summary.get("medium_count", 0)),
                "severe": summary.get("severe_count", 0),
            }
    result["frame_drop_summary"] = frame_drop_summary

    # 3f. thread_queries（通过 ctx.meta 传递 all_render_jank_frames，算子内加 fallback）
    ctx = PreprocessContext(data=result, meta={}, sqlite_conn=None)
    ctx.meta["thread_query_top_n"] = top_n
    ctx.meta["all_render_jank_frames"] = all_render_jank_frames
    if package_name:
        ctx.meta["package_name"] = package_name
    ctx = build_thread_queries_from_jank_intervals(ctx)
    result = ctx.data

    conn.close()
    return _json_dumps(result)


@mcp.tool()
def analyze_launch_phases(
    sqlite_path: str = Field(..., description="trace.db 路径"),
    start_ms: float | None = None,  # 注意：直接用 None，不要用 Field(default=None)
    end_ms: float | None = None,  # 注意：直接用 None，不要用 Field(default=None)
    bottleneck_threshold_ms: float = 50.0,
    package_name: str | None = Field(default=None, description="包名过滤器，仅分析指定包名的启动阶段"),
    launch_duration: float | None = Field(default=None, description="启动时长(ms)，当 end_ms 未指定时用于计算 end_ms"),
    max_visible_processes: int = 3,
) -> str:
    """拆解启动阶段，返回各进程启动链路。

    提示：对于完整的启动性能分析，优先使用 run_skill(skill_id="launch_perf", ...)，

    返回字段: sqlite_path, time_range, launch_process (含 phases/bottleneck/thread_queries),
    thread_queries (扁平数组，由 build_thread_queries_from_jank_startup 产出),
    可选 package_name_filter, launch_duration_ms

    参数:
      max_visible_processes: 最多保留的可见进程数，按 total_launch_ms DESC 取 Top N；
                             超出部分标记 filtered=True。默认 3。
          ],
          "bottleneck": { phase: str, duration_ms: float, threshold_ms: float } | null,
          "thread_queries": [{ tag, tid, thread_name, start_ms, end_ms, priority }, ...]
        }, ...
      ]
    }
    """
    from pydantic.fields import FieldInfo
    # 修复: FieldInfo 比较问题
    if isinstance(start_ms, FieldInfo):
        start_ms = start_ms.default
    if isinstance(end_ms, FieldInfo):
        end_ms = end_ms.default
    if isinstance(package_name, FieldInfo):
        package_name = package_name.default
    if isinstance(launch_duration, FieldInfo):
        launch_duration = launch_duration.default
    if isinstance(max_visible_processes, FieldInfo):
        max_visible_processes = max_visible_processes.default

    from core.preprocess import PreprocessContext
    from core.preprocess.thread_query_ops import build_thread_queries_from_jank_startup
    # TODO: migrate all direct operator calls to run_pipeline for uniform dispatch

    # launch_duration 校验
    if launch_duration is not None and launch_duration <= 0:
        return _json_dumps({
            "sqlite_path": sqlite_path,
            "error": "launch_duration must be greater than 0",
        })

    # 自动推断时间范围（优先从 trace_range 表，否则扫描 callstack）
    if start_ms is None or end_ms is None:
        conn = sqlite3.connect(sqlite_path)
        cur = conn.cursor()
        cur.execute("SELECT start_ts, end_ts FROM trace_range LIMIT 1")
        row = cur.fetchone()
        conn.close()
        if row:
            auto_start_ms = row[0] / 1_000_000
            auto_end_ms = row[1] / 1_000_000
        else:
            conn = sqlite3.connect(sqlite_path)
            cur = conn.cursor()
            cur.execute("SELECT MIN(ts), MAX(ts) FROM callstack LIMIT 1")
            row = cur.fetchone()
            conn.close()
            if row and row[0]:
                auto_start_ms = row[0] / 1_000_000
                auto_end_ms = row[1] / 1_000_000
            else:
                auto_start_ms = 0.0
                auto_end_ms = 0.0
        if start_ms is None:
            start_ms = auto_start_ms
        if end_ms is None:
            end_ms = auto_end_ms

    # launch_duration 仅用于 Completion 阶段计算（从 FirstFrame 结束往后延伸），
    # 不应用于缩窄搜索窗口——启动事件可能在 trace 起始后任意位置发生。

    if end_ms <= start_ms:
        return _json_dumps({
            "sqlite_path": sqlite_path,
            "error": "end_ms must be greater than start_ms",
        })

    result = ENGINE.execute(
        sqlite_path=sqlite_path,
        indicator_names=["launch_phase_breakdown"],
        base_params={"start_ms": start_ms, "end_ms": end_ms},
        agent_params={"launch_phase_breakdown": {
            "bottleneck_threshold_ms": bottleneck_threshold_ms,
            "package_name": None,
            "launch_duration": launch_duration,
        }},
        max_rows_per_indicator=100000,
    )

    indicator_result = result.get("indicators", {}).get("launch_phase_breakdown", {})
    if "error" in indicator_result:
        return _json_dumps({
            "sqlite_path": sqlite_path,
            "error": indicator_result["error"],
        })

    data = indicator_result.get("data", {})
    result_dict = {
        "sqlite_path": sqlite_path,
        "time_range": {
            "start_ms": start_ms,
            "end_ms": end_ms,
            "duration_ms": end_ms - start_ms,
        },
        **data,
    }
    if package_name is not None:
        result_dict["package_name_filter"] = package_name
    if launch_duration is not None:
        result_dict["launch_duration_ms"] = launch_duration

    # 集成 build_thread_queries_from_jank_startup，确保直接调用也能产出 thread_queries
    _startup_params = {"max_visible_processes": max_visible_processes}
    if package_name:
        _startup_params["package_name"] = package_name
    ctx = PreprocessContext(data=result_dict, meta={}, sqlite_conn=None, params=_startup_params)
    ctx = build_thread_queries_from_jank_startup(ctx)
    result_dict = ctx.data

    return _json_dumps(result_dict)


@mcp.tool()
def identify_chip_model(
    sqlite_path: str = Field(..., description="trace.db 路径"),
) -> str:
    """基于 trace 数据识别芯片型号及 CPU 拓扑配置。

    自动检测：
    - trace 时间范围（从 trace_range 表或核心表推断）
    - 逻辑 CPU 总数
    - 每个 CPU 的频点范围（MIN/MAX）
    - SMT sibling 配对

    与 config/chips/chip_database.json 中的芯片配置库匹配，
    返回最可能的芯片型号及其配置详情。

    返回 JSON：
    {
      "sqlite_path": str,                    // 输入的数据库路径
      "trace_time_range": {
        "start_ms": float,
        "end_ms": float,
        "duration_ms": float
      },
      "cpu_topology": {
        "total_logical_cpus": int,           // 逻辑 CPU 总数
        "per_cpu_freq": [                    // 每核频点范围
          {"cpuid": int, "freq_min": int, "freq_max": int}, ...
        ],
        "smt_pairs": [[int, int], ...]       // 检测到的 SMT sibling 对
      },
      "matched_chips": [                     // 匹配的芯片列表（按匹配度排序）
        {
          "chip_model": str,                 // 芯片型号
          "vendor": str,                     // 芯片厂商
          "match_score": float,              // 匹配分数（0-1）
          "match_details": {                 // 匹配详情
            "cpu_count_match": bool,
            "cluster_config_match": bool,
            "smt_config_match": bool,
            "freq_range_match": bool
          }
        }, ...
      ]
    }
    """
    result = identify_chip(sqlite_path)
    return _json_dumps(result)


@mcp.tool()
def detect_rendering_pipeline(
    sqlite_path: str,
    package_name: Optional[str] = None,
) -> str:
    """检测渲染管线类型 (v3.3 动态 YAML 架构)。

    注意：此函数仅用于 SkillExecutor 内部调用，不对外暴露为 MCP tool。
    请使用 run_skill 工具执行 detect_rendering_pipeline_skill。

    基于 Pipeline YAML 信号定义，动态生成 SQL 打分排名，
    返回主管线、候选列表、子变体、4-Feature 分型和采集建议。

    返回 JSON：
    {
      "pipeline_result": {
        "primary_pipeline_id": str,            // 主管线 ID
        "primary_confidence": float,            // 置信度 (0-1)
        "candidates_list": str,                 // 候选 "P1:0.85,P2:0.30"
        "features_list": str,                   // 特征管线 "VRR:0.60"
        "doc_path": str | null
      },
      "subvariants": {
        "webview_mode": str,    // SURFACE_CONTROL / GL_FUNCTOR / TEXTUREVIEW_CUSTOM / SURFACEVIEW_WRAPPER / N/A
        "buffer_mode": str,     // BLAST / LEGACY / UNKNOWN
        "flutter_engine": str,  // IMPELLER / SKIA / UNKNOWN / N/A
        "game_engine": str      // UNITY / UNREAL / GODOT / N/A
      },
      "trace_requirements": {
        "hint_web": str | null,   // Graphics.Pipeline/SkiaOutputSurface 缺失提示
        "hint_rs": str | null     // render_service 进程缺失提示
      },
      "active_rendering_processes": [{"ipid": int, "process_name": str, "frame_count": int, "render_thread_tid": int | null}],
      "layer_signals": {"app_layer_count": int, "app_layer_names": str, "has_surfaceview_layer": int, ...},
      "extra_rhythm_signals": {"swappy_count": int, "primary_rhythm_source": str, ...},
      "bufferqueue_path_signals": {"blast_bq_count": int, "bufferqueue_path": str, ...},
      "candidates": [{"id": str, "confidence": float}],
      "pipeline_scores": [{"pipeline_id": str, "score": float, "required_ok": int, ...}]
    }
    """
    from pydantic.fields import FieldInfo
    # 修复: @mcp.tool() 直接 Python 调用时，Field() 默认值是 FieldInfo 对象而非 None
    if isinstance(package_name, FieldInfo):
        package_name = package_name.default

    from core.rendering_pipeline import (
        detect_rendering_pipeline as _detect,
    )
    result = _detect(sqlite_path, package_name)
    return _json_dumps(result.to_dict())


# ---------------------------------------------------------------------------
# 4 个元数据 / 查询工具
# ---------------------------------------------------------------------------

@mcp.tool()
def list_indicators(
    category: Optional[str] = Field(
        default=None, description="筛选类别，如 cpu / gpu / thermal"
    ),
    keyword: Optional[str] = Field(
        default=None, description="对 name / display_name / description 模糊搜索"
    ),
) -> str:
    """列出所有可用指标，含 sql_params 和 result_schema 自描述。

    返回 JSON：
    {
      "total": int,                          // 指标总数
      "indicators": [                        // 指标列表
        {
          "name": str,                       // 指标名（唯一标识）
          "display_name": str,               // 显示名称
          "category": str,                   // 分类
          "description": str,                // 描述
          "unit": str,                       // 单位
          "type": str,                       // atomic 或 group
          "default_granularity": str,        // 默认粒度
          "result_schema": object,           // 结果 schema
          "sql_params": [                    // 仅 atomic 有
            {
              "name": str,
              "type": str,
              "required": bool,
              "description": str,
              "default": any,
              "enum": [str] | null
            }
          ]
        }
      ]
    }
    """
    from pydantic.fields import FieldInfo
    # 修复: @mcp.tool() 直接 Python 调用时，Field() 默认值是 FieldInfo 对象而非 None
    # 在 MCP 协议调用时由框架处理，但直接调用需要手动还原
    if isinstance(category, FieldInfo):
        category = category.default
    if isinstance(keyword, FieldInfo):
        keyword = keyword.default

    out: list[dict] = []
    keyword_l = keyword.lower() if keyword else None

    for name, meta in REGISTRY.indicators.items():
        if category and meta.category != category:
            continue
        if keyword_l:
            haystack = (
                f"{meta.name} {meta.display_name} {meta.description}".lower()
            )
            if keyword_l not in haystack:
                continue

        item: dict[str, Any] = {
            "name": meta.name,
            "display_name": meta.display_name,
            "category": meta.category,
            "description": meta.description,
            "unit": meta.unit,
            "type": meta.type,
            "default_granularity": meta.default_granularity,
            "result_schema": meta.result_schema,
        }
        if meta.type == "atomic":
            item["sql_params"] = [
                {
                    "name": p.name,
                    "type": p.type,
                    "required": p.required,
                    "description": p.description,
                    "default": p.default,
                    "enum": p.enum,
                }
                for p in meta.sql_params
            ]
            if meta.preprocess:
                item["preprocess"] = meta.preprocess
        else:
            item["expands_to"] = [c["name"] for c in meta.expands_to]

        out.append(item)

    return _json_dumps(
        {"total": len(out), "indicators": out},
    )


@mcp.tool()
def query_metrics(
    sqlite_path: str = Field(..., description="trace.db 路径"),
    start_ms: float = Field(..., description="时间范围起点（必须来自上一步工具）"),
    end_ms: float = Field(..., description="时间范围终点"),
    indicators: List[str] = Field(
        ..., description="指标名列表，支持 atomic 和 group"
    ),
    granularity: str = Field(
        default="auto", description="raw / 1ms / 10ms / 100ms / auto"
    ),
    indicator_params: Optional[Dict[str, Dict[str, Any]]] = Field(
        default=None,
        description=(
            "为特定指标传入额外参数，如 "
            "{'cpu_freq': {'cluster': 'big'}, 'thread_runtime': {'limit': 20}}"
        ),
    ),
    max_rows_per_indicator: int = Field(
        default=500,
        description="单指标最大返回行数，超过则按时序分桶 / 非时序 Top N 截断",
    ),
    summary_only: bool = Field(
        default=False,
        description="true 时只返回汇总不返回 per_cpu 数组（有 summary 的指标生效）",
    ),
    iterate: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="数组参数，框架自动循环执行并聚合结果，item.xxx 语法代换参数",
    ),
) -> str:
    """统一指标查询入口，支持动态参数 + 大数据采样 + group 展开 + 预处理引擎。

    返回 JSON：
    {
      "indicators": {                        // 各指标结果
        "<indicator_name>": {
          "type": str,                       // array / object / scalar
          "data": any,                       // 查询结果
          "truncated": bool,                 // 是否被截断
          "schema": object                   // schema 描述
        }
      },
      "errors": []                           // 错误信息数组
    }
    """
# 修复: @mcp.tool() 直接 Python 调用时，Field() 默认值是 FieldInfo 对象
    from pydantic.fields import FieldInfo as _FI
    if isinstance(indicator_params, _FI):
        indicator_params = indicator_params.default
    if isinstance(granularity, _FI):
        granularity = granularity.default
    if isinstance(max_rows_per_indicator, _FI):
        max_rows_per_indicator = max_rows_per_indicator.default
    if isinstance(summary_only, _FI):
        summary_only = summary_only.default
    if isinstance(iterate, _FI):
        iterate = iterate.default

    _svr_log = get_observability_logger("server")
    _svr_log.info("mcp_tool_called", tool="query_metrics",
                  indicators=indicators,
                  indicator_params_keys=list(indicator_params.keys()) if indicator_params else [])

    try:
        result = ENGINE.execute(
            sqlite_path=sqlite_path,
            indicator_names=indicators,
            base_params={
                "start_ms": start_ms,
                "end_ms": end_ms,
                "granularity": granularity,
            },
            agent_params=indicator_params,
            max_rows_per_indicator=max_rows_per_indicator,
            summary_only=summary_only,
            iterate=iterate,
        )
    except Exception as _e:
        _svr_log.error("mcp_tool_error", tool="query_metrics",
                       error=str(_e))
        raise
    return _json_dumps(result)


@mcp.tool()
def analyze_tag_instructions(
    sqlite_path: str = Field(..., description="trace.db 路径"),
    thread_name: str | None = Field(None, description="目标线程名(支持任意线程,与process_name二选一,优先级高于process_name)"),
    process_name: str | None = Field(None, description="目标进程名(查找主线程,与thread_name二选一)"),
    tag_pattern: str | None = Field(None, description="单标签 LIKE 模式(如 H:UI skip%); 若不含%则自动追加%作为前缀匹配"),
    id_pattern: str | None = Field(None, description="单标签标识符提取正则(如 vsyncId:(\\d+))"),
    id_label: str | None = Field(None, description="单标签标识符列标题(如 vsyncId),不提供则从id_pattern推导或回退到绝对时间(s)"),
    child_tag_pattern: str | None = Field(None, description="子标签 LIKE 模式(双标签模式); 若不含%则自动追加%"),
    parent_tag_pattern: str | None = Field(None, description="父标签 LIKE 模式(双标签模式); 若不含%则自动追加%"),
    child_id_pattern: str | None = Field(None, description="子标签标识符提取正则（仅用于报告展示，不影响计算）"),
    parent_id_pattern: str | None = Field(None, description="父标签标识符提取正则"),
    parent_id_label: str | None = Field(None, description="父标签标识符列标题(如 vsyncId),不提供则从parent_id_pattern推导或回退到绝对时间(s)"),
    hiperf_sqlite_path: str = Field("", description="hiperf SQLite 路径(可选,为空则从trace DB查perf_sample;若目标线程perf_sample为空则自动查找同名_hiperf.db)"),
    abnormal_dur_ns: int = Field(4_000_000_000, description="丢弃 dur>=此值的父标签(ns),默认4秒"),
) -> str:
    """分析 callstack 标签区间的 CPU 指令数。支持单标签/双标签模式。

    单标签模式(tag_pattern): 直接查标签指令数。
    双标签模式(child_tag_pattern+parent_tag_pattern): 子标签映射到父标签,子标签仅输出次数,父标签输出指令数。
    模式根据提供的参数自动推断。

    返回 JSON 含 tag_count/total_instr/pct/max_entry/avg_entry/min_entry/zero_count + markdown。
    """
    from core.preprocess import PreprocessContext
    from core.preprocess.tag_instruction_ops import (
        find_thread, query_tag_intervals, map_child_to_parent,
        _calc_instructions_for_intervals, _compute_sample_entries,
        format_tag_instruction_markdown,
    )
    from pydantic.fields import FieldInfo as _FI
    _svr_log = get_observability_logger("server")

    # FieldInfo 默认值处理
    if isinstance(thread_name, _FI):
        thread_name = thread_name.default
    if isinstance(process_name, _FI):
        process_name = process_name.default
    if isinstance(tag_pattern, _FI):
        tag_pattern = tag_pattern.default
    if isinstance(id_pattern, _FI):
        id_pattern = id_pattern.default
    if isinstance(child_tag_pattern, _FI):
        child_tag_pattern = child_tag_pattern.default
    if isinstance(parent_tag_pattern, _FI):
        parent_tag_pattern = parent_tag_pattern.default
    if isinstance(child_id_pattern, _FI):
        child_id_pattern = child_id_pattern.default
    if isinstance(parent_id_pattern, _FI):
        parent_id_pattern = parent_id_pattern.default
    if isinstance(id_label, _FI):
        id_label = id_label.default
    if isinstance(parent_id_label, _FI):
        parent_id_label = parent_id_label.default
    if isinstance(hiperf_sqlite_path, _FI):
        hiperf_sqlite_path = hiperf_sqlite_path.default
    if isinstance(abnormal_dur_ns, _FI):
        abnormal_dur_ns = abnormal_dur_ns.default

    # Validate thread params
    if not thread_name and not process_name:
        return _json_dumps({"error": "至少需要提供 thread_name 或 process_name"})

    # Validate sqlite_path exists (SQLite silently creates empty DB if file missing)
    if not os.path.isfile(sqlite_path):
        return _json_dumps({"error": f"File not found: {sqlite_path}"})

    # Auto-append % wildcard to tag patterns without %
    # Rationale: callstack tag names typically contain extra info after the
    # user-specified prefix (e.g. "H:RSSurfaceRenderNodeDrawable::OnDraw[SCBDesktop8](0,0,1256,2760) ...|M0538").
    # Without %, SQL LIKE requires exact match and returns 0 results.
    # If user explicitly includes %, respect it as-is.
    if tag_pattern and "%" not in tag_pattern:
        tag_pattern = tag_pattern + "%"
    if child_tag_pattern and "%" not in child_tag_pattern:
        child_tag_pattern = child_tag_pattern + "%"
    if parent_tag_pattern and "%" not in parent_tag_pattern:
        parent_tag_pattern = parent_tag_pattern + "%"

    # Infer query_mode
    has_tag = tag_pattern is not None
    has_child = child_tag_pattern is not None
    has_parent = parent_tag_pattern is not None

    if has_tag and not has_child and not has_parent:
        query_mode = "single_tag"
    elif has_child and has_parent:
        query_mode = "child_and_parent"
    elif (has_child and not has_parent) or (has_parent and not has_child):
        return _json_dumps({"error": "双标签模式需要同时提供 child_tag_pattern 和 parent_tag_pattern，或改用 tag_pattern 单标签模式"})
    else:
        return _json_dumps({"error": "至少需要提供一个 tag_pattern 或 child_tag_pattern + parent_tag_pattern"})

    tconn = None
    pconn = None
    try:
        # Connect DBs
        tconn = sqlite3.connect(sqlite_path)

        # Auto-detect hiperf: if hiperf_sqlite_path not provided, check builtin
        # perf_sample; if empty, try same-name _hiperf.db as fallback
        use_hiperf = False
        if hiperf_sqlite_path:
            use_hiperf = True
        else:
            # Check if builtin perf_sample has data for the target thread
            # (need find_thread first, so defer to after thread lookup)
            pass

        # Find thread
        thread_ctx = find_thread(PreprocessContext(data=None, params={
            "sqlite_conn": tconn,
            "thread_name": thread_name,
            "process_name": process_name,
        }))
        if thread_ctx.data is None:
            target = thread_name or process_name
            return _json_dumps({"error": f"Thread not found: '{target}'"})

        itid = thread_ctx.data["itid"]
        main_tid = thread_ctx.data["tid"]
        actual_thread_name = thread_ctx.data["thread_name"]
        pid = thread_ctx.data["pid"]

        # Get process_name if not provided
        if not process_name:
            pn_row = tconn.execute(
                "SELECT name FROM process WHERE ipid = ?", (thread_ctx.data["ipid"],)
            ).fetchone()
            process_name = pn_row[0] if pn_row else actual_thread_name

        # Auto-detect hiperf: check builtin perf_sample, fallback to _hiperf.db
        if not hiperf_sqlite_path:
            builtin_total_row = tconn.execute(
                "SELECT SUM(event_count) FROM perf_sample WHERE thread_id = ?", (main_tid,)
            ).fetchone()
            builtin_total = builtin_total_row[0] if builtin_total_row and builtin_total_row[0] else 0
            if builtin_total == 0:
                # Try same-name _hiperf.db
                base, _ = os.path.splitext(sqlite_path)
                candidate = base + "_hiperf.db"
                if os.path.isfile(candidate):
                    hiperf_sqlite_path = candidate
                    use_hiperf = True

        # Auto-detect parent/child depth: if both tag patterns provided,
        # query their actual depth in callstack and swap if inverted
        if query_mode == "child_and_parent":
            child_depth_row = tconn.execute(
                "SELECT AVG(depth) FROM callstack WHERE callid = ? AND name LIKE ? AND dur IS NOT NULL AND dur > 0",
                (itid, child_tag_pattern),
            ).fetchone()
            parent_depth_row = tconn.execute(
                "SELECT AVG(depth) FROM callstack WHERE callid = ? AND name LIKE ? AND dur IS NOT NULL AND dur > 0",
                (itid, parent_tag_pattern),
            ).fetchone()
            child_avg_depth = child_depth_row[0] if child_depth_row and child_depth_row[0] is not None else None
            parent_avg_depth = parent_depth_row[0] if parent_depth_row and parent_depth_row[0] is not None else None
            if child_avg_depth is not None and parent_avg_depth is not None and child_avg_depth < parent_avg_depth:
                # Declared child is actually at a shallower depth than declared parent → swap
                _svr_log.info(
                    "auto_swap_parent_child",
                    original_child=child_tag_pattern, original_parent=parent_tag_pattern,
                    child_avg_depth=child_avg_depth, parent_avg_depth=parent_avg_depth,
                    action="swapped",
                )
                child_tag_pattern, parent_tag_pattern = parent_tag_pattern, child_tag_pattern
                # Also swap id patterns and labels if provided
                child_id_pattern, parent_id_pattern = parent_id_pattern, child_id_pattern
                id_label, parent_id_label = parent_id_label, id_label

        pconn = sqlite3.connect(hiperf_sqlite_path) if use_hiperf else tconn

        # Query sched_slice + perf_sample
        sched_rows = tconn.execute(
            "SELECT ts, dur FROM sched_slice WHERE itid = ? ORDER BY ts", (itid,)
        ).fetchall()
        perf_rows = pconn.execute(
            "SELECT timestamp_trace, event_count FROM perf_sample WHERE thread_id = ? ORDER BY timestamp_trace",
            (main_tid,),
        ).fetchall()
        thread_total_row = pconn.execute(
            "SELECT SUM(event_count) FROM perf_sample WHERE thread_id = ?", (main_tid,)
        ).fetchone()
        thread_total = thread_total_row[0] if thread_total_row and thread_total_row[0] else 0

        # Build result dict
        result: Dict[str, Any] = {
            "trace_file": os.path.basename(sqlite_path).replace(".db", ""),
            "process_name": process_name,
            "pid": pid,
            "thread_name": actual_thread_name,
            "tid": main_tid,
            "thread_total": thread_total,
            "use_hiperf": use_hiperf,
            "query_mode": query_mode,
        }

        if query_mode == "single_tag":
            tag_ctx = query_tag_intervals(PreprocessContext(data=None, params={
                "sqlite_conn": tconn, "itid": itid, "tag_pattern": tag_pattern,
            }))
            intervals = tag_ctx.data["intervals"]
            interval_instr, total_instr = _calc_instructions_for_intervals(
                intervals, sched_rows, perf_rows
            )
            max_entry, avg_entry, min_entry, zero_count, id_fallback, auto_id_pattern, auto_id_label = _compute_sample_entries(
                intervals, interval_instr, id_pattern
            )
            result["tag_count"] = tag_ctx.data["count"]
            result["total_instr"] = total_instr
            result["pct"] = total_instr / thread_total * 100 if thread_total else 0
            result["zero_count"] = zero_count
            result["max_entry"] = max_entry
            result["avg_entry"] = avg_entry
            result["min_entry"] = min_entry
            result["id_fallback"] = id_fallback
            result["auto_id_pattern"] = auto_id_pattern
            result["auto_id_label"] = auto_id_label
            result["tag_pattern"] = tag_pattern

        else:  # child_and_parent
            mapping_ctx = map_child_to_parent(PreprocessContext(data=None, params={
                "sqlite_conn": tconn,
                "itid": itid,
                "child_tag_pattern": child_tag_pattern,
                "parent_tag_pattern": parent_tag_pattern,
                "abnormal_dur_ns": abnormal_dur_ns,
            }))
            parent_intervals = mapping_ctx.data["parent_intervals"]
            parent_interval_instr, parent_total_instr = _calc_instructions_for_intervals(
                parent_intervals, sched_rows, perf_rows
            )
            parent_max, parent_avg, parent_min, parent_zero_count, parent_id_fallback, auto_id_pattern, auto_id_label = _compute_sample_entries(
                parent_intervals, parent_interval_instr, parent_id_pattern
            )
            result["child_tag_count"] = mapping_ctx.data["child_count"]
            result["parent_tag_count"] = mapping_ctx.data["parent_count"]
            result["parent_total_instr"] = parent_total_instr
            result["parent_pct"] = parent_total_instr / thread_total * 100 if thread_total else 0
            result["parent_mapped_count"] = mapping_ctx.data["mapped_count"]
            result["abnormal_count"] = mapping_ctx.data["abnormal_count"]
            result["parent_zero_count"] = parent_zero_count
            result["parent_max_entry"] = parent_max
            result["parent_avg_entry"] = parent_avg
            result["parent_min_entry"] = parent_min
            result["parent_id_fallback"] = parent_id_fallback
            result["parent_auto_id_pattern"] = auto_id_pattern
            result["parent_auto_id_label"] = auto_id_label
            result["child_tag_pattern"] = child_tag_pattern
            result["parent_tag_pattern"] = parent_tag_pattern

        # Generate markdown
        md_params = {
            "query_mode": query_mode,
            "tag_pattern": tag_pattern,
            "id_pattern": id_pattern,
            "id_label": id_label,
            "child_tag_pattern": child_tag_pattern,
            "parent_tag_pattern": parent_tag_pattern,
            "child_id_pattern": child_id_pattern,
            "parent_id_pattern": parent_id_pattern,
            "parent_id_label": parent_id_label,
            "process_name": process_name,
        }
        md_ctx = format_tag_instruction_markdown(PreprocessContext(data=None, params={
            "results": [result],
            "params": md_params,
        }))
        result["markdown"] = md_ctx.data["markdown"]

        return _json_dumps(result)

    except Exception as exc:
        _svr_log.error("mcp_tool_error", tool="analyze_tag_instructions", error=str(exc))
        return _json_dumps({"error": str(exc)})
    finally:
        if tconn:
            tconn.close()
        if pconn and use_hiperf:
            pconn.close()


@mcp.tool()
def generate_tag_instruction_report(
    results_json: str | list = Field(..., description="analyze_tag_instructions 的 iterate 结果（JSON 字符串或将被序列化的 list）"),
    query_mode: str = Field("single_tag", description="查询模式: single_tag / child_and_parent"),
    tag_pattern: str | None = Field(None, description="单标签 LIKE 模式"),
    id_pattern: str | None = Field(None, description="单标签标识符提取正则"),
    id_label: str | None = Field(None, description="单标签标识符列标题(如 vsyncId),不提供则从id_pattern推导或回退到绝对时间(s)"),
    child_tag_pattern: str | None = Field(None, description="子标签 LIKE 模式"),
    parent_tag_pattern: str | None = Field(None, description="父标签 LIKE 模式"),
    child_id_pattern: str | None = Field(None, description="子标签标识符提取正则（仅用于报告展示，不影响计算）"),
    parent_id_pattern: str | None = Field(None, description="父标签标识符提取正则"),
    parent_id_label: str | None = Field(None, description="父标签标识符列标题(如 vsyncId),不提供则从parent_id_pattern推导或回退到绝对时间(s)"),
) -> str:
    """将多个 trace 的 analyze_tag_instructions 结果聚合为完整的 Markdown 报告。

    复用 format_tag_instruction_markdown 算子生成详情表和汇总表，
    替代 LLM reasoning，确保输出格式确定且与 calc_tag_instructions_v2.py 一致。
    """
    from core.preprocess import PreprocessContext
    from core.preprocess.tag_instruction_ops import format_tag_instruction_markdown
    from pydantic.fields import FieldInfo as _FI

    if isinstance(query_mode, _FI):
        query_mode = query_mode.default
    if isinstance(tag_pattern, _FI):
        tag_pattern = tag_pattern.default
    if isinstance(id_pattern, _FI):
        id_pattern = id_pattern.default
    if isinstance(child_tag_pattern, _FI):
        child_tag_pattern = child_tag_pattern.default
    if isinstance(parent_tag_pattern, _FI):
        parent_tag_pattern = parent_tag_pattern.default
    if isinstance(child_id_pattern, _FI):
        child_id_pattern = child_id_pattern.default
    if isinstance(parent_id_pattern, _FI):
        parent_id_pattern = parent_id_pattern.default
    if isinstance(id_label, _FI):
        id_label = id_label.default
    if isinstance(parent_id_label, _FI):
        parent_id_label = parent_id_label.default

    try:
        # results_json may be a list (from _resolve_expr) or a JSON string
        if isinstance(results_json, list):
            all_results = results_json
        elif isinstance(results_json, str):
            all_results = json.loads(results_json)
        else:
            return _json_dumps({"error": "results_json must be a list or JSON string"})

        if not isinstance(all_results, list):
            return _json_dumps({"error": "results_json must be a JSON array"})

        # Filter out error results and _hiperf.db results
        valid_results = []
        for r in all_results:
            if isinstance(r, dict) and "error" not in r:
                trace_file = r.get("trace_file", "")
                if "_hiperf" not in trace_file:
                    valid_results.append(r)

        # Auto-infer query_mode from result data when params don't override
        # Prefer result data (source of truth after auto-swap) over caller parameters
        if valid_results and any("child_tag_count" in r for r in valid_results):
            query_mode = "child_and_parent"
        elif child_tag_pattern and parent_tag_pattern:
            query_mode = "child_and_parent"
        elif tag_pattern:
            query_mode = "single_tag"
        # else: keep default "single_tag"

        # Sort by trace_file
        valid_results.sort(key=lambda r: r.get("trace_file", ""))

        # Build params for format_tag_instruction_markdown
        # Extract process_name and tag patterns from first valid result
        # (prefer data from analyze_tag_instructions results over external params,
        #  because results contain the actual patterns after auto-swap)
        process_name = ""
        r0 = valid_results[0] if valid_results else {}
        process_name = r0.get("process_name", "")

        # Auto-extract tag patterns from result data (source of truth after auto-swap)
        data_tag_pattern = r0.get("tag_pattern") or tag_pattern
        data_child_tag_pattern = r0.get("child_tag_pattern") or child_tag_pattern
        data_parent_tag_pattern = r0.get("parent_tag_pattern") or parent_tag_pattern

        md_params = {
            "query_mode": query_mode or "child_and_parent",
            "tag_pattern": data_tag_pattern,
            "id_pattern": id_pattern,
            "id_label": id_label,
            "child_tag_pattern": data_child_tag_pattern,
            "parent_tag_pattern": data_parent_tag_pattern,
            "child_id_pattern": child_id_pattern,
            "parent_id_pattern": parent_id_pattern,
            "parent_id_label": parent_id_label,
            "process_name": process_name,
        }

        md_ctx = format_tag_instruction_markdown(PreprocessContext(data=None, params={
            "results": valid_results,
            "params": md_params,
        }))

        return _json_dumps({
            "markdown": md_ctx.data["markdown"],
            "trace_count": len(valid_results),
            "skipped_count": len(all_results) - len(valid_results),
        })

    except Exception as exc:
        return _json_dumps({"error": str(exc)})


@mcp.tool()
def compare_process_instructions(
    baseline_sqlite_path: str = Field(description="基线版本 trace.db 路径"),
    current_sqlite_path: str = Field(description="当前版本 trace.db 路径"),
    baseline_start_ms: float | None = None,
    baseline_end_ms: float | None = None,
    current_start_ms: float | None = None,
    current_end_ms: float | None = None,
    regression_threshold_pct: float = 5.0,
) -> str:
    """一键对比基线与当前版本的逐步骤进程指令数，生成 CSV 文件。

    内聚完成步骤配对、进程查询、劣化计算、线程拆解、CSV 生成，零 LLM 往返。
    生成 2 个 CSV 文件（进程级 + 线程级），写入 trace.db 同目录。

    返回 JSON:
    {
      "process_csv_path": str,
      "thread_csv_path": str,
      "step_count": int,
      "regressed_process_count": int,
      "summary": [{case_id, step_name, process_count, regressed_count}]
    }
    """
    from core.preprocess import PreprocessContext
    from core.preprocess.perf_compare_ops import (
        build_perf_step_comparison,
        format_comparison_csv,
    )

    # FieldInfo 默认值处理（与 query_metrics 一致）
    from pydantic.fields import FieldInfo as _FI
    if isinstance(baseline_start_ms, _FI):
        baseline_start_ms = baseline_start_ms.default
    if isinstance(baseline_end_ms, _FI):
        baseline_end_ms = baseline_end_ms.default
    if isinstance(current_start_ms, _FI):
        current_start_ms = current_start_ms.default
    if isinstance(current_end_ms, _FI):
        current_end_ms = current_end_ms.default

    # 时间范围自动推断
    if baseline_start_ms is None or baseline_end_ms is None:
        baseline_start_ms, baseline_end_ms = _detect_trace_time_range(baseline_sqlite_path)
    if current_start_ms is None or current_end_ms is None:
        current_start_ms, current_end_ms = _detect_trace_time_range(current_sqlite_path)

    # 算子 1: 计算核心
    ctx1 = PreprocessContext(
        data=None,
        params={
            "baseline_sqlite_path": baseline_sqlite_path,
            "current_sqlite_path": current_sqlite_path,
            "baseline_start_ms": baseline_start_ms,
            "baseline_end_ms": baseline_end_ms,
            "current_start_ms": current_start_ms,
            "current_end_ms": current_end_ms,
            "regression_threshold_pct": regression_threshold_pct,
            "engine": ENGINE,
        },
    )
    ctx1 = build_perf_step_comparison(ctx1)

    if "error" in ctx1.data:
        return _json_dumps(ctx1.data)

    # 算子 2: 文件生成
    db_dir = str(Path(baseline_sqlite_path).parent)
    ctx2 = PreprocessContext(
        data=None,
        params={
            "process_rows": ctx1.data["process_rows"],
            "thread_rows": ctx1.data["thread_rows"],
            "output_dir": db_dir,
        },
    )
    ctx2 = format_comparison_csv(ctx2)

    # 合并结果
    result = {
        "process_csv_path": ctx2.data["process_csv_path"],
        "thread_csv_path": ctx2.data["thread_csv_path"],
        "step_count": len([sq for sq in ctx1.data["step_queries"] if sq["paired"]]),
        "regressed_process_count": len(ctx1.data["drill_down_queries"]),
        "summary": ctx1.data["summary"],
    }
    return _json_dumps(result)


@mcp.tool()
def get_skill_catalog(
    format: str = Field(
        default="json",
        description="输出格式,默认 'json'。可选 'compact' 仅返回 skill_id 列表",
    ),
) -> str:
    """列出所有 Skill + 优先级路由表，供 Agent 做意图匹配。

    参数:
      format: 'json'(默认,完整输出) 或 'compact'(仅 skill_id 列表)

    返回 JSON:
    {
      "skills": [                            // Skill 列表
        {
          "skill_id": str,                   // Skill 唯一标识
          "name": str,                       // Skill 名称
          "triggers": [str],                 // 触发词列表
          "priority": str,                   // high / low
          "description": str,                // 描述
          "input_params": [                  // 可传入的参数摘要
            {
              "name": str,
              "type": str,
              "required": bool,
              "description": str             // 仅 required=false 时包含
            }
          ]
        }
      ],
      "routing_table": {                     // 路由表
        "<trigger_word>": "<skill_id>"
      }
    }
    """
    if format == "compact":
        return _json_dumps({"skill_ids": [s["skill_id"] for s in _list_skills_payload(REGISTRY)]})
    return _json_dumps({
        "skills": _list_skills_payload(REGISTRY),
        "routing_table": _routing_table_payload(REGISTRY),
    })


@mcp.tool()
def get_skill(
    skill_id: str = Field(..., description="Skill 标识符"),
) -> str:
    """返回指定 Skill 的完整工作流定义（steps / rules / 默认参数）。

    返回 JSON：
    {
      "skill_id": str,
      "name": str,
      "description": str,
      "trigger_condition": str,
      "priority": str,
      "input_params": [{"name": str, "type": str, "required": bool, "description": str, "example"?: Any, "enum"?: list, "default"?: Any}],
      "steps": [                             // 工作流步骤
        {
          "step": int,
          "tool": str,                       // 工具名，null 表示 LLM 推理
          "action": str,                     // llm_decision / llm_reasoning
          "args": object,                    // 步骤参数
          "output": str,                     // 输出变量名
          "instruction": str                 // LLM 指令
        }
      ],
      "rules": [str]                         // Skill 规则
    }
    """
    payload = _get_skill_payload(REGISTRY, skill_id)
    return _json_dumps(payload)


@mcp.tool()
def run_skill(
    skill_id: str = Field(..., description="Skill 标识符，优先使用此工具而非手动调用 analyze_launch_phases/analyze_frame_drops 等单独工具"),
    trace_path_or_dir: str = Field(..., description="trace 文件路径或包含 trace 文件的目录路径"),
    step: int | None = None,
    iterate_index: int | None = None,
    auto_continue: bool = True,
    overrides: Dict[str, Any] | None = None,
    resume: str | None = None,
    input_params: Dict[str, Any] = Field(
        ...,
        description=(
            "从用户输入中提取的参数（必填，无参数可提取时传 {}）。"
            "调用流程：1) get_skill_catalog 返回各 skill 的 input_params 摘要；"
            "2) 根据用户描述提取参数值；"
            "3) 将提取的参数作为 input_params 传入，无匹配参数则传 {}。"
            "package_name 提取规则：优先使用用户说的中文名（如：微信→\"微信\"，抖音→\"抖音\"），"
            "不要自行翻译为 Android 包名（com.tencent.mm 等），框架内部会自动解析映射。"
            "示例：用户说'微信滑动卡顿'→input_params={\"package_name\": \"微信\"}；"
            "用户说'短信启动1秒'→input_params={\"package_name\": \"短信\", \"launch_duration\": 1000}；"
            "用户说'分析启动性能'（未提应用名）→input_params={}"
        ),
    ),
) -> str:
    """执行 Skill 工作流，支持断点控制 和 iterate 逐项执行。

    auto_continue=True 时:
      - 非 LLM action step: 自动执行到下一步
      - 遇到 LLM action step: 暂停执行，返回完整上下文，等待 Agent 推理

    auto_continue=False 时:
      - 每执行一个 step 就暂停，返回中间结果，Agent 明确控制节奏

    overrides: 覆盖 YAML 中定义的 step-level 参数（如 indicator_params）
      例: overrides={"indicator_params": {"temperature": {"tid": 25448}}}

    input_params: 从用户输入中提取的参数（必填，无参数可提取时传 {}）。调用流程：
      1) get_skill_catalog 返回各 skill 的 input_params 摘要，查看有哪些参数可传；
      2) 根据用户描述提取参数值；package_name 优先使用中文（如：微信→"微信"），不要翻译为 Android 包名；
      3) 将提取的参数作为 input_params 传入，无匹配参数则传 {}。
      示例：用户说"微信滑动卡顿"→input_params={"package_name": "微信"}；
      用户说"短信启动1秒"→input_params={"package_name": "短信", "launch_duration": 1000}；
      用户说"分析启动性能"（未提应用名）→input_params={}

    返回 JSON:
    {
      "executed_steps": [1, 2, 3],
      "state": { step1: {output: {...}}, ... },
      "next_step": { number: 5, is_llm_action: false, iterate_remaining: 4 },
      "current_result": {...},
      "waiting_for_agent": true,
      "is_complete": false,
      "llm_context": {...}   // 仅在 LLM action 步骤暂停时返回
    }
    """
    # 修复: @mcp.tool() 直接 Python 调用时，Field() 默认值是 FieldInfo 对象而非实际值
    from pydantic.fields import FieldInfo as _FI
    if isinstance(input_params, _FI):
        input_params = {}
    if isinstance(overrides, _FI):
        overrides = None
    if isinstance(step, _FI):
        step = None
    if isinstance(iterate_index, _FI):
        iterate_index = None
    if isinstance(resume, _FI):
        resume = None

    result = EXECUTOR.run(
        skill_id=skill_id,
        trace_path_or_dir=trace_path_or_dir,
        step=step,
        iterate_index=iterate_index,
        auto_continue=True,
        overrides=overrides,
        resume=resume,
        input_params=input_params,
    )
    return _json_dumps(result)


@mcp.tool()
def query_skill_state(
    session_id: str = Field(..., description="run_skill 返回的 session_id"),
) -> str:
    """查询指定 session 的 Skill 执行状态。

    每次 run_skill 调用返回一个新的 session_id，
    用于在 auto_continue=False 模式下跨多次调用追踪执行状态。

    返回 JSON:
    {
      "session_id": str,
      "skill_id": str,
      "state": { step1: {...}, step2: {...}, ... },
      "executed_steps": [1, 2, 3],
    }
    若 session 不存在返回 error。
    """
    from core.skill_executor import query_skill_state as _query_state
    result = _query_state(session_id)
    return _json_dumps(result)


@mcp.tool()
def clear_skill_state(
    session_id: str = Field(..., description="要清除的 session_id"),
) -> str:
    """清除指定 session 的 Skill 执行状态。"""
    from core.skill_executor import clear_skill_state as _clear_state
    _clear_state(session_id)
    return _json_dumps({"session_id": session_id, "status": "cleared"})


# ---------------------------------------------------------------------------
# 注册 SkillExecutor 可调用的工具（在所有 @mcp.tool() 定义之后）
# ---------------------------------------------------------------------------

register_executor_tools(
    get_hitrace_path=get_hitrace_path,
    convert_hitrace_to_sqlite=convert_hitrace_to_sqlite,
    convert_hiperf_data=convert_hiperf_data,
    analyze_frame_drops=analyze_frame_drops,
    analyze_launch_phases=analyze_launch_phases,
    analyze_parallelism_opportunity_intervals=analyze_parallelism_opportunity_intervals,
    identify_chip_model=identify_chip_model,
    detect_rendering_pipeline=detect_rendering_pipeline,
    query_metrics=query_metrics,
    compare_process_instructions=compare_process_instructions,
    analyze_tag_instructions=analyze_tag_instructions,
    generate_tag_instruction_report=generate_tag_instruction_report,
    list_indicators=list_indicators,
)


# ---------------------------------------------------------------------------
# 热加载（开发期可选）
# ---------------------------------------------------------------------------

def _start_hot_reload(config_dir: Path) -> None:
    """监听 config/ 目录变化，自动重载 Registry。生产环境建议关闭。"""
    try:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer
    except ImportError:
        logger.warning("watchdog 未安装，跳过热加载")
        return

    class _Reloader(FileSystemEventHandler):
        def on_modified(self, event):  # type: ignore[override]
            if not str(event.src_path).endswith(".yaml"):
                return
            logger.info("[hot-reload] %s", event.src_path)
            try:
                REGISTRY.reload()
                logger.info("[hot-reload] registry reloaded")
            except Exception as e:  # noqa: BLE001
                logger.error("[hot-reload] FAILED: %s", e)

    observer = Observer()
    observer.schedule(_Reloader(), path=str(config_dir), recursive=True)
    observer.daemon = True
    observer.start()


# ---------------------------------------------------------------------------
# 启动入口
# ---------------------------------------------------------------------------

def main() -> None:
    """命令行入口（pyproject.toml 中注册为 perf-mcp-server）。"""
    import os

    if os.environ.get("PERF_MCP_HOT_RELOAD") == "1":
        _start_hot_reload(CONFIG_DIR)

    logger.info(
        "perf-mcp-server boot: %d indicators, %d skills",
        len(REGISTRY.indicators),
        len(REGISTRY.skills),
    )
    mcp.run()


if __name__ == "__main__":
    main()
