# perf-mcp-server

性能分析 MCP Server 与声明式 Skill 系统。

通过 **17 个 MCP Tool** 暴露性能指标查询、工作流编排与元数据发现能力，任何 MCP Client Agent（Claude、Cursor、Cline 等）即连即用，**无需写代码**即可做根因分析。覆盖 HiTrace / systrace 与 hiperf (.data) 两条采集链路，支持 62 个原子指标 + 6 个组合指标。

---

## 安装与运行

```bash
pip install -r requirements.txt
pip install -e .[dev]                  # 开发环境（含 pytest 全家桶）

PYTHONIOENCODING=utf-8 python server.py              # 生产模式
PERF_MCP_HOT_RELOAD=1 python server.py               # 开发模式（YAML 热加载）
```

---

## 暴露的 Tool（17 个）

所有指标通过 `query_metrics` 统一查询，不拆成多个 Tool。

| Tool | 类型 | 作用 |
|------|------|------|
| `get_hitrace_path` | 原子 | 获取 trace 文件路径（支持目录扫描） |
| `convert_hitrace_to_sqlite` | 原子 | HiTrace / systrace → SQLite，返回 trace 时间范围 |
| `convert_hiperf_data` | 原子 | hiperf .data → SQLite（TraceStreamer + BRBE/SPE extender） |
| `analyze_frame_drops` | 原子 | 识别丢帧区间 + thread_queries 供下钻 |
| `analyze_launch_phases` | 原子 | 拆解启动阶段 + 瓶颈定位 |
| `analyze_parallelism_opportunity_intervals` | skill-only | 并行化机会点区间识别（启动推导 + callstack span 拆解，仅供 skill 调用） |
| `identify_chip_model` | 原子 | 从 trace 数据识别芯片型号与 CPU 拓扑 |
| `detect_rendering_pipeline` | 原子 | 检测渲染管线类型（5 管线 / 子变体 / 4-Feature 分型） |
| `list_indicators` | 元数据 | 发现指标目录（含 sql_params / result_schema） |
| `query_metrics` | **统一查询** | 批量查 atomic / group 指标，支持动态参数与大数据采样 |
| `analyze_tag_instructions` / `generate_tag_instruction_report` | 原子 | 标签指令数统计与报告 |
| `compare_process_instructions` | 原子 | 逐步骤进程指令数对比 |
| `get_skill_catalog` / `get_skill` | 元数据 | Skill 发现与工作流定义获取 |
| `run_skill` | **执行** | 执行 Skill 工作流（断点续执 / iterate / overrides） |
| `query_skill_state` / `clear_skill_state` | 状态 | Skill 执行状态查询与清除 |

### query_metrics 调用示例

```json
{
  "sqlite_path": "/tmp/trace.db",
  "start_ms": 1000,
  "end_ms": 6000,
  "indicators": ["cpu_freq", "frame_ts"],
  "indicator_params": {
    "cpu_freq": { "cluster": "big" },
    "frame_ts": { "summary_only": true }
  },
  "max_rows_per_indicator": 500
}
```

---

## 渲染管线检测（5 个管线）

`detect_rendering_pipeline` 基于 `config/pipelines/` 下的 YAML 信号定义，动态生成 SQL 打分排名。

| pipeline_id | display_name | family | 关键信号 |
|-------------|--------------|--------|----------|
| `HARMONY_ARKUI` | HarmonyOS ArkUI | harmony | VSyncGenerator / ReceiveVsync / FlushMessages / MarshRSTransactionData |
| `HARMONY_FLUTTER` | Flutter (HarmonyOS) | flutter | `*raster*` 线程 / `*flutter*VsyncProcessCallback*` / `*GPURasterizer::Draw*` |
| `HARMONY_KMP` | Kotlin Multiplatform | harmony | VSyncGenerator / `*Recomposer*` / `*RenderView*onDraw*` |
| `HARMONY_RN` | React Native | harmony | VSyncGenerator / `*RNView*` / `*RNNode*` |
| `HARMONY_WEB_PIPELINE` | Web (HarmonyOS) | webview | `VizCompositor*` / `*OnVSyncImpl*` / `*IssueBeginFrame*` |

返回结构：主管线 + 候选列表 + 子变体（webview_mode / buffer_mode / flutter_engine / game_engine）+ 4-Feature 分型 + 采集建议。

---

## hiperf 采样分析

| 组件 | 用途 |
|------|------|
| `convert_hiperf_data` Tool | .data → SQLite（TraceStreamer 解析 callchain + hiperf_extender 扩展 BRBE/SPE 表） |
| `brbe_sample` 表 | BRBE 分支记录（含符号列，extender 一次性填充） |
| `spe_sample` 表 | SPE 内存采样 |
| `hiperf_brbe_inst` 指标 | BB 级 IPC |
| `hiperf_brbe_func` 指标 | 函数级 IPC |
| `hiperf_branch_mispredict` 指标 | 分支预测失败率 |
| `hiperf_spe_miss` 指标 | SPE 内存延迟 |
| `hiperf_sampling_analysis` Skill | 编排：解析 → 查指标 → LLM 总结 |

**符号解析在 extender 阶段一次性完成**（GOLDEN_RULES 规则 24），指标 SQL 零 JOIN。

---

## 项目结构

```
perf-mcp-server/
├── server.py                     # MCP Server 入口（17 个 Tool）
├── pyproject.toml
├── requirements.txt
│
├── core/                         # 核心引擎（部分文件禁止直接修改，见 CLAUDE.md）
│   ├── registry.py               # YAML 加载 + ConfigRegistry
│   ├── query_engine.py           # SQL 渲染、参数合并、大数据采样、预处理调度
│   ├── skill_executor.py         # Skill 工作流执行器（断点控制、iterate、表达式解析）
│   ├── skill_router.py           # Skill 路由与发现
│   ├── rendering_pipeline.py     # 渲染管线检测（YAML 驱动打分排名）
│   ├── rendering/                # 渲染子系统（models）
│   ├── validators.py             # YAML Schema 校验
│   ├── observability.py          # 结构化日志（JSON Lines，按 session_id 串联）
│   ├── extensions/               # DB 扩展器（page_cache_io 表注入）
│   └── preprocess/               # 预处理算子（新增算子需补充单测）
│       ├── base.py               # PreprocessContext + @register_operator + run_pipeline
│       ├── frame_ops.py          # build_render_frames（渲染帧链路构建）
│       ├── jank_ops.py           # build_drop_ranges / build_thread_queries
│       ├── launch_ops.py         # 启动阶段拆解算子
│       ├── flamegraph_ops.py     # 火焰图相关算子
│       ├── marker_ops.py         # Trace Marker 树构建与聚合
│       ├── sched_ops.py          # 调度延迟与运行时算子
│       ├── io_ops.py             # IO 延迟与块大小算子
│       ├── brbe_ops.py           # BRBE 分支记录算子（BB pairing、IPC）
│       └── ...
│
├── config/
│   ├── indicators/               # 原子指标（62 个）+ 组合指标（6 个），按域分 15 个 category
│   │   ├── cpu/       freq / load / state_freq / throttle
│   │   ├── sched/     latency / runtime / runtime_agg / parallelism / thread_sched
│   │   ├── rendering/ frame_ts / frame_summary / jank_intervals / gpu_pipeline_analysis / ...
│   │   ├── io/        io_block / io_latency / io_page_cache / io_priority / io_size
│   │   ├── marker/    animation_interval / perf_step_segments / so_load_stats / trace_hotpath
│   │   ├── startup/   phases
│   │   ├── game/      game_experience / game_launch_phases / game_thread_sched
│   │   ├── gpu/       freq
│   │   ├── process/   profile
│   │   ├── memory/    heap
│   │   ├── sleep/     thread_sleep_summary
│   │   ├── uninterruptible/  uninterruptible_dstate
│   │   ├── network/   throughput
│   │   ├── sampling/  hiperf/ (brbe_inst / brbe_func / branch_mispredict / spe_miss / hot_function / thread_hotpath)  pmu/ (pmu_summary / pmu_timeline)
│   │   └── groups/    jank / launch / sched / memory / game_launch
│   ├── skills/                   # 工作流定义（15 个 Skill）
│   │   ├── ad_hoc_exploration.yaml
│   │   ├── frame_drop.yaml
│   │   ├── launch_perf.yaml / game_launch.yaml
│   │   ├── sched_analysis.yaml / game_sched.yaml
│   │   ├── freq_distribution.yaml / load_compare.yaml
│   │   ├── game_performance.yaml / io_analysis.yaml
│   │   ├── hiperf_sampling_analysis.yaml
│   │   ├── detect_rendering_pipeline.yaml
│   │   ├── parallelism_analysis.yaml
│   │   ├── tag_instruction_analysis.yaml
│   │   └── perf_process_instructions.yaml
│   └── pipelines/                # 渲染管线 YAML（5 个 + index）
│       ├── harmony_arkui_render.skill.yaml
│       ├── harmony_flutter.skill.yaml
│       ├── harmony_kmp_render.skill.yaml
│       ├── harmony_rn_render.skill.yaml
│       ├── harmony_web_pipeline.skill.yaml
│       └── index.yaml
│
├── docs/
│   ├── architecture.md                # 系统架构设计（权威来源）
│   ├── skill-execution-framework-design.md  # Skill 执行框架（已实现）
│   ├── GOLDEN_RULES.md                  # 34 条编码黄金规则
│   ├── MCP_CLIENT_SETUP.md              # 各 MCP Client 配置指南
│   ├── frame_drop_analysis_design.md   # 丢帧分析设计
│   ├── frame_rendering_design.md       # 渲染链路设计
│   ├── game_jank_design.md             # 游戏卡顿分析设计
│   ├── observability-design.md          # 可观测性设计
│   └── sql_schema.md                    # SQLite 表结构说明
│
├── tests/                        # pytest 测试套件
│   ├── fixtures/                # 黄金样本（HiTrace / hiperf）
│   ├── spy/                      # Spy Server 参数血缘校验
│   └── test_*.py
│
├── scripts/
│   ├── validate_yaml.py          # YAML 静态校验
│   ├── scaffold_indicator.py     # 指标脚手架生成
│   ├── run_local.py              # 本地调试查询
│   └── check-consistency.sh      # 指标完整性检查
│
└── utils/                       # 工具函数（进程名映射等）
```

---

## 核心设计

1. **协议级跨平台** — Skill 定义内嵌于 MCP Server，任何 MCP Client Agent 即连即用，无需本地代码仓库。
2. **声明式配置** — 指标（SQL + 参数 + schema）与工作流（steps + rules）全部 YAML 化。开发期 `PERF_MCP_HOT_RELOAD=1` 自动重载。
3. **原子暴露（仅 17 个 Tool）** — 60+ 指标不拆成几十个 Tool，通过 `query_metrics` 统一查询。Agent 先 `list_indicators` 发现元信息，再按需查询。
4. **大数据强制管控** — QueryEngine 自动判断时序 vs 非时序：时序分桶聚合、非时序 Top N 截断、标量 object 完整透传。
5. **预处理管线** — 复杂分析通过 `preprocess.pipeline` 声明多阶段算子，纯函数 `(ctx) → ctx` 可复用：
   ```yaml
   preprocess:
     pipeline:
       - op: build_render_frames
       - op: build_drop_ranges
       - op: build_thread_queries
   ```
6. **Skill 执行框架** — 支持 iterate 循环、LLM action 断点、参数血缘注入、断点续执：
   ```yaml
   steps:
     - step: 1
       tool: query_metrics
       iterate: "{step2.thread_queries}"
     - step: 2
       action: llm_reasoning   # 暂停等待 Agent 推理
   ```
   框架自动处理 `default_indicator_params` 注入、iterate 展开、表达式解析、断点控制、LLM action 暂停。
7. **参数四层合并** — `sql_params.default < group.override_params < agent.indicator_params < base_params`
8. **可观测性** — 所有模块日志统一写入 `logs/observability/{date}/observability.jsonl`（JSON Lines，按 session_id 串联）。**排查问题先查日志**。

---

## 扩展

| 目标 | 做法 |
|------|------|
| 新增指标 | `python scripts/scaffold_indicator.py <category> <name>` → 编辑 YAML → `validate_yaml.py --check-placeholders` |
| 新增算子 | 在 `core/preprocess/<topic>_ops.py` 写 `@register_operator("xxx")` → `__init__.py` 加 import → 补单测 |
| 新增 Skill | 在 `config/skills/<name>.yaml` 写 workflow → `validate_yaml.py config/` → 写 e2e 测试 |
| 新增渲染管线 | 在 `config/pipelines/<name>.skill.yaml` 写信号定义 → 更新 `index.yaml` 注册 |

---

## 校验与测试

```bash
ruff check . --fix                                         # lint
python scripts/validate_yaml.py --check-placeholders config/   # 占位符对齐
python scripts/validate_yaml.py --json config/                 # CI 解析用
pytest tests/ -v --tb=short                                    # 全部测试
pytest tests/spy/ -v                                           # Spy Server 参数血缘
git config core.hooksPath .githooks                            # 启用 pre-commit
```

YAML 校验任意报错 **禁止提交**。

---

## 相关文档

| 文档 | 内容 |
|------|------|
| `docs/architecture.md` | 系统架构设计（权威来源） |
| `docs/GOLDEN_RULES.md` | 34 条编码黄金规则 |
| `docs/skill-execution-framework-design.md` | Skill 执行框架设计（已实现） |
| `docs/MCP_CLIENT_SETUP.md` | 各 MCP Client 配置指南 |
| `docs/frame_drop_analysis_design.md` | 丢帧分析设计 |
| `docs/frame_rendering_design.md` | 渲染链路设计 |
| `docs/game_jank_design.md` | 游戏卡顿分析设计 |
| `docs/observability-design.md` | 可观测性设计 |
| `docs/sql_schema.md` | SQLite 表结构说明 |
| `AGENTS.md` | AI Agent 入口文档（项目导航） |
| `CLAUDE.md` | Claude Code 专用开发约束 |

---

最后更新：2026-07-06
