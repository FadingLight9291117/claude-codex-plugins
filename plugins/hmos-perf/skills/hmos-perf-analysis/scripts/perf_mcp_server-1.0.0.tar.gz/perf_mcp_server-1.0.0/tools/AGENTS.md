<!-- Parent: ../AGENTS.md -->
<!-- Generated: 2026-06-11 -->

# tools -- External Tool Binaries

## Purpose
Bundled native binaries for the TraceStreamer tool used by `convert_hitrace_to_sqlite` to parse HiTrace/systrace files into SQLite databases. Includes platform-specific binaries for macOS, Linux, and Windows, plus macOS C++ runtime libraries.

## Directory Structure

| Path | Description |
|------|-------------|
| `trace_streamer_binary/trace_streamer_mac` | TraceStreamer binary for macOS (23 MB) |
| `trace_streamer_binary/trace_streamer_linux` | TraceStreamer binary for Linux (13 MB) |
| `trace_streamer_binary/trace_streamer_windows.exe` | TraceStreamer binary for Windows (17.7 MB) |
| `trace_streamer_binary/config/` | TraceStreamer configuration (config.json) |
| `trace_streamer_binary/lib/` | macOS C++ runtime libraries (libc++, libc++abi with symlinks) |

## For AI Agents

### Working In This Directory
- **Do NOT modify or replace binaries** without human confirmation.
- Binary selection is automatic based on `sys.platform` detection in `server.py` (`_get_trace_streamer_bin()`).
- New platform support requires: platform binary + any needed runtime libraries + config if different.
- The binaries live under `trace_streamer_binary/`, referenced by `server.py` line 120: `Path(__file__).parent / "tools" / "trace_streamer_binary"`.

### Testing Requirements
- Verify `convert_hitrace_to_sqlite` works on each supported platform.
- Test with known-good trace files to confirm correct SQLite output.
- Binary updates require full regression test pass.

### Common Patterns
- Binaries are version-locked with the project -- update them together.
- Runtime libraries (macOS) use symlink chains: `libc++.dylib -> libc++.1.dylib -> libc++.1.0.dylib`.
- Conversion timeout: 5 minutes per trace file.

## Dependencies

### Internal
- `server.py` -- MCP tool `convert_hitrace_to_sqlite` uses these binaries via `_get_trace_streamer_bin()`

### External
- Platform C++ runtime (macOS: bundled; Linux: system libstdc++; Windows: system MSVC runtime)
